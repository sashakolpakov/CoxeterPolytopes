# Conditional manuscript Lean interfaces and their assumptions

18 October 2026. **New sources prepared; compilation pending.** No Lean
process, checker or build was run while writing this register. Root owns
the gated compilation queue. No theorem below is currently promoted by
this document to newly kernel-checked status.

The user explicitly permits published facts and exact script-enumeration
conclusions as conditional hypotheses. Written internal geometry is also
exposed as a remaining interface, rather than disguised as a published
theorem. The files declare no custom axioms, use no proof placeholders,
and do not assume their final dimension or structure conclusions.

**Axiom output is not an assumption inventory.** A proof parameter does
not appear in the output of Lean's axiom printer. Successful compilation
with only standard foundational axioms would certify each implication
with the hypotheses listed here; it would not certify that those
hypotheses have been instantiated for actual hyperbolic polytopes.

## Modules, order and scope

The new [ManuscriptInterfaces.lean](../formal/CoxeterProofs/ManuscriptInterfaces.lean)
imports only the small modules below, never the large generated tables.
It is separate from the old aggregate root, which is unchanged.
Each of the four new per-paper modules also contains its own actual
axiom-printer commands for the key theorems. Compilation alone must not
be called an axiom audit for an older module without such commands.

|Order|Module|Dependencies and main theorem names|
|---|---|---|
|1|CoxeterProofs.ManuscriptDataBounds|Std; sum_le_cap_mul_length, sum_charge_gaps, sum_nonpositive|
|2|CoxeterProofs.CompactArithmetic20|Existing CompactHVector; new paired_coefficients21_formula; endpoint_surplus21 and no_rank21_weight_model reviewed as source|
|3|CoxeterProofs.ManuscriptCompact20|Previous two; no_rank21_geometry, compact_arithmetic_dimension_at_most20|
|4|CoxeterProofs.ManuscriptFinite57|DataBounds, existing GuardedRank58; no_rank58_charges, finite_volume_dimension_at_most57|
|5|CoxeterProofs.ManuscriptIdeal4|Existing IdealRA4Gap and CertificateBounds; gap/count/decomposition/equality theorems listed below|
|6|CoxeterProofs.ManuscriptRightAngled|DataBounds, existing FiveFaceCarrier and RightAngledDensity; necessary conditions listed below|
|7|CoxeterProofs.ManuscriptInterfaces|Imports modules3–6 and prints the dependencies of selected theorems|

Each module must be compiled in its own serial bounded batch once root
releases the resource gate. From the repository root, the named entrypoint
is the signal-safe runner, for example:

    python3 -B scripts/run_lean_batches_signal_safe_20261018.py CoxeterProofs.ManuscriptIdeal4 --audit-axioms

This is a queued command description, not a record of execution. Keep the
40GiB disk/6GiB memory start gates,8GiB/3GiB abort gates, exclusive lock,
one thread,2048MiB cap, bounded output and cleanup rules in
[AGENTS.md](../AGENTS.md). Do not run an unrestricted aggregate build.
Existing imported objects retain their actual ledger/cache provenance;
source preparation does not newly verify them.

## Compact arithmetic20

Source:
[ManuscriptCompact20.lean](../formal/CoxeterProofs/ManuscriptCompact20.lean).
The arithmetic endpoint is in
[CompactArithmetic20.lean](../formal/CoxeterProofs/CompactArithmetic20.lean).

|Parameter/type|Content actually assumed|Category, real source and status|
|---|---|---|
|Certificate|A positive-denominator encoding of native payments and complete forest offers|Data schema; not yet an import of the saved rational array|
|ScriptChecks.denominatorPositive|The common denominator is positive|Exact arithmetic input|
|ScriptChecks.nativePaid|Every listed native payment is at least one|Admitted script result:1979 faces,102917 common-spectator cases; exact minimum60007431727/60000000000|
|ScriptChecks.forestUpper|Every complete-recurrence offer is at most40|Admitted script result:68 types,729 exact tuples,850 offers; maximum40 atD21; selected numerical support rows alone do not suffice|
|Rank21Geometry.pairedCoefficientLower|Each tail coefficient is at least40 times its multiplicity|Written h-vector pairing and nonnegative masses; the eleven numerical coefficients are separately recomputed by paired_coefficients21_formula|
|Rank21Geometry.vertexCount|The paired h-data encode the actual number of finite vertices|Published h-vector identities plus the written identification with the actual chamber|
|Rank21Geometry.completeForestDomination|Each actual vertex charge is bounded by some complete forest offer|Written finite-forest recurrence/domain bridge, exact hub counts and once-only pool costs|
|Rank21Geometry.coveredFaceIncidence|If all native cases pay, angle double counting gives the stated lower bound|Written actual-face projection, final touching-star coverage, whole-component sealing, persistent triangle baseline, D5 active/inactive and H4 funded transfers, including all physical exceptions|
|PublishedInputs.compactCeiling29|Compact dimension is at most29|Published Vinberg compact theorem|
|PublishedInputs.thirteenFieldsAt21|At21 the actual ground field is among the13 encoded fields|Published field restriction valid from dimension14, with simplest-type/rational isotropy input; never the shorter list valid only from22|
|EarlierInternalProofs.higherBranches|All24 dimension/field branches22–29 are excluded|Earlier internally proved compact21 package, including script coverage and geometry; explicitly not relabeled published|
|EarlierInternalProofs.nongoldenAt21|The12 nongolden branches at21 are excluded|Earlier internally proved single-field reduction; Q(sqrt2,sqrt5) means that exact field, not its golden subfield|
|GoldenGeometryBridge.actualRank21Data|An actual golden rank21 chamber supplies the preceding charge witness|Remaining unformalized actual-polytope bridge|

The theorem derives the global finite-charge sum from the per-offer
bound, uses the550 strict endpoint surplus, excludes the remaining
golden case, and composes all fields. No premise states dimension≤20.
The weaker older branch exclusions are visible inherited results.

Authoritative sources and execution status:
[compact20 proof map](compact_arithmetic20_proof_map.md),
[universal composition](../results/compact_arithmetic20_universal_composition_20261018.md),
[independent exact ledger](../results/fresh_compact21_self_hub_exact40_independent_check_20261018.json),
[single-field reduction](../results/fresh_compact21_single_field_20261016.md),
and [older compact21 map](compact_arithmetic21_proof_map.md).
The exact script results have already passed their separately recorded
replays; this new Lean source has not imported or re-enumerated them.

## Finite-volume57

Source:
[ManuscriptFinite57.lean](../formal/CoxeterProofs/ManuscriptFinite57.lean).

|Parameter/type|Content actually assumed|Category/source|
|---|---|---|
|Certificate.scale and ScriptChecks.scalePositive|One positive common denominator|Arithmetic encoding; construction of the actual rational charges must justify it|
|ScriptChecks.finiteUpper|Every complete finite offer is at most377 after scaling|Admitted exact complete-forest result, including eight lowered and six increasing guarded families|
|ScriptChecks.terminalSurplus|Every listed ideal terminal profile has absolute surplus at least36 after scaling|Admitted exact2552-profile result; positivity and all-family envelopes matter|
|ActualCharges|Finite charges, ideal cost/curvature pairs, deficit|Data schema; its natural-number encoding after denominator clearing/nonnegativity is part of the geometric bridge|
|PublishedIndex.exactDeficit|Deficit equals the exact Khovanskii index expression represented by value|Published exact index interface; the full geometric index is not defined in this file, and merely setting an arbitrary number is not a geometric instantiation|
|WrittenGeometry.finiteDomination|Actual finite forests are dominated by checked offers|Written complete context/domain cover, whole components and retained-output logic|
|WrittenGeometry.idealSurplusDomination|Actual surplus dominates that of a checked terminal profile|Written concentration/product and actual factor-fiber bridge; it does not assert actual cusps equal terminal profiles|
|WrittenGeometry.shapeLower|Index has the377 finite term, actual ideal curvatures and strict4205 correction|Internal two-extrema and shape argument built on published incidence/index identities|
|WrittenGeometry.paymentUpper|Actual face payments bound the deficit from above|Internal simultaneous local rule, triangle≥2, quad≥1, and nonnegative larger-face weights|
|Earlier58Tail.atMost58|The completed higher-dimensional tail gives n≤58|Earlier internally proved result, not a published or final57 axiom|
|Rank58Bridge.chargesAt58|An actual dimension58 chamber supplies these data|Remaining actual-polytope bridge|

The theorem sums the finite offers and ideal surplus, cancels the global
budgets, and contradicts the positive scaled4205. It then removes58
from the older tail. No premise states dimension≤57.
Sources: [finite57 lemma map](finite_volume57_lemma_map.md) and
[final binder report](../results/fresh_d13_context_dimension57_20261018.md).
Published diagram/cusp classifications and index identities remain
separate from all internal output-retention, whole-component,
concentration and higher-tail arguments.

## Ideal RA4 minimum, second value, equality and restricted chains

Source:
[ManuscriptIdeal4.lean](../formal/CoxeterProofs/ManuscriptIdeal4.lean).
Its numerator is volume divided by pi²/3. **It never assumes universal
integrality in24-cell-volume units4pi²/3.** Multiples of four are derived
only from the explicit Oct/D decomposition.

|Parameter/type|Content actually assumed|Category/source|
|---|---|---|
|PublishedMinimum.minimum/minimumUnique/cellNumerator|Numerator≥4, equality only for the24-cell, and its numerator4|Published Kolpakov minimum theorem and normalization|
|GapPartition|Actual selected/rest defect lists, total2W, selected count1+q+s, minimum m, and typed FacetCase|Internal opposite-cusp injection and complete minimum-facet reduction; small3D classifications are explicit published inputs to constructing the case|
|GapGeometry.divisibility/volumeIdentity|W divisible3 and W=3(numerator−4)|Published volume/incidence formula plus internal ridge-defect double counting|
|GapGeometry.selectedFacetPartition|Each noncell supplies the actual partition|Written geometry, not a final gap hypothesis|
|SevenBranchScriptChecks|The cuboctahedral model has six nontriangles and twelve nonsquare cusps|Admitted finite model result from the equality producer and separate checker|
|WrittenEqualityStages.total24/minimum3/sevenFacetInjection|The equality defect list sums24, all entries≥3, and has at least seven entries|Internal antiprism/minimum4/large-minimum reductions and actual opposite-cusp injection|
|WrittenEqualityStages.remainingSevenBranchInjection|IfN7 remains, its actual facet is identified with the checked model and its cusp injection applies|Internal no-positive-triangle rule, exclusion of defect4 using Figure7's matching, and embedded medial recovery; these universal reductions are not established by the model script|
|WrittenEqualityStages.classifyDefectZeroAndThree|Exactly eight positive defects3 yield the Oct/D spectrum|Actual positive-list coverage and published nine-vertex classification/rigidity; octahedral zero defects|
|EqualitySpectrum.spectrumAtNumerator8|High-level equality→Oct/D reduction, when used directly|Still an explicit internal hypothesis until the granular stages above are instantiated; not a published or final double theorem|
|OctDGeometry.zeroRecognition|An all-O member of the stated spectrum is a24-cell|Internal actual-wall propagation/recognition|
|OctDGeometry.positiveCut|A positive Oct/D member admits two actual same-spectrum halves, reducing total D-count by exactly8|Internal closed triangle surface, component injection, cube normals, actual octahedral section, no outside crossing and no finite new vertex|
|OctDGeometry.numeratorAdditive|The actual cut adds volumes|Geometric measure additivity on the constructed halves|
|OctDGeometry.pathRecognition|The derived finite cut tree is a chain|Internal D4 common-neighbor obstruction using the at-most-two-octahedra boundary-facet spectrum|
|OctDGeometry.canonicalTwoCellGluing|Two24-cell halves across an actual cut form the canonical double|Internal facet-symmetry extension/flag-transitivity placement argument|

Useful theorem names:

- gap_from_partition, nonminimum_numerator_at_least8,
  minimum_or_second_gap;
- minimum_four_budget_impossible,
  minimum_at_least_five_forces_four;
- equality_positive_count_seven_or_eight,
  equality_exactly_eight_all_three,
  seven_branch_injection_impossible,
  equality_spectrum_from_stages;
- octD_decomposition_and_counts: strong induction from one-step cuts,
  proving D-count8k, numerator4(k+1), a finite decomposition and a chain;
- equality8_is_two_cell_chain_and_double and two_volume_units_is_double:
  numerator8, or an explicit conversion of two24-cell units, forces
  exactly two leaves and the double;
- minimum_gap_and_equality: the combined conditional logical statement.

The new finite-list proofs genuinely derive N7or8 and, after the N7
injection contradiction, N8 with every defect exactly3. The graph,
Lorentz and topology needed to supply the stage hypotheses are still
written geometry. No direct premise assumes universal decomposition or
the final equality isometry.

Sources: [second-value map](ideal_ra4_second_volume_lemma_map.md),
[equality map](ideal_ra4_structure_reproduce_and_map.md),
[full equality proof](../results/ideal_ra4_second_volume_equality_20261018.md),
and [restricted Oct/D proof](../results/ideal_ra4_octahedral_block_decomposition_research_20261018.md).
The published ten-vertex Figure7 entry is distinct from the internal
cuboctahedral reconstruction and cube/section arguments. The script
checks are local finite support, not a census of four-polytopes.

Attainment of numerator8 is supplied by the independently checked
reflected-double construction, not by these universal implication
theorems alone. The exact f-vector is(42,168,164,38). The corresponding
example/halfspace bridge is not yet a concrete geometric Lean object.

## Right-angled necessary conditions

Source:
[ManuscriptRightAngled.lean](../formal/CoxeterProofs/ManuscriptRightAngled.lean).

|Theorem|Explicit hypotheses and source boundary|
|---|---|
|chain_kappa_nonpositive|m≥1 and the chain f-vector; proves κ≤0 arithmetically|
|ideal5_has_nonchain_kappa|Finite actual facet-kappa list has sum48; uses the existing checked positive-member logic|
|ideal5_excludes_small_three_face_spectrum|The same box/Euler identity, plus the internal Oct/D/A4 spectrum→chain-count bridge; the antiprism exclusion and actual decomposition remain written geometry|
|carrier_excess_fraction_from_transport|The analytic count comparison f−b≤384b and actual carrier cover b≤14E; derives f≤5390E. The178-box script and real reciprocal-pair argument supply the first comparison externally to this Lean proof; actual rows are not asserted integer-valued|
|nine_part_boundary / nine_part_further_support|Actual degree190, cleared Schur bound, boundary partition and true-twin capacity20; derives the exact102344/3125 and39844/3125 counts. The actual opposition graph and universal moment proof remain hypotheses|
|ideal6_necessary_size|The inherited56/170 facet sizes, actual facet/cusp injection and box incidence; reuses the checked227/3859 arithmetic|
|ideal6_sharp_vertex_lower4462|F≥227 and the new cleared reciprocal/actual-incidence inequality2673F≤136V; proves the exact integer lower boundV≥4462|
|ideal6_sharp_rounding_exact|No hypothesis:2673·227=606771 lies strictly above136·4461 and at most136·4462|

Sources: [five-face carrier proof](../results/right_angled_five_face_carrier_20261018.md),
[antiprism exclusion extension](../results/ideal_ra4_square_antiprism_exclusion_extension_research_20261018.md),
[carrier-fraction review](../results/review_right_angled_carrier_excess_fraction_20261018.md),
[actual-support review](../results/review_right_angled_actual_move_support_20261018.md),
and [ideal6 carrier proof](../results/right_angled_ideal6_carrier_propagation_20261018.md).
The newer4462 input is the
[sharp reciprocal transport proof](../results/ideal_ra6_sharp_reciprocal_20261018.md)
and its [independent root review](../results/ideal_ra6_sharp_reciprocal_root_review_20261018.md):
actual cusp transport and reciprocal pairing give a4−F≤136V/99,
and actual4/5-face incidence with the facet minimum gives
27F≤136V/99. These geometric and analytic premises are not proved by
the new integer-rounding theorem. The older3859 theorem is preserved as
an inherited consequence, not presented as the current strongest bound.
The published entirely ideal ceiling6 and mixed ceiling12 remain
unchanged. No local maximum-height inequality has been converted into
a universal unweighted triangle-average bound.

## Status handoff

The files above are conditional source preparations. Root must record
their serial compile results and axiom output before claiming that even
these particular statements are newly Lean-verified. Concrete script
arrays are currently admitted through their typed checks; actual
hyperbolic objects and the listed geometry bridges are not constructed
in Lean. This explicit boundary is the intended user-authorized
conditional verification, not an end-to-end formalization claim.

## Current ideal5/6 successor,19 October2026

`RightAngledElevenVertexCounts` now compiles and passes its separate axiom
audit. Its current37/25,63/211,275/6106 and4/47,15/248 implications replace
none of the historical module scopes above. The [execution map](right_angled_eleven_vertex_counts_verification_20261019.md)
binds its source, compiler and capped dependencies.

The internal premises are the actual large-three-facet bridge, +3
spinor/cusp-defect counts, eleven-vertex carrier equality exclusion,
facet injection and propagation, complete actual face-list realization,
coface incidence and universal reciprocal transport. They are reviewed
written theorems awaiting geometric formalization, separately from the
published3D small-facet classification, general face minima and NK
averages. The final size bounds are derived, not assumed. Existing frame
and scalar scripts have their declared reproducibility scopes and are
not treated as universal geometric enumerations.

## Eight-field compact arithmetic successor,19 October2026

`ArithmeticEightField19` was compiled only after the complete written
consumer proof and independent full-packet review passed. Its separate
seven-theorem axiom audit prints only `propext` and `Quot.sound`; the
paired-coefficient identity is axiom-free. The
[proof map](compact_arithmetic_eight_field19_proof_map_20261019.md)
binds its source and capped execution ledgers.

The actual field must equal one of Q(sqrt3),Q(sqrt6),K9,K11,K15,K16,
K20,K24. The finite enum records this scope; algebraic number fields
are not constructed in Lean. The conclusion is19 only in this scope;
the unrestricted compact arithmetic ceiling remains20.

The earlier internally proved universal20 theorem supplies the higher
tail. The complete earlier charge/forest theorem supplies
`VertexEntry.oldAllowance`, including the exact ten cost36 target
families. The new written actual-triangle and six-row quadrilateral
consumer proof supplies the geometric payment hypotheses. Whole-star
role separation, classification completeness, actual selection of
target factors, and complete vertex/face realization remain explicit
internal geometric premises. The mandatory E8 spectator-only coverage
addendum is included in the written source ledger.

Published external inputs include compact acute simplicity, finite and
affine Coxeter classification, arithmetic cyclic integrality and
strict conjugate positivity, and nonnegative symmetric h-vectors.
The actual h-vector and polygon double-count identifications enter
through `coefficientCoverage`, `completeVertexCount` and
`incidenceLower`. The kernel proves the35-per-vertex upper, strict500
endpoint surplus, contradiction and tail composition. It does not
assume the desired19 conclusion, or certify the written geometric
interfaces merely by compiling them. No new enumeration result is
assumed in this rank20 step.

## Mixed right-angled ceiling11,19 October2026

The complete new written proof and independent packet review pass;
the small exact positive-part certificate passed generation and a
separate replay. Only afterwards was `RightAngledMixed11` compiled
and separately audited. Its six named theorems print only propext
and Quot.sound; exact_comparison is axiom-free. No sorryAx occurs.
The [proof/reproduction map](right_angled_dimension11_proof_map_20261019.md)
binds the source and all execution records.

Published inputs: Dufour's ceiling12, the82-facet lower bound in
dimension8, standard acute/link/face geometry and simple truncation
with Dehn--Sommerville. The compact4 and entirely ideal6 bounds give
the corresponding all-right-angled corollary. New and inherited
internal geometry: actual P3/all-wall recognition and invariance,
Q8 attachment, exceptional-incidence bounds, all formal-triple ratio
normalization, moments, nonnegative deletion and reciprocal pairing.

`Counts12` exposes the strict weighted face row, coface/Euler
identity, exact excess/defect identities, nonnegative excess and both
exceptional-incidence comparisons. The kernel derives the complete
polygon coupling and strict lower184460/1619 from these interfaces.
`Data12.positivePartTransport` is the cleared upper1420561/12500
supplied by the written real-valued majorant/moment/opposition proof.
The kernel does not treat actual ratios or row sums as integer-valued.
It assumes that aggregate analytic comparison explicitly, then proves
the contradiction and dimension11 tail composition.

The Fraction script independently expands the primitive polynomial,
all220 subset monomials through degree four, all17 Bernstein entries
and the final constants. Its output supports the written full-interval
majorant proof; it neither enumerates polytopes nor proves actual
Lorentz geometry. This is conditional final-count verification,
not end-to-end Lean verification of the manuscript.

## Current mixed right-angled ceiling ten

The new [current theorem](../results/right_angled_mixed_dimension10_20261020.md)
supersedes the preceding ceiling eleven. Its mathematical proof, all
subset-size contracts and finite exact certificates passed full written
review before the final `RightAngledMixed10` compilation. The separate
eight-theorem audit lists only propext and Quot.sound, no sorryAx;
the exact integer comparison is axiom-free. It imports only Std.

`Counts11` exposes the actual strict weighted row, coface/Euler and
excess/defect identities, exceptional upper, signed balance lower,
noncanonical all-ideal-edge corner upper and summed local corner balance.
The kernel derives the strengthened ordinary lower and the final
contradiction. `Data11.subsetTransport` is the explicit cleared aggregate
real-analytic premise8B<=336f+3H. The real frame inequalities, exact
script positivity and the geometric interpretation of actual ratios
are supplied by the written proof, not formalized in this module.

The dimension tail assumes the standard eleven-face interpretation and
the published compact4 and entirely ideal6 bounds. The weighted row
uses the published82-facet minimum in dimension8 and standard
truncation/DS. Dufour12 and the old internal ceiling11 are unnecessary
for this successor proof. The full scope and reproduction commands are
in the [new proof map](right_angled_dimension10_proof_map_20261020.md).

## Actual K7 and the nine-field compact arithmetic ceiling nineteen

The [complete K7 charge composition](../results/compact_arithmetic_k7_dimension19_charge_composition_20261020.md)
has passed full root and independent mathematical review. The primary
compact arithmetic paper now includes its composition as AppendixB,
after the eight-field AppendixA. The current PDF has20 pages and zero
warnings, with all76 named inputs bound before and after the build.
The [nine-field map](compact_arithmetic_nine_field19_proof_map_20261020.md)
identifies the seven complete internal geometric consumer theorems.
Those remain written proofs, not external assumptions or consequences
of typesetting. No new enumeration is assumed in this rank20 step.

Only after the mathematics and composition reviews, the new
`ArithmeticK7Field19` conditional kernel compiled and its six named
theorems passed the axiom audit. Printed dependencies contain only
propext and Quot.sound, with no sorryAx. It checks thirteen family
budgets in quarter units, the total-vertex upper, strict500 endpoint
surplus and the dimension-tail implication.

`VertexEntry.actualRoleBound` imports actual source/coupon counts;
`otherAllowance` bounds remaining forests. Actual classification into
the thirteen labels, complete vertex and coefficient coverage, polygon
incidence and h-vector realization are explicit premises. The final
`actualK7Geometry` interface requires the actual ground field K7,
not containment in an overfield. The earlier universal20 theorem
supplies the higher tail; arithmetic inheritance by faces is unnecessary.

This extends ceiling19 to nine specified fields, leaving uniform20
and the three remaining actual fields unchanged. The earlier eight-field
kernel is an imported checked dependency. Its source-bound audit record
is preserved rather than overwritten by a redundant standalone audit.
The inherited CompactHVector object retains its legacy cache provenance;
no fresh capped rebuild of that dependency or complete geometric Lean
formalization is claimed.

## Entirely ideal right-angled ceiling four

The new [four-page manuscript](../manuscripts/ideal_right_angled_dimension4.tex)
proves a sharp ideal dimension ceiling4 by maximum cusp height. Its
complete [proof map](ideal_right_angled_dimension4_proof_map_20261020.md)
separates the written proof, published inputs and conditional kernel.
The result does not depend on the older ideal5/6 size estimates or the
restricted ideal4 facet-spectrum/chain arguments.

Published inputs are Musin's Main theorem (Annals168,2008,printed p4),
the24-point bound for spherical60-degree codes in S3, and Kolpakov's
Theorem4 (AGT12,2012,printed p1945), the24-facet lower bound and
metric equality characterization for ideal right-angled four-polytopes.
All-wall acuteness is the standard fact recorded by Vinberg,1985,
Section2.1,printed p42. Face inheritance and connectedness of the actual
facet graph are standard convex/Coxeter-polytope inputs.

In `IdealRightAngled4`, the supplied `FiveData` has finite actual
facet indices, exact neighbor lists, actual path connectedness, a
positive-maximum height unequal to zero, a maximizing facet and a
zero-height cusp facet. Heights have an arbitrary type representing
the actual real geometry; no integer-height replacement is made.
`PublishedInputs` has separate Musin upper, Kolpakov lower and metric
equality fields. `WrittenGeometry` separately supplies ideal-face
inheritance, the all-wall projection point, normalized bounds, code
reduction, the opposite-pair center calculation and its height-ratio
consequence. These are written geometric lemmas, not extra published
theorems or consequences of the finite model script.

Lean checks their24-count squeeze and conditional composition, induction
along finite paths, the cusp-height contradiction and final dimension
implication. The published theorems, all Lorentz/real geometry, actual
path connectedness and five-face inheritance remain explicit premises.
The exact model script checks only the displayed standard24-cell and
one scalar identity; no enumeration hypothesis is needed for the theorem.

## Unified sharp right-angled ceilings eight and four

The current [unified manuscript](../manuscripts/right_angled_sharp_dimension_bounds.tex)
supersedes the earlier ideal-cusp-height and mixed10 manuscripts as the
primary dimension paper. The [proof map](right_angled_sharp_dimensions_proof_map_20261020.md)
lists every published input. General8 needs the universal RA6 facet
minimum27, from Dufour2010 Lemma1/Proposition4, explicitly stated in
Alexandrov2023 Section4. Entirely ideal4 additionally uses Musin's
cardinality24 and Kolpakov's24-facet minimum with metric equality.
Potyagailo--Vinberg's actual8-dimensional construction supplies
sharpness only. Standard all-wall and actual-face inheritance facts
remain explicit foundations.

`RightAngledSharpDimensions` uses typed face/point predicates.
`ProjectionGeometry` supplies actual finite interior points and the
one-step strict height update; the kernel composes it three times.
`heightBound k` is an abstract statement about true real heights
below1/sqrt k, not an integer encoding of a real variable.
`RadialGeometry` supplies the distinct actual-wall spherical codes.

`WrittenCubicGeometry` supplies the integer COUNT consequences of
the written real tensor-square argument: N²<=27N and, at N=27,
positive semidefiniteness of the concrete four-point half-Gram matrix.
Lean derives the count bounds and contradicts its exact quadratic
form-4. The twelve-variable exact worker independently checks the
universal tensor identities modulo explicit unit-norm ideal generators;
it does not formalize real norm positivity or the equality implication.

`PublishedDufour` is independent of `PublishedIdealFour`. The ideal
branch separately supplies the metric opposite-pair center calculation,
unit heights at that center, and their incompatibility with strict
height bounds. Actual five-face/nine-face inheritance remains explicit
in the two final dimension implications. No field, enumeration,
optimizer or final nonexistence theorem is assumed as an interface.
Full Lorentz geometry and the external theorems are not formalized here.

The actual unified four-job core now passes. The new single-module
capped compilation and separate12-theorem printed-axiom audit pass;
only propext/Quot.sound appear where dependencies are not axiom-free,
and no sorryAx appears. These are genuine conditional kernel proofs
with the interfaces above. The core-time assumption register and
catalogue are preserved as byte-verified compressed snapshots before
this status update. No stronger geometric formalization is implied.
