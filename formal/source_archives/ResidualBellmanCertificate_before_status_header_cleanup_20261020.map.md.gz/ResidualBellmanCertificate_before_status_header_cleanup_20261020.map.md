# Residual Bellman certificate: assumptions map

The source-only module [ResidualBellmanCertificate.lean](../formal/CoxeterProofs/ResidualBellmanCertificate.lean) addresses the saved-table clause of Proposition `dp-certificate` in [finite_volume57.tex](../manuscripts/finite_volume57.tex). It imports only `Std`. Its SHA-256 is `c3876078d53f282a6e239a2345e65d5967d5381a89cf60bc3021b46c18dd3045` (201 lines, 8197 bytes). **UNCOMPILED:** no elaboration, axiom-printer or runtime result is asserted. The installed project toolchain is Lean 4.32.2. No verification plan or catalogue entry has been changed.

The finite item alphabet is `Fin n`. A `Certificate n cutoff` supplies positive natural item ranks, arbitrary integer item weights and `memo : Nat → Option Int`, with exactly these local obligations:

- `base`: rank zero stores `some 0`.
- `transition`: every item appended to every stored predecessor within the cutoff has a stored successor whose value dominates predecessor value plus item weight. This quantifies over **all** items and predecessors, not only a selected attaining path.
- `tight`: every stored positive rank within the cutoff has an item and a stored predecessor with the exact rank and weight equations.

`list_upper` uses list induction to derive reachability and the upper bound for every item list within the cutoff. `memo_attained` uses strong rank induction to derive an attaining list for each stored value. Strict rank positivity makes every predecessor smaller. `memo_exact` and `some_iff_exactMaximum` combine these directions; no maximum or attainment conclusion is a certificate field. `none_iff_no_list` derives absence of all item lists. For positive ranks, `none_iff_no_predecessor` derives the equivalent absence of any stored predecessor transition; zero is correctly treated separately as the base.

`totals_perm` proves invariance of both additive totals under list permutation, so the exactness statement also applies to residual multisets. `length_le_rank` and `attained_within_58` give an attaining witness of at most 58 items when the explicit additional input is `cutoff ≤ 58`. Empty alphabets and negative weights are allowed; `none` remains distinct from every integer, including zero.

The application must still supply the complete allowed alphabet, its actual ranks and scaled-64 **integer** residual weights, the context split removing all pair interactions, and a concrete memo table satisfying all local obligations. Those obligations are finite: at most `cutoff + 1` states and `n` item transitions per state, with tight witnesses checked at stored positive states. The module does not implement a table generator or an enumeration checker, instantiate the actual table, prove geometric domination or context completeness, or reinterpret real heights/tensor weights as integers. It therefore supplies the abstract certificate implication and witness bound, not an end-to-end formalization of the finite-volume theorem.

Eight `#print axioms` requests are prepared for the principal upper-bound, attainment, exactness, unreachability, permutation and rank-58 witness theorems. Their outputs remain pending compilation by the parent-owned bounded execution queue.
