import Std

/-! Source draft: finite termination and absolute-surplus lifting for the
rank-57 low-eight concentration process. Zero ranks are harmless padded
factors: they contribute zero mass/potential and a factor one to link size.

This file does not prove the real convex-order comparison or identify
these lists with actual horospherical links. Its normalized comparison
is an explicit, denominator-cleared premise. No computation or compiled
verification is claimed merely by the presence of this source. -/

namespace CoxeterProofs.ConcentrationDescent58

def potential (p : List Nat) : Nat := (p.map (fun r => r*r)).sum
def linkSize (p : List Nat) : Nat := (p.map (fun r => r+1)).prod

/-- A complete low-eight move, up to permutation of factors. -/
def Step (p q : List Nat) : Prop :=
  ∃ a b rs, 1 ≤ a ∧ a ≤ b ∧ b < 8 ∧
    p.Perm (a::b::rs) ∧ q.Perm ((a-1)::(b+1)::rs)

def Terminal (p : List Nat) : Prop := ∀ q, ¬ Step p q

inductive Chain : Nat → List Nat → List Nat → Prop where
  | refl (p : List Nat) : Chain 0 p p
  | cons {p q r : List Nat} {k : Nat} :
      Step p q → Chain k q r → Chain (k+1) p r

theorem mass_le_potential (p : List Nat) : p.sum ≤ potential p := by
  induction p with
  | nil => simp [potential]
  | cons r rs ih =>
    have square : r ≤ r*r := by
      cases r with
      | zero => simp
      | succ r =>
        have h := Nat.mul_le_mul_left (r+1)
          (show 1 ≤ r+1 by omega)
        simpa using h
    simp only [potential, List.map_cons, List.sum_cons] at *
    omega

theorem potential_le_mass_square (p : List Nat) :
    potential p ≤ p.sum*p.sum := by
  induction p with
  | nil => simp [potential]
  | cons r rs ih =>
    simp only [potential, List.map_cons, List.sum_cons] at *
    simp only [Nat.add_mul, Nat.mul_add]
    omega

theorem linkSize_positive (p : List Nat) : 0 < linkSize p := by
  induction p with
  | nil => simp [linkSize]
  | cons r rs ih =>
    simp only [linkSize, List.map_cons, List.prod_cons]
    exact Nat.mul_pos (by omega) ih

theorem pair_potential_increase (a b : Nat) (positive : 1 ≤ a)
    (ordered : a ≤ b) :
    a*a+b*b+2 ≤ (a-1)*(a-1)+(b+1)*(b+1) := by
  cases a with
  | zero => omega
  | succ a =>
    simp only [Nat.succ_eq_add_one, Nat.add_sub_cancel,
      Nat.add_mul, Nat.mul_add, Nat.mul_one, Nat.one_mul]
    omega

theorem pair_size_decrease (a b : Nat) (positive : 1 ≤ a)
    (ordered : a ≤ b) :
    ((a-1)+1)*((b+1)+1) < (a+1)*(b+1) := by
  cases a with
  | zero => omega
  | succ a =>
    simp only [Nat.succ_eq_add_one, Nat.add_sub_cancel,
      Nat.add_mul, Nat.mul_add, Nat.mul_one, Nat.one_mul]
    omega

theorem step_mass (p q : List Nat) (step : Step p q) : q.sum = p.sum := by
  obtain ⟨a,b,rs,positive,ordered,small,hp,hq⟩ := step
  have ep := hp.sum_nat
  have eq := hq.sum_nat
  simp only [List.sum_cons] at ep eq
  omega

theorem step_potential (p q : List Nat) (step : Step p q) :
    potential p+2 ≤ potential q := by
  obtain ⟨a,b,rs,positive,ordered,small,hp,hq⟩ := step
  have ep := (List.Perm.map (fun r : Nat => r*r) hp).sum_nat
  have eq := (List.Perm.map (fun r : Nat => r*r) hq).sum_nat
  have inc := pair_potential_increase a b positive ordered
  simp only [potential, List.map_cons, List.sum_cons] at *
  omega

theorem step_linkSize (p q : List Nat) (step : Step p q) :
    linkSize q < linkSize p := by
  obtain ⟨a,b,rs,positive,ordered,small,hp,hq⟩ := step
  have ep := (List.Perm.map (fun r : Nat => r+1) hp).prod_nat
  have eq := (List.Perm.map (fun r : Nat => r+1) hq).prod_nat
  have strict := Nat.mul_lt_mul_of_pos_right
    (pair_size_decrease a b positive ordered) (linkSize_positive rs)
  simpa only [linkSize, List.map_cons, List.prod_cons,
    Nat.mul_assoc, ep, eq] using strict

theorem chain_mass {p q : List Nat} {k : Nat} (chain : Chain k p q) :
    q.sum = p.sum := by
  induction chain with
  | refl => rfl
  | cons first rest ih => exact ih.trans (step_mass _ _ first)

theorem chain_potential {p q : List Nat} {k : Nat}
    (chain : Chain k p q) : potential p+2*k ≤ potential q := by
  induction chain with
  | refl => omega
  | cons first rest ih =>
    have inc := step_potential _ _ first
    omega

theorem chain_linkSize {p q : List Nat} {k : Nat}
    (chain : Chain k p q) : linkSize q ≤ linkSize p := by
  induction chain with
  | refl => exact Nat.le_refl _
  | cons first rest ih =>
    exact Nat.le_trans ih (Nat.le_of_lt (step_linkSize _ _ first))

theorem chain_length_at_rank57 {p q : List Nat} {k : Nat}
    (mass : p.sum = 57) (chain : Chain k p q) : k ≤ 1596 := by
  have mq : q.sum = 57 := (chain_mass chain).trans mass
  have lower := mass_le_potential p
  have upper := potential_le_mass_square q
  have growth := chain_potential chain
  rw [mass] at lower
  rw [mq] at upper
  omega

/-- No infinite choice of moves is needed: bounded strong induction
produces a terminal state, with the same bound for every possible path. -/
theorem terminal_exists_at_rank57 (p : List Nat) (mass : p.sum = 57) :
    ∃ q k, Chain k p q ∧ Terminal q ∧ k ≤ 1596 := by
  classical
  have descent : ∀ fuel p, p.sum = 57 → 3249-potential p = fuel →
      ∃ q k, Chain k p q ∧ Terminal q ∧ k ≤ 1596 := by
    intro fuel
    induction fuel using Nat.strongRecOn with
    | ind fuel ih =>
      intro p mass measure
      by_cases next : ∃ q, Step p q
      · obtain ⟨q, step⟩ := next
        have mq : q.sum = 57 := (step_mass p q step).trans mass
        have upper := potential_le_mass_square q
        rw [mq] at upper
        have growth := step_potential p q step
        have smaller : 3249-potential q < fuel := by omega
        obtain ⟨r,k,tail,terminal,bound⟩ :=
          ih (3249-potential q) smaller q mq rfl
        have whole := Chain.cons step tail
        exact ⟨r,k+1,whole,terminal,chain_length_at_rank57 mass whole⟩
      · refine ⟨p,0,Chain.refl p,?_,by omega⟩
        intro q step
        exact next ⟨q,step⟩
  exact descent (3249-potential p) p mass rfl

/-- Clear a common charge denominator first. The normalized comparison
is (kp-cp)/vp >= (kq-cq)/vq, written without truncated subtraction.
Positive terminal surplus and link-size decrease give absolute surplus. -/
theorem absolute_surplus_lift (vp vq kp cp kq cq gap : Nat)
    (terminalSize : 0 < vq) (volume : vq ≤ vp)
    (normalised : vp*kq+vq*cp ≤ vq*kp+vp*cq)
    (terminalGap : cq+gap ≤ kq) : cp+gap ≤ kp := by
  have scaled := Nat.mul_le_mul_left vp terminalGap
  have gapMono := Nat.mul_le_mul_right gap volume
  simp only [Nat.mul_add] at scaled
  apply (Nat.mul_le_mul_left_iff terminalSize).mp
  rw [Nat.mul_add]
  omega

theorem chain_absolute_surplus {p q : List Nat} {k : Nat}
    (chain : Chain k p q) (kp cp kq cq gap : Nat)
    (normalised : linkSize p*kq+linkSize q*cp ≤
      linkSize q*kp+linkSize p*cq)
    (terminalGap : cq+gap ≤ kq) : cp+gap ≤ kp := by
  exact absolute_surplus_lift (linkSize p) (linkSize q) kp cp kq cq gap
    (linkSize_positive q) (chain_linkSize chain) normalised terminalGap

end CoxeterProofs.ConcentrationDescent58

#print axioms CoxeterProofs.ConcentrationDescent58.pair_potential_increase
#print axioms CoxeterProofs.ConcentrationDescent58.step_linkSize
#print axioms CoxeterProofs.ConcentrationDescent58.chain_length_at_rank57
#print axioms CoxeterProofs.ConcentrationDescent58.terminal_exists_at_rank57
#print axioms CoxeterProofs.ConcentrationDescent58.absolute_surplus_lift
#print axioms CoxeterProofs.ConcentrationDescent58.chain_absolute_surplus
