# D18 central-opposite native-prefix search: proof and pre-execution contract

23 October2026. **SOURCE-ONLY packet, UNEXECUTED and awaiting complete
different-author/root review.** This is a concrete bounded necessary-domain
search for actual dimension18 Coxeter data, not a claimed exclusion or example.
No import, worker, test, enumeration, optimizer, compiler, Lean or TeX has run.
All decimals below denote exact rational numbers.

Worker: `scripts/compact18_central_prefix_interval_search_20261023.py`,
SHA256 `3c2b69ebdbb520ac1c8f95f0c2e45a50d0505b452c777bfb6f0f574a0e2c2fc9`.
The worker has569 lines /21,105 bytes. This note supplies its mathematics,
coverage/termination statements and exact execution boundary, not runtime PASS.

Root requested an actual central-opposite packet after the spectral method's
terminal-frame positivity obstruction. The present author derived the fresh
35-profile list, the central/head parameter bounds, the finite pressure test
and worker. Earlier compact arguments and the reviewer's earlier A17 norm
square are inherited background; that square is NOT an input here. The frozen
316-line return-cone source remains unreviewed and is NOT used by this packet.

## 1. Bound inputs, one point and one original farthest vertex

All source paths in this table are under `results/`; the pins were freshly
matched during preparation. The finite spherical classification and compact
acute simplicity are the stated external mathematical inputs. No arithmeticity,
root-scale integrality or Coxeter/arithmetic inheritance by a face is assumed.

|ID|Source|SHA256|Exact imported statement|
|---|---|---|---|
|H|compact18_whole_d18_fresh_tail_window_strong_five_and_long_head_reduction_candidate_20261023.md|3a71f17c6d25902bd6c93551780cd90e1974a3035ef815d413ffdb06cdb6a763|Actual long-head opposite is isolated with own5, finite>=7 or DOT; genuine D18 coordinates|
|HA|review_compact18_whole_d18_fresh_window_strong_five_head_root_acceptance_20261023.md|bd0c02fe896064b7b47b2532cd0af0ed6ba4d6a41387f782be10f5b35c22e68c|Accepted H boundary|
|S|review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md|d1f94ee4d488e5ee37ae285bbcd630de38d67555375d4837eca74c7f1609c7a1|Unconditional S16>4-.58/sqrt2 for the SAME original vector|
|R|compact18_d18_terminal_slack_actual_a18_neighbor_and_fork_pair_reduction_candidate_20261023.md|09f2cabacb22f0bff6c78e716c76a1570800cac9a83d8e748e2ff3b7d2864ffc|Complete remaining individual fork roles, native own lists and exact actual edge lengths|
|RA|review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md|c07c6c2846f90c4a9dad97a1a1f5b613af866bcfc7e8c1396735a2da8c516d23|Accepted R boundary|
|I|compact18_d18_isolated_fork_fifteen_eighths_cutoff_actual_a17_rank_one_paired_projection_candidate_20261023.md|bcf501819eb8ca0cd4c250cb2aab5229a36b7fb8697f4c220df5a7765abf41c4|Isolated fork own<15/8|
|IA|review_compact18_d18_fifteen_eighths_isolated_cutoff_root_acceptance_20261023.md|34b9031d4c6ee59b7fb90e32d5c67238b9eb53f4f26a89b2f65a07f2d92e9710|Accepted I boundary|
|X|compact_farthest_vertex_mixed_replacement_inequalities_20261020.md|3732b82614e13dfe2f7a3c66ab6c7fe67e517cbaeb77be0ca533f559ddf6ed84|Actual-point/all-wall convention and one original-vector square, rederived below|

Assume an ACTUAL original farthest vertex p of whole type D18 in a compact
Coxeter18-polytope. Fix the SAME strict interior unit point z throughout:

    z=E(p-x), ||x||^2<1, x1>...>x17>|x18|,
    n_j=(e_j-e_(j+1))/sqrt2 (j1..17), n18=(e17+e18)/sqrt2,
    Omega_j=sqrt2 P_j (j<=16),
    Omega17=(P17-e18)/sqrt2, Omega18=(P17+e18)/sqrt2.

Here P_j=e1+...+e_j. The tangent product is Euclidean and p is orthogonal to
all original roots. Its dual Gram K has

    K_jk=2min(j,k) for j,k<=16;
    K_jf=j for j<=16, f17 or18;
    K_17,17=K_18,18=9, K_17,18=8.                            (1)

Every chosen cap below is the ACTUAL other wall at an old edge endpoint.
These restrictions are NEVER assigned to arbitrary unobserved walls.

## 2. Entire finite-white list at release6,7,8

Release i in{6,7,8}. The retained actual diagram is
`A_(i-1)+D_(18-i)`, with A ranks5/6/7 and D ranks12/11/10.
Its actual other endpoint has exactly one additional wall c, by simplicity.
Write

    c=A p-v, v=gamma Omega_i+H_i, A>0,
    A^2=v^2-1, gamma=-c.n_i>=0.                              (2)

The helper H_i is exactly one of the following35 cases. A listed3 means
coefficient1/2 on that old dual, and a listed4 means1/sqrt2.

|i|isolated|A-side3 indices|A-side4 indices|D-side3 index|two3 bridge indices|count|
|---|---|---|---|---|---|---:|
|6|H=0|1,2,3,4,5|1,5|7|(1,7),(5,7)|11|
|7|H=0|1,2,3,4,5,6|1,6|8|(1,8),(6,8)|12|
|8|H=0|1,2,3,5,6,7|1,7|9|(1,9),(7,9)|12|

Proof of completeness. A finite Coxeter diagram is a tree, so c cannot have
two contacts with one connected old component. On A_r a single3 at an end
gives A_(r+1), next to an end D_(r+1), and three from an end E6/E7/E8
at the listed ranks. The middle of A7 would not be finite. A single4 is
allowed only at an A endpoint, giving B_(r+1); no5+ fits these ranks.
On D_m with m>=10, only a single3 at its long endpoint is finite: a fork
extension would need an E type above rank8, an internal contact adds another
branch, and a4 cannot belong to finite A/B/D with that retained fork.
If c joins both components, the full connected rank is18. It cannot be
an exceptional type or a path; finite D18 forces3 at an A endpoint and3
at the D long endpoint. These are exactly the two bridge rows. This
uses the complete finite classification at the ACTUAL endpoint, not a
rank decrement or an intrinsic-face assertion.

Own0 is impossible in EVERY row. For isolation A^2=-1. A-side far3 at1
has A^2=-1/2; next3 at2 has A^2=0. Every other single3 at old j>=2
has an actual affine-D principal on c,n_(j-1),n_j,...,n16,n17,n18:
coefficient2 on the chain and1 on its four leaves. This also treats the
D-side long3, taking j=i+1. A-side4 at1 has A^2=0; its other endpoint
has the affine-B principal with coefficients sqrt2 on c,2 on the chain
and1 on each fork. A bridge at own0 gives the all3 cycle through c
and the old chain between its marked endpoints. All these kernels are
positive actual-normal sums, have positive time through A>0, and pair
nonpositively with EVERY unselected actual wall. A feasible future null
contradicts compactness. Thus gamma>0 and native gamma>=1/2.

## 3. Complete bounded parameter domains

For an actual edge endpoint q=Cp-s u, s=sqrt(C^2-1), with positive unit
old edge dual u, original maximality gives

    E(C-s x.u)=-z.q<=E,
    x.u >= sqrt((C-1)/(C+1)).                                (3)

Let S_j=x.P_j. S gives S16>4-.58/sqrt2>3.58 and also>3.589.
For i6,7,8 put t=S_i/sqrt(i). If t>=19/20, Cauchy on the two old
coordinate blocks gives

    S16<=sqrt(i)t+sqrt(16-i)sqrt(1-t^2)
        <=sqrt8(19+sqrt39)/20<3.58.                          (4)

The first function decreases in t>=.95, since its maximum is at
sqrt(i/16)<=sqrt(1/2); at t=.95 it increases in i<=8. For the final
strict rational seal use sqrt2<1.415 and sqrt39<6.245, obtaining
sqrt2(19+sqrt39)/10<3.5721675. This contradicts S16, so t<.95.
By (3), EVERY such central edge has

    C<761/39<20.                                             (5)

Set D_i=K_ii=2i, and define

    delta=1-H_i^2+(H_i.Omega_i)^2/D_i,
    C=(gamma D_i+H_i.Omega_i)/sqrt(D_i delta).                (6)

This is exact: projecting v onto the unit Omega_i direction gives sigma;
`sigma^2-A^2=delta`, and the actual endpoint equation gives `C=sigma/sqrt(delta)`.
The finite white Gram makes delta>0, while its Euclidean expression gives
delta<=1. Therefore C>=gamma sqrt(D_i), and (5) gives gamma<6.
The entire central own domain is thus native3,4,5,6 or native finite7+/DOT
inside `[.9,6]`; the worker retains harmless parallel/boundary values.

The ACTUAL isolated head is `H=A_H p-eta Omega1`, A_H^2=2eta^2-1.
If x1>=2/3, Cauchy would give
S16<=(2+5sqrt3)/3<32/9<3.58, a contradiction. The function
t+sqrt15 sqrt(1-t^2) decreases for t>=2/3; sqrt3<26/15 seals the bound.
Thus x1<2/3. Its actual edge C_H=sqrt2 eta and (3) imply
`C_H<13/5`, hence eta<2. H/HA leave only native5 or finite7+/DOT.

The complete inherited individual fork rows, for f17 or18 and its other
fork o, are as follows. These remain necessary lists, never examples.

|role|shadow v|actual C|native own|upper bound|
|---|---|---|---|---|
|isolated|g Omega_f|3g|finite>=7 or DOT|g<15/8|
|near3|g Omega_f+Omega_o/2|(18g+8)/sqrt19|4,5,finite>=7 or DOT|g<1.21|
|far3|g Omega_f+Omega1/2|(18g+1)/sqrt19|5,finite>=7 or DOT|g<1.6|
|far_next3|g Omega_f+Omega2/2|9g+1|5 or finite>=7|g<.96|

The last C and bound follow from R's C<9.64. Thus all four parameters
(head, fork17, fork18, central) lie in bounded intervals, with no uncontrolled
original DOT magnitude. Strict original bounds are enlarged to closed boxes
for the search, which can only weaken a rejection attempt.

For completeness cos(pi/7)>.9 has an elementary exact seal. The bound
pi<22/7 and cos u>=1-u^2/2 give cos(pi/7)>2159/2401>.89.
With c=cos(pi/7), cos4theta=-cos3theta gives
`8c^3-4c^2-4c+1=0`. This polynomial is strictly increasing on[.89,1]
and has value-.008 at.9, proving c>.9. Hence all finite labels>=7
and DOT are safely enclosed by the continuous high intervals used above.

## 4. Exact native and ONE-vector rejection tests

The four chosen caps are DISTINCT. The central one has positive contact
with old i6/7/8, while all terminal shadows vanish on that old wall.
The head has only its old1 contact; each fork cap has its own positive
signed-fork contact. Two near fork caps could coincide only at both owns1/2,
excluded by their actual native lists. Every other fork pair has different
nonzero support. Thus the native gap applies to all six cap pairs.

For their sparse shadows v_j and times A_j=sqrt(v_j^2-1)>0, compute

    lambda_jk=A_j A_k-v_j.v_k=-c_j.c_k.                       (7)

Actual acuteness and native angles require lambda in
`{0,1/2,sqrt2/2,(1+sqrt5)/4,sqrt3/2} union [.9,infinity)`.
The continuous high interval is a necessary relaxation. A rigorously
enclosed (7) lying strictly negative or strictly within a complementary
open gap rejects the ENTIRE parameter box. The worker also rejects own
parameters lying in gaps of their ROLE-SPECIFIC native lists, and boxes
where any entire time square has nonpositive upper endpoint.

The second test uses the FIVE actual pressures on

    U=(P1, P_i, P16, P17+e18, P17-e18).

Their exact Gram is the worker's `pressure_gram`. Lower pressure bounds are
respectively `F(C_H)`, `sqrt(i)F(C_i)`, `3.589`, `sqrt18 F(C_17)` and
`sqrt18 F(C_18)`, where `F(C)=sqrt((C-1)/(C+1))` and (3) applies.
Every bound is rounded DOWN by exact rational arithmetic.

For ANY nonnegative rational coefficients b let W=sum b_j U_j.
One original-vector square gives

    ||x||^2>=2x.W-W^2>=2 sum_j b_j l_j-b^T Gram(U)b.           (8)

A rational value greater than one rejects the box. The search proposes b
by checking the31 nonempty subsets of the five directions: solve their
positive definite Gram systems against their lower bounds and retain a
nonnegative solution if it proves (8). This finite witness generator need
not be a complete quadratic-program solver. Replay verifies the listed
nonnegative b and (8) DIRECTLY, without trusting that proposal search or
adding separately optimized energies. No head gain, old reference reserve,
component energy or auxiliary farthest vector is also counted.

## 5. Exact interval arithmetic and all-case coverage

The worker uses standard-library rational arithmetic only. Square roots
are enclosed on the fixed2^-64 grid using integer square root. For q>=0,
`floor(sqrt(floor(q*2^128)))/2^64` is a lower bound; adding2^-64 when
the square is not exact gives an upper bound. All arithmetic operations
take endpoint extrema; zero-crossing square roots/times are conservatively
clipped, never assigned an unjustified positive lower bound. Division is
used only with a strictly positive constant residual enclosure. Every
helper residual in (6) is computed as an exact rational: single3/4 has
coefficient-square1/4 or1/2; bridges have two rational half coefficients.

A unit fixes site, central profile and both fork roles. Setting all four
own selectors to `all` covers its entire native parameter domain with
conservative radical-enclosing rational boxes. There are35*4*4=560 such
units before any accepted pair exclusions are used. Both signed orientations
are retained. The optional narrower native selectors are documented by
`own_domain`; their union covers the `all` domain's ACTUAL possibilities,
but successful narrow units do not by themselves credit their parent unit.

Each unit is processed by deterministic depth-first bisection of the longest
parameter interval, ties in parameter order. Closed children cover the
parent, including their shared midpoint. An exact rejected leaf contributes
a sound necessary-domain elimination. A surviving depth-limited leaf is
explicit DEFER, not an example, realization, exclusion or numeric bound.

## 6. Termination, evidence, replay and resource contract

The unit limits are fixed and bounded: depth<=24, nodes<=8191, internal
time<=45seconds, rational numerator/denominator<=512bits, certificate<=16MiB.
Defaults are depth8/nodes511/time20seconds. The entire depth8 binary tree
has511 nodes, so these defaults permit full low-resolution coverage even
without any pruning, subject to time/bit limits. The DFS stack is linear in
depth; it never stores a large grid. Each node has four parameters, six cap
pairs and at most31 exact systems of size at most five. This is a finite
algorithm; no unbounded optimizer, recursion or field census is invoked.

The coordinator must launch search and replay as SEPARATE bounded research
units through `scripts/run_bounded_research_check_20261018.py`, sharing the
existing exclusive lock and using its `--parent-lock` option because this
worker does not acquire the lock itself. The checker is deliberately under
`scripts/`, as required by the unchanged runner's path restriction.
Admission remains40GiB free disk/6GiB RAM; abort
floors8GiB/3GiB,59seconds/1GiB/one thread remain unchanged. The worker does
not replace these gates, process-tree monitoring or the coordinating owner.
No direct shell command in this note authorizes a launch before source review.

Certificates are created exclusively, never overwrite an earlier receipt,
and stream one JSON object per line. They contain a source-hash/initial-box
header, explicit split/reject/defer tree records and one final footer.
Limits/exceptions produce FAIL, never truncation credited as a completed
proof. A killed/disk-truncated unit lacks a valid complete footer and fails
replay. Output size, input size and individual replay line size are bounded.
After a resource FAIL, preserve its artifact and report it; do not credit its
partial prunings as a completed unit or silently relabel pending boxes DEFER.

Replay regenerates the exact initial box and reconstructs the DFS tree.
Every address must be its next expected node. Splits cover both children;
rejected leaves get exact interval or ONE-vector checking; deferred leaves
must be at the recorded resolution. Its footer requires an EMPTY pending
stack and matching counts. Strict EOF forbids any character after the footer.
An EXCLUDED result needs zero DEFER leaves; exit0 is reserved for that result.
A completely covered but unresolved DEFER exits2. Any FAIL exits4. A preserved
failure is reported as FAIL on replay, not as valid full coverage. Replay is
a separate exact certificate check sharing interval helpers; it is not an
independent implementation or new Lean verification.

The existing runner requires child exit0 for its bounded PASS receipt.
Consequently a DEFER unit and a DEFER replay deliberately yield a failed
wrapper invocation, with their certificate/stdout preserved and NO runtime
PASS credited. Do not change that runner convention or relabel the result.
An initial small pilot may select site7, profile`isolated`, head-own`high`,
fork-plus-role`isolated`/own`high`, fork-minus-role`far3`/own`high`,
central-own`high`, depth4/nodes31/seconds10; that is only ONE named unit,
not coverage of all560, and remains unlaunched pending full source clearance.

No surrounding condition is assumed, no spectral covariance inequality is
used here, and no omitted wall is assigned the selected finite-white list.
Adding return-cone covariance later requires a proved surrounding set at the
same canonical point and another reviewed contract. A single complete unit
exclusion proves only its named necessary-domain statement. A wholeD18 or
dimension17 theorem would need an exhaustive accepted conjunction beyond this
packet. At present there is NO execution, exclusion or global ceiling change.
