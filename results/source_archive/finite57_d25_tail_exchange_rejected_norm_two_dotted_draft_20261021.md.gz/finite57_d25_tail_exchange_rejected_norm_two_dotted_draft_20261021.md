# A D25 short-eight tail exchange and its different off-face cusp

21 October 2026. New manual supporting calculation. No scientific, symbolic, enumeration, worker-import, Lean or TeX job ran. All current sources and weights remain unchanged. This proves an exact feasible local-star obstruction to the proposed universal replacement route, together with a conditional forced off-face D10 cusp. It does not construct a finite-volume ambient polytope, exclude one, delete a coupon or change a dimension bound.

The inherited comparison is `finite57_d25_short8_off_face_a16_e8_financing_20261021.md`, SHA `3223a636c43db5014d9714e819470545d15c336395822c10226fd6848548c7bed` (paths are under `results/` unless stated). That theorem requires its precise contacts and spectator orthogonality. The current weights are those of `manuscripts/finite_volume57.tex`, SHA `c300db69c58211ffdf69c22970b289325224ad284d9e63a3c28d88821fca82a0`, especially lines1263–1280 and the cross-role table. The following is a different branch, not another instance of that financed A16/E8 family.

## 1. Exact native star with a contacted spectator tail

Use norm-two D25 roots alpha0,...,alpha24, spine0..22 and short leaves23,24 at22. Put a=alpha15, b=alpha23. Let Z be a whole finite A15 with roots z0,...,z14 plus17 mutually orthogonal A1 roots, all orthogonal to D25. Thus the old whole finite forest has rank57. Its duals are omega_i for D25 and eta for the endpoint z0 of A15; in particular

`omega16^2=17`, `omega23^2=25/4`, `omega16.omega23=17/2`, `eta^2=15/16`.

Let p be a future unit timelike vector orthogonal to that forest. Define

`tau=sqrt(120/103)>1`,

`c=(sqrt(255)/4)*p-omega16-eta`,

`d=sqrt(544/103)*p-tau*omega23`.

Then c and d have norm2. Their only nonzero old products are

`c.alpha16=c.z0=-1`, `d.b=-tau`.

In particular `c.a=c.b=d.a=c.d=0`. The last equality follows from

`(sqrt(255)/4)*sqrt(544/103)=(17/2)*tau`.

Every new finite bond is simple3; b,d have a permitted dotted product, and all other new distinct-root products vanish. These are full scalar products, not projected native labels. The complete old rank57 block is positive definite. Its Schur complement for c,d is

`[ -255/16       -(17/2)tau ]`

`[ -(17/2)tau    -544/103  ]`.

The two diagonal entries are negative and its determinant is0. Therefore the full59-root Gram has signature(57 positive,1 negative,1 zero). This also explicitly realizes it in Lorentz space, with no unspecified negative-direction completion.

Write `W=(D25 minus {15,23})+Z=A15+A8+A15+17A1`. Its rank is55 and it is the supporting-white forest of the local quadrilateral below. Crucially c has a nonzero contact with the ORIGINAL spectator forest Z. No omitted inert cusp root is being called a supporting white.

## 2. All four finite corners and their current weights

Each corner is obtained by adding its two indicated black roots to W:

|Marks|Whole finite components|Current marked payment|
|---|---|---:|
|a,b|D25 + A15 +17A1|1: short leaf b, distance8|
|c,b|D25 + A15 +17A1|1: short leaf b, distance8|
|a,d|A24 + A15 +18A1|0: a in A24, d in separate A1|
|c,d|A24 + A15 +18A1|0: c in A24, d in separate A1|

At c,b the D25 long tail is z14,...,z0,c,alpha16,...,alpha22; the old alpha0,...,alpha14 are now the separate A15. Thus this is a genuine exchange of which whole A15 tail belongs to the D25. At a,d the A24 path is alpha0,...,alpha22,alpha24. At c,d it is z14,...,z0,c,alpha16,...,alpha22,alpha24. The mark a or c has path position15 in the corresponding A24. All four positive-definite corner diagrams have rank57.

The two D25 weights are exactly the targeted units: their short-leaf mark has feature depth0, and their distance is8 rather than the distance9 half orbit. Both A1/A24 cross roles are unlisted and receive0; the inert A15 and A1 multiplicities activate no current coupon for these marks. Hence deleting the two units leaves THIS quadrilateral with zero current corner payment. Neither the A17 endpoint financing nor an ideal-corner priority pays it directly: all its four corners are finite. There is no white-interior adjacent-black path shorter than8: a and c each reach b through alpha16,...,alpha22 in length8, while d has no white contact.

## 3. A strictly feasible actual local face, not just a Gram signature

Eliminate W and order the side roots as a,b,c,d. Their projected Gram in W-perp is

`[ 25/144   -2/9    -8/9       0 ]`

`[ -2/9      4/9    -2/9    -tau ]`

`[ -8/9     -2/9    25/144     0 ]`

`[  0       -tau      0        2 ]`.

For example the A15 endpoint cost is15/16, the A8 endpoint cost8/9, their A8 cross entry toward alpha22 is2/9, and alpha22's A8 inverse diagonal is14/9. Thus the displayed diagonals and off-diagonals follow directly, including the shared alpha16 cost8/9 in a,c.

An explicit realization in coordinates (X,Y,T), square X^2+Y^2-T^2, is

`a_bar=(sqrt(17/32),0,sqrt(103/288))`,

`c_bar=(-sqrt(17/32),0,sqrt(103/288))`,

`b_bar=(0,-sqrt(60/103),sqrt(128/(9*103)))`,

`d_bar=(0,sqrt2,0)`.

Taking all four outward halfspaces to have nonpositive product gives, in the Klein plane T=1, the rectangle

`|X|<=sqrt(103/153)`, `-sqrt(32/135)<=Y<=0`.

Its four corner rays are timelike: the upper two have square `-50/153`, and the lower two have square `2089/2295-1=-206/2295`. At every corner the two unselected side inequalities are strict. The rectangle has a timelike strict interior. Thus these are feasible finite rays against EVERY displayed root, not merely positive corner principals.

The intersection of all displayed halfspaces in H57 has this actual two-face and its four actual finite vertices. Full dimension follows by perturbing a strict rectangle-interior ray slightly into the negative side of each independent white normal; its four strict side signs persist. This proves realizable local Coxeter polyhedron data. It does NOT prove that this halfspace polyhedron has finite volume, nor that it admits a finite-volume completion preserving the face.

## 4. What is forced off the face, and the remaining obstruction

There is a different positive affine principal here. The roots

`{a,c,alpha16,...,alpha22,b,alpha24}`

form affine D10, with null vector

`nu=alpha16+...+alpha22+(a+c+b+alpha24)/2`.

Its two fork centers are16 and22. Its product with p is negative, so it is future null. In any finite-volume polytope containing this actual star, positivity of this expression and acuteness put nu in its closure; the finite-volume ideal-vertex theorem makes it an actual cusp, and the positive kernel makes this affine D10 a WHOLE cusp factor. Every additional facet through nu is orthogonal to that entire factor. This assertion is conditional on actual finite-volume containment, not supplied by the local construction.

But `nu.alpha14=nu.z0=-1/2` and `nu.d=-tau/2`. In particular nu is OUTSIDE Q; two original supporting whites do not pass through it. Its other displayed orthogonal tails are alpha0,...,alpha13 and z1,...,z14, both finite A14 paths, not the affine A16/E8 pair of3223. There is no displayed affine A16 cycle: the new finite-bond graph is a tree. Further cusp-completing facets and inert factors have not been classified, so this observation does not exclude undisplayed A factors or other off-face payments.

This is the precise next interface: a universal short-eight replacement must cover tail-exchange faces with a WHOLE off-face D10 factor, two orthogonal finite A14 remnants, unknown further cusp completion, and actual contacts to Z. It must prove an incidence/multiplicity bound and available source surplus, or rule out finite-volume completion. Reusing3223's A16/E8 rectangle injection, counting the new omitted facets as Q-whites, or invoking a Context662 recipient bound would not establish any of those facts.

The phenomenon is structural rather than a special scalar accident. Replacing each A15 tail by A_p gives a D_(p+10) pair at the same short-leaf distance8, with

`A_c^2=p(p+2)/(p+1)`, `tau^2=8p/(7p-2)`, `A_d^2=2(p+1)(p+2)/(7p-2)`.

The projected rectangle has squared half-width `(7p-2)/(9(p+2))` and squared depth `2(p+1)/(9p)`. Their sum is less than1 for every integer p>=1, since the positive difference numerator is14p-4. The ambient57 instance p15 above respects its exact supporting rank. No universal finite-volume realization is inferred for this family.

**Scope:** this is an exact obstruction to deducing Z-orthogonality or the already financed A16/E8 model solely from large spherical white extensions and local actual-star feasibility. It leaves the universal D_r short-leaf-eight replacement open. No current weight is deleted; no global finite maximum, bound56, new finite-volume example or formal geometric theorem is claimed.
