#!/usr/bin/env python3
"""Audit a matching capped Lean object; never compile a missing object.

This child requires the unchanged outer bounded research runner.  It obtains
the shared lock itself and refuses if any dependency needs rebuilding.  A
separate successful compilation is therefore a prerequisite, not a fallback.
"""
import os
import sys

if not __debug__ or sys.flags.optimize:
    raise SystemExit('ASSERTIONS_REQUIRED: Lean audit cannot run with Python -O')
if os.environ.get('PYTHONOPTIMIZE', '') not in ('', '0'):
    raise SystemExit('ASSERTIONS_REQUIRED: remove PYTHONOPTIMIZE before verification')

import argparse
import fcntl
import json
import re
import signal

import run_lean_batches_signal_safe_20261018 as safe


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('module')
    args = parser.parse_args()
    if not re.fullmatch(r'CoxeterProofs(?:\.[A-Za-z0-9_]+)+', args.module):
        parser.error('Choose one named module')
    owner = os.environ.get('COXETER_CHECK_OWNER', '')
    if not owner.isdigit() or int(owner) <= 1 or os.getppid() != int(owner):
        raise RuntimeError('OUTER_RSS_MONITOR_REQUIRED: use run_proof_batch lean-audit')
    base = safe.base
    if (base.ROOT / 'repro/RESEARCH_PAUSED').exists():
        raise RuntimeError('Research is paused; no audit was started')
    base.STATE.mkdir(exist_ok=True)
    with (base.STATE / 'exclusive.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        base.stop_group = safe.stop_group
        for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(signum, base.interrupt)
        safe.resources()
        states = {name: base.cached(name) for name in base.dependency_order(args.module)}
        if states.get(args.module) != 'KERNEL_COMPILED':
            raise RuntimeError('SEPARATE_COMPILATION_REQUIRED: no matching capped target object')
        if any(state is None for state in states.values()):
            raise RuntimeError('SEPARATE_COMPILATION_REQUIRED: dependency needs rebuilding')
        source = base.source(args.module)
        with source.open() as stream:
            printed = [line.strip() for line in stream
                       if line.lstrip().startswith('#print axioms ')]
        if not printed:
            raise RuntimeError('NO_ACTUAL_AXIOM_COMMANDS: audit would print no declarations')
        try:
            base.batch(args.module, audit=True)
            print(json.dumps(dict(status='PASS_SEPARATE_ACTUAL_AXIOM_INVOCATION',
                module=args.module, compilation_performed=False,
                printed_commands=printed, cache_provenance=states)), flush=True)
        finally:
            base.clean_unused()


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, OSError, KeyboardInterrupt) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
