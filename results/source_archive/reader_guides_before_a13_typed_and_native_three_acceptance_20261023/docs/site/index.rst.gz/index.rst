Coxeter polytopes: results and verification
===========================================

This project studies dimension bounds, explicit reflection chambers and
right-angled volume/structure problems. There are **six paper families**,
with matching TeX/PDF editions and separately scoped mathematical reviews,
exact computations and Lean kernels. Updated23 October2026.

Current dimension bounds
------------------------

The new ceilings are internally reviewed written proofs. They are distinct
from published theorems, external refereeing and full geometric formalization.

.. list-table:: Dimension comparison
   :header-rows: 1
   :widths: 43 16 18 23

   * - Class
     - Largest example
     - Published ceiling
     - Repository ceiling
   * - General Coxeter, finite volume
     - 21
     - 995
     - **57**
   * - General compact Coxeter
     - 8
     - 29
     - **18**
   * - Compact arithmetic Coxeter
     - 8
     - 29
     - **15**
   * - Noncompact arithmetic Coxeter
     - 21
     - 21
     - **21**, published and sharp
   * - Right-angled, finite volume, all vertices
     - 8
     - 12
     - **8**, internally sharp
   * - Right-angled, entirely ideal
     - 4
     - 6
     - **4**, internally sharp
   * - Right-angled, compact
     - 4
     - 4
     - **4**, published and sharp

The compact18 and arithmetic15 arguments are supporting work in the existing
compact paper families; their frozen PDFs still state23 and20. Arithmetic
reflection lattices automatically admit the quadratic-form model: “first type”
is not an additional restriction. See the
:download:`current guide <../current_bounds_and_verification.md>` and
:download:`published-input register <../manuscript_assumptions.md>`.

At exact compact dimension18, only **whole D18** remains in the accepted
necessary frontier after the
:download:`complete whole-B18 exclusion <../../results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md>`.
This concerns a selected farthest vertex, not every vertex or an example. The
:download:`complete D18 conjunction <../../results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md>`
proves unconditional center16 strength. The
:download:`new D18 pair theorem <../../results/review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md>`
gives both fork cosh lengths<9.64 and excludes both-near3 for all heads,
plus near3/far3 under native5 head. The
:download:`actual A17+A1 neighbor theorem <../../results/review_compact18_d18_actual_a17_a1_isolated_cutoff_native5_far_pair_root_acceptance_20261023.md>`
excludes native5 far3/far3. The stronger
:download:`actual-neighbor cutoff <../../results/review_compact18_d18_fifteen_eighths_isolated_cutoff_root_acceptance_20261023.md>`
now bounds every isolated fork own by15/8, for every head.
That head forces an isolated dotted fork; the remaining pair roles are
refined below. WholeD18 is still open.

The new :download:`GLOBAL compact-arithmetic ceiling15 <../../results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md>`
closes the last whole-D16 case. Actual geometry first forces a quadratic
field, dotted isolated head and BOTH isolated dotted forks. Integer norms,
all three splitting types of2, complete maximal-order strips and full
field-square tests exclude every remaining triple. The two geometric
residues each fail ONE original-vector budget.

The final obstruction is handwritten. The global composition retains the
authenticated older computational premises of the prior16 bound and its
complete dimension16 frontier. The prepared D16 census was not executed
and is not a premise. Full source and different-author composition reviews
are complete; the new discrete Lean kernel is prepared but uncompiled.
The :download:`fresh dimension15 frontier <../../results/review_arithmetic15_fresh_complete_twenty_two_group_frontier_root_full_source_acceptance_20261023.md>`
started with22 necessary groups, directly at actual total rank15. The
:download:`complete whole-B14+actual-I exclusion <../../results/review_arithmetic15_whole_b14_actual_i_all_degree_manual_root_acceptance_20261023.md>`
removes original group19. A joint head/I
scalar, cubic integer obstructions and full quadratic strips with
original time-square tests exclude every actual field in that group.
The entire source has full outside/root review after a preserved
single-exponent correction. The
:download:`complete B13 rank-two exclusion <../../results/review_arithmetic15_b13_ordinary_and_typed_seven_whole_group17_root_acceptance_20261023.md>`
also removes original17. Ordinary
spectators use only fresh6..10; actual typed-seven spectators have
fresh11/12 field estimates before E12 is used. The
:download:`complete D13 theorem <../../results/review_arithmetic15_d13_both_actual_typed_seven_and_whole_group18_root_acceptance_20261023.md>`
now removes original18 too, leaving **19 necessary groups**. Its new
typed case uses complete K7 strips and both fork lengths>6, omitting
node11 before its one paid head contradiction>1.00854.
Both have full source reviews and root acceptance. There is no14 bound,
realized example or new worker/Lean execution. The arithmetic PDF still states20.

For general compact18, the new
:download:`all-head isolated-pair theorem <../../results/review_compact18_d18_all_head_finite_isolated_pair_actual_a16_neighbor_root_full_source_acceptance_20261023.md>`
excludes EVERY finite nonright mutual angle between two isolated forks,
including unequal parameters. Its ACTUAL A16+I2 neighbor retains an
explicit comparison factor from the original maximum. The
:download:`dotted-mutual gap <../../results/review_compact18_d18_isolated_fork_mutual_four_thirds_gap_root_full_source_acceptance_20261023.md>`
forces any remaining dotted mutual to exceed4/3, with both owns dotted.
The :download:`orthogonal-pair proof <../../results/review_compact18_d18_orthogonal_isolated_pair_root_full_source_acceptance_20261023.md>`
also excludes mutual0. The
:download:`complete isolated/near3 theorem <../../results/review_compact18_d18_whole_isolated_near_three_family_root_acceptance_20261023.md>`
now excludes its entire family for every head and unequal own parameter.
An actual future core handles dotted mutuals; an actual A16+2A1
neighbor retains both reverse coordinates and the full foreign costs
in the orthogonal case. Isolated/isolated dotted pairs, isolated/far3,
other fork roles and wholeD18 remain open; there is no compact17.
The :download:`complete isolated/far3 finite-mutual reduction <../../results/review_compact18_d18_isolated_far_three_complete_finite_reduction_root_acceptance_20261023.md>`
now leaves native3 or dotted mutuals for every head, with at least one
dotted own. Native5 head leaves only dotted mutuals. Actual B18/H3
points and a continuous finite7+ core argument have full source reviews;
neither remaining case nor wholeD18 is excluded.

The finite-volume continuation has
:download:`positive native-six weights and exact incidence <../../results/review_finite57_native_six_positive_weighting_flags_and_single_factor_receiver_root_acceptance_20261023.md>`,
with :download:`all finite-factor shape minima <../../results/review_finite57_native_six_all_finite_minima_smoothed_ideal_root_acceptance_20261023.md>`.
The :download:`complete native-six finite budgets <../../results/review_finite57_all_single_native_six_finite_budgets_root_acceptance_20261023.md>`
now cover EVERY finite vertex containing native6, including Context and
all old tokens. Formal same-rank replacements, a rational certificate
and complete finite remainder bounds close the single-factor case.
The :download:`complete selected old ideal-debt theorem <../../results/review_finite57_native_six_all_old_ideal_debts_root_full_source_acceptance_20261023.md>`
now covers priorities, Context and original fixed receiving loads. The
residual bare small-factor domain now has
:download:`actual generation, separate full replay and complete ideal-budget acceptance <../../results/review_finite57_native_six_complete_weighted_ideal_budgets_root_acceptance_20261023.md>`:
all 6,626 cases across 862 profiles are strictly positive. The two guarded
units each took less than one second and 55 MiB sampled process-tree RSS.
Together with the old-debt theorem, this closes ALL selected weighted
ideal budgets. Replay uses the same implementation; no new Lean scope
is claimed. The
:download:`strict weighted global comparison <../../results/review_finite57_native_six_weighted_global_extrema_strictness_root_acceptance_20261023.md>`
is now proved from the actual weighted link graphs and global extrema.
Heavy vertices without native6 and complete face payment remain open;
there is no56.

The :download:`complete zero-exchanged far-row8 refund <../../results/review_finite57_zero_exchanged_far8_all_corner_refund_one_unit_root_acceptance_20261023.md>`
now finances every source in that subdomain. Both finite/affine corner
restrictions and fifteen exact Gram cases force actual faces to have at
least five sides. Eight unit refunds, or seven plus one unique arrival,
retain all old debts. There is no next-wall, isolation or dotted-width
assumption. Its
:download:`positive-exchange companion <../../results/review_finite57_all_far8_positive_exchange_normalized_refund_root_acceptance_20261023.md>`
now covers every positive contact on that far8 domain, sharing ONE
reverse receiver port across the zero/positive union. The
:download:`broader pure-D17 theorem <../../results/review_finite57_whole_d17_large_inert_d_far8_refund_root_acceptance_20261023.md>`
permits any inert D-factors of ranks>=9 and total40, conditional on
an actual qualifying centre, and retains the full D40+D17 old load.
Other heavy configurations and global coverage remain open; no56
or new runtime/Lean result is claimed.

The six papers
--------------

.. list-table:: Current frozen editions
   :header-rows: 1
   :widths: 53 30 17

   * - Paper
     - Result in PDF
     - Read
   * - General finite volume
     - Dimension at most57
     - :download:`48 pages <../../manuscripts/build/finite_volume57.pdf>`
   * - Sharp right-angled dimensions
     - Finite volume8; entirely ideal4
     - :download:`5 pages <../../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf>`
   * - General compact
     - Dimension at most23
     - :download:`36 pages <../../manuscripts/build/compact_farthest_vertex_bounds.pdf>`
   * - Compact arithmetic
     - Dimension at most20
     - :download:`21 pages <../../manuscripts/build/compact_arithmetic_dimension_bound.pdf>`
   * - Ideal right-angled four-volume and structure
     - Minimum, second volume, restricted chains
     - :download:`17 pages <../../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf>`
   * - Compact right-angled four-volume constraints
     - Capacity, excess and recognition
     - :download:`14 pages <../../manuscripts/build/compact_ra4_volume_constraints.pdf>`

All six are **written, compiled and internally reviewed**. The57 paper has
12 pages of main exposition and36 pages of essential appendices. The
:download:`reader index <../../manuscripts/README.md>` maps each result to its
technique, source, proof map and verification ID. Earlier notes and refinements
are not additional proposed papers.

Recent verified work
--------------------

The new compact arguments use an actual neighboring vertex and an explicit
comparison factor from the ORIGINAL farthest maximum. The neighbor is never
chosen farthest. Complete finite-white and foreign-cost analyses supply
orthogonal costs for ONE vector there. The
:download:`distinct B18 cap theorem <../../results/review_compact18_b18_distinct_terminal_caps_and_seven_common_cases_root_acceptance_20261023.md>`
and :download:`five common-cap theorem <../../results/review_compact18_b18_five_common_cases_and_two_holdouts_root_acceptance_20261023.md>`
and :download:`head-gap/H3-neighbor theorem <../../results/review_compact18_b18_zero_own_short_five_and_last_common_case_root_acceptance_20261023.md>`
first leave one terminal case. The
:download:`last common3/3 exclusion <../../results/review_compact18_b18_last_common_three_three_actual_neighbor_root_acceptance_20261023.md>`
uses a full actual A18 neighbor with comparison factor11/8, fresh .87
pressures and one funded endpoint graft. The separately reviewed complete
conjunction then closes wholeB18. The D18
:download:`dotted fork-three exclusion <../../results/review_compact18_d18_dotted_fork_three_neighbor_root_acceptance_20261023.md>`
and complete zero-own/fork7--10 theorem finish its weak-center inventory;
the :download:`full conjunction review <../../results/review_compact18_d18_unconditional_strong16_complete_conjunction_full_scope_foundations_20261023.md>`
checks that every weak-center case is covered. The wholeD18 fork budget
and compact17 remain open. These new written theorems are not full geometric
Lean formalizations.

The :download:`B16 quadratic census receipt <../../results/b16_isolated_quadratic_pair_census_verification_20261023.json>`
binds FOUR actual guarded units:43 fields and273 ordered pairs, with ONE
necessary pair. A uniform argument excludes every cubic field, and a single
original-vector estimate excludes that quadratic pair. The census is not
empty and constructs no example. The complete written proof has full
outside/root acceptance. The new A14 proof closes both actualN7/O7 and
the entire ordinaryT2 alternative. The two new A10 proofs and the A11
actual-I coupling first leave four arithmetic groups. The complete
whole-A15 conjunction first left three. The complete B15/D15 ordinary/I
conjunction first left only wholeD16. The new complete dyadic exclusion
and GLOBAL15 composition above close that final case; the older execution
records retain their individual scopes.

The :download:`zero-exchanged row7/near-row8 theorem <../../results/review_finite57_zero_exchanged_all_row7_near_row8_financing_root_acceptance_20261023.md>`
and far-row8 isolated :download:`contact3/4/parallel financing <../../results/review_finite57_far_row8_isolated_intervening_cusp_financing_root_acceptance_20261023.md>`
plus :download:`orthogonal-contact financing <../../results/review_finite57_far_row8_orthogonal_isolated_b4_cusp_financing_root_acceptance_20261023.md>`
retain all older payments. These use22 parameterized whole-cusp families,
actual source reconstruction and every prior debt. The
:download:`affected-D23 finite-contact theorem <../../results/review_finite57_far_row8_d23_finite_a21_dihedral_receiver_root_acceptance_20261023.md>`
has a unique finite receiver with full356+8=364. The D17 analogue
still has a4.5-unit deficit; dotted contacts and other source types
remain. No dimension56 theorem follows.

The :download:`explicit special-face proof <../../results/review_finite57_special_native_bond_compact_face_and_label_restriction_root_acceptance_20261023.md>`
gives a derived bound20 for finite-volume polytopes with a native5 or native7+
bond at a finite vertex, using the internal compact18 theorem. Published
compact29 alone gives31 for this restricted class. Compactness and every
intrinsic Coxeter angle of the codimension-two face are proved directly.
The finite57 application uses only published29 and leaves native6 as the
last finite5+ contact. This does not bound all finite-volume polytopes by20.

The :download:`B18 scalar kernel <../../results/lean_b18_terminal_pressure_verification_20261023/manifest.json>`
now has actual bounded compilation in1.71seconds and a SEPARATE ten-declaration
audit in1.16seconds. The audit reused its object; no successful old module
ran. All ten prints use standard foundational axioms and no ``sorryAx``.
Actual geometry, inventories, original-vector pressure and terminal sums
remain external. This is scalar verification for near3/own6, not wholeB18
or later geometric exclusions. See its :download:`logic map <../b18_terminal_pressure_kernel_logic_20261023.md>`.
Two unused-variable warnings are preserved; temporary proof work is absent.

The new :download:`B16 scalar source/map <../b16_isolated_pair_scalar_kernel_logic_20261023.md>`
has full static review and :download:`root precompile clearance <../../results/review_b16_isolated_pair_scalar_kernel_root_precompile_acceptance_20261023.md>`.
Its first admitted compile failed on two reserved local names; the failure
is preserved. The two-name repair has
:download:`outside review and root clearance <../../results/review_b16_isolated_pair_scalar_reserved_identifier_repair_root_clearance_20261023.md>`.
**No successful compilation or separate actual audit is credited.** Fresh
RAM is below the unchanged6GiB retry gate. The written mathematics and
actual census keep their separate acceptance and execution records.

The new :download:`dyadic logic map <../quadratic_dyadic_triple_kernel_logic_20261023.md>`
prepares fourteen discrete valuation, coupled-fork and norm declarations.
**No actual compilation or separate axiom audit is credited.** Field theory,
finite coefficient tables, square exceptions and geometry remain external.

The earlier :download:`A13 eleven-declaration <../../results/lean_a13_i_endpoint_graft_verification_20261023/manifest.json>`,
:download:`A12 ten-declaration <../../results/lean_a12_adjusted_loss_verification_20261023/manifest.json>`,
:download:`A18 ten-declaration <../../results/lean_a18_two_dotted_endpoint_verification_20261023/manifest.json>`
and :download:`heavy-centre eleven-declaration <../../results/lean_heavy_centre_forest_verification_20261023/manifest.json>`
audits retain their exact conditional scopes. Preparation labels are
historical; actual receipts supply execution status. Earlier failures and
resource deferrals earn zero PASS credit. No end-to-end geometric
formalization is claimed.

Both the :download:`glued H9 host <../../results/review_glued_e7_a2_two_unit_releases_original_period_and_literal_nonreflectivity_root_acceptance_20261023.md>`
and the :download:`squared-unit host <../../results/review_h9_squared_unit_e7_return_original_period_literal_nonreflectivity_root_acceptance_20261023.md>`
are now proved nonreflective by original chamber symmetries of infinite
order. The latter product has trace16phi^6=80+128phi>10; its earlier
order-two symmetry alone did not establish infinite volume. These close
two literal hosts, not their whole commensurability classes.

A different :download:`prime41 host and first actual edge <../../results/review_h9_cubed_unit_prime41_original_host_first_edge_root_acceptance_20261023.md>`
and its :download:`second actual unit edge <../../results/review_h9_prime41_second_actual_unit_edge_original_germ_obstruction_root_acceptance_20261023.md>`
are proved with complete original-lattice firstness arguments. The
:download:`third edge and original order-two symmetry <../../results/review_h9_prime41_third_actual_edge_original_involution_full_hexagon_root_acceptance_20261023.md>`
close the WHOLE compact E7 hexagon, of area4pi/3. Ambient volume remains
open; the symmetry is not an infinite period. The new
:download:`ambient continuation <../../results/review_h9_prime41_ambient_d6_pentagon_mixed_d4_original_obstructions_root_acceptance_20261023.md>`
proves three further actual walls, a full H3+D4+A1+[2b41] corner and
one whole regular right pentagon. All original norm classes, full
covectors, both embeddings, firstness and local-map obstructions are
checked. The :download:`next two actual edges <../../results/review_h9_prime41_mixed_d4_two_actual_edges_b2_double_h3_root_acceptance_20261023.md>`
reach full2H3+B2+[2b41], retaining complete six/nine-profile firstness
and the original-map obstruction. Ambient volume and an infinite period
remain open; there is still no new finite-volume example.

Read and reproduce
------------------


The :download:`whole compact quadrilateral theorem <../../results/review_h9_prime41_double_h3_whole_compact_quadrilateral_root_full_source_acceptance_20261023.md>`
continues with two original unit walls and a direct positive projection
to an already actual old wall. It closes the WHOLE two-face retaining
both H3 factors and N, with angles pi/4,pi/2,pi/2,pi/2 and area pi/4.
Every unknown original wall and the intrinsic four halfplanes are checked.
Ambient volume and a new H9 example remain unresolved.

Two further :download:`norm2 <../../results/review_h9_prime41_known_outer_gap_actual_e6_unit_cutter_root_full_source_acceptance_20261023.md>`
and :download:`norm4 <../../results/review_h9_prime41_initial_e6_a2_actual_norm_four_b3_edge_root_full_source_acceptance_20261023.md>`
actual facets have complete original-module firstness proofs. They cut
explicit open directions of successive known-wall outer polyhedra.
Full chamber volume and a new example remain unproved.

The next E6+B2 edge has a
:download:`finite-termination proof <../../results/review_h9_prime41_e6_b3_e2_relative_unit_termination_five_profiles_root_acceptance_20261023.md>`
using an original relative unit and index12 congruence. Its complete
five-profile :download:`witness/firstness packet <../../results/review_h9_prime41_e6_b2_witness_firstness_worker_contract_root_preexecution_clearance_20261023.md>`
has full source review and zero execution. No numerical next facet or
full chamber volume is claimed from this preparation.

.. toctree::
   :maxdepth: 1

   papers
   methods
   verification
   reproducibility
   scope

The `GitHub repository <https://github.com/sashakolpakov/CoxeterPolytopes>`_
contains the source arguments and evidence. Before interpreting a PASS, read
its declared scope: source review, arithmetic replay, conditional kernel logic
and full geometric formalization are different checks. The optional936-file
bulk payload has not been uploaded and is excluded from Git.
