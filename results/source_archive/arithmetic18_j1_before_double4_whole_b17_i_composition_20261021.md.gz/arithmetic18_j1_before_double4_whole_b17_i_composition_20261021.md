# Arithmetic B17+I: the simple3 short-white contact at1 is impossible

21 October2026. **Complete manual supporting candidate, pending full root and outside-author review.** No scientific, symbolic, enumeration, mathematical worker import, Lean or TeX job, field-list assumption, or manuscript edit was used. This is new work after the preceding checkpoint; it does not alter that checkpoint's three-role theorem. Root identified the additional own two-cycle integrality and proposed the norm reduction; the author independently checked the normalization, complete reductions and final contact cases. Independent review is required.

**Theorem.** At an actual farthest vertex of a compact arithmetic first-type Coxeter18-polytope with whole finite forest B17+I, where I is the actual isolated short type, the opposite in the short B17 direction cannot have exactly a simple3 contact at node1 inside the retained A16. The exclusion covers own0, every finite native own angle, parallel or dotted own contact, and every permitted finite contact with I.

Combined with the previous necessary-contact and three-role theorems, this leaves only the two double4 short-white roles, at1 or16. Neither of those is classified here. There is no exclusion of B17+I or arithmetic dimension18, no new example and no seventh manuscript.

## 1. Inputs and actual endpoint geometry

Paths are under `results/` except the manuscript.

| Input | SHA-256 | Used interface |
|---|---|---|
| arithmetic18_simple_short_white_role_exclusions_20261021.md |e85f2c4d4eccaa9543cc2d17fb693fdb313280839343e443070d29983232f3a4|Sections1–2's same-vector first6/I reference and necessary short-edge bound C<=47/5, not its separately stated j2/15/16 conclusions|
| arithmetic18_actual_dotted_short_cap_continuation_20261021.md |54938d11b9c5b232a88dba4663b130592ae6d00fe59e17c55e8fe82106d84c35|Actual I wall and prefix6..15 interfaces; necessary six-role white list; NOT its isolated-cap parameter bound|
| arithmetic_uniform_classical_weak_helper_obstruction_20261021.md |535ac0d0fa92d28ccab2976fa147a4ccff0bd3bfcd1e04ca4e134c6ae6857905|Rescaling root lines OVER the actual field, cyclic integrality and nonphysical positive definiteness|
| manuscripts/compact_arithmetic_dimension_bound.tex |5d5235dab7a1842e2fa3a9b0559220957a775608bb61e3097f5fbb17aec8caba|Named Meyer obstruction for compact rational first-type forms, lines1308–1310|

Compact acute simplicity, finite spherical Coxeter classification and quadratic integer-basis facts are explicit foundations. No whole-D19 field conclusion is transferred.

Use the same unit normal convention as the first input:

    n_i=(e_i-e_(i+1))/sqrt2 (1<=i<=16), n17=e17,
    P_i=e1+...+e_i,

and let e be the orthogonal unit I normal. The actual opposite with simple3 helper at1 is

    c=A*p-gamma*P17-P1/sqrt2-beta*e,
    a=2sqrt2*gamma,
    A²=(17a²+4a-4)/8+beta², A>0.                (1)

The endpoint retains A16 and I. The A16 path plus c is A17; a finite extension at the new endpoint can only be A18 or B18. Thus the COMPLETE I-contact list is

    beta=0, 1/2 or1/sqrt2.                      (2)

Own gamma is0, cos(pi/m) for integer m>=3,1 for parallel, or>1 for dotted. For every positive-own case a>=sqrt2. Own0 already fails(1), since beta²<=1/2 gives A²<=0. It remains to exclude all positive-own cases.

On the actual short edge put v=P17/sqrt17. Projection of c onto its Lorentz edge plane gives spatial coefficient

    b=(17a+2)/(2sqrt34),
    delta=b²-A²=9/17-beta²>0,
    C=cosh L=b/sqrt(delta).                     (3)

This is the actual finite endpoint `q=Cp-sqrt(C²-1)v`, with inward minus sign. It uses no formal completion. The first input's same-vector certificate, proved from the complete prefix6..15 and the actual I barrier, supplies C<=47/5 independently of the cap's helper type. It charges the I energy once. Applying that NECESSARY bound here is not a second energy gain and does not assume the present role exclusion.

Because beta0 has the largest residual, (3) gives

    C>=(17a+2)/(6sqrt2),
    a<23/5.                                    (4)

For a rational seal use sqrt2<17/12 in `17a+2<=282sqrt2/5`, giving a<779/170<23/5. This replaces, rather than transfers, the earlier isolated-cap physical bound.

## 2. Two different actual cycles and the actual ground field

Normalize the old B17 long roots over K to square2, its short root to square1, and c to square2 using the actual simple3 helper. The raw helper product is-1 and the raw short-own product is-a/2. No sqrt2 extension of K is made by the unit-coordinate notation in(1).

The simple cycle from c through node1 along the old chain to17 and back has Cartan product plus or minus a. The OWN two-cycle has Cartan product

    4(-a/2)²/(2*1)=a²/2.

Both are actual cycles of root lines. Arithmetic cyclic integrality therefore gives the two separate constraints

    a in O_K, B=a²/2 in O_K.                   (5)

The second is essential; integrality of a alone would leave a larger degree bound.

The raw old B17+c Schur complement is

    2-(17a²/4+a+1)=-(17a²+4a-4)/4<0.           (6)

It is negative for every a>=sqrt2, independently of beta. Thus this actual principal Gram is Lorentzian. If K properly extended Q(a), a nonidentity real embedding fixing a would preserve its Lorentzian Gram inside a positive definite nonphysical ambient form. That is impossible, so ACTUAL K=Q(a). At every nonphysical embedding strict Schur positivity consequently forces

    17a_sigma²+4a_sigma-4<0,
    (-2-6sqrt2)/17<a_sigma<(-2+6sqrt2)/17.       (7)

Using sqrt2<17/12 gives the convenient rational consequences

    |a_sigma|<5/8,
    a_sigma>0 implies a_sigma<2/5.              (8)

These are bounds for every nonidentity embedding of the actual field. No primitiveness assertion about B is needed below.

## 3. Complete integral norm reduction

The physical bound(4) and the conjugate bound(8) give

    0<B<11,
    0<B_sigma<25/128<1/5.

If d=[K:Q]>=3, the nonzero integral norm of B is strictly between0 and

    11*(1/5)^(d-1)<=11/25<1,

impossible. If K=Q, its actual-field identity was already proved in Section2; the compact rational first-type form in19 variables is excluded by Meyer. Therefore K is quadratic.

Let a' be its other conjugate and N=Norm_K(a), a nonzero integer. By(5),

    Norm_K(B)=N²/4 is an integer,

so N is even. Equations(4),(8) give |N|<23/8<3, hence N=2 or-2. Positive N would mean a'>0 and imply N<(23/5)*(2/5)=46/25<2. Thus

    N=-2, a'=-2/a.

The negative strip implies a>16/5. Its integral trace T=a+a' therefore satisfies

    103/40<T<a<23/5<5,
    T=3 or4.                                  (9)

There are exactly these two possible minimal polynomials `X²-TX-2`; no finite list has been guessed or enumerated.

T3 is impossible because B is integral whereas

    Tr_K(B)=(T²-2N)/2=13/2.

Equivalently, a=(3+sqrt17)/2=1+theta17 gives B=(5+3theta17)/2 outside O_K=Z[theta17], theta17=(1+sqrt17)/2. The ONLY surviving parameter is consequently

    a=2+sqrt6, K=Q(sqrt6), B=5+2sqrt6.          (10)

This reduction treated every positive native own contact at once. In particular (10) has a>4>2sqrt2 and is dotted; finite and parallel own contacts have already been excluded, without a cyclotomic label census or published field list.

## 4. All remaining I contacts

For either positive I contact in(2), delta<=9/17-1/4=19/68. Since (10) gives a>4, formula(3) implies

    C>=(17a+2)/sqrt38>70/7=10>47/5.

This contradicts the SAME necessary edge bound from Section1. It closes both native3 and native4 I contacts, with no additional I charge or separate optimized reference.

It remains beta0. Put s=sqrt6. Equation(1) becomes

    A²=87/4+9s.                                (11)

The ACTUAL isolated-I opposite is

    c_I=sqrt(h)*p-sqrt(1+h)*e, 0<h<1/2.

Its own two-cycle makes J=4(1+h) an algebraic integer in K, with

    4<J<6, 0<J'<4.                             (12)

The second strip follows from the strictly positive definite nonphysical two-root Gram. In O_K=Z[s], write J=m+n s. Since J>J', n is positive; the gap<6 forces n=1. The physical strip allows m=2 or3, and positive J' rules out m2. Therefore the COMPLETE list is the single value

    J=3+s.

The two actual walls c,c_I are distinct: c has nonzero product at old node1, while c_I has none. At beta0 their unit product is -A*sqrt(h). Its actual two-cycle must therefore satisfy

    4(c.c_I)²=A²(J-4)
       =(87/4+9s)(s-1)
       =(129+51s)/4 in Z[s].                   (13)

Both integer-basis coefficients fail divisibility by4. This contradicts cyclic integrality and eliminates the last case.

## 5. Exact conclusion

Own0 failed before the field reduction; every positive finite, parallel and dotted own case is exhausted by Sections2–4. The complete finite endpoint list(2) is also exhausted. Thus the literal simple3-at1 short-white role is impossible.

The proof uses primitive actual-wall cycles and the derived necessary edge bound, not a desired role conclusion, a field-list premise, a D19 theorem, an isolated-B parameter bound or an auxiliary vector declared to be a wall. All six primary papers, prior accepted sources and the preceding checkpoint remain unchanged. The only remaining nonisolated short-white alternatives after combining the earlier three-role theorem are double4 at1 and16; no assertion about those roles or a lower global ceiling is made.
