What has actually been verified
===============================

There are four distinct layers: written mathematical proof, replay of finite
certificates, compiled conditional Lean logic, and full geometric formalization.
A successful source hash or PDF build is not a mathematical verification.
The :download:`current bounds guide <../current_bounds_and_verification.md>`
and each proof map identify the premises left external.

Papers and later bounds
-----------------------

All six paper editions are written, compiled and internally reviewed, with
matching source/PDF/build records. Their
:download:`delivery receipt <../../results/six_paper_final_tex_delivery_20261021.json>`
retains those exact editions. General compact18 and arithmetic16 are later
supporting arguments; the frozen PDFs still state23 and20. No externally
refereed status or complete geometric Lean formalization is claimed.

.. list-table:: Current verification boundaries
   :header-rows: 1
   :widths: 27 73

   * - Package
     - Actual evidence and limit
   * - Finite volume57
     - Complete written composition review. All25 bounded B13/frontier replacements passed and are integrated; matching inherited records cover111 other script selections. No combined146-job runtime PASS or complete transitive regeneration.
   * - Compact18
     - Complete written composition, outside review and root acceptance. Its five-declaration conditional composition compiled and passed a separate actual audit under23 written inputs.
   * - Arithmetic16
     - Complete written composition and reviews over every actual admissible field. Its three-declaration conditional composition and separate thirteen-group frontier kernel passed their actual compile/audit batches.
   * - Sharp right-angled8/ideal4
     - Complete5-page paper, internal reviews, exact polynomial/model checks and selected compiled projection/height/count logic. Published facet/code/classification results and actual geometry remain external.
   * - Ideal RA4 volume/structure
     - Complete17-page paper, reviewed arguments, exact checks and selected conditional logic. No complete geometric Lean proof.
   * - Compact RA4 constraints
     - Complete14-page paper, reviewed capacity/excess arguments and exact checks. No proof of the absolute volume minimum or unique second-volume double.

Relevant maps and actual records:

* :download:`Finite57 proof map <../finite_volume57_lemma_map.md>`
* :download:`Finite57 reproduction guide <../finite_volume57_reproduce.md>`
* :download:`Complete bounded-loader integration <../../results/finite57_complete_loader_catalogue_integration_20261022.json>`
* :download:`Compact18 composition logic <../compact_dimension_eighteen_composition_logic_20261022.md>`
* :download:`Compact18 actual compile/audit receipt <../../results/lean_compact18_composition_verification_20261022/manifest.json>`
* :download:`Arithmetic16 composition logic <../arithmetic_dimension_sixteen_composition_logic_20261022.md>`
* :download:`Arithmetic16 actual compile/audit receipt <../../results/lean_arithmetic16_composition_verification_20261022/manifest.json>`
* :download:`Arithmetic16 thirteen-group logic <../arithmetic_sixteen_frontier_refinement_logic_20261022.md>`
* :download:`Arithmetic16 thirteen-group actual receipt <../../results/lean_arithmetic16_frontier_thirteen_group_verification_20261022/manifest.json>`
* :download:`Sharp right-angled proof map <../right_angled_sharp_dimensions_publication_proof_map_20261021.md>`

New continuous scalar kernel
----------------------------

``CoxeterProofs.A18TwoDottedEndpointScalarKernel`` has a
:download:`bounded compile and separate ten-declaration actual audit PASS <../../results/lean_a18_two_dotted_endpoint_verification_20261023/manifest.json>`.
Its :download:`source <../../formal/CoxeterProofs/A18TwoDottedEndpointScalarKernel.lean>`
uses Std only and a genuine generic ordered ring. It derives three radical
chords from exact square-gap identities, the tangent estimate, continuous
core gap, both endpoint gains, one completed square and all four end budgets.

The :download:`immutable preparation map <../a18_two_dotted_endpoint_scalar_kernel_logic_20261023.md>`
identifies actual geometric pressures, all-hole inventories, individual legal
prices, orthogonality, reference norm floors and a real interpretation as
premises. These are theorem parameters, not entries in Lean's printed
foundational axiom list. The source supports the TWO-DOTTED branch, not a
whole-A18 exclusion or the later full mixed-end theorem by itself.

Compilation took3.25seconds and the admitted separate audit1.77seconds.
All ten actual printed sets contain exactly ``propext``, ``Classical.choice``
and ``Quot.sound``. There is no ``sorryAx``. The
:download:`complete actual stdout <../../results/lean_a18_two_dotted_endpoint_verification_20261023/axiom_stdout.txt>`
retains one unused-variable warning. No cosmetic rerun was made. The earlier
:download:`audit admission refusal <../../results/lean_a18_two_dotted_endpoint_verification_20261023/audit_admission_deferral.txt>`
and :download:`pre-audit receipt <../../results/lean_a18_two_dotted_endpoint_verification_20261023/pre_audit_manifest.json>`
are preserved. Owned work is absent; its691656-byte object is an ignored cache.

Later written frontiers do not enlarge older kernels
----------------------------------------------------

The complete :download:`B17+actual-I exclusion <../../results/review_compact18_whole_b17_actual_i_and_four_group_frontier_root_acceptance_20261023.md>`
and :download:`D17+actual-I exclusion <../../results/review_compact18_whole_d17_actual_i_and_three_group_frontier_root_acceptance_20261023.md>`
first leave three necessary groups. The complete
:download:`whole-A18 exclusion <../../results/review_compact18_whole_a18_and_two_classical_group_frontier_root_acceptance_20261023.md>`
then leaves only wholeB18 or wholeD18 at that same vertex. It includes all
actual endpoint contacts, the native-gap orthogonality step and one positive
H4+A1 projection with all legal prices. The full theorem is written and
internally reviewed, not Lean-verified; the scalar module above proves only
its older two-dotted branch. The global compact ceiling stays18, and neither
remaining group is an example.

The older :download:`five-case endpoint logic map <../general_eighteen_endpoint_refinement_logic_20261023.md>`
retains its :download:`eleven-declaration actual audit PASS <../../results/lean_general18_endpoint_refinement_verification_20261023/manifest.json>`
for its original five-case deduction and finite analytic integer seals.
Eight prints are axiom-free; the other three use propext/Quot.sound.
Its successful six-case dependency was reused, not rerun or relabelled.
The newer written exclusions are not automatically formal instances of it.

Finite-volume discharge and construction
----------------------------------------

The accepted :download:`isolated finite-cap financing <../../results/review_finite57_all_isolated_finite_short_fork_receivers_root_acceptance_20261023.md>`,
:download:`ideal-centre financing <../../results/review_finite57_ideal_fork_centre_joint_parallel_financing_root_acceptance_20261023.md>`
and :download:`finite-centre safe union/escape theorem <../../results/review_finite57_finite_centre_safe_union_and_heavy_escape_root_acceptance_20261023.md>`
have full written proofs, different-author reviews and root acceptances.
The finite table retains every costly/overloaded holdout. A component escape
is not a Hall condition or a sufficient receiving budget. No56 theorem follows.

The :download:`glued-host B3 continuation <../../results/review_glued_e7_a2_three_actual_edges_and_original_b3_break_root_acceptance_20261023.md>`
and :download:`heptagon plus ambient-e2 continuation <../../results/review_glued_e7_a2_heptagon_and_ambient_e2_edge_full_scope_root_acceptance_20261023.md>`
prove actual original-lattice edges and full germs, including all unknown-wall
firstness. The heptagon is a two-face, not a finite-volume nine-dimensional
chamber. Both immediate matching maps fail original integrality; no later
period, example or reflectivity conclusion is inferred.

Reproduction and resources
--------------------------

Use named batches in the :download:`formal guide <../../formal/README.md>`
and :download:`computational proof contract <../computational_proof_contract.md>`.
One scientific/Lean/TeX child runs at a time under the shared exclusive lock.
Admission requires40GiB free disk and6GiB available RAM. Script/TeX batches
use59seconds/1GiB/one thread; Lean2048MiB/one thread followed by a SEPARATE
actual audit. Remove owned unused build products after each batch. Start
cleanup below20GiB disk; preserve mathematical sources and evidence.

Strict Sphinx and actual staged-index hygiene checks use the separate
publication watchdog and do not run mathematics. Generated sites, compiler
objects and caches are not publication assets. The optional936-file bulk
payload remains unuploaded and excluded from Git. The preceding reader
guides are :download:`byte-preserved <../../results/source_archive/reader_guides_before_classical_frontier_refresh_20261023/manifest.json>`;
historical receipts retain their original bindings.
