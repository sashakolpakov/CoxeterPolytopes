# The six papers and their techniques

There are **six current paper families**, with written, compiled and internally
reviewed TeX/PDF editions. The compact17 and arithmetic15 supporting improvements
belong in the existing compact families when integrated. They are not extra
papers, and the frozen PDFs still state23 and20. Earlier TeX notes, fragments,
predecessors and generated atlases are preserved supporting material.

| Paper and TeX | Main technique | Result in this PDF | PDF | Proof/reproduction map | Verification ID |
|---|---|---|---|---|---|
| [General finite volume](finite_volume57.tex) | Corner payments, Coxeter forests and cusp curvature | Dimension at most57 | [48 pages](build/finite_volume57.pdf),12 main +36 essential appendices | [Proof map](../docs/finite_volume57_lemma_map.md) | `finite57` |
| [Sharp right-angled dimensions](right_angled_sharp_dimension_bounds_publication.tex) | Actual projections, descending heights and spherical codes | Finite volume at most8; entirely ideal at most4; both internally sharp | [5 pages](build/right_angled_sharp_dimension_bounds_publication.pdf) | [Proof map](../docs/right_angled_sharp_dimensions_publication_proof_map_20261021.md) | `right_angled_sharp` |
| [General compact](compact_farthest_vertex_bounds.tex) | One farthest vertex and additive component energies | Dimension at most23; later supporting proof17 | [36 pages](build/compact_farthest_vertex_bounds.pdf) | [Proof map](../docs/compact_farthest_vertex_bounds_proof_map_20261020.md) | `compact_farthest_bounds` |
| [Compact arithmetic](compact_arithmetic_dimension_bound.tex) | Field reduction and exact angle rules, with the same geometric budget | Dimension at most20; later supporting proof15 | [21 pages](build/compact_arithmetic_dimension_bound.pdf) | [Proof map](../docs/compact_arithmetic20_proof_map.md) | `compact20` |
| [Ideal RA4 volume and structure](ideal_ra4_volume_and_structure_publication.tex) | Volume gap, equality recognition and restricted decomposition | Published minimum; second volume and unique double; restricted24-cell chains | [17 pages](build/ideal_ra4_volume_and_structure_publication.pdf) | [Proof map](../docs/ideal_ra4_volume_and_structure_proof_map.md) | `ideal_ra4_volume_and_structure` |
| [Compact RA4 volume constraints](compact_ra4_volume_constraints.tex) | Facet capacity, excess and recognition | Necessary volume/structure constraints | [14 pages](build/compact_ra4_volume_constraints.pdf) | [Proof map](../docs/compact_ra4_volume_constraints_reproduce_20261019.md) | `compact_ra4` |

The57 and sharp right-angled papers are the priority entry points. The
[current comparison guide](../docs/current_bounds_and_verification.md) distinguishes
published bounds, supporting improvements and actual verification. The
[detailed result correspondence](../docs/result_manuscript_correspondence.md)
preserves the longer provenance. The
[six-paper delivery receipt](../results/six_paper_final_tex_delivery_20261021.json)
binds the matching frozen sources, PDFs and build records.

## Where the common arguments split

Finite57 first establishes one simultaneous corner-payment rule. Finite vertices
then require exact spherical-forest maxima; ideal vertices require affine-factor
charges and actual cusp multiplicities. Both branches reunite in one incidence
contradiction. The higher-dimensional tail is separate and does not assume a
facet is itself Coxeter.

The compact proofs start with the same original farthest vector. Ordinary,
large-A and large-B/D component estimates have separate geometric arguments,
then reunite through additive squared norms. Rank-specific endpoint and fork
cases close the surviving configurations. Arithmeticity adds field/angle
restrictions rather than a second unrelated geometric framework.

The sharp right-angled paper shares one actual projection lemma between its
general and entirely ideal cases. Spherical-code estimates and the relevant
published facet minima enter at clearly identified later steps. Its internally
sharp8/4 bounds do not assume arithmeticity.

The ideal four-dimensional paper combines the published minimum, second-volume
recognition and restricted24-cell chains as one sequence. It does not classify
arbitrary ideal right-angled polytopes as24-cell garlands. The compact RA4 paper
does not prove that the120-cell is the absolute volume minimum, nor that its
double is the unique second-volume example; those remain open here.

## Supporting research and actual checks

The later compact17 and arithmetic15 arguments are complete reviewed written
supporting proofs. Their frozen paper editions remain23 and20. Consolidate
future improvements within those families rather than create a paper per
numerical increment. The [result correspondence](../docs/result_manuscript_correspondence.md)
links the individual sources, reviews, accepted interfaces and verification.

The [general compact17 theorem](../results/compact_dimension17_global_written_acceptance_20261024.json)
now excludes wholeD18, the only necessary alternative at exact18. The prior
global18 tail excludes higher dimensions. The final dotted-head argument
uses an actual head point, four complete initial references, BOTH individual
anchor prices and a fresh local whole-A18 lemma. All use the SAME original
farthest vector and every actual wall; no arithmeticity is assumed.
Its [full root acceptance](../results/review_compact_dimension17_whole_d18_and_global_composition_root_acceptance_20261024.md)
records the complete different-author review and21 bound inputs. The
[two conditional Lean sources](../docs/compact_dimension17_conditional_logic_map_20261024.md)
have complete static reviews; neither has been compiled or actually
axiom-audited because RAM failed the6GiB admission gate. A fresh exact17
forest analysis now has a [complete reviewed necessary cover](../results/review_compact_dimension17_fresh_complete_necessary_cover_root_acceptance_20261024.md)
with thirteen conservative dominant rows, retaining H3/H4 under BOTH
typed-seven roles. The later whole-family
[A11/A12](../results/review_compact17_whole_a11_a12_fresh_four_foot_root_acceptance_20261024.md)
and [A14](../results/review_compact17_whole_a14_point79_all_feet_root_acceptance_20261024.md)
exclusions remove three rows. The
[fresh classical-tail proof](../results/review_compact17_whole_d14_and_b15_d15_rank_two_tails_root_acceptance_20261024.md)
also closes wholeD14 and every B15/D15 rank-two spectator with
energy>3/19, leaving nine dominant rows and only ACTUAL N7/O7
beside B15/D15. These are complete original-vector arguments,
including all isolated feet and paid helper corrections. No16 ceiling
or new example follows.
Arithmetic15 now retains thirteen necessary groups. The
[complete A13+ordinary-A2 proof](../results/review_arithmetic15_a13_ordinary_a2_whole_original12_root_acceptance_20261024.md)
closes original12 when combined with the accepted old-label-at-least4
and two-ordinary-A1 theorems. It retains all foreign contacts and uses
one ALL-foot reference, a common actual triangle and Cartan determinants.
These field and integrality arguments use arithmeticity; the general
compact exclusions do not. No arithmetic14 bound follows.
The [new arithmetic common-cap alphabet](../results/review_arithmetic_large_a_common_end_cap_trace_alphabet_root_acceptance_20261024.md)
uses a local Lorentzian principal to identify the ACTUAL field, then an
exact trace bound and native-angle tests. Five fields survive at its
stated cap interface; this is not a global field list or a new exclusion
among the thirteen remaining groups.

Toward finite volume56, all selected weighted ideal budgets and all native6
finite budgets are accepted. Actual generation and separate replay cover
6,626 small-factor ideal cases. The new polygon-refund method also finances
complete centre-exit rows5 and11 for literal2D17+D23. Both positive far-row6
rank cases now have complete refund/receiver proofs too. ALL positive
near-row6 exits are now financed at both ranks: exceptions use full
actual receiving budgets, while regular arrivals pay for themselves with
distinct receiver-corner refunds. The original dual-index error and a
later omitted old-V23 debt are both preserved with their exact repairs.
An all-actual-facet extension restricts finite native labels to2/3/4/6
at dimension57. ALL positive NEAR end3 row4 exits are now financed at both
ranks, sharing one old-plus-new exception reserve and refunding distinct
regular receiver corners. The corrected raw A15 charge362 is retained.
The complementary [complete FAR-end3 proof](../results/review_finite57_far_end_three_and_whole_row_four_root_acceptance_20261024.md)
now closes ENTIRE row4. Quadrilateral sources transfer8 with no corner
refund; regular cases use actual larger polygons. All36 ideal parent
templates and old debts fit one shared8N union. The
[complete positive-NEAR8 theorem](../results/review_finite57_positive_near_eight_and_entire_row_eight_root_acceptance_20261024.md)
now closes ENTIRE row8 too, together with accepted zero-NEAR8/all-FAR8.
Four paired actual corner refunds preserve the old B22 receiver unit;
all E8 exceptions share ONE full8N reserve. The corrected
[positive NEAR7 proof](../results/review_finite57_all_near_row_seven_corrected_root_acceptance_20261024.md)
now covers both ranks too. Its full D5/A11 charge includes the two
omitted ordinary cross units; the failed predecessor is preserved.
The [per-port composition theorem](../results/review_finite57_all_centre_port_activation_near_seven_and_conditional_l12_root_acceptance_20261024.md)
allows unused covered ports at already-paid sources and finances every
full component with b_F<=c+1, where b_F counts positive FAR7 exits and
c its original heavy-centre components. That condition is not established
universally. Positive FAR7, other finite forests, zero-arrival A16 receivers
and complete face/source coverage remain open; no56 theorem follows.

The compact spectral work proves a full-wall Gram band and a fourth-order
transverse obstruction. Its unknown-return and bounded central-prefix work
has no numerical bound or execution credit. Construction research has one
new actual original H9 facet and E6+B2+A1 endpoint after four authenticated
units, followed by a manually proved J facet and full E6+H3 endpoint.
On a separate branch, complete closed strips identify the new actual R7
facet with D7+2A1 endpoint; an old-U edge reaches D6+3A1. All four direct
matches to the earlier such germ are nonoriginal. This is no period or
volume theorem. A fresh mixed direction proves the50-entry recorded
outer relaxation still has infinite volume; unknown walls may cut it.
The [next short-leaf edge](../results/review_h9_prime41_p7_short_leaf_actual_e7_return_root_acceptance_20261024.md)
now has unique actual R* and full E7+2A1 endpoint. All eleven necessary
first-wall profiles are covered by original parities and closed strips
at both embeddings, including a redundant same-time root. The metric
return is a nonoriginal order-two reflection. The
[next original norm4 facet B*](../results/review_h9_returned_e7_actual_dyadic_edge_return_words_and_outer_gap_root_acceptance_20261024.md)
has a fresh complete firstness proof and full E7+[4]+[2b41] endpoint.
The enlarged54-entry outer relaxation still has infinite volume; every
nonzero alternating power of the natural returns is nonoriginal.
Full-chamber volume remains open.
The prepared Y-release worker was not run or used. Ambient finite volume and
a new example remain open. These are supporting
methods and research notes, not additional paper editions.

Finite57's25 bounded replacement units have actual PASS and catalogue
integration. Its full136-script/nine-Lean-root/one-PDF selection has no combined
146-job replay or complete transitive regeneration; the111 other command
matches retain inherited execution scope. The core11 selection is unchanged.
See the [reproduction guide](../docs/finite_volume57_reproduce.md).

Selected Lean packages have compilation and SEPARATE actual axiom audits,
including the new [fourteen dyadic declarations](../results/lean_quadratic_dyadic_triple_verification_20261023/manifest.json)
and [twelve repaired B16 scalar declarations](../results/lean_b16_isolated_pair_scalar_verification_20261023/manifest.json).
Their [logic maps and receipts](../formal/README.md) retain the external geometric,
field, classification and enumeration premises. This is not a complete geometric
formalization. A compiled PDF, a source review and an executed replay remain
different evidence. All six TeX/PDF bindings stay unchanged.
