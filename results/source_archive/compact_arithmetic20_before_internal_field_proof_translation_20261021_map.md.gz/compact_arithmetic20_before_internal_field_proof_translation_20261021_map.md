# Compact arithmetic dimension20: proof and reproduction

The current [manuscript](../manuscripts/compact_arithmetic_dimension_bound.tex) proves the
internally checked compact arithmetic ceiling20. This supersedes the
compact ceiling21 as a current result; the older21 package remains an
essential preserved proof input. The noncompact arithmetic ceiling21 and
the combined finite-volume arithmetic ceiling21 are unchanged.

The current publication source is
[compact_arithmetic_dimension_bound.tex](../manuscripts/compact_arithmetic_dimension_bound.tex).
It excludes the parked dimension19 refinements and now spells out the
finite seed boxes, contact-queue termination/coverage and forest algorithm.
The [fresh source exposition audit](../results/review_compact_arithmetic20_exposition_finite57_20261020.md)
passes at the declared finite-data and companion-theorem interfaces. Its
[17-page PDF](../manuscripts/build/compact_arithmetic_dimension_bound.pdf)
has a successful bounded build with zero warnings, recorded in the
[six-paper completion receipt](../results/six_paper_pdf_completion_20261020.json).
The source/PDF bindings remain unchanged. The six universal conditional
Lean roots retain their existing compilation records; a PDF build does
not constitute a fresh full-package mathematical replay.

The original combined
[20-page source](../manuscripts/compact_arithmetic20.tex) and
[PDF](../manuscripts/build/compact_arithmetic20.pdf), both parked appendices,
the76-input manifest and all previous execution records remain unchanged
at their original paths. The catalogue id for that preserved version is
`compact20_with_parked_refinements`; it is not an additional current paper.
The [ten-job universal core](../results/compact20_core_verification_20261019.json)
and [eleven-job combined predecessor core](../results/compact20_nine_field_core_verification_final_20261020.json)
retain their original source/assumption scopes. They are not presented as
fresh verification of the publication successor.

The new theorem has a written universal-composition proof and independent
exact checks. It has not been externally refereed or formalized end to end
in Lean. No example in dimension20 or sharpness assertion is made.

The subsequent [reviewed structural batch](../results/compact21_frontier_and_arithmetic_a_packing_acceptance_20261021.json)
adds an all-field [whole B20 exclusion](../results/arithmetic_whole_b20_shifted_norm_and_d20_obstruction_candidate_20261021.md)
and [central A cap packing with A18/A19 consumers](../results/arithmetic_large_a_central_cap_packing_20261021.md).
Together with the prior D19+I exclusion, only whole D20 remains in the
classical dimension20 sector; whole A20 and smaller A alternatives were
still open at that checkpoint. These are written mathematical results, with full root and
separate-agent reviews, not a ceiling19 theorem or new Lean coverage.
They use the farthest-vertex paper's shared geometry and add arithmetic
conjugate restrictions; they do not reopen the parked field refinements.

The [next accepted batch](../results/whole_a20_and_two_end_couplings_written_acceptance_20261021.json)
excludes **whole A20 over every actual ground field**. It classifies
the changed loss-.58 window, excludes the extra golden caps and sums
actual isolated dotted feet, including adjacent ones; its final exact
energy lower bound is1.002147>1. Whole D20 and smaller A alternatives
remain, so no ceiling19 follows. The [generic summed-foot kernel](summed_actual_foot_kernel_assumptions_20261021.md)
now compiles and passes a separate ten-declaration axiom audit. Actual
geometry, the complete cap inventory and concrete scalar estimates are
outside this kernel; it is not an end-to-end A20 formalization. The
current20-stage TeX/PDF is unchanged, and no parked field case is used.

## Mathematical dependency chain

1. The [completed compact arithmetic21 package](compact_arithmetic21_proof_map.md)
   excludes dimensions22 through29 by24 field/dimension branches, and the
   published compact29 theorem excludes higher dimensions.
2. At21 the [single-field reduction](../results/fresh_compact21_single_field_20261016.md)
   uses the thirteen-field list valid from dimension14. It excludes twelve
   branches, including the rational field and the actual biquadratic field
   Q(sqrt2,sqrt5). Only the actual field Q(sqrt5) remains. The shorter field
   list starting at22 is not used at21.
3. The final actual touching contact star of any unpaid quadrilateral is
   covered by the inherited complete queues. Its marked components are
   whole, and all remaining factors are common orthogonal spectators.
   Expandable singular states remain stopping obligations. This internal
   geometric proof is essential to evaluating the new angle rule.
4. With k whole copies of a rank-r hub, the r²*binom(k,2) cross-component
   angles share a nonnegative pool. Summing contributes that pool once to
   the vertex budget. Full hub counts choose pools; capped contexts choose
   the old additive bonuses. D5/H4 physical exceptions are retained with
   their independently reviewed geometric consumer proofs.
5. The new rational rule pays every relevant quadrilateral and has complete
   finite-forest allowance at most40. A separate implementation reconstructs
   both statements; it imports none of the new coefficient, recurrence or
   solver helpers.
6. Nonnegative angle weights, triangle payment>=2 and quadrilateral
   payment>=1 imply total weight>=5f2-210v. Symmetry and nonnegativity of
   the21-dimensional h-vector give total weight>=40v+550, contradicting
   the exact upper40v. Equality at the average threshold is sufficient.

The full [universal composition report](../results/compact_arithmetic20_universal_composition_20261018.md)
and [root mathematical review](../results/review_compact_arithmetic20_composition_root_20261018.md)
state these arguments and their inherited dependencies explicitly. Internal
coverage and incidence lemmas are not relabeled as published assumptions.

## Exact evidence and what was run

|Layer|Result|Verification scope|
|---|---|---|
|Literal native face payments|1979 faces,102917 common-spectator cases; minimum60007431727/60000000000>1|Independent exact rational coefficients and actual full-count denominators.|
|Complete finite forests|68 types,729 exact hub tuples,850 final offers; maximum40 atD21|Independent reverse-alphabet unbounded recurrence, including all physical exceptions.|
|Final field/dimension composition|13 branches at21 and24 higher branches; compact ceiling20|Exact final arithmetic and streamed recursive source audit.|
|Recursive source integrity|107 manifests,228 distinct files,502126809 bytes streamed|1359 source references checked; historical Gram queues were not regenerated.|

Root independent execution7766fb took4.121seconds and peaked at85.7MB
process-tree RSS. The [independent ledger](../results/fresh_compact21_self_hub_exact40_independent_check_20261018.json)
pins the final candidate. Final composition64777c took0.79seconds with
74.6MB peak process-tree RSS; its
[certificate](../results/compact_arithmetic20_composition_20261018.json) and
[execution ledger](../results/compact_arithmetic20_composition_execution_20261018.json)
are separate. These were59-second,1GiB,one-thread batches under the shared
lock and40GiB/6GiB start gates.

The single numerical solve proposed coefficients. Its initial rational
rounding gave40+3e-10. The final solver-free reconstruction replaces five
nearly integral entries by0,0,0,36,39 and rechecks every face and complete
forest bound exactly. Numerical closeness is used only to choose a
candidate, never to accept an inequality. The
[reconstruction report](../results/fresh_compact21_self_hub_exact40_reconstruction_20261018.md)
preserves both the proposal and earlier failed reconstruction attempt.

## Solver-free reproduction

Run these as separate serial batches from the repository root:

```sh
python3 -B scripts/run_bounded_research_check_20261018.py -- scripts/fresh_compact21_self_hub_exact40_reconstruction_20261018.py --verify
python3 -B scripts/run_bounded_research_check_20261018.py -- scripts/check_compact21_self_hub_primal_independent_20261018.py --candidate results/fresh_compact21_self_hub_exact40_reconstruction_20261018.json
python3 -B scripts/run_bounded_research_check_20261018.py -- scripts/check_compact_arithmetic20_composition_20261018.py --verify
python3 -B scripts/build_illustrated_ra_manuscript_20261018.py manuscripts/compact_arithmetic_dimension_bound.tex --check-only
```

The first two reconstruct different coefficient/forest implementations.
The third binds their exact results to the old field proofs, checks the
eleven symmetric h-pair coefficients and streams large source maps/hashes.
It does not load a giant scientific JSON merely to read its source map.
The fourth checks typesetting, removes temporary build files and preserves
any existing PDF. All jobs must retain the repository resource guards;
missing start memory is a reason to defer a job, not to bypass the gate.
The common wrapper supplies a live process-tree monitor even when a direct
checker entry point has only its own alarm and periodic resource checks.

## Lean boundary

The existing project verifies the strict weighted h-vector implication
and conditional field composition for the older result. The new geometric
whole-star coverage, same-hub rule, D5/H4 incidence arguments, complete
rational coefficient evaluation and full field-specific proofs are not
all represented by a checked Lean theorem. A formal theorem assuming those
internal conclusions would verify only the final implication. Published
structural inputs may be explicit assumptions; the new internal arguments
remain obligations to prove. Research and exact checks precede those
formalization batches.

The new [Lean source](../formal/CoxeterProofs/CompactArithmetic20.lean)
checks the paired coefficients,550 endpoint surplus and scaled
contradiction. [ManuscriptCompact20](../formal/CoxeterProofs/ManuscriptCompact20.lean)
then derives the ceiling from separately typed published, exact-script,
earlier-internal and geometric inputs. Both modules compile and pass
printed-axiom audits in the core ledger: only propext and Quot.sound,
with no sorryAx. The initial use of an unavailable tactic was replaced
by a direct case proof before success; no failed object was published.
Actual whole-star coverage, pool geometry, D5/H4 consumers and certificate
interpretation remain explicit premises. This is the requested conditional
logic verification, not an end-to-end formalization of hyperbolic geometry.
