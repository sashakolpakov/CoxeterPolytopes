# Lorentz obstructions: internal logic and application boundaries

`formal/CoxeterProofs/LorentzObstructionKernel.lean` is prepared source,
not yet compiled or axiom-audited. It imports only `Std` and requests seven
actual axiom outputs. There is currently no execution credit for those
commands. Resource admission remains mandatory; a source review is a
different kind of evidence.

## A second-orbit obstruction

For a positive squared root norm c, let q be the squared coefficient
along a fixed future unit timelike vector and W=q+c the Euclidean squared norm
of its orthogonal projection. If an isometry fixes that timelike vector
and the first-orbit product is zero, Euclidean Cauchy gives

```
2*q² <= W*(W + second + q).
```

The kernel derives `second > -3*c` from this inequality. If instead
`second <= -3*c`, multiplication by positive W bounds the right side by
`(q+c)*(2*q-2*c) = 2*q² - 2*c²`, a contradiction. It specializes to
the norm-two cutoff `second > -6` and proves that the explicit golden
pair `second = -80 - 132*phi`, with `phi > 1`, lies below that cutoff.

The finite-order application has a named, substantive external bridge:
averaging a future timelike orbit supplies a fixed future unit vector;
the Lorentz/Euclidean decomposition and Cauchy supply q,W and the displayed
inequality. The kernel assumes that bridge as a theorem parameter, then
derives that finite order is impossible. It does not assume an infinite
order conclusion or declare a custom axiom.

Actual original-lattice integrality, the map of full chamber germs and
the index/covolume consequence remain separate written inputs. The new
norm79 D9 continuation is an application under review; this prepared
kernel alone excludes no lattice or polytope.

## The marked-D quadrilateral obstruction

The kernel expands the cleared two-by-two determinant numerator and proves
it cannot vanish when `m >= 3`, `h >= 0`, and `g = 0` or `g >= 1`.
At zero g the numerator is negative. Otherwise it is

```
h*((m+1)*g-2) + 2*m*g - 4 > 0.
```

It also checks the natural-number contradiction between rank n+2 and
the ambient upper rank n+1. The complete white support, the actual
long-end/center role assignment, native gap, Schur elimination and rank
interpretation remain written mathematics in
[the restricted theorem](../results/finite57_homogeneous_large_d_quadrilateral_schur_obstruction_20261021.md).
This is not a universal transfer rule or a reduction of finite57's charge372.

## Reproduction after source review and admission

Run serially from the repository root, once the written logic is settled
and the existing resource gates admit execution:

```sh
python3 -B scripts/run_lean_batches_signal_safe_20261018.py CoxeterProofs.LorentzObstructionKernel
python3 -B scripts/run_lean_batches_signal_safe_20261018.py CoxeterProofs.LorentzObstructionKernel --audit-axioms
```

These commands have not run. The runner retains one module, 2,048 MiB,
one thread, the shared exclusive lock and all existing admission/abort
gates. No successful old module or dependency needs rerunning. Actual
printed axioms, when available, must be read separately from the geometric
and arithmetic theorem parameters above.
