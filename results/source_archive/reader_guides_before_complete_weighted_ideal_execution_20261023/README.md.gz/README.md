# Coxeter Polytopes

Dimension bounds, explicit hyperbolic reflection chambers and right-angled
volume problems. The repository has **six paper families**, their frozen
TeX/PDF editions, supporting proofs, reproducibility records and selected
Lean verification.

Start with the [documentation website](https://sashakolpakov.github.io/CoxeterPolytopes/),
the [current bounds and verification guide](docs/current_bounds_and_verification.md)
or the [paper index](manuscripts/README.md).

## Current dimension results

The repository improvements are **internally reviewed written proofs**:
complete arguments at their declared input boundaries, another author's
source review and coordinating acceptance. Publication, external refereeing,
script replay and geometric formalization have separate statuses.

| Class | Largest published example | Published ceiling | Repository ceiling |
|---|---:|---:|---:|
| General Coxeter, finite volume | 21 | 995 | **57** |
| General compact Coxeter | 8 | 29 | **18** |
| Compact arithmetic Coxeter | 8 | 29 | **15** |
| Noncompact arithmetic Coxeter | 21 | 21 | **21**, published and sharp |
| Right-angled, finite volume, all vertex types | 8 | 12 | **8**, internally sharp |
| Right-angled, entirely ideal | 4 | 6 | **4**, internally sharp |
| Right-angled, compact | 4 | 4 | **4**, published and sharp |

Arithmetic reflection lattices automatically admit the quadratic-form
model; “first type” adds no restriction to these arithmetic rows. Exact
published inputs and scopes are in the [assumption register](docs/manuscript_assumptions.md).
There is **no new polytope example** from the active construction search.

## The six papers

All six editions are **written, compiled and internally reviewed**. Later
compact18/arithmetic15 proofs belong in the existing compact families;
the frozen PDFs still state23/20. Earlier notes, fragments and atlases
are supporting material, rather than additional proposed papers.

| Paper | Result in the PDF | PDF |
|---|---|---|
| General finite volume | Dimension at most57 | [48 pages](manuscripts/build/finite_volume57.pdf) |
| Sharp right-angled dimensions | Finite volume at most8; entirely ideal at most4 | [5 pages](manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf) |
| General compact | Dimension at most23; supporting proof18 | [36 pages](manuscripts/build/compact_farthest_vertex_bounds.pdf) |
| Compact arithmetic | Dimension at most20; supporting proof15 | [21 pages](manuscripts/build/compact_arithmetic_dimension_bound.pdf) |
| Ideal right-angled four-volume and structure | Published minimum; second volume and unique double; restricted24-cell chains | [17 pages](manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf) |
| Compact right-angled four-volume constraints | Facet capacity, excess and recognition | [14 pages](manuscripts/build/compact_ra4_volume_constraints.pdf) |

The57 paper has12 pages of main exposition and36 pages of essential proof
and algorithm appendices. The [paper index](manuscripts/README.md) and
[result correspondence](docs/result_manuscript_correspondence.md) identify
each technique, source, proof map and verification boundary. The ideal
four-volume paper does not classify all ideal polytopes as24-cell chains.
The compact four-volume paper does not establish a120-cell minimum or
a unique second-volume double.

## What the proofs do

The finite-volume argument assigns weights to actual polygon corners.
Spherical and affine vertex diagrams bound the available payment; global
face counting requires more. It is one simultaneous rule, including every
shared debt. The compact arguments use one farthest vertex and one spatial
vector: orthogonal component projections have additive squared norms and
force a cost above its budget. Arithmeticity adds field and integrality
restrictions. The sharp right-angled proof uses actual facet projections
followed by spherical-code bounds.

At exact compact dimension 18, only **whole D18** remains in the
necessary farthest-vertex list after the
[complete whole-B18 exclusion](results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md).
The last B18 role uses an actual A18 neighbor, retaining comparison
factor11/8 and one norm budget there. The complete conjunction covers
every original terminal role. For D18,
[center16 is unconditionally .58-strong](results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md),
but its whole-family exclusion remains open. This is a necessary
diagram at a selected farthest vertex, not a realized example or a
claim about every vertex. The compact ceiling stays18. The
[new D18 fork-pair theorem](results/review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md)
gives both fork cosh lengths<9.64 and excludes both-near3 for all heads
and near3/far3 under a native5 head. The remaining isolated-containing
pairs are refined below.
The [actual A17+A1 neighbor theorem](results/review_compact18_d18_actual_a17_a1_isolated_cutoff_native5_far_pair_root_acceptance_20261023.md)
excludes native5 far3/far3. A stronger
[actual-neighbor estimate](results/review_compact18_d18_fifteen_eighths_isolated_cutoff_root_acceptance_20261023.md)
now bounds every isolated fork own by15/8, for every head. Thus a native5
head forces at least one isolated dotted fork; isolated-containing pairs
remain under investigation.

The [new global compact-arithmetic ceiling15](results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md)
closes the last exact-dimension16 family. Geometry first forces the
actual field to be quadratic and the head and both forks to be isolated
and dotted. Integer norms, the three splitting types of2, full maximal
orders and complete field-square tests then exclude every remaining
triple. Two final geometric residues fail one original-vector budget.
The new obstruction is handwritten; the global theorem retains the
authenticated older computational inputs of the previous global16 bound.
The prepared D16 census was not executed and is not a premise. The
[fresh exact-dimension15 cover](results/review_arithmetic15_fresh_complete_twenty_two_group_frontier_root_full_source_acceptance_20261023.md)
began with22 necessary diagram groups. The
[complete B14+actual-I exclusion](results/review_arithmetic15_whole_b14_actual_i_all_degree_manual_root_acceptance_20261023.md)
removes original group19. One joint head/I
estimate, cubic integer obstructions and complete quadratic field strips
exclude every actual field in that group. A field-product exponent was
corrected with the predecessor preserved before full acceptance. The
[complete B13 rank-two exclusion](results/review_arithmetic15_b13_ordinary_and_typed_seven_whole_group17_root_acceptance_20261023.md)
also removes original group17, leaving **20 necessary groups**. Ordinary
spectators use only the fresh body through10; actual typed-seven
spectators have separately proved11/12 estimates. These are necessary
alternatives, not realized examples; no14 bound is claimed.
The [direct D13 ordinary-rank-two proof](results/review_arithmetic15_d13_ordinary_rank_two_root_acceptance_20261023.md)
also trims original group18 to actual N7/O7 only, without changing
the count of20 remaining groups.

For general compact18, a new [actual-neighbor theorem](results/review_compact18_d18_all_head_finite_isolated_pair_actual_a16_neighbor_root_full_source_acceptance_20261023.md)
excludes EVERY finite nonright mutual angle between two isolated forks,
for every head and unequal fork parameters. Its actual A16+I2 neighbor
retains an explicit comparison factor from the original maximum. The
[orthogonal-pair argument](results/review_compact18_d18_orthogonal_isolated_pair_root_full_source_acceptance_20261023.md)
also excludes mutual orthogonality. A further
[negative-core argument](results/review_compact18_d18_isolated_fork_mutual_four_thirds_gap_root_full_source_acceptance_20261023.md)
forces a dotted mutual to exceed4/3, with both fork owns dotted and
their product exceeding7/3. The
[complete isolated/near3 exclusion](results/review_compact18_d18_whole_isolated_near_three_family_root_acceptance_20261023.md)
now covers every mutual angle, every head and unequal own parameters.
Its orthogonal case uses an actual A16+2A1 neighbor retaining both
reverse coordinates; its dotted case uses a positive future core.
Isolated/isolated dotted pairs, isolated/far3, other fork roles and
wholeD18 remain open.

Toward finite volume 56, the allocation arguments finance
[all zero-exchanged row7 and near-row8 exits](results/review_finite57_zero_exchanged_all_row7_near_row8_financing_root_acceptance_20261023.md),
and far-row8 isolated [contacts 3/4/parallel](results/review_finite57_far_row8_isolated_intervening_cusp_financing_root_acceptance_20261023.md)
and [orthogonal contact](results/review_finite57_far_row8_orthogonal_isolated_b4_cusp_financing_root_acceptance_20261023.md).
These use 22 parameterized whole-cusp families and every prior debt. A
[unique finite receiver](results/review_finite57_far_row8_d23_finite_a21_dihedral_receiver_root_acceptance_20261023.md)
also handles finite positive contacts on the affected D23 component.
The old D17 receiver has a4.5-unit deficit. The new
[complete zero-exchanged far-row8 theorem](results/review_finite57_zero_exchanged_far8_all_corner_refund_one_unit_root_acceptance_20261023.md)
bypasses it: a finite/affine corner argument proves selected actual
faces have at least five sides. Eight unnecessary corner units, or
seven plus one uniquely bounded transfer, supply the full saving.
No next-wall, isolation or dotted-product cutoff is assumed. The
[positive-exchange extension](results/review_finite57_all_far8_positive_exchange_normalized_refund_root_acceptance_20261023.md)
now covers the same far-row8 sources with every positive exchanged
contact, sharing ONE receiver port across the zero/positive union.
The [whole pure-D17 extension](results/review_finite57_whole_d17_large_inert_d_far8_refund_root_acceptance_20261023.md)
also permits arbitrary inert D-factors of rank at least9 and total
rank40, conditional on an actual qualifying far8 centre. It retains
the old D40+D17 debts explicitly. Other heavy configurations and
complete global coverage remain open; no56 is claimed.
The [new positive native-six weighting](results/review_finite57_native_six_positive_weighting_flags_and_single_factor_receiver_root_acceptance_20261023.md)
gives an exact global incidence identity and a different local budget.
The selected D17 receiver has headroom5/6, including its
[complete old-debt audit](results/review_finite57_native_six_selected_receiver_zero_old_debt_root_acceptance_20261023.md).
The [all-factor extension](results/review_finite57_native_six_all_finite_minima_smoothed_ideal_root_acceptance_20261023.md)
now gives every finite shape minimum analytically and a conditional
ideal-envelope comparison when another factor has rank at least13.
The [complete native-six finite budgets](results/review_finite57_all_single_native_six_finite_budgets_root_acceptance_20261023.md)
now cover EVERY finite vertex containing at least one native-six factor,
including Context and every retained receiving token. The single-factor
proof compares formal forests of the same rank and uses a rational
certificate, a strict congruence step and complete finite case bounds.
The [complete old ideal-debt argument](results/review_finite57_native_six_all_old_ideal_debts_root_full_source_acceptance_20261023.md)
now covers the selected priorities, Context transfers and original fixed
receiving loads. It reduces the remaining weighted ideal budgets to a
bare small-factor computation. Its
[worker and mathematical reduction have full source clearance](results/review_finite57_native_six_bare_ideal_worker_contract_root_preexecution_clearance_20261023.md),
with no execution or positivity claim. The
[strict global comparison is now proved](results/review_finite57_native_six_weighted_global_extrema_strictness_root_acceptance_20261023.md),
using actual weighted link graphs and the two global extrema. Heavy
vertices without native6, full face coverage and the bare ideal check
remain open. There is no56 theorem.

An [explicit special-face argument](results/review_finite57_special_native_bond_compact_face_and_label_restriction_root_acceptance_20261023.md)
also gives a derived ceiling of 20 for finite-volume polytopes with a
native5 or native7+ bond at a finite vertex, using the internal compact18
bound. The published compact29 bound alone gives 31 for that restricted
class. In the finite57 lane this leaves only native6 among the remaining
finite5+ contacts; it does not bound every finite-volume polytope by 20.

The construction lane walks actual edges in original lattices. The
[glued](results/review_glued_e7_a2_two_unit_releases_original_period_and_literal_nonreflectivity_root_acceptance_20261023.md)
and [squared-unit](results/review_h9_squared_unit_e7_return_original_period_literal_nonreflectivity_root_acceptance_20261023.md)
hosts are nonreflective by original infinite-order chamber symmetries.
The different prime41 host has reviewed actual edges and compact
two-faces. Two [new norm2](results/review_h9_prime41_known_outer_gap_actual_e6_unit_cutter_root_full_source_acceptance_20261023.md)
and [norm4](results/review_h9_prime41_initial_e6_a2_actual_norm_four_b3_edge_root_full_source_acceptance_20261023.md)
facets cut successive explicit gaps in the known-wall outer polyhedron,
with complete original-module firstness proofs. Its full chamber volume
remains unresolved. These local constructions do not give a new example.
The next edge has a [proof of finite termination](results/review_h9_prime41_e6_b3_e2_relative_unit_termination_five_profiles_root_acceptance_20261023.md)
using an original-lattice relative unit. Its five-profile
[witness/firstness worker has full source clearance](results/review_h9_prime41_e6_b2_witness_firstness_worker_contract_root_preexecution_clearance_20261023.md),
but no numerical witness or next facet has been computed.

## Verification and reproduction

The [computational proof contract](docs/computational_proof_contract.md)
requires each algorithm's domain, completeness and termination argument,
exact arithmetic, execution result and replay boundary. Hash agreement and
PDF compilation establish neither mathematical completeness nor correctness.

Finite57's25 bounded B13/frontier replacement units have all actually
passed and are integrated in the primary catalogue. The146-job full
selection has no combined runtime PASS or complete transitive regeneration;
111 other command matches retain their inherited execution scope. See
the [reproduction guide](docs/finite_volume57_reproduce.md).

Selected Lean kernels have actual compilation and **separate actual axiom
audits**. Their logic maps expose the ordinary theorem parameters that
printed foundational axioms do not enumerate.

The new [B16 isolated-pair scalar source and input map](docs/b16_isolated_pair_scalar_kernel_logic_20261023.md)
have full static review. The first admitted compile failed on two reserved
local names; its output is preserved. The two-name repair has
[outside review and root clearance](results/review_b16_isolated_pair_scalar_reserved_identifier_repair_root_clearance_20261023.md).
**No successful compilation or separate actual axiom audit is credited.**
Fresh RAM is below the unchanged 6 GiB gate for the retry.

The new [dyadic logic map](docs/quadratic_dyadic_triple_kernel_logic_20261023.md)
prepares fourteen discrete declarations for the arithmetic15 argument.
Compilation and a separate actual axiom audit are pending. Number fields,
finite coefficient tables and actual geometry remain external premises.

| Kernel | Actual audited declarations | Scope and receipt |
|---|---:|---|
| B18 terminal pressure | 10 | [Continuous scalar pressure contradictions](results/lean_b18_terminal_pressure_verification_20261023/manifest.json) |
| A13 endpoint graft | 11 | [Continuous gains and paid-square logic](results/lean_a13_i_endpoint_graft_verification_20261023/manifest.json) |
| A12 adjusted loss | 10 | [Continuous loss and finite-list paid square](results/lean_a12_adjusted_loss_verification_20261023/manifest.json) |
| A18 dotted endpoints | 10 | [Continuous endpoint inequalities](results/lean_a18_two_dotted_endpoint_verification_20261023/manifest.json) |
| Heavy-centre forest | 11 | [Cone, conditional chain and incidence algebra](results/lean_heavy_centre_forest_verification_20261023/manifest.json) |

The new B18 module compiled in1.71seconds; its separate audit took1.16seconds
and reused the object. All ten prints use only standard foundational axioms,
with no `sorryAx`. Two unused-variable warnings are preserved. Actual geometry,
inventories, legal pressure, terminal sums and real instances remain external;
this is not wholeB18 or end-to-end manuscript formalization. Earlier failures
and resource deferrals retain zero PASS credit. The [formal guide](formal/README.md)
records the complete coverage.

For named, serial reproduction batches:

```sh
python3 -B scripts/verify_manuscript.py finite57 --mode core
python3 -B scripts/verify_manuscript.py right_angled_sharp --mode core
python3 -B scripts/run_lean_batches_signal_safe_20261018.py CoxeterProofs.B18TerminalPressureKernel
python3 -B scripts/run_lean_batches_signal_safe_20261018.py CoxeterProofs.B18TerminalPressureKernel --audit-axioms
```

Successful modules and dependencies need not be rebuilt without changed inputs.

## Resources and publication

Run one scientific, Lean or TeX child at a time under the shared lock.
Admission requires40GiB free disk and6GiB available RAM. Script/TeX batches
use59seconds/1GiB/one thread; Lean uses2048MiB/one thread and a separate
axiom audit. Remove owned unused products after each batch. Start cleanup
below20GiB free disk, preserving sources, certificates, final PDFs and history.

Before every push, audit the **actual Git index** and build Sphinx with
warnings treated as errors through the publication watchdog. Final PDFs and
verification stdout are evidence. Compiler objects, dependencies, TeX
intermediates, caches and generated sites stay untracked.

The optional [bulk-data manifest](repro/public-data-manifest.json) binds936
scientific files in33 archives. **No bulk asset has been uploaded.** See
[repro/README.md](repro/README.md) and [external input retrieval](repro/EXTERNAL_INPUTS.md)
for availability and the distinction between byte restoration and mathematical
verification. No third-party redistribution licence is implied.
