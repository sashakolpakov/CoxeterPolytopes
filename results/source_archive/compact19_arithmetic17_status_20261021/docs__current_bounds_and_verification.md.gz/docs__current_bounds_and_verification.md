# Dimension bounds and verification

Updated 21 October 2026. There are six finished TeX papers, each with a
matching PDF. Parked arithmetic refinements are excluded and preserved.
Fresh internal mathematical audits found no blocker at the stated
published-input and finite-data boundaries. This is not external
refereeing or complete geometric formalization.

The [reader’s index](../manuscripts/README.md) gives the six PDFs and
reproduction commands. The [result–manuscript map](result_manuscript_correspondence.md)
separates the theorem printed in each PDF from later supporting research.
The [delivery receipt](../results/six_paper_final_tex_delivery_20261021.json)
binds the finished editions; the
[completed-audit checkpoint](../results/six_paper_completed_audits_and_restricted_continuations_20261021.json)
records those reviews; the [latest continuation checkpoint](../results/six_paper_audits_d18_dotted_frontier_and_d20_native5_repair_20261021.json)
records the later head exclusions, degree reduction and corrected endpoint proof.

## Dimension comparison

A ceiling is an upper bound on dimension, not an existence claim.
The repository columns report internally reviewed written arguments.

| Class | Largest known example | Published ceiling | Repository written ceiling | Finished PDF |
| --- | ---: | ---: | ---: | --- |
| Arbitrary finite-volume Coxeter | 21 | 995, Prokhorov | 57 | [57](../manuscripts/build/finite_volume57.pdf), 48 pages |
| Arbitrary compact Coxeter | 8 | 29, Vinberg | 20 | [23](../manuscripts/build/compact_farthest_vertex_bounds.pdf), 36 pages |
| Compact arithmetic Coxeter, first type | 8 | 29, Vinberg | 18 | [20](../manuscripts/build/compact_arithmetic_dimension_bound.pdf), 21 pages |
| Noncompact arithmetic Coxeter | 21 | 21, Esselmann | 21, published and sharp | No separate new paper |
| Arithmetic compact or noncompact, with the first-type reflection criterion | 21 | 29 overall | 21, sharp as a union | Compact argument plus published noncompact theorem |
| Compact right-angled | 4 | 4, Potyagailo–Vinberg | 4, published and sharp | Background in the right-angled paper |
| Entirely ideal right-angled | 4 | 6, Kolpakov | 4, sharp | [4](../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf), same 5-page paper |
| Right-angled with mixed finite/ideal vertices | 8 | 12, Dufour | 8, sharp | [8](../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf), same 5-page paper |

The universal right-angled theorem permits all vertex types and proves
dimension at most eight without arithmeticity. Its entirely ideal branch
proves four. Compact right-angled four was already sharp in the literature.
Noncompact arithmetic dimension twenty is excluded by the published
classification; its sharp ceiling twenty-one must not be confused with
the compact arithmetic problem.

The [general compact composition](../results/compact20_and_all_field_arithmetic19_global_composition_candidate_20261021.md)
and [compact arithmetic composition](../results/compact_arithmetic_dimension18_global_composition_20261021.md)
have full root and outside-author written reviews. The latter permits
every admissible actual ground field; it does not assume the parked
nine-field result. Their stronger twenty/eighteen conclusions are not
silently attributed to the finished twenty-three/twenty PDFs. Integration
belongs in the same two papers, with one coherent proof in each.

## What has been checked

| Paper | Written audit | Reproduction and formal boundary |
| --- | --- | --- |
| Finite volume 57 | [Fresh full composition audit](../results/review_finite57_geometric_composition_new_audit_20261021.md); no blocker at named finite-input boundaries | Matching bounded records cover 111/113 selected script commands. The reviewed 25-unit replacement for two eager commands has **2 PASS, 23 without PASS**. There is no combined 123-job full replay or complete transitive regeneration. Conditional Lean checks selected counting, table and scalar implications. |
| Sharp right-angled 8/ideal 4 | Fresh [geometry](../results/review_sharp_ra_geometric_foundations_adversarial_20261021.md) and [tensor/equality](../results/review_sharp_ra_tensor_ideal_equality_adversarial_20261021.md) audits | Exact core checks and selected conditional Lean have actual successful runs. Coordinate projection, height and cubic identities are formalized; published bounds and actual geometric interfaces remain explicit premises. |
| Compact arithmetic PDF 20 | Full exposition/field-closure reviews and [completed internal-field proof review](../results/review_compact_arithmetic20_internal_field_translation_foundations_20261021.md) | Its matching 21-page build has zero warnings. Accounting and finite checks keep their declared scopes; this is not formal verification of the later eighteen theorem. |
| General compact PDF 23 | [Full source review](../results/review_compact_farthest23_full_batch_guard_20261020.md), with source-bound editorial delta review | Matching 36-page build has zero warnings. The compiled accounting kernel retains twenty-three; actual geometric inequalities and later twenty remain outside that kernel. |
| Ideal RA4 volume/structure | [Fresh full adversarial audit](../results/review_ideal_ra4_volume_structure_fresh_adversarial_20261021.md) | Universal second-volume equality is proved before the restricted chain theorem is applied. Exact model outputs and conditional Lean have explicit scopes; the actual cutting and recognition proofs are written geometry. |
| Compact RA4 constraints | [Fresh full adversarial audit](../results/review_compact_ra4_volume_constraints_fresh_adversarial_20261021.md) | Graph and geometric cases are written out. The catalogue selection checks typesetting only; there is no universal geometric Lean proof. |

The finite57 [reproduction guide](finite_volume57_reproduce.md) records
all completed bounded replacements and the still-unintegrated loader.
Its immutable [partial successor ledger](../results/finite57_loader_replay_post_finishing_20261021.json)
preserves the parser and first B13 pin-group PASS, and the next group’s
resource refusal before a child started. Resume in a new ledger; never
replace this partial receipt with a completion claim.

Recent actual Lean additions include the
[two-foot payment kernel](two_foot_paid_logic_20261021.md) and
[large-parent arithmetic kernel](large_inert_parent_arithmetic_logic_20261021.md),
with separate compile and actual axiom-audit records. The
[regular 24-cell height kernel](regular_ideal_24cell_height_logic_20261021.md)
has complete source/math reviews but remains **uncompiled**. Its latest
[admission attempt](../results/regular24_height_compile_admission_refusal_20261021.json)
was refused before a compiler started at 4.9 GiB available RAM. Five requested
axiom prints are not five verified declarations. Each kernel’s map says
which geometry, external theorem and script statements remain assumed;
axiom output alone is not an assumption register.

## Remaining dimension work

The general compact twenty frontier is now whole D20: the
[whole-B20 two-foot proof](../results/compact_whole_b20_two_end_actual_foot_exclusion_20261021.md)
has two complete outside-author written reviews. This closes a family,
not the remaining dimension.
The arithmetic eighteen frontier now has **one** family: whole D18.
The previously reviewed
[B17+I exclusion](../results/arithmetic18_whole_b17_isolated_i_short_cap_exclusion_20261021.md)
is joined by complete
[A17+I](../results/arithmetic18_whole_a17_isolated_i_two_endpoint_triangle_exclusion_20261021.md)
and [D17+I](../results/arithmetic18_whole_d17_isolated_i_triangle_cycle_exclusion_20261021.md)
exclusions over every actual admissible first-type field. Here I is the
actual isolated short A1. The new proofs use integral cycles of three
actual walls, covering every finite I contact. The A proof also uses
both endpoint opposites; the D proof finishes with an elementary complete
quadratic norm/trace argument. Both have full root and outside-author
written reviews. Whole D18 remains open, so the ceiling is still eighteen.

The reviewed [fresh D18 reduction](../results/arithmetic18_whole_d18_long_end_isolation_and_head_field_reduction_20261021.md)
provides genuine strong prefix indices 5–15 and actual long-head isolation.
The [native12/18 argument](../results/arithmetic18_whole_d18_native_twelve_and_eighteen_head_exclusion_20261021.md)
and [complete finite-head proof](../results/arithmetic18_whole_d18_finite_head_fork_isolation_and_exclusion_20261021.md)
now exclude **every finite long head**. Only a dotted head remains, with
actual field $K=\mathbb Q(U)$, $4<U<28/3$ and every other conjugate in $(0,2)$.
The [norm/divisibility proof](../results/arithmetic18_whole_d18_dotted_head_degree_four_and_isolated_forks_20261021.md)
further forces field degree at most four; in degrees three and four both
fork opposites must be isolated and dotted. These statements have full
root and outside-author written checks. They use all nonphysical embeddings,
not a chosen finite field list. The quadratic, cubic and quartic dotted
cases remain unresolved; no arithmetic seventeen theorem follows.

For general compact D20, the [coverage audit](../results/compact_d20_native5_tail_floor_coverage_defect_20261021.md)
identified unsupported individual tail floors in the old native-five proof.
The complete [adaptive-endpoint repair](../results/compact_whole_d20_native_five_adaptive_endpoint_repair_20261021.md)
now has full root and outside-author written reviews. It retains left
helpers and selects an actual strong endpoint from each neighboring pair;
it restores the entire native-five-head exclusion without claiming the old
individual floors were proved. The [head-independent bootstrap](../results/compact_whole_d20_old_strong_five_head_independent_bootstrap_20261021.md)
separately proves the old strong-five floor with no head or arithmetic
premise. The global compact ceiling remains twenty, with whole D20,
finite labels at least seven and dotted heads still open.

For finite volume, the [complete Context662 composition](../results/finite57_complete_context662_source_composition_20261021.md)
finances this one selected producer over all whole-parent domains.
Its inequality is against held actual ideal charge after retained
priorities and assigned debt. The [current A17 provenance audit](../results/finite57_current_a17_endpoint_producer_scope_audit_20261021.md)
finds only the two already-financed endpoint producers at the named
complete written interfaces. It is not a fresh all-current target replay,
whole-coupon deletion or a global fifty-six proof. The formal forest
2D17+D23 still has charge 372, independently of A17; a new global budget
argument would be necessary. No new polytope example has been found.
A [norm79 construction continuation](../results/compact_h9_nonunit_coupling_prime79_full_base_and_first_transverse_20261021.md)
has a full Bugaenko base and actual E7+I2(5) and D9 corners in a distinct
literal golden module. Its fifteen known walls still admit a spacelike
escape. The reviewed [next-edge contract](../results/compact_h9_prime79_a7_c_finite_upper_and_complete_interval_contract_20261021.md)
now proves a finite mirror upper and a complete nine-model domain of at
most 38,784 scalar trials. Its [exact checker and algorithm specification](../results/compact_h9_prime79_a7_c_interval_checker_spec_20261021.md)
have full root and outside-author source reviews, but no fixture or census
has run: the next wall, its ties and compact completion remain unresolved. These local corners and
the finite upper are not a finite-volume example.

## Ideal and compact right-angled four-volume

| Statement | Result and limit |
| --- | --- |
| Ideal minimum | Published: 4π²/3, uniquely the regular ideal 24-cell. |
| Second ideal volume | Internal reviewed proof: 8π²/3, uniquely its facet reflection double, with face vector (42,168,164,38). |
| Restricted structure | Octahedral/doubled-octahedral facets force a chain of 24-cells, with opposite cuts in intermediate cells. This is not a classification of arbitrary entirely ideal polytopes or a universal volume-divisibility theorem. |
| Compact constraints | f≥2V+5, neighboring-excess bounds, local facet cutoffs 46/46/96, zero-excess recognition, W=0 or W≥17, and degree two implies W≥20. |
| Compact minimum/second volume | Still open here. The constraints do not prove that the 120-cell minimizes volume or that its double has the second volume. |

These occupy the last two existing papers. Their
[ideal proof map](ideal_ra4_volume_and_structure_proof_map.md) and
[compact reproduction map](compact_ra4_volume_constraints_reproduce_20261019.md)
identify published inputs and actual script/formal evidence.

## Resource discipline and preserved history

Only root starts proof jobs. All scientific, TeX and Lean batches share
one exclusive lock and run serially. Admission requires 40 GiB free disk
and 6 GiB available RAM; abort thresholds stay 8/3 GiB. Scientific/TeX
jobs keep their 59-second, 1-GiB, one-thread caps; Lean uses one module,
one thread and 2,048 MiB. Owned temporary products are removed after each
batch. Below 20 GiB free disk, start cleanup before more jobs.

The former 1,000-line cumulative status page and the predecessor
result map are byte-preserved in the
[documentation archive manifest](../results/source_archive/six_paper_completed_audits_status_20261021/manifest.json).
Historical execution counts and intermediate bounds belong to those
records, not the current status. Lean remains a final verification step;
resource gates do not prevent manual mathematical review.
