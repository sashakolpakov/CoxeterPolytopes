# Results and manuscripts

Updated 21 October 2026. There are **six current papers**, with finished
TeX sources and matching PDFs. The other repository-owned TeX files are
predecessors, supporting notes, input fragments or generated atlases.
They are not additional proposed papers. The
[catalogue](../manuscripts/catalogue.json) retains the complete inventory;
the [reader’s index](../manuscripts/README.md) gives the current PDFs and
verification commands.

The [delivery receipt](../results/six_paper_final_tex_delivery_20261021.json)
binds all six source/PDF/build triples. Their theorem scopes and pages
are unchanged by the subsequent audits. Parked field-specific arithmetic
refinements remain excluded and preserved.

## Current correspondence

| Result | Primary manuscript and PDF | Main technique and point where cases separate | Verification scope |
| --- | --- | --- | --- |
| General finite-volume Coxeter dimension ≤57 | [TeX](../manuscripts/finite_volume57.tex), [48-page PDF](../manuscripts/build/finite_volume57.pdf) | One corner-payment rule and global incidence curvature. Separate finite spherical forests from affine cusp links; then handle dimension 58 and the complete higher-dimensional tail. Twelve main pages, 36 essential proof/algorithm appendices. | [Proof map](finite_volume57_lemma_map.md), [reproduction guide](finite_volume57_reproduce.md), [fresh composition audit](../results/review_finite57_geometric_composition_new_audit_20261021.md). Partial bounded replay and selected conditional Lean; no complete 123-job replay. |
| Compact arithmetic first-type dimension ≤20 in this PDF; later reviewed written ceiling18 | [TeX](../manuscripts/compact_arithmetic_dimension_bound.tex), [21-page PDF](../manuscripts/build/compact_arithmetic_dimension_bound.pdf) | Angle payments with arithmetic restrictions: actual-field reduction precedes the golden branch and exact charge maximum. The two required nongolden proofs are now included. The later eighteen proof uses farthest-point geometry plus arithmetic packing. | [PDF proof map](compact_arithmetic20_proof_map.md), [later eighteen guide](arithmetic18_logic_and_reproduction_20261021.md). Full written source reviews; eighteen is not yet in this PDF or verified by its old accounting kernel. |
| General compact dimension ≤23 in this PDF; later reviewed written ceiling20 | [TeX](../manuscripts/compact_farthest_vertex_bounds.tex), [36-page PDF](../manuscripts/build/compact_farthest_vertex_bounds.pdf) | One actual farthest vector supplies the norm budget. Ordinary components separate from large-A paired pressures and B/D coordinate-prefix arguments, followed by the terminal forest ledger. | [Proof map](compact_farthest_vertex_bounds_proof_map_20261020.md), [general twenty composition](../results/compact20_and_all_field_arithmetic19_global_composition_candidate_20261021.md). Full written reviews; compiled accounting retains twenty-three. |
| Right-angled dimension ≤8 universally and ≤4 if entirely ideal; both sharp | [TeX](../manuscripts/right_angled_sharp_dimension_bounds_publication.tex), [5-page PDF](../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf) | Shared finite projection and height comparison. The universal branch uses a cubic tensor spherical-code argument; the ideal branch uses the explicitly named Musin/Kolpakov inputs. | [Proof/reproduction map](right_angled_sharp_dimensions_publication_proof_map_20261021.md), fresh [geometry](../results/review_sharp_ra_geometric_foundations_adversarial_20261021.md) and [tensor/equality](../results/review_sharp_ra_tensor_ideal_equality_adversarial_20261021.md) audits. Exact core runs and selected conditional Lean pass; actual geometry remains external. |
| Ideal RA4 minimum, second volume and unique double; restricted 24-cell chains | [TeX](../manuscripts/ideal_ra4_volume_and_structure_publication.tex), [17-page PDF](../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf) | Defect counting proves the gap and equality spectrum first. Actual sections, cutting, metric recognition and gluing then prove the restricted Oct/D chain theorem and identify the second-volume double. | [Proof map](ideal_ra4_volume_and_structure_proof_map.md), [fresh full audit](../results/review_ideal_ra4_volume_structure_fresh_adversarial_20261021.md). Published minimum is an input. Exact model checks and conditional Lean do not replace the universal geometric proof. |
| Compact RA4 volume constraints | [TeX](../manuscripts/compact_ra4_volume_constraints.tex), [14-page PDF](../manuscripts/build/compact_ra4_volume_constraints.pdf) | Perpendicular-facet capacity and neighboring excess. Separate zero-excess recognition from positive-excess graph and metric configurations. | [Reproduction map](compact_ra4_volume_constraints_reproduce_20261019.md), [fresh full audit](../results/review_compact_ra4_volume_constraints_fresh_adversarial_20261021.md). Cases are written out; catalogue execution checks typesetting only. No universal 120-cell minimum or second-volume theorem. |

A written review is an internal audit at declared premises. It is not
external refereeing, an independent reproduction of every finite input,
or formalization of all geometric steps.

## Shared methods and consolidation

The two angle-payment papers each state the local-to-global mechanism
before introducing their different arithmetic and cusp reductions.
The compact farthest-point method is a separate approach and has its own
paper. Any stronger compact twenty/eighteen successor belongs in the
same general/arithmetic paper families; it should replace the old argument
coherently rather than append chapters for successive increments.
The [architecture guide](paper_architecture.md) gives that division and
the intended order of exposition.

The ideal RA4 paper already follows the requested sequence: the published
minimum, the universal gap and equality reduction, the restricted
structure theorem, then its application to the unique double. The chain
hypothesis is proved at second volume before it is used. No unrestricted
chain or volume-divisibility theorem is claimed. The compact case uses
different metric and capacity arguments, so it remains a separate paper.

## Algorithms and formal logic

Every proof-relevant computation has separate obligations: a finite
input domain, the algorithm, termination, soundness, completeness and
the exact output from execution. These are mathematical propositions;
a list of filenames or a saved PASS cannot establish coverage.
The [computational proof contract](computational_proof_contract.md)
and each paper’s proof map record those obligations.

Finite57’s 25-unit loader replacement is reviewed but has only two actual
PASS records, with the next unit refused for RAM before launch. Its old
full selection remains an inventory until the replacement is completed
and integrated. Do not run its eager commands as though the entire plan
were memory-safe. The [partial ledger](../results/finite57_loader_replay_post_finishing_20261021.json)
is immutable; resume in a new ledger. There is no combined full-replay claim.

Selected Lean kernels prove internal implications with external theorem,
geometry and script premises explicit. Their assumption maps separate
those premises from derived conclusions; actual axiom audits are recorded
separately from compilation. The [assumption register](manuscript_assumptions.md)
and [verification guide](manuscript_verification.md) explain that boundary.
The regular 24-cell coordinate-height kernel is source-reviewed but still
uncompiled; requested prints earn no execution credit.

## Preserved material

The parked [eight-field](../manuscripts/appendices/compact_arithmetic_eight_field19.tex)
and [K7](../manuscripts/appendices/compact_arithmetic_k7_field19.tex)
refinements, combined predecessor and its PDF remain intact. Earlier
right-angled bounds, compact intermediate bounds and generated proof
atlases are supporting history, not new manuscript families.
The previous complete 33-file inventory and execution chronology are
byte-preserved by the [archive manifest](../results/source_archive/six_paper_completed_audits_status_20261021/manifest.json)
and remain indexed in the catalogue. The
[completed-audit checkpoint](../results/six_paper_completed_audits_and_restricted_continuations_20261021.json)
binds the present short status pages, full reviews and unchanged papers.
