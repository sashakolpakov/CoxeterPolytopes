# Bounded B13/frontier replacement: root source review

21 October 2026. **Source-equivalence PASS; runtime untested.** Root read
the complete new worker and both original producers. This is outside the
worker's authorship, with shared prior contributions to the finite57 proof.
It does not certify runtime fitness, the inherited native geometry, or a
combined manuscript replay.

Reviewed worker:
`scripts/check_finite57_b13_frontier_batches_20261021.py`, SHA256
`f2aebea5021d8ce467069a1d25b78019a513c172a069559c4b1328d1c3201583`.
The exact conjunction contract is the final section of
`docs/finite_volume57_lemma_map.md`, SHA256
`f9d9bd6d67a5135b7f84ee80ee31902c20c5725e40d1b064ceadf50d82c0f6cf`.
The original producer sources are pinned at `5d0a7828` and `7b3f9664`.

## Mathematical equivalence

There are 25 required units: the parser fixture, sixteen B13 units, and
eight frontier units. The eight pin units retain both original mandatory
all-STEMS status and source-map loops. The metadata units reconstruct
every remaining top-level scalar and source-domain field. Exact key-set
checks rule out silently unassigned output fields.

B13 calls its original support, repairs and universal-role functions.
The monolithic interfaces are split at the original independent domains:
216 literals with both strict zips; four disjoint ordered groups covering
all 564 later corners; the eight newer collections with their original
index/default semantics; all 24 variants; and both full 280/52 positive
D12 traversals. Every original saved row is compared after the original
encoding and JSON tuple normalization. Metadata also checks the complete
source membership of the later rows and their total, rather than treating
each successful subset as the whole interface. All 78 B13 pair weights,
their sum 77, and the two distinct existing-coupon repairs remain checked.

The frontier invokes the unchanged original `representative_cover`,
`increasing_family` and `complement` functions. In particular, `complement`
is not replaced by checking its winning forests. It retains all 39
classes, 748 fibers, 1549 tables and 96528 options, including every
transition upper bound, reachable tight predecessor, unreachable state,
tie-breaking rule and reconstructed rank-58 forest. Every resulting class
and every global summary field is compared. The eight exceptional forests
and the other 38 class bounds therefore have the original proof meaning.
The two increasing-family option domains and the representative costly-key
equality are also recomputed, not inferred from their saved counts.

## Allocation and execution boundaries

Exact path projection replaces eager ancestor decoding. The expected
frontier classes are indexed on a read-only mmap and decoded singly;
the native function accesses them by bounded nonnegative class indices.
The expected class normalization is likewise performed singly. The old
complete output is never decoded or copied as one dictionary. Inputs
remain bounded by the existing 40-MiB file and 24-MiB selected-value caps.
No new interpretation of skipped JSON is claimed: the frozen full-file
hash and the original decoder semantics remain part of the contract.

The static 132-source import closure, old producer/certificate pins,
projection helper and runners are bound before and after a mathematical
unit. No original eager `run()` is called. Runtime import safety and
actual RSS/time still require execution; static bounds are not measured
resource evidence. The worker requires the parent's shared lock and
owner, has a 55-second alarm, and is launched only through the unchanged
59-second/1-GiB, one-thread wrapper with the 40/6-GiB start gates.

The resume coordinator checks current pins before reporting, credits
only source-bound receipts with hashed actual stdout and matching
bounded-runner metadata, and retains failures/deferrals. Missing units
remain explicit. A job-limit exit is not a complete-producer PASS.
Unsigned local receipts are not authenticated attestations.

No TeX change or new dimension theorem follows. Runtime measurements,
parser fixtures and all 25 units are pending at this review's creation.
The catalogue must retain its existing caveat until the reviewed complete
replacement has actually passed and its selected commands are integrated.
