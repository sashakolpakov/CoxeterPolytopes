# Reproduce the proof-publication packages

From the repository root, with Python3, Lean/Lake4.32.2, TeX Live and
`latexmk` available:

```sh
python3 scripts/check_proof_translation_20261018.py
```

This single command checks the exact Lean exports, builds and audits the
Lean project, replays the completed dimension57 and58 compositions and compact
arithmetic21 composition/scope checks, runs the independent RA4 saved
checkers and new right-angled incidence arithmetic, and compiles all thirteen
TeX documents across four projects. These include supporting notes and a
superseded bound; the count is not thirteen independent main results.
The preceding ten-document aggregate passed on
2026-10-18. The current version adds the resource-capped batch runner and
the octahedral-block and compact supported-triangle packages; their new
checks and the eleventh/twelfth PDFs passed
separately, but the updated whole aggregate has not been rerun. Lean follows
mathematical progress. The command reports
`full_geometric_theorems_lean_verified: false`: the checked arithmetic is
not the full geometric proof.

The thirteenth manuscript and all five small mixed-corner checkers passed
the separate serial command
`python3 -B scripts/check_mixed_corner_package_20261018.py --build`.
Its compact ledger is `docs/mixed_corner_package_audit_20261018.json`;
the final PDF pass had zero warnings and all TeX intermediates were removed.
It runs no Lean process. This check does not relabel the entire aggregate
as rerun.

The strengthened ideal-six manuscript and its three exact checkers also
pass the separate serial command
`python3 -B scripts/check_ideal6_cusp_package_20261018.py --build`.
Its [audit](../docs/ideal6_cusp_package_audit_20261018.json) records the
updated source/PDF hashes and zero final-pass warnings; its TeX
intermediates are removed after the batch. The reviewed result is
V>=ceil(2673F/136), hence4,462 vertices with the inherited227 facets.
No Lean process is run by this package, and the old aggregate has not
been relabelled as rerun.

The successful Python package versions are recorded in
[requirements-proof-20261018.txt](requirements-proof-20261018.txt). Python
3.14 was used; the Lean project uses only its pinned standard library.
The saved-certificate verifiers do not need an optimizer. A clean Lean
build repeats the ideal-profile kernel computation, which took about
eleven and a half minutes in this environment; cached builds are fast.

The complete historical exact-census replays are separate, potentially
substantial jobs. Their commands, external premises and internal geometric
obligations are in the result-specific maps:

* [Finite-volume57](../docs/finite_volume57_reproduce.md).
* [Finite-volume58](../docs/finite_volume58_reproduce.md).
* [Compact arithmetic21](../docs/compact_arithmetic21_proof_map.md).
* [Second distinct ideal RA4 volume](../docs/ideal_ra4_second_volume_reproduce.md).
* [Unique second-volume structure](../docs/ideal_ra4_structure_reproduce_and_map.md).

The edited manuscripts are accompanied by mechanically translated source
archives covering329 reports for the57 endpoint,282 for its58
predecessor and22 compact arithmetic reports. The exporter is also configured
for right-angled and compact-research archives; those new archive exports
and PDFs remain pending. These preserve historical statuses and superseded intermediate
results. They are source archives, not additional independently reviewed
proofs. Regenerate or verify their TeX and hash manifests with:

```sh
python3 scripts/export_proof_atlases_20261018.py
python3 scripts/export_proof_atlases_20261018.py --verify
```

This archive export uses Pandoc and jq; source manifests larger than20MiB
are traversed with jq's streaming parser, and file hashes are streamed.
PDF compilation uses XeLaTeX and the
STIXGeneral, STIX Two Math, Menlo and Arial Unicode MS fonts available in
the recorded macOS environment. The edited manuscripts instead build
with ordinary PDFLaTeX. Unrecognized bare backslash notation in archived
Markdown is preserved literally; recognized bare math commands are placed
in math mode without changing their arguments. Unicode subscripts have
explicit rendering fallbacks.

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=manuscripts/build/atlas manuscripts/generated/compact_arithmetic21_atlas.tex
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=manuscripts/build/atlas manuscripts/generated/finite_volume58_atlas.tex
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=manuscripts/build/atlas manuscripts/generated/finite_volume57_atlas.tex
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=manuscripts/build/atlas manuscripts/generated/right_angled_atlas.tex
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=manuscripts/build/atlas manuscripts/generated/compact_research_atlas.tex
```

Frozen research inputs are read only. Generated publication/formalization
files can be regenerated by their exporters. See [formal coverage](../formal/README.md)
and the [current bounds table](../docs/current_bounds_and_verification.md).
