Coxeter polytopes: results and verification
===========================================

This project studies dimension bounds, explicit reflection chambers and
right-angled volume and structure problems. There are **six paper families**,
with frozen TeX/PDF editions, supporting proofs and separately scoped reviews,
exact computations and Lean kernels. Updated24 October2026.

Current dimension bounds
------------------------

The repository improvements are internally reviewed written proofs, distinct
from publication, external refereeing and full geometric formalization.

.. list-table:: Dimension comparison
   :header-rows: 1
   :widths: 43 16 18 23

   * - Class
     - Largest example
     - Published ceiling
     - Repository ceiling
   * - General Coxeter, finite volume
     - 21
     - 995
     - **57**
   * - General compact Coxeter
     - 8
     - 29
     - **17**
   * - Compact arithmetic Coxeter
     - 8
     - 29
     - **15**
   * - Noncompact arithmetic Coxeter
     - 21
     - 21
     - **21**, published and sharp
   * - Right-angled, finite volume, all vertices
     - 8
     - 12
     - **8**, internally sharp
   * - Right-angled, entirely ideal
     - 4
     - 6
     - **4**, internally sharp
   * - Right-angled, compact
     - 4
     - 4
     - **4**, published and sharp

Arithmetic reflection lattices automatically admit the quadratic-form model;
“first type” adds no restriction here. General results assume no arithmeticity.
The :download:`current comparison guide <../current_bounds_and_verification.md>`
and :download:`assumption register <../manuscript_assumptions.md>` give exact
premises and references. **No new polytope example has been established.**

Current research frontiers
--------------------------

The :download:`general compact17 theorem <../../results/compact_dimension17_global_written_acceptance_20261024.json>`
is now an accepted internally reviewed written proof. It excludes wholeD18,
the sole necessary alternative at exact18; the earlier global18 tail excludes
higher dimensions. One actual head point supplies four fully funded
references. Both fork heights and a fresh local whole-A18 lemma then close
the remaining dotted-head cases. Every original wall and the SAME original
farthest vector remain in use. **No arithmeticity is assumed.** The frozen
compact PDF still states23; no sharpness or new example is claimed.

The :download:`conditional logic map <../compact_dimension17_conditional_logic_map_20261024.md>`
records two new Std-only Lean sources with complete static reviews.
Neither has been compiled or actually axiom-audited: measured RAM was below
the6GiB admission gate, so no new Lean process was launched. Older successful
kernels retain their scopes. A fresh exact17 forest analysis is underway;
it does not decrement the old rank18 table or establish16.

Compact arithmetic15 has a complete supporting proof, ending in a handwritten
whole-D16 dyadic obstruction. It retains older authenticated computations as
inputs. At exact15, the
:download:`new complete A13+ordinary-A2 proof <../../results/review_arithmetic15_a13_ordinary_a2_whole_original12_root_acceptance_20261024.md>`
closes original12 together with the accepted old-label-at-least4 and
two-ordinary-A1 theorems. Thirteen necessary diagram groups remain.
The new proof keeps all foreign contacts, actual-field equality and
Cartan-cycle integrality; these arithmetic conditions enter only this lane.
These are necessary alternatives, not examples or a14 bound.
The frozen arithmetic PDF still states20. See the
:download:`full current frontier <../current_bounds_and_verification.md>`.

Toward finite volume56, all selected weighted ideal budgets and native-six
finite budgets are closed. Actual generation and separate same-implementation
replay cover6,626 positive ideal cases. Complete centre-exit rows5/11 and
:download:`positive far-row6 at both ranks <../../results/review_finite57_positive_far_six_both_ranks_root_acceptance_20261024.md>`
and :download:`ALL positive near-row6 at both ranks <../../results/review_finite57_all_positive_near_six_root_acceptance_20261024.md>`
are financed for the literal heavy forest2D17+D23, retaining all old debts and
one simultaneous refund/transfer rule. Regular near6 arrivals fund
themselves with distinct held receiver corners. The proofs preserve both
the original dual-index failure and a later omitted V23 debt with their
exact repairs. The
:download:`complete positive NEAR end3 row4 theorem <../../results/review_finite57_all_positive_near_end_three_row_four_root_acceptance_20261024.md>`
adds both ranks with ONE shared old-plus-new exception reserve and distinct
receiver refunds. Its full regular caps retain the corrected362/355.
The complementary
:download:`complete FAR theorem <../../results/review_finite57_far_end_three_and_whole_row_four_root_acceptance_20261024.md>`
now closes ENTIRE row4 at both ranks. Quad sources transfer8 with NO
quad refund; all36 typed cusp parent templates retain old debts in ONE8N
union. Regular A15/A21 caps are362/363. Universal coverage remains open. The
:download:`all-actual-facet label theorem <../../results/review_finite57_all_actual_facet_finite_bonds_root_acceptance_20261024.md>`
restricts finite labels at57 to2/3/4/6 without arithmeticity. Other finite configurations,
other heavy configurations and complete face/source coverage remain open.

The spectral lane has a reviewed
:download:`full-wall Gram band <../../results/review_spectral_frog_canonical_lorentz_gram_band_root_full_source_acceptance_20261023.md>`
and :download:`fourth-order transverse obstruction <../../results/review_spectral_frog_fourth_order_transverse_schur_root_acceptance_20261023.md>`.
The maximum is an interior centre; a farthest vertex is a separate point.
Every unknown-wall moment stays in the constraints. The proposed restriction
cone now has the reviewed native-nine geometric application and separate
arithmetic residue applications. It uses physical geometry generally and
adds cyclic integrality/conjugate positivity only in the arithmetic lane.
General dotted products remain real parameters. No new global bound follows.

A :download:`bounded central-profile packet <../../results/review_compact18_central_prefix_interval_packet_root_preexecution_clearance_20261024.md>`
has complete mathematical/static code review. Actual finite one-node
extensions give11/12/12 profiles at three chosen D18 edges; metric parameters
stay in bounded intervals. The sole signed-pressure notation correction is
byte-preserved. **The worker is unexecuted:** no selected-unit exclusion or
full560-unit runtime cover is credited.

The prime41 H9 construction has an actual original norm-two W facet and full
E6+B2+A1 endpoint after four recorded units. A further
:download:`manual relative-unit firstness proof <../../results/review_h9_prime41_y_release_manual_h3_full_chain_root_acceptance_20261024.md>`
reaches the unique J facet and full E6+H3 endpoint. Its prepared Y-release
worker was not run or used. On a separate branch, the
:download:`actual R7 facet and old-U edge <../../results/review_h9_prime41_actual_r7_firstness_old_u_and_nonoriginal_maps_root_acceptance_20261024.md>`
reach full D7+2A1 and D6+3A1 endpoints. All four direct metric germ maps
are nonoriginal. A
:download:`fresh mixed gap <../../results/review_h9_prime41_after_r7_fifty_entry_outer_gap_root_acceptance_20261024.md>`
proves the50-entry recorded outer relaxation still has infinite volume.
The :download:`next actual P7 short-leaf edge <../../results/review_h9_prime41_p7_short_leaf_actual_e7_return_root_acceptance_20261024.md>`
now reaches a full E7+2A1 vertex through unique actual norm2 R*. All eleven
necessary profiles are covered by original parity and closed strips at
both embeddings; a same-time root is conically redundant. R* cuts that
old gap. Its metric return is a nonoriginal order-two reflection. The
:download:`next original dyadic facet <../../results/review_h9_returned_e7_actual_dyadic_edge_return_words_and_outer_gap_root_acceptance_20261024.md>`
is the unique actual norm4 B*, with full E7+[4]+[2b41] endpoint.
All unknown earlier walls are excluded by a fresh original-module proof.
A shifted witness survives the full54-entry outer list, proving infinite
volume only for that relaxation. No nonzero alternating power of the
natural return involutions is original. Full-chamber volume stays open.
Unknown actual mirrors may cut it; ambient volume, compactness, a chamber
period and a new example remain unresolved.

The six papers
--------------

All six editions are written, compiled and internally reviewed. Supporting
improvements remain in these families; earlier notes and atlases are not
additional proposed papers. The
:download:`paper index <../../manuscripts/README.md>` and
:download:`result correspondence <../result_manuscript_correspondence.md>`
identify the common techniques and where their cases separate.

.. list-table:: Current frozen editions
   :header-rows: 1
   :widths: 53 30 17

   * - Paper
     - Result in PDF
     - PDF
   * - General finite volume
     - At most57
     - :download:`48 pages <../../manuscripts/build/finite_volume57.pdf>`
   * - Sharp right-angled dimensions
     - Finite volume8; entirely ideal4
     - :download:`5 pages <../../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf>`
   * - General compact
     - At most23; supporting proof18
     - :download:`36 pages <../../manuscripts/build/compact_farthest_vertex_bounds.pdf>`
   * - Compact arithmetic
     - At most20; supporting proof15
     - :download:`21 pages <../../manuscripts/build/compact_arithmetic_dimension_bound.pdf>`
   * - Ideal right-angled four-volume and structure
     - Minimum; unique second-volume double; restricted chains
     - :download:`17 pages <../../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf>`
   * - Compact right-angled four-volume constraints
     - Capacity, excess and recognition
     - :download:`14 pages <../../manuscripts/build/compact_ra4_volume_constraints.pdf>`

The ideal four-dimensional paper does not classify all ideal polytopes as
24-cell chains. The compact four-dimensional paper establishes neither an
absolute120-cell minimum nor a unique second-volume double.

Read and reproduce
------------------

Finite57 has25 actual bounded replacement PASS units and catalogue integration.
Its full136-script/nine-Lean-root/one-PDF selection has no combined146-job
runtime PASS or complete transitive regeneration;111 other command matches
retain inherited execution scope. Core11 is unchanged. See the
:download:`reproduction guide <../finite_volume57_reproduce.md>`.

Selected Lean kernels have actual compilation and SEPARATE actual axiom audits.
The new dyadic and B16 scalar modules have14 and12 audited declarations;
their field, census, geometry and real-instance premises remain external.
The :download:`formal guide <../../formal/README.md>` preserves logic maps,
exact receipts, failures and resource deferrals. No selected conditional kernel
is called a full geometric formalization.

One root-owned scientific/Lean/TeX process runs at a time under the shared lock.
Admission requires40GiB disk and6GiB available RAM. Script/TeX batches use
59seconds/1GiB/one thread; Lean2048MiB/one thread followed by a separate audit.
Owned unused products are removed after each batch; cleanup starts below20GiB.
Publication I/O and strict Sphinx use their separate monitored watchdog and
must not launch mathematical checks. Generated sites, compiler objects and
caches remain untracked. The optional936-file bulk payload is **unuploaded**.

.. toctree::
   :maxdepth: 1

   papers
   methods
   verification
   reproducibility
   scope

The `GitHub repository <https://github.com/sashakolpakov/CoxeterPolytopes>`_
contains source arguments and evidence. Read each check's declared scope before
interpreting PASS: written review, arithmetic replay and conditional Lean
logic supply different evidence.
