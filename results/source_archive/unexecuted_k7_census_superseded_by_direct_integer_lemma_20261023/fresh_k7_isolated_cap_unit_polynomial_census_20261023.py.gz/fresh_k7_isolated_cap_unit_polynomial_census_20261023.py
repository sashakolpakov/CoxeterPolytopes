#!/usr/bin/env python3
"""Exact finite necessary census for small isolated-cap cycles in K7.

This script has no geometry or field-recognition oracle. Its mathematical
input is an algebraic integer w of degree three in the real seventh
cyclotomic field (field discriminant 49), with one root in (0,256/25)
and the other two in (0,28/45), and norm one. Necessary polynomial
coefficients satisfy p=X^3-T*X^2+B*X-1, 1<=T<=11, 1<=B<=13,
and disc(p)=49*k^2 for a positive integer k. Norm-one reduction and
the geometric interpretation are external obligations, not outputs.

Algorithm: visit all 143 coefficient pairs, filter the exact integer
discriminant, and count roots in both rational open intervals with a
complete rational Sturm sequence. All endpoint evaluations are nonzero
because the endpoints are zero or nonintegral rationals and p is monic
with constant term -1. Output every discriminant candidate and both
root counts, including any survivors. Empty output must not be assumed
before actual execution. No floating point, samples or coefficient
cutoffs beyond the proved T/B domain are used.

Termination/completeness: the coefficient rectangle is finite; each
Euclidean remainder strictly lowers degree. Sturm's theorem gives the
two exact root counts. Every input polynomial occurs at its own T/B
pair. A survivor requires all three roots in the larger interval and
exactly two in the small one. This is a necessary overapproximation;
no surviving polynomial is claimed realized in K7 or by an actual wall.
"""

from fractions import Fraction
from math import isqrt
import json


SMALL = Fraction(28, 45)
LARGE = Fraction(256, 25)


def trim(poly):
    while poly and poly[-1] == 0:
        poly.pop()
    return poly


def remainder(numerator, denominator):
    result = list(numerator)
    while result and len(result) >= len(denominator):
        offset = len(result) - len(denominator)
        quotient = result[-1] / denominator[-1]
        for index, coefficient in enumerate(denominator):
            result[offset + index] -= quotient * coefficient
        trim(result)
    return result


def sturm_sequence(poly):
    derivative = [index * poly[index] for index in range(1, len(poly))]
    result = [poly, derivative]
    while True:
        rem = remainder(result[-2], result[-1])
        if not rem:
            return result
        result.append([-coefficient for coefficient in rem])


def evaluate(poly, point):
    result = Fraction(0)
    for coefficient in reversed(poly):
        result = result * point + coefficient
    return result


def variations(sequence, point):
    signs = []
    for poly in sequence:
        value = evaluate(poly, point)
        if value:
            signs.append(1 if value > 0 else -1)
    return sum(left != right for left, right in zip(signs, signs[1:]))


def root_count(sequence, lower, upper):
    return variations(sequence, lower) - variations(sequence, upper)


def census():
    # These exact inequalities certify the complete integer coefficient box.
    assert 11 < LARGE + 2 * SMALL < 12
    assert 13 < 2 * LARGE * SMALL + SMALL**2 < 14
    candidates = []
    survivors = []
    for trace in range(1, 12):
        for pair_sum in range(1, 14):
            discriminant = (
                trace**2 * pair_sum**2 - 4 * pair_sum**3
                - 4 * trace**3 - 27 + 18 * trace * pair_sum
            )
            if discriminant <= 0 or discriminant % 49:
                continue
            index_square = discriminant // 49
            index = isqrt(index_square)
            if index * index != index_square:
                continue
            polynomial = [Fraction(-1), Fraction(pair_sum),
                          Fraction(-trace), Fraction(1)]
            assert all(evaluate(polynomial, point) != 0
                       for point in (Fraction(0), SMALL, LARGE))
            sequence = sturm_sequence(polynomial)
            small_roots = root_count(sequence, Fraction(0), SMALL)
            large_roots = root_count(sequence, Fraction(0), LARGE)
            row = {
                'trace': trace,
                'pair_sum': pair_sum,
                'discriminant': discriminant,
                'order_index': index,
                'roots_in_small_interval': small_roots,
                'roots_in_large_interval': large_roots,
            }
            candidates.append(row)
            if small_roots == 2 and large_roots == 3:
                survivors.append(row)
    return {
        'status': 'EXACT_NECESSARY_POLYNOMIAL_CENSUS',
        'coefficient_pairs_examined': 143,
        'small_interval': ['0', str(SMALL)],
        'large_interval': ['0', str(LARGE)],
        'discriminant_candidates': candidates,
        'survivors': survivors,
        'necessary_domain_empty': not survivors,
        'scope': 'Conditional local K7 norm-one algebraic-integer domain only; '
                 'no whole dimension bound or wall realization.',
    }


if __name__ == '__main__':
    print(json.dumps(census(), indent=2))
