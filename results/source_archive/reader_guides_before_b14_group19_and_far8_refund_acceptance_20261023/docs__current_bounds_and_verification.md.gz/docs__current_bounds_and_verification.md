# Current bounds and verification

Updated23 October2026. There are **six paper families**, each with a written,
compiled and internally reviewed TeX/PDF edition. Later supporting proofs improve
the compact bounds without multiplying papers. This page reports the current
mathematical state; dated receipts and preserved predecessor guides record history.

## Dimension comparison

| Class | Largest published example | Published ceiling | Current internally reviewed ceiling | Relation to the PDF |
|---|---:|---:|---:|---|
| General Coxeter, finite volume | 21 | 995, Prokhorov/Khovanskii | **57** | Current48-page paper |
| General compact Coxeter | 8 | 29, Vinberg | **18** | Supporting proof;36-page PDF states23 |
| Compact arithmetic Coxeter | 8 | 29, Vinberg | **15** | Supporting proof;21-page PDF states20 |
| Noncompact arithmetic Coxeter | 21 | 21, Esselmann | **21**, sharp and published | No new claim |
| Arithmetic Coxeter, compact or noncompact | 21 | 29 overall | **21**, sharp overall | New compact proof plus published noncompact theorem |
| Right-angled, finite volume, all vertex types | 8 | 12, Dufour | **8**, internally sharp | Current5-page paper |
| Right-angled, entirely ideal | 4 | 6, Kolpakov | **4**, internally sharp | Same5-page paper |
| Right-angled, compact | 4 | 4, published and sharp | **4**, unchanged | External starting result |

“Internally reviewed” means a complete written argument with the stated external
and finite-data interfaces, another author's source review and root acceptance.
It is distinct from publication, refereeing, complete computational replay and
end-to-end formalization. References and exact published scopes are recorded in
[the assumption register](manuscript_assumptions.md) and the
[right-angled proof map](right_angled_sharp_dimensions_publication_proof_map_20261021.md).
The quadratic-form model is automatic for arithmetic reflection lattices;
“first type” is not an extra restriction on the arithmetic rows.

## Current compact frontiers

The [global compact18 composition](../results/compact_dimension18_global_composition_and_whole_d19_exclusion_candidate_20261022.md)
excludes dimension19 and combines it with the independent higher-dimensional
argument. Its [written acceptance](../results/compact_dimension18_global_written_acceptance_20261022.json)
and [conditional Lean execution](../results/lean_compact18_composition_verification_20261022/manifest.json)
have separate scopes. At exact18 the complete necessary farthest-vertex
list contains only **whole D18**, after the
[complete whole-B18 exclusion](../results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md).
This is a necessary diagram at a selected farthest vertex, not a claim
about every vertex or a realized example. The frozen PDF states23.

For B18, the [complete terminal inventory](../results/review_compact18_b18_uniform_terminal_lengths_complete_seventeen_inventory_root_acceptance_20261023.md)
and earlier finite/dotted far-helper exclusions are followed by two new
actual-neighbor arguments. The [distinct-cap theorem](../results/review_compact18_b18_distinct_terminal_caps_and_seven_common_cases_root_acceptance_20261023.md)
leaves seven common-wall cases; the
[five-case theorem](../results/review_compact18_b18_five_common_cases_and_two_holdouts_root_acceptance_20261023.md)
removes five of them. The
[head-gap and H3-neighbor theorem](../results/review_compact18_b18_zero_own_short_five_and_last_common_case_root_acceptance_20261023.md)
then removes own0/short5. The
[last common3/3 theorem](../results/review_compact18_b18_last_common_three_three_actual_neighbor_root_acceptance_20261023.md)
excludes the final own3/short-white3 role using the actual short-edge
neighbor with full A18 diagram. It retains comparison factor11/8 from
the ORIGINAL maximum and a reverse incident pressure>.8. A fresh .87
inventory, actual helper packing and one legally funded endpoint graft
give a norm above1.0131845 in every weak pattern. The
[complete conjunction](../results/compact18_whole_b18_complete_terminal_role_composition_and_single_d18_frontier_candidate_20261023.md)
has its own [full outside review](../results/review_compact18_whole_b18_complete_role_composition_single_d18_frontier_full_scope_replay_20261023.md)
and root acceptance: every far, near, distinct and common terminal role
is covered, including the explicit older anchor-price erratum. Thus
wholeB18 is excluded at the selected original vertex. No neighbor is
chosen farthest and no original/neighbor energies are added. WholeD18
and compact17 remain open.

For D18, **center16 is unconditionally .58-strong**:
`S16 > 4 - .58/sqrt(2)` for the original farthest vector. The
[complete conjunction](../results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md)
has a separate [full outside composition review](../results/review_compact18_d18_unconditional_strong16_complete_conjunction_full_scope_foundations_20261023.md).
It combines the complete original inventory, both pure-helper exclusions,
the finite-own fork-three exclusion, the
[new dotted fork-three theorem](../results/review_compact18_d18_dotted_fork_three_neighbor_root_acceptance_20261023.md)
and the entire zero-own/fork7--10 exclusion. The last two use actual
A15+A2+A1 or A15+I2+A1 neighbors. They check the complete foreign-cost
alphabet directly rather than importing a farthest-only rule there.
Every weak16 case is excluded, for both signed forks. This does not supply
the remaining fork budget or exclude whole D18.

The [new all-head fork theorem](../results/review_compact18_d18_unconditional_fork_ten_complete_white_native_five_head_root_acceptance_20261023.md)
reassembles the same reference ending16, including a possible weak15
deletion, and gives effective energy>.9729. Both fork cosh lengths are
then<10, with the complete seven-profile and finite isolated-centre
dispatch retained. The [terminal-slack and pair theorem](../results/review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md)
improves both lengths to<9.64. Its actual A18-neighbor lemma retains
factor11/8 and one reverse endpoint pressure; it gives near3 own<1.21
and far3 own<1.6. Both-near3 is impossible for all heads, and near3/far3
is impossible under native5 head. The [actual A17+A1 neighbor theorem](../results/review_compact18_d18_actual_a17_a1_isolated_cutoff_native5_far_pair_root_acceptance_20261023.md)
gave every isolated fork own<341/150 for all heads. Its full
native5 far3/far3 negative-core argument retains the first-coordinate
reference cross and pays only one terminal price. Thus native5 head
forces at least one isolated dotted fork; iso/iso, iso/near3 and iso/far3
remain. Other heads and wholeD18 remain open. This is written geometry,
without an enlarged scope for older Lean kernels.
The stronger [full actual-neighbor proof](../results/review_compact18_d18_fifteen_eighths_isolated_cutoff_root_acceptance_20261023.md)
now gives every isolated fork own<15/8, for all heads and both signed
forks. It uses factor8/5 at an actual A17+A1 neighbor, with the full
unequal-chain inventory and one paired reference in the exceptional row.

The new [all-head isolated-pair theorem](../results/review_compact18_d18_all_head_finite_isolated_pair_actual_a16_neighbor_root_full_source_acceptance_20261023.md)
excludes EVERY finite nonright mutual angle between two isolated D18
fork caps, including unequal parameters. A paid coordinate envelope gives
an actual A16+I2 neighbor with comparison factor<3/2; one vector there
has squared norm>431/400. The further
[dotted-mutual gap](../results/review_compact18_d18_isolated_fork_mutual_four_thirds_gap_root_full_source_acceptance_20261023.md)
excludes the entire interval1<mutual<=4/3. A remaining dotted mutual
has both owns dotted and own product>7/3. The subsequent
[orthogonal-pair theorem](../results/review_compact18_d18_orthogonal_isolated_pair_root_full_source_acceptance_20261023.md)
excludes mutual0 through an actual A15+I2+A1 neighbor. Thus the
isolated/isolated pair has ONLY the dotted region just described.
For isolated/near3, a separate
[actual-neighbor theorem](../results/review_compact18_d18_isolated_near_three_finite_mutual_root_full_source_acceptance_20261023.md)
excludes every positive finite mutual, retaining zero/dotted mutuals.
Those cases, isolated/far3 and wholeD18 remain open. There is no compact17.

The [global compact-arithmetic ceiling15](../results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md)
is now accepted after a full different-author review of the complete
written proof and global composition. The [445-line argument](../results/arithmetic16_whole_d16_quadratic_dyadic_splitting_complete_manual_exclusion_candidate_20261023.md)
excludes the last exact-dimension16 family, wholeD16. Its predecessor
and one corrected time-product coefficient are byte-preserved; the full
review checks every field case and the sole actual source delta.

The [geometric reduction](../results/review_arithmetic16_whole_d16_actual_quadratic_dotted_head_both_isolated_forks_root_acceptance_20261023.md)
first forces the ACTUAL field to be quadratic, with a dotted isolated
head and BOTH actual forks isolated and dotted. The final proof uses
all three original quarter-products and full K-time-square conditions.
Odd/even head norms and inert/ramified/split2 exhaust the fields;
complete maximal-order strips and full square tests close their finite
residues. The sqrt57 and sqrt6 geometric cases fail ONE legally funded
original-vector reference each. The new exclusion requires no census.

The [prior global16 theorem](../results/review_arithmetic17_whole_a17_global16_complete_composition_root_acceptance_20261022.md)
already excludes every dimension>=17. The [complete dimension16 frontier](../results/review_arithmetic16_b15_d15_complete_conjunction_and_single_d16_frontier_root_acceptance_20261023.md)
leaves only wholeD16 at the SAME selected original farthest vertex.
Removing it therefore proves the global15 bound, with no face heredity
or rank-decrement assumption. The overall theorem retains those older
authenticated computational premises; they were not rerun or relabelled
as handwritten. The prepared D16 worker is UNEXECUTED and not a premise.
The [fresh exact-dimension15 frontier](../results/review_arithmetic15_fresh_complete_twenty_two_group_frontier_root_full_source_acceptance_20261023.md)
now gives a complete reviewed cover by22 necessary groups. It starts
at actual total rank15, retains all typed exceptions and handles the
new small D tails with actual H4 projections. It is not obtained by
decrementing a rank16 list and supplies no dimension14 bound or example.

Within its FULL B14+actual-I group19, the
[complete head reduction](../results/review_arithmetic15_b14_all_finite_pure_heads_positive_foreign_root_acceptance_20261023.md)
leaves a pure dotted head or native3 old-I contact with zero mutual to
the I opposite. The [complete short-cap reduction](../results/review_arithmetic15_b14_complete_short_white_isolated_dotted_root_acceptance_20261023.md)
then makes the actual short14 cap isolated within B14 and dotted, retaining
all its finite old-I contacts. Both proofs have full different-author
reviews and root acceptance. In actual degree3, a new
[elementary cubic/mod-two argument](../results/review_arithmetic15_b14_cubic_terminal_even_norm_foreign_four_root_acceptance_20261023.md)
leaves norm2/4 and old-I contact0/3. Its native4 exclusion uses one
funded reference with total1.00457. These do not exclude group19 or
prove14; no new worker or Lean execution supports these written steps.

The frozen arithmetic PDF still states20. The older three-declaration
Lean composition audit proves its preserved16 implication under27 inputs;
it does not verify the new15 theorem. The new fourteen-declaration
[dyadic logic map](quadratic_dyadic_triple_kernel_logic_20261023.md)
is source preparation, with compilation and a separate actual audit
pending. All improvements stay within the same arithmetic paper family.

The earlier [whole-B16 theorem](../results/review_arithmetic16_whole_b16_complete_census_and_reference_root_acceptance_20261023.md)
retains its distinct computational boundary. Its [actual census receipt](../results/b16_isolated_quadratic_pair_census_verification_20261023.json)
binds three disjoint field parts and a separate authenticated combine:
43 fields and273 ordered pairs, with168 half-product failures,104
full-field nonsquares and ONE necessary pair. That pair fails a separate
original-vector estimate. All four guarded units passed in1.918seconds,
maximum sampled process-tree RSS56,999,936bytes. This is not an empty
census, an independent second implementation or a new polytope example.

## Verification status

| Result or package | Written status | Executed verification and remaining boundary |
|---|---|---|
| General finite volume57 | Complete paper, internal composition review | All25 bounded B13/frontier replacement units passed and are integrated. Matching inherited evidence covers111 other script selections. No combined146-job full runtime PASS or complete transitive regeneration. Selected counting/table/scalar kernels compiled and separately audited; actual geometry remains external. |
| General compact18 | Complete supporting composition, outside review and root acceptance | Its five-declaration composition kernel compiled and separately audited under23 written inputs. The later whole-B18 exclusion and single-D18 necessary frontier are written mathematics; older kernels are not relabelled as verifying them. |
| Compact arithmetic15 | Complete written whole-D16 exclusion and global composition, full different-author review and root acceptance | New dyadic step is handwritten; older authenticated computations remain inputs. The prepared D16 census was not executed or used. Older Lean kernels retain their16/precursor scopes; the new fourteen-declaration discrete kernel is prepared, with compilation and separate actual audit pending. |
| Right-angled8 and ideal4 | One complete5-page paper, internal reviews and exact checks | Projection/height, tensor-polynomial and count logic have selected script/Lean checks. Actual geometry and the cited facet/code/classification results remain external. |
| Ideal RA4 volume and structure | Complete17-page paper and internal reviews | Exact combinatorial/model checks and selected conditional logic; no complete geometric Lean formalization or external referee approval. |
| Compact RA4 volume constraints | Complete14-page paper and internal reviews | Exact capacity/excess checks and conditional logic. It does not prove a global minimum or a unique second-volume double. |

### Quadratic dyadic triple logic preparation

The new [Std-only source](../formal/CoxeterProofs/QuadraticDyadicTripleKernel.lean)
and [input map](quadratic_dyadic_triple_kernel_logic_20261023.md) prepare
fourteen discrete declarations: primitive valuation/parity contradictions,
both-fork consequences, bounded integer norms and the final numerical
implication. There is no compile or separate actual axiom-audit PASS.
Ideal theory, finite coefficient tables, field-square tests, geometry
and a real application remain external. The unchanged6GiB proof gate
applies before any named compilation or audit.

### B16 isolated-pair scalar preparation

The [consolidated source/input map](b16_isolated_pair_scalar_kernel_logic_20261023.md)
has a [full different-author static review](../results/review_b16_isolated_pair_scalar_kernel_precompile_full_source_and_map_replay_20261023.md)
and [root precompile clearance](../results/review_b16_isolated_pair_scalar_kernel_root_precompile_acceptance_20261023.md).
It derives integer valuation parity, the complete small-conjugate cubic
root bound and both case-specific prefix contradictions over a genuine
ordered ring. Number-field/ideal facts, actual geometry, the census,
primitive pressures and real instances remain explicit external inputs.

**No successful compilation or separate actual axiom audit is credited.**
The first admitted compile failed because two local proof names used the
reserved token `prefix`. Its entire diagnostics, source and map are
[byte-preserved](../results/lean_b16_isolated_pair_scalar_verification_20261023/failed_compile_source_preservation.json).
Diagnostic `sorryAx` prints are failed output and have zero audit credit.
The successor changes only those names and has
[full delta review](../results/review_b16_isolated_pair_scalar_reserved_identifier_and_map_delta_compact_20261023.md)
and [root clearance](../results/review_b16_isolated_pair_scalar_reserved_identifier_repair_root_clearance_20261023.md).
Fresh RAM is below6GiB, so no retry has launched. The unchanged admission
gate remains; earlier successful modules have not rerun. The written
theorem and four guarded census units retain their separate scopes.

### B18 terminal-pressure scalar logic

The [new logic map](b18_terminal_pressure_kernel_logic_20261023.md) has
full different-author static review and [root precompile clearance](../results/review_b18_terminal_pressure_kernel_root_precompile_acceptance_20261023.md).
Its [actual bounded compile and separate ten-declaration audit PASS](../results/lean_b18_terminal_pressure_verification_20261023/manifest.json)
took1.71seconds and1.16seconds. The audit reused the successful object;
no older module ran. All ten actual prints contain only propext,
Classical.choice and Quot.sound, with no sorryAx. Two unused-variable
warnings are preserved, and owned temporary proof work is absent.

The module derives the unbounded mixed-pressure polynomial and the full
subcritical radical/convex-sum contradiction from primitive scalar data.
Actual normals, complete inventories, the original farthest vector,
all-wall future feasibility, pressure, terminal sums and a real instance
remain ordinary explicit premises. This is conditional scalar verification
for the near3/own6 theorem, not a full geometric theorem, wholeB18 or
verification of later role exclusions. Preparation source/map headers
retain their historical zero-execution labels; the receipt records PASS.

### Heavy-centre forest logic

The [new kernel map](heavy_centre_forest_scalar_kernel_logic_20261023.md)
has an [actual bounded compilation and separate eleven-declaration audit PASS](../results/lean_heavy_centre_forest_verification_20261023/manifest.json).
Primitive square equations imply the cone inequalities; strong finite-chain
induction derives no-return from two local geometric bridges. Natural variables
index the chain or count incidences; metric quantities remain in an ordered ring.
Actual hyperbolic instances, graph-cycle realization,
forest Euler and reverse ports remain external. All eleven prints use only
standard foundational axioms, with no `sorryAx`. Compilation took2.4seconds
and the separate audit1.93seconds. The earlier5.8GiB admission refusal and
one unused-variable warning are retained. The531912-byte object is ignored;
owned temporary proof work is absent. No older successful module was rerun.

### A18 continuous scalar verification

[A18TwoDottedEndpointScalarKernel](a18_two_dotted_endpoint_scalar_kernel_logic_20261023.md)
now has [actual bounded compilation and a separate ten-declaration audit PASS](../results/lean_a18_two_dotted_endpoint_verification_20261023/manifest.json).
The unchanged12998-byte source derives radical chords from square identities,
the full continuous core gap, endpoint gains, one paid completion and all four
endpoint budget patterns over a genuine ordered ring. Actual geometric pressures,
all-hole references, individual legal prices, orthogonality and a real instance
remain explicit premises. It supports the two-dotted branch, not a wholeA18
exclusion or the later mixed theorem by itself.

Compilation took3.25seconds and the admitted audit1.77seconds. All ten printed
axiom sets contain exactly`propext`, `Classical.choice` and `Quot.sound`; no
`sorryAx` occurs. One unused-variable warning is retained, and no cosmetic rerun
was made. The earlier audit admission refusal is preserved alongside the later
PASS. Owned temporary proof work is absent; its691656-byte object is an ignored
cache, not a publication asset. The linked map and preclear are immutable
preparation records; the execution receipt supplies the later status.

The earlier [eleven-declaration endpoint kernel](general_eighteen_endpoint_refinement_logic_20261023.md)
retains its [actual PASS](../results/lean_general18_endpoint_refinement_verification_20261023/manifest.json)
for the preceding FIVE-case deduction and finite analytic integer seals. Its
scope is not expanded by later source reviews. Printed foundational axioms do
not list theorem parameters; consult each logic map for external assumptions.

## Work toward finite volume56

The latest far-row8 proofs finance the entire isolated first-neighbor
[contact3/4/parallel domain](../results/review_finite57_far_row8_isolated_intervening_cusp_financing_root_acceptance_20261023.md)
and its [orthogonal-contact extension](../results/review_finite57_far_row8_orthogonal_isolated_b4_cusp_financing_root_acceptance_20261023.md).
Their 22 parameterized whole-cusp families have actual edge endpoints,
complete source injections and every prior debt retained. The smallest
remaining capacities after all new loads are3352 and7234 respectively.
The corrected small coefficient factor and the original wording are preserved.

For an affected WHOLE D23, the
[finite-contact receiver theorem](../results/review_finite57_far_row8_d23_finite_a21_dihedral_receiver_root_acceptance_20261023.md)
handles every finite positive contact: an actual A21+I2+2D17 receiver
has full C0=356 and at most one original heavy source, so its8 arrival
reaches364. The analogous affected-D17 receiver has full C0=360.5,
including both half cross payments. Its8 arrival reaches368.5, leaving
a genuine4.5 deficit. Dotted contacts, other first-neighbor forms and
complete global coverage remain open. No56 theorem or new execution
credit follows from these reviewed written arguments.

The [special-face theorem](../results/review_finite57_special_native_bond_compact_face_and_label_restriction_root_acceptance_20261023.md)
proves compactness and the Coxeter property explicitly for the codimension-two
face of a native5 or native7+ bond at a finite vertex. Every intrinsic facet
and projected angle is checked; arbitrary face heredity is not assumed.

| Additional restricted class | From published compact29 | From internal compact18 | Verification |
|---|---:|---:|---|
| Finite volume with a native5 or native7+ bond at a finite vertex | <=31, derived | <=20, derived | Complete written special-face proof, full outside review and root acceptance; no new Lean or historical-novelty claim |

These are consequences of the respective compact bounds, not a claim that31
is the published optimum for this class. The finite57 application uses only
published29: its compact face would have dimension55. Thus the remaining
finite5+ contact is ONLY native6. Native6 can lie in an affine G2 cusp,
so its face need not be compact and that last finite case is not excluded.
The affected-D17 4.5-unit deficit is retained by the old unweighted
rule; a new weighted local comparison is described below. Dotted
continuation and complete global financing remain open.
The [positive native-six weighting](../results/review_finite57_native_six_positive_weighting_flags_and_single_factor_receiver_root_acceptance_20261023.md)
instead weights each actual polygon by(2/3)^r, with r its number of
containing native-six faces. Its exact weighted flag identity avoids
subtracting an old lower bound. The selected D17 receiver has original
weighted charge241 and at most one8 arrival, below the single-factor
shape minimum1499/6 by5/6, including its accepted
[complete old-debt audit](../results/review_finite57_native_six_selected_receiver_zero_old_debt_root_acceptance_20261023.md). The [all-factor theorem](../results/review_finite57_native_six_all_finite_minima_smoothed_ideal_root_acceptance_20261023.md)
now gives the exact finite shape minimum for every factor count and
parity. At a cusp with another factor of rank>=13, a discrete smoothing
argument compares the ORIGINAL normalized factor envelope. Actual
weighted ideal charges and receiving reserves require separate bounds;
the selected old-debt argument below now supplies those comparisons.
The [complete native-six finite budgets](../results/review_finite57_all_single_native_six_finite_budgets_root_acceptance_20261023.md)
now cover EVERY finite vertex with at least one native-six factor,
including Context and every retained token. The single-factor proof
compares formal rank57 forests under two replacements. A rational
certificate and a strict modular endpoint handle the general case;
the complete A17 and modified D15 remainder bounds handle the exceptions.
The smallest normalized single-factor margin proved is19/960.
The [complete selected old ideal-debt theorem](../results/review_finite57_native_six_all_old_ideal_debts_root_full_source_acceptance_20261023.md)
now pays the whole-A15 and A16/E8 priorities, all Context branches and
every retained fixed receiving load at native-six cusps. Face-indexed
transfers use actual inert-port weights; fixed tokens keep their ORIGINAL
amounts. Large ordinary factors are covered analytically. The only ideal
obligation left for this ledger is the bare small-factor domain. Its
[complete convex reduction and exact worker](../results/review_finite57_native_six_bare_ideal_worker_contract_root_preexecution_clearance_20261023.md)
have full mathematical/code source clearance. Generation and separate
same-implementation replay are unexecuted; no positivity is credited.
The [strict weighted global comparison](../results/review_finite57_native_six_weighted_global_extrema_strictness_root_acceptance_20261023.md)
is now proved independently of the missing caps: actual weighted link
graphs and the two global extrema give the positive correction
280*(2/3)^28. It is conditional on the SAME complete face rule and all
vertex caps. Heavy vertices without native6, full face coverage and the
unexecuted bare ideal check remain open. No56 follows.

The [local native6 port obstruction](../results/review_finite57_native_six_unbounded_same_face_local_ports_root_full_source_acceptance_20261023.md)
constructs arbitrarily many actual heavy records on one common I2(6)
face with one specified full affineG2 cusp. Its region has infinite
volume. Thus local geometry alone supplies no bounded source-to-cusp
count; a valid continuation must use finite volume or the still-unpaid
priority domain. It sends no charge and removes none of the old debts.


The global ceiling remains57. New accepted selected-domain results finance:

* [all isolated finite short-fork caps](../results/review_finite57_all_isolated_finite_short_fork_receivers_root_acceptance_20261023.md), with unique actual cheap finite centre receivers;
* [every actual ideal fork-centre neighbour](../results/review_finite57_ideal_fork_centre_joint_parallel_financing_root_acceptance_20261023.md), with all parent families, cusp ports and previous debts;
* the [safe finite-centre union](../results/review_finite57_finite_centre_safe_union_and_heavy_escape_root_acceptance_20261023.md), from the complete twelve-class finite endpoint table.

The last result also proves that a component of heavy vertices cannot be closed
under all three centre moves: its actual three-face would be compact and
right-angled, and three facet colours would force every polygon to have an even
number of sides at least six, contradicting Euler's formula.

The [new metric forest theorem](../results/review_finite57_heavy_centre_forest_and_linear_exit_expansion_root_acceptance_20261023.md)
strengthens this: heavy-to-heavy centre edges have cosh length at least16,
and successive directions are orthogonal, so no cycle is possible. Every
heavy set S has exactly |S|+2c(S) centre-edge incidences leaving it. A full
component with H vertices has H+2 nonheavy exits. This supplies linear
expansion. The later [mixed row1/row2 theorem](../results/review_finite57_row_one_two_variable_cone_component_financing_root_acceptance_20261023.md)
extends the forest to both receiving types, including every finite dihedral
label and arbitrary dotted exchanged products. A variable-angle cone argument
handles the nonright row2 turns. Full-component counting supplies enough safe
eight-unit tokens when all nonheavy centre neighbours have these types,
retaining the old K/Q/L1 payments. Other exits remain explicit in its criterion;
there is no universal364 cap or dimension56 theorem.

The [zero-exchanged costly-exit theorem](../results/review_finite57_zero_exchanged_bad_centre_affine_financing_root_acceptance_20261023.md)
finances rows4/5/6/11 through complete actual cusp recoveries. The newer
[all-row7/near-row8 theorem](../results/review_finite57_zero_exchanged_all_row7_near_row8_financing_root_acceptance_20261023.md)
finances every zero-exchanged row7 and the near orientation of row8.
Its actual finite A4/B4 receivers retain all old debts; full restorer
products force at most ONE qualifying source across both A4 ports.
Maximum new finite cost is358<364. Far-row7 instead has an actual ideal
short-leaf endpoint already paid by the retained J allocation.

Among still-unpaid nonheavy finite centre exits with zero exchanged
product, only FAR-row8 remains. Its actual affine B4 kernel lies on an
old two-face and accounts for rank55. It does not supply a rank56 cusp
classification or a virtual extra affine A1. The immediate finite
receivers cost371.75/365 and cannot accept8 under364. Positive exchanged
products and complete global coverage remain open. No universal364 cap
or dimension56 theorem follows.

## Construction search

The glued E7/ternary nine-dimensional host is now [proved nonreflective](../results/review_glued_e7_a2_two_unit_releases_original_period_and_literal_nonreflectivity_root_acceptance_20261023.md).
After the actual norm-four corner, two complete23-profile first-wall proofs
give two actual finite vertices and their full outward germs. Each proof keeps
all primitive norm classes, both embeddings, original-module membership and
unknown-wall firstness. Five displayed projection-sign errors in excluded
rows of the first edge were [corrected with byte-preserved history](../results/review_glued_e7_a2_e2_release_five_sign_successor_root_acceptance_20261023.md);
the repaired exclusions and actual first wall survive.

Two individually nonintegral metric involutions have a product G that preserves
the ENTIRE original module, proved by a universal parity identity. It maps the
two actual full germs and preserves the full chamber. Its exact trace5+4phi>10
proves infinite order. Distinct powers give infinitely many cosets of the full
reflection group in the arithmetic lattice, hence infinite chamber volume.
This closes precisely this literal host. It gives no new compact9 example,
field-wide theorem or commensurability-class exclusion.

The different [squared-unit coupling host](../results/review_h9_squared_unit_e7_return_original_period_literal_nonreflectivity_root_acceptance_20261023.md)
is now also proved nonreflective. Its actual E7 quadrilateral and ambient
D6/B3 walk return to a full E7+A2 germ. The return map is original on all
ten basis columns; composing it with the earlier original involution gives
trace16phi^6=80+128phi>10. This infinite-order chamber stabilizer proves
infinite chamber volume. The earlier order-two symmetry alone did not
supply that conclusion. This closes the second literal host, not its
whole form or commensurability class, and gives no new example.

A genuinely different [prime41 cubed-unit host](../results/review_h9_cubed_unit_prime41_original_host_first_edge_root_acceptance_20261023.md)
has original ternary Gram[[2,-1,phi^3],[-1,2,0],[phi^3,0,-2phi]] and an
independent E7 summand. Its norm41 determinant valuation separates the
specified unit-coupled E8 family up to K-similarity. Complete original
root classes, both embeddings, strips and primitive filters prove the
first actual edge. The [second actual unit edge](../results/review_h9_prime41_second_actual_unit_edge_original_germ_obstruction_root_acceptance_20261023.md)
is also accepted, with its full E7+[2b]+[2] endpoint. A repeated abstract
germ does not provide a period: its uniquely prescribed metric return
fails the ORIGINAL lattice test. The [third actual edge](../results/review_h9_prime41_third_actual_edge_original_involution_full_hexagon_root_acceptance_20261023.md)
returns to a full E7+A2 germ through a genuine original chamber
involution of order two. Its three actual edges and their images close
the WHOLE compact E7 hexagon, with angles(pi/3,pi/2,pi/2,pi/3,pi/2,pi/2)
and area4pi/3. Neither this face nor the finite-order symmetry establishes
ambient finite volume, nonreflectivity or a new H9 example.

The [accepted ambient continuation](../results/review_h9_prime41_ambient_d6_pentagon_mixed_d4_original_obstructions_root_acceptance_20261023.md)
now leaves that E7 face. Three complete original wall censuses produce
U,S,H and a full H3+D4+A1+[2b41] corner through actual intermediate
vertices. They retain all four primitive norm classes, full original
covectors, both embeddings, closed coefficient covers and unknown-wall
firstness. One D6+N-fixed face is recognized as the entire regular
right pentagon. All norm-class-preserving metric candidates there and
all five nonidentity D4 local permutations fail original membership.
Two wording-only scope repairs are byte-preserved. This is local ambient
construction, not a finite-volume chamber or infinite period; no new
H9 example has been established.

The [next two original edges](../results/review_h9_prime41_mixed_d4_two_actual_edges_b2_double_h3_root_acceptance_20261023.md)
reach full2H3+B2+[2b41]. A global prime41 finite-N congruence removes
both nonunit classes; complete six/nine-profile domains and closed
embedding strips establish actual firstness. The first step resolves
the coincident norm2/norm4 mirrors by the local B2 chamber, and the
second uniquely finds V=phi(g+omega5). The terminal H3 swap fails
original integrality. This is further accepted ambient construction,
with finite volume, compactness, a period and a new example still open.

## Papers, algorithms and resource limits

The [six-paper index](../manuscripts/README.md) maps results to techniques,
source/PDF editions and proof maps. The
[result-manuscript correspondence](result_manuscript_correspondence.md) preserves
more detailed history. Supporting improvements remain in the same paper families;
parked refinements and earlier editions are preserved rather than added as papers.

The [computational proof contract](computational_proof_contract.md) requires each
algorithm's domain, completeness and termination proof, exact arithmetic, output
and replay boundary. Use [finite57's reproduction guide](finite_volume57_reproduce.md)
and [the formal-project guide](../formal/README.md) for named batches. Hashes,
source review, arithmetic replay and geometric formalization are different checks.

One scientific/Lean/TeX child runs at a time under the shared lock. Admission is
40GiB disk/6GiB available RAM; runtime floors are8GiB/3GiB. Script/TeX batches
retain59seconds/1GiB/one thread; Lean2048MiB/one thread, then a SEPARATE audit.
Remove only owned unused products after each batch. Cleanup starts below20GiB
free disk; sources, certificates, final PDFs and execution history are preserved.

Publication requires the actual staged-index debris/secret audit and strict
Sphinx build through the256MiB sampled-RSS publication watchdog. No compiler
objects, caches or generated sites belong in Git. The optional936-file/33-archive
bulk payload remains unuploaded and excluded from Git; see
[repro/README.md](../repro/README.md).

The exact preceding reader guides are [byte-preserved](../results/source_archive/reader_guides_before_short_cap_and_strict_weighted_counting_20261023/manifest.json).
Historical execution receipts retain their original source bindings and are not
silently rebound to this rewritten current guide.

The [whole compact quadrilateral theorem](../results/review_h9_prime41_double_h3_whole_compact_quadrilateral_root_full_source_acceptance_20261023.md)
now closes the two-face retaining both H3 factors and N, by two further
original unit edges and a direct positive projection to an old actual
wall. Its angles are pi/4,pi/2,pi/2,pi/2 and its area is pi/4.
The all-wall and intrinsic-face proof has full written review. Ambient
volume and a new H9 example remain open; this stays construction research.

The next prime41 E6+B2 edge has a
[complete finite-termination proof](../results/review_h9_prime41_e6_b3_e2_relative_unit_termination_five_profiles_root_acceptance_20261023.md).
A relative order unit, an explicit index12 submodule and a congruence
power give a genuine original-lattice forward mirror. The complete
finite-white domain reduces to five profiles. The associated
[witness/firstness worker and contract](../results/review_h9_prime41_e6_b2_witness_firstness_worker_contract_root_preexecution_clearance_20261023.md)
have full source review, with generation, separate replay and complete
firstness still unexecuted. No numerical unit, witness or next facet is
claimed from that preparation.
