# The six papers and their techniques

There are **six current paper families**, with written, compiled and internally
reviewed TeX/PDF editions. The compact18 and arithmetic15 supporting improvements
belong in the existing compact families when integrated. They are not extra
papers, and the frozen PDFs still state23 and20. Earlier TeX notes, fragments,
predecessors and generated atlases are preserved supporting material.

| Paper and TeX | Main technique | Result in this PDF | PDF | Proof/reproduction map | Verification ID |
|---|---|---|---|---|---|
| [General finite volume](finite_volume57.tex) | Corner payments, Coxeter forests and cusp curvature | Dimension at most57 | [48 pages](build/finite_volume57.pdf),12 main +36 essential appendices | [Proof map](../docs/finite_volume57_lemma_map.md) | `finite57` |
| [Sharp right-angled dimensions](right_angled_sharp_dimension_bounds_publication.tex) | Actual projections, descending heights and spherical codes | Finite volume at most8; entirely ideal at most4; both internally sharp | [5 pages](build/right_angled_sharp_dimension_bounds_publication.pdf) | [Proof map](../docs/right_angled_sharp_dimensions_publication_proof_map_20261021.md) | `right_angled_sharp` |
| [General compact](compact_farthest_vertex_bounds.tex) | One farthest vertex and additive component energies | Dimension at most23; later supporting proof18 | [36 pages](build/compact_farthest_vertex_bounds.pdf) | [Proof map](../docs/compact_farthest_vertex_bounds_proof_map_20261020.md) | `compact_farthest_bounds` |
| [Compact arithmetic](compact_arithmetic_dimension_bound.tex) | Field reduction and exact angle rules, with the same geometric budget | Dimension at most20; later supporting proof15 | [21 pages](build/compact_arithmetic_dimension_bound.pdf) | [Proof map](../docs/compact_arithmetic20_proof_map.md) | `compact20` |
| [Ideal RA4 volume and structure](ideal_ra4_volume_and_structure_publication.tex) | Volume gap, equality recognition and restricted decomposition | Published minimum; second volume and unique double; restricted24-cell chains | [17 pages](build/ideal_ra4_volume_and_structure_publication.pdf) | [Proof map](../docs/ideal_ra4_volume_and_structure_proof_map.md) | `ideal_ra4_volume_and_structure` |
| [Compact RA4 volume constraints](compact_ra4_volume_constraints.tex) | Facet capacity, excess and recognition | Necessary volume/structure constraints | [14 pages](build/compact_ra4_volume_constraints.pdf) | [Proof map](../docs/compact_ra4_volume_constraints_reproduce_20261019.md) | `compact_ra4` |

The57 and sharp right-angled papers are the priority entry points. The
[current comparison guide](../docs/current_bounds_and_verification.md) distinguishes
published bounds, supporting improvements and actual verification. The
[detailed result correspondence](../docs/result_manuscript_correspondence.md)
preserves the longer provenance. The
[six-paper delivery receipt](../results/six_paper_final_tex_delivery_20261021.json)
binds the matching frozen sources, PDFs and build records.

## Where the common arguments split

Finite57 first establishes one simultaneous corner-payment rule. Finite vertices
then require exact spherical-forest maxima; ideal vertices require affine-factor
charges and actual cusp multiplicities. Both branches reunite in one incidence
contradiction. The higher-dimensional tail is separate and does not assume a
facet is itself Coxeter.

The compact proofs start with the same original farthest vector. Ordinary,
large-A and large-B/D component estimates have separate geometric arguments,
then reunite through additive squared norms. Rank-specific endpoint and fork
cases close the surviving configurations. Arithmeticity adds field/angle
restrictions rather than a second unrelated geometric framework.

The sharp right-angled paper shares one actual projection lemma between its
general and entirely ideal cases. Spherical-code estimates and the relevant
published facet minima enter at clearly identified later steps. Its internally
sharp8/4 bounds do not assume arithmeticity.

The ideal four-dimensional paper combines the published minimum, second-volume
recognition and restricted24-cell chains as one sequence. It does not classify
arbitrary ideal right-angled polytopes as24-cell garlands. The compact RA4 paper
does not prove that the120-cell is the absolute volume minimum, nor that its
double is the unique second-volume example; those remain open here.

## Supporting research and actual checks

General compact18 and arithmetic15 have complete reviewed written supporting
compositions. Older conditional Lean modules retain their declared scopes;
the new15 discrete kernel is prepared, with no compilation/audit yet.
At exact compact18 the latest
accepted necessary frontier is ONLY wholeD18 after the
[complete whole-B18 exclusion](../results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md).
This concerns a selected farthest vertex, not every vertex or a realized
example. The new [complete arithmetic15 proof](../results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md)
closes that arithmetic family’s last whole-D16 case. Its actual-field
reduction leaves a quadratic head/fork triple; the full dyadic splitting
and maximal-order analysis excludes it without executing the prepared
census. The global deduction retains the older authenticated computational
inputs, with the SAME original farthest vertex throughout.
Earlier exclusions and the complete necessary-list chain are mapped in
[the result correspondence](../docs/result_manuscript_correspondence.md).
The earlier whole-B16 quadratic census retains four actual guarded
PASS units and one necessary pair, subsequently excluded geometrically;
the newer B15/D15 proofs use written all-field arguments instead.
The PDFs have not been revised for these later bounds. The new compact
terminal reductions and literal-host nonreflectivity belong to supporting
research, not additional proposed manuscripts.

The finite-volume family now includes zero-exchanged row7/near-row8 financing
and complete far-row8 isolated contact0/3/4/parallel cusp financing. A
unique finite receiver also covers positive finite contacts on affected D23. Other
far-row8 and positive exchanged products remain. The general compact family
now has the [last B18 role exclusion](../results/review_compact18_b18_last_common_three_three_actual_neighbor_root_acceptance_20261023.md)
and [unconditional D18 centre16 strength](../results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md).
The shared new technique is comparison at an actual neighbor with an explicit
loss from the original maximum, followed by one orthogonal norm budget there.
The separately reviewed complete conjunction closes wholeB18; wholeD18
and compact17 remain open. The [D18 pair refinement](../results/review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md)
retains the terminal surplus to bound both cosh lengths<9.64. An actual
A18 neighbor lemma excludes two complete pair families at their stated
head scopes. The [actual A17+A1 neighbor theorem](../results/review_compact18_d18_actual_a17_a1_isolated_cutoff_native5_far_pair_root_acceptance_20261023.md)
excludes native5 far3/far3. The stronger
[actual-neighbor cutoff](../results/review_compact18_d18_fifteen_eighths_isolated_cutoff_root_acceptance_20261023.md)
bounds every isolated fork own by15/8, for every head.
That head now forces an isolated dotted fork; iso/iso, iso/near3 and
iso/far3 remain. The [new all-head pair theorem](../results/review_compact18_d18_all_head_finite_isolated_pair_actual_a16_neighbor_root_full_source_acceptance_20261023.md)
excludes every finite nonright mutual between isolated forks, including
unequal parameters. The [dotted-mutual gap](../results/review_compact18_d18_isolated_fork_mutual_four_thirds_gap_root_full_source_acceptance_20261023.md)
further forces mutual>4/3 and both owns dotted. The
[orthogonal-pair proof](../results/review_compact18_d18_orthogonal_isolated_pair_root_full_source_acceptance_20261023.md)
also excludes mutual0; the
[isolated/near3 proof](../results/review_compact18_d18_isolated_near_three_finite_mutual_root_full_source_acceptance_20261023.md)
excludes its positive finite mutuals. The remaining dotted isolated pairs,
other fork roles and wholeD18 remain. These are supporting
results within the same paper family, with no new ceiling.

The [fresh arithmetic15 frontier](../results/review_arithmetic15_fresh_complete_twenty_two_group_frontier_root_full_source_acceptance_20261023.md)
has22 necessary groups, obtained directly at total rank15 with complete
small-rank inventories. It is not a realized-example list or a14 bound.
Its group19 now has complete
[head](../results/review_arithmetic15_b14_all_finite_pure_heads_positive_foreign_root_acceptance_20261023.md)
and [short-cap](../results/review_arithmetic15_b14_complete_short_white_isolated_dotted_root_acceptance_20261023.md)
reductions. A [cubic norm argument](../results/review_arithmetic15_b14_cubic_terminal_even_norm_foreign_four_root_acceptance_20261023.md)
leaves norm2/4 and old-I contact0/3 in that degree. Group19 remains
open; these are handwritten supporting proofs, without new Lean credit.

The finite-volume family also has a direct special-face restriction:
native5 or native7+ at a finite vertex forces a compact Coxeter face of
codimension two. Its derived ceiling is31 from published compact29,
or20 using internal compact18. In the finite57 continuation this removes
every remaining finite5+ contact except6; it does not prove global56.

The squared-unit construction host is now proved nonreflective by an
original infinite-order chamber symmetry. The different prime41 host has
three complete actual edges and a whole compact E7 hexagon, closed by
an original order-two chamber symmetry. Its new
[ambient D6/mixed-D4 continuation](../results/review_h9_prime41_ambient_d6_pentagon_mixed_d4_original_obstructions_root_acceptance_20261023.md)
has three further actual wall censuses and a full H3+D4+A1+[2b41] corner.
The [next two actual edges](../results/review_h9_prime41_mixed_d4_two_actual_edges_b2_double_h3_root_acceptance_20261023.md)
reach full2H3+B2+[2b41]. Further unit edges and an actual old-wall
projection now close a [whole compact quadrilateral two-face](../results/review_h9_prime41_double_h3_whole_compact_quadrilateral_root_full_source_acceptance_20261023.md)
of area pi/4, with every original wall checked. Ambient volume remains
open. Construction adds neither a seventh paper nor a new example.

Two further [norm2](../results/review_h9_prime41_known_outer_gap_actual_e6_unit_cutter_root_full_source_acceptance_20261023.md)
and [norm4](../results/review_h9_prime41_initial_e6_a2_actual_norm_four_b3_edge_root_full_source_acceptance_20261023.md)
actual facets cut successive explicit open directions in the known-wall
outer polyhedron. Their complete firstness proofs retain every original
norm class; full chamber volume and a new example remain unproved.
The [next edge terminates finitely](../results/review_h9_prime41_e6_b3_e2_relative_unit_termination_five_profiles_root_acceptance_20261023.md)
by an original relative-unit argument. Its five-profile numerical
[worker/contract](../results/review_h9_prime41_e6_b2_witness_firstness_worker_contract_root_preexecution_clearance_20261023.md)
are source-reviewed and unexecuted.

The finite-volume continuation has a [positive native-six weighting](../results/review_finite57_native_six_positive_weighting_flags_and_single_factor_receiver_root_acceptance_20261023.md)
and [all finite-factor shape minima](../results/review_finite57_native_six_all_finite_minima_smoothed_ideal_root_acceptance_20261023.md).
The [complete native-six finite budgets](../results/review_finite57_all_single_native_six_finite_budgets_root_acceptance_20261023.md)
now cover EVERY finite vertex containing native6, with Context and all
old tokens. Formal replacements and a rational certificate handle the
remaining single-factor domain; this is written mathematics, with no
new enumeration. The [selected old ideal debts](../results/review_finite57_native_six_all_old_ideal_debts_root_full_source_acceptance_20261023.md)
are now covered, reducing the weighted ideal problem to the bare
small-factor domain. Its [reduction and worker](../results/review_finite57_native_six_bare_ideal_worker_contract_root_preexecution_clearance_20261023.md)
have full source clearance, with no execution or positivity yet. The
[weighted strict global comparison](../results/review_finite57_native_six_weighted_global_extrema_strictness_root_acceptance_20261023.md)
is now proved. Heavy vertices without native6, complete face payment
and the bare ideal computation remain open; there is no56.

The consolidated [B16 scalar kernel map](../docs/b16_isolated_pair_scalar_kernel_logic_20261023.md)
has complete static review. An admitted compile failed on two reserved
local names; the preserved failure earns no PASS credit. The two-name
repair has [outside review and root clearance](../results/review_b16_isolated_pair_scalar_reserved_identifier_repair_root_clearance_20261023.md),
but no successful compilation or separate actual audit. The retry awaits
the unchanged6GiB admission gate; older successful modules have not rerun.

The new [dyadic triple logic map](../docs/quadratic_dyadic_triple_kernel_logic_20261023.md)
prepares fourteen declarations for the discrete core of the arithmetic15
proof. It has no actual compile or separate axiom audit. Number-field
facts, finite strips, field-square exceptions and geometry remain external.

Each computational algorithm needs a mathematical specification: its complete
domain, a termination and completeness argument, exact output, and the part
actually replayed. The [computational proof contract](../docs/computational_proof_contract.md)
and individual proof maps give those boundaries. A source hash or a successful
PDF build proves neither coverage nor a mathematical theorem.

Finite57 has all25 bounded B13/frontier replacement units passed and integrated.
The full146-job selection, including136 script selections, nine Lean roots and
one PDF build, has no combined runtime PASS or complete transitive regeneration.
Historical and bounded replacements retain their individual execution records.

The [A12 continuous-loss scalar kernel](../docs/a12_adjusted_loss_kernel_logic_20261023.md)
has [bounded compilation and a separate ten-declaration audit PASS](../results/lean_a12_adjusted_loss_verification_20261023/manifest.json).
It verifies the conditional loss and paid-square argument; actual geometry,
field inventories and the later universal A12/A13 theorems remain external.
Earlier failed/refused attempts are preserved with zero verification credit.

The [A13 endpoint-graft scalar source/map](../docs/a13_i_endpoint_graft_scalar_kernel_logic_20261023.md)
have complete static review and root preclear. A failed admitted compile and
two before-child RAM refusals are preserved. Two explicit identity rewrites
have outside/root clearance and an actual1.33second compile PASS. The separate
audit was initially refused at5.3GiB RAM and now has an
[actual eleven-declaration PASS in1.28seconds](../results/lean_a13_i_endpoint_graft_verification_20261023/manifest.json),
with no successful compilation rerun and no `sorryAx`. Failed diagnostic
prints earn zero credit. This is not full geometric
verification of the A13 result.

The newest [A18 continuous scalar kernel](../docs/a18_two_dotted_endpoint_scalar_kernel_logic_20261023.md)
has an [actual bounded compile and separate ten-declaration audit PASS](../results/lean_a18_two_dotted_endpoint_verification_20261023/manifest.json).
Actual geometry, legal prices and a real instance remain explicit. It verifies
the two-dotted scalar branch, not wholeA18 or the newer two-family written
frontier. The previous five-case kernel retains its original scope. See
[formal/README.md](../formal/README.md) for all conditional logic boundaries.

The [B18 terminal-pressure kernel](../docs/b18_terminal_pressure_kernel_logic_20261023.md)
now has an [actual compile and separate ten-declaration audit PASS](../results/lean_b18_terminal_pressure_verification_20261023/manifest.json),
with geometry and actual pressure premises external. Its scope is one
near3/own6 scalar argument, not the whole B18 geometry or later exclusions.

Run named checks through the existing coordinator/runner, for example:

```sh
python3 -B scripts/verify_manuscript.py finite57 --mode core
python3 -B scripts/verify_manuscript.py right_angled_sharp --mode core
```

One scientific/Lean/TeX child runs at a time. Admission requires40GiB disk and
6GiB available RAM; the existing time, memory and thread caps remain. Remove
owned unused products after every batch, preserving mathematical evidence.
The preceding reader guide is [byte-preserved](../results/source_archive/reader_guides_before_b18_terminal_and_prime41_refresh_20261023/manifest.json).
