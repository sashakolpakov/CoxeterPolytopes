# Whole D20: old strong5 without a head hypothesis

21 October 2026. New manual supporting proof, **pending full independent review**. No computation, mathematical-worker import, Lean or TeX job, or change to a frozen source or guide. The author independently assembled this early-reference bootstrap from the inherited actual weak5 and D4-foot interfaces. Earlier actual-foot and prefix work has shared authorship. This is a local necessary floor, not a whole-D20 exclusion or a new dimension bound.

**Theorem.** At an actual farthest vertex with WHOLE diagram D20, the SAME original farthest vector satisfies

`S5 > sqrt5−.61/sqrt2`,

without arithmeticity or any hypothesis on its long-head wall. In particular no native5 head gain is used.

## 1. Exact inputs and their restricted use

All paths in the table are under `results/`.

| Source | SHA256 | Used interface |
|---|---|---|
| `compact_classical_generic_prefix_energy_20261020.md` | `f637d7294d17e37581330ca508c914c23a08ce259845614b055e45815d2790ef` | Old .61 bulk/nonadjacency through12; weak5 actual pressure x1>.5965 and strong6 |
| `compact_whole_d20_complete_continuation_20261021.md` | `9cec3f696bd5e67fba56de98db45d433188d5b13ee88eb1be5be788a8d0fe3f3` | Section2's COMPLETE local D4 inventory at16, actual own5 and finite>=7/dotted feet and scalar bounds only |
| `compact_whole_b22_d22_uniform_terminal_pressure_exclusion_candidate_20261021.md` | `22aaa88e32d3524d2a3cd866986f70840f58b3d3baef41d7c2dc7446a7b627e3` | Local .58 bulk/isolated/left-contact seals; no whole-rank theorem |
| `compact_dn_large_components_short_tail_transfer_20261020.md` | `651a9d047d904f1b6496ba2664df5f313878466f67d011dcda144edef6a5620a` | Finite-white/affine classification at D4 and actual positive H4/core corrections |
| `compact_farthest_vertex_mixed_replacement_inequalities_20261020.md` | `3732b82614e13dfe2f7a3c66ab6c7fe67e517cbaeb77be0ca533f559ddf6ed84` | Actual finite projection/future-point comparison and all-wall feasibility |

The new proof does NOT import the head-dependent reference, the native5-head strong5/6/7 conclusion, a centre floor, or a larger-rank terminal exclusion. The D4 interface in the second source is local: its head contribution enters its displayed reference inequality, not its finite-white list or its feet. Below that contribution is replaced by a stronger early reference derived from the assumed weak5 itself.

Use unit old roots n_i=(e_i−e_(i+1))/sqrt2 for i<20 and n20=(e19+e20)/sqrt2. Put P_i=e1+...+e_i, S_i=x.P_i and `f_i=sqrt(i)−.61/sqrt2`. The actual chamber has x1>...>x19>|x20| and ||x||²<1. All finite classifications and all opposite walls below refer to this actual vertex.

## 2. A reference forced by an old weak5

Suppose S5<=f5. The generic theorem applies at M11 since 20>=11+6. Its complete weak5 list is the pure far3 helper, with own5, finite>=7 or dotted, and its actual feasible-point table gives

`x1>a=.5965`, `S6>B=2.01815`.

Old weak indices are nonadjacent. Thus at least one K in{11,12} is old-strong, independently of index16 or either fork. Set

`gK=B+sqrtK−sqrt6 < fK`.

Let w be the concave reference through (0,0),(1,a),(6,B),(K,gK), constant zero after K. Its slopes are

`a`, five copies of `(B−a)/5=.28433`, and K−6 copies of `1/(sqrtK+sqrt6)`.

They are strictly decreasing at the junctions and positive. Its only positive dual coefficients are at1,6,K, and the corresponding strict individual actual floors are available. Therefore x.w>w², with

`qK=w²=C+(sqrtK−sqrt6)²/(K−6)`,

`C=a²+(B−a)²/5=.7600299945`.

For K11, sqrt11<3.317 and sqrt6<2.45 give `(sqrt11+sqrt6)²<100/3`, so the last term `5/(sqrt11+sqrt6)²>.15`. For K12, sqrt12<3.465 gives `(sqrt12+sqrt6)²<35`, and the term `6/(sqrt12+sqrt6)²>.17`. In particular

`qK>.91`, `gK<fK<3.034`, `betaK=1/(sqrtK+sqrt6)>1/7`.        (1)

For ANY actual displacement V that is1 on its first K coordinates, with x.V>=G and V²<=R, use W=w+(V−PK)/7. This removes1/7 from the available coefficient betaK and leaves every old coefficient nonnegative. Also w.(V−PK)=0 and `(V−PK)²<=R−K`. The original x consequently satisfies

`||x||² > qK+(2/7)(G−gK)−(R−K)/49`.                       (2)

This is one completed square with primitive actual anchor floors. No separate energy bound or head pressure is added, and no unknown actual S_K is subtracted.

## 3. Complete .58-weak D4 check at16

Suppose index16 is .58-weak. Releasing it retains A15+D4. The complete finite one-node white extensions are the inherited left endpoint3/4, next-to-end3 and admissible E positions, a simple3 at any D4 leaf, and the full rank20 endpoint bridges. No foreign factor exists. The isolated and left-only rows are already .58-strong by their local actual feet and ratio seals: isolated dotted16 has loss<.5795, finite5/7/>=8 have loss<.58, near-left3/own5 is strong from index6 onward, and all other left positions have the listed stronger ratios. Zero-own affine/null principals remain unchanged. Two-piece bridges have residual1/32 and are strong (own0 is the all3 affine cycle). Thus the only additional row is one right-leaf3 with no left contact. D4 leaf symmetry does not change its scalar or its actual left correction.

For this row, own0/3/4/6 are excluded by the actual affine E8, all3 cycle, affine F4 path and 6–3 path, respectively. The H4 own5 and finite>=7/dotted cases are exactly the following two rows; they do not require a head hypothesis.

* **Own5.** The actual LEFT H4 projection has displacement V flat1 through13, squared norm R<16 and pressure `G>sqrt(16−125/448)−.091>3.745`. These facts are Section2 of9cec at i16, with positive correction coefficients and all-wall finite-projection feasibility. Since K<=12, (2) and(1) give

  `||x||² > .91+(2/7)(3.745−3.034)−5/49 > 1.0111`.

* **Finite>=7 or dotted.** Under the supposed .58 weakness, the exact target is `<2773138/1687945<1.643`. The D4 ratio `(gamma+1/4)/sqrt(1/2)` forces `.9<gamma<.92`. The ACTUAL positive combination

  `xi=c+gamma^(-1)n16+(2gamma)^(-1)n15`

  has products0 at c,n15, negative at n16, positive future time coefficient, and norm `−k`, where `k=1−3/(4gamma²)>0`. All unselected actual-wall products are nonpositive term by term. Its normalized displacement V is flat1 through14 and has

  `x.V>=G>3.768`, `V²<R=15.82`.

  These are the exact i16 local seals in9cec; they depend only on this actual core and the D4 inverse matrix. Hence (2) gives

  `||x||² > .91+(2/7)(3.768−3.034)−4.82/49 >1.0213`.

Both contradict ||x||²<1. The complete list therefore proves that16 is .58-strong under the single assumption that5 was old-weak. In particular S16>f16 at the old loss.

## 4. The resulting late knot contradicts weak5

Now use the positive concave interpolation through (1,a),(6,B),(16,B+4−sqrt6). The same original actual floors at1,6,16 give its strict norm lower bound

`||x||² > C+(4−sqrt6)²/10 = C+11/5−(4/5)sqrt6`.

Its last ten coordinates are `(4−sqrt6)/10<.16`, below .28433, so all reference coefficients are nonnegative. Finally sqrt6<244949/100000 (its square is6.0000012601>6) yields

`||x||² > .7600299945+2.2−1.959592 = 1.0004379945 >1`.

This contradiction proves old .61-strong5. The argument has not assumed new .58-strong5, a particular head type, or any centre/fork bound. It supplies a reference prerequisite for further whole-D20 geometric work; those further head branches and the general dimension bound are not conclusions of this note.
