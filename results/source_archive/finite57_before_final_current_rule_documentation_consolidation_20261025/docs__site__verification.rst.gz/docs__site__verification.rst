What has actually been verified
===============================

Written mathematical proof, finite-certificate replay, conditional Lean logic
and PDF production are different records. No complete geometric formalization
or fresh combined whole-manuscript runtime PASS is claimed. Updated25 October2026.

The :download:`current audit guide <../audit_and_consolidation_status_20261024.md>`
tracks the four authorized tasks. Further dimension and example searches are
stopped. The :download:`six-paper index <../../manuscripts/README.md>` identifies
matching delivered editions; a working revision is never paired with an old PDF.

Papers and working revisions
----------------------------

.. list-table:: Current evidence and remaining gates
   :header-rows: 1
   :widths: 27 73

   * - Package
     - Evidence and boundary
   * - Finite volume57
     - Compiled48-page edition and internal written review. All25 bounded replacement units and35 later literal units actually passed. Current-rule terminal bindings and their remaining replays are open; no full current runtime conjunction.
   * - General compact17
     - Complete revised mathematical and editorial source accepted, including exact18 and the independent actual-rank19–29 tail. Matching284-page working PDF compiled, with202 warnings and editorial/rendering review pending; frozen36-page PDF states23. Two new conditional Lean modules compiled with separate actual audits for ten declarations.
   * - Compact arithmetic15
     - Complete revised mathematical and editorial source accepted. Four computed premises and the literal golden-lattice external input remain explicit. Matching216-page working PDF compiled, with205 warnings and editorial/rendering review pending; frozen21-page PDF states20. Existing successful composition and dyadic kernels retain their conditional scopes.
   * - Sharp right-angled8/ideal4
     - Matching5-page edition, written reviews, exact model/polynomial checks and selected actual conditional-Lean audits. Both internally sharp. Geometry and named facet/code/classification inputs remain external.
   * - Ideal RA4 volume and structure
     - Matching17-page edition, written review, exact fixed-model checks and selected conditional logic. The second-volume double and restricted chain theorem do not classify arbitrary ideal polytopes as24-cell chains.
   * - Compact RA4 volume constraints
     - Matching14-page edition and scoped written/verification records. No universal120-cell minimum or unique second-volume theorem is proved.

The :download:`compact17 working map <../compact17_consolidated_proof_map_20261025.md>`
and :download:`arithmetic15 working map <../compact_arithmetic_consolidation_proof_map_20261025.md>`
identify the common foundation, actual branch points, complete consumers and
external or computed premises. Their
:download:`final source acceptance <../../results/compact17_arithmetic15_final_working_source_root_acceptance_20261025.json>`
remains source evidence. Matching later build receipts and the separate actual
compact Lean completion are linked independently; geometry and complete-data
parameters are not validated by compilation.

Finite57 current-rule audit
---------------------------

The :download:`reproduction guide <../finite_volume57_reproduce.md>` preserves
historical146-job/core11 evidence separately from the audited151/16 plans.
A plan executes no mathematical child. Existing successful unchanged jobs
are not rerun for a date or documentation update.

Later actual checks include35 literal units,332 scoped D12 payment checks,
10 near-end cases and all216 original direct receipts. All117 prepared
prerequisite jobs, the36-provider occurrence catalogue and47 release controls
now have actual execution records at their declared scopes.
All64 route INDEX batches record28,028 maps:15,510 direct units and12,518
nonunit obligations, plus83 prefixes. The first selected application failed
on an unsupported exact target role. An INDEX or association count does not
discharge those obligations. The complete selected application conjunction
remains open. The :download:`saved-output inspection <../../results/finite57_all64_route_index_inspection_20261025.json>`
reads those outputs without rerunning enumeration.

The bounded59–163
:download:`source-binding closure <../../results/finite57_bounded_tail_source_binding_closure_context_scope_corrected_20261025.md>`
is accepted at explicit inherited array/map/cost/profile premises. It does not
regenerate those numerical propositions. The
:download:`triangle-retention acceptance <../../results/finite57_current_triangle_retention_root_acceptance_20261025.json>`
proves current payment retention conditional on the complete old witness
calculation, including paths, features and all four exceptional markings.

Earlier source-only control plans were followed by their actual scoped
executions; their original statuses and failures remain preserved. Current
S8 application records and universal receiver joins retain complete geometry
and finite-data premises. The later all24 D14 current-receipt job passed at
its whole-core-seal premises; exact full-map applications remain separate.
An exact-key association or named theorem does not automatically supply
current payment or close a whole face. No combined full-manuscript runtime
PASS or complete transitive regeneration is claimed.

The two right-angled release records
------------------------------------

The :download:`accepted release packages <../right_angled_release_packages_20261025.md>`
bind precise source/PDF, computation and formal records. Their manifest has
57 file pins, twelve embedded verification outputs and five selected module
records. Historical combined cores bind predecessor TeX; unchanged components
are reused at their recorded scopes, not called a new combined current run.

Thirty audited declarations belong to the sharp paper's three selected
kernels; five more belong to the separately recorded regular24-cell supplement.
The ideal paper's selected ManuscriptIdeal4 kernel has eight. Legacy dependency
objects are identified separately and gain no fresh source-to-object credit.
The maps retain actual geometry, classifications, code bounds, cutting and
recognition as parameters or external facts.

Selected conditional Lean
-------------------------

The :download:`formal guide <../../formal/README.md>` links every existing
successful module and its SEPARATE actual axiom-audit receipt. The selected
publication gate's two modules and nine declarations passed on21 October.
Later successful arithmetic composition, dyadic and scalar kernels retain
exactly their recorded scopes and are not rerun without a changed input.

The two new named targets are
``CoxeterProofs.D18UniformDottedHeadScalarKernel`` and
``CoxeterProofs.CompactDimensionSeventeenComposition``. Their
:download:`logic map <../compact_dimension17_conditional_logic_map_20261024.md>`
exposes ordinary analytic, geometric and complete-cover parameters. Seven
scalar and three composition declarations now have
:download:`actual bounded compilation and separate actual axiom audits <../../results/compact17_targeted_lean_completion_20261025/manifest.json>`.
The reserved-binder predecessor failure and the reviewed three-token rename
are preserved. Successful unchanged earlier modules were not rebuilt.

A printed foundational axiom list does not enumerate ordinary theorem
parameters. Even an empty list would not authenticate external literature,
complete enumeration outputs, geometric realization or the real instance.
The :download:`assumption register <../manuscript_assumptions.md>` and each
logic map list those obligations separately. Failures and resource deferrals
are preserved without PASS credit.

Running necessary work and publishing
-------------------------------------

Use ``scripts/run_proof_batch_20261024.py`` for named scientific, Lean and
TeX work. Compilation and actual axiom auditing are separate stages. Root
launches one process at a time under the shared exclusive proof lock.
The user's25October override uses percentages of total filesystem capacity
and physical RAM: admit at2% free disk/15% available RAM; stop active jobs
below1% disk/6% RAM; start cleanup below2% disk. Exact ratios, totals and
policy hashes are recorded. Scientific/TeX jobs use59seconds/1GiB/one thread;
Lean uses2048MiB/one thread. Process identity and RSS monitoring remain enabled.

Before a push, build Sphinx with warnings as errors and audit the ACTUAL Git
index through the publication watchdog. It uses the same percentage policy
and256MiB sampled process-group RSS monitoring; it may not run mathematical
checks. Matching PDFs and verification stdout are intentional
evidence. Lean objects/dependencies, TeX intermediates, caches and generated
sites remain untracked. The optional936-file/33-archive bulk payload remains
UNUPLOADED and is separate from source publication.
