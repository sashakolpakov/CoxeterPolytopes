Coxeter polytopes: results and verification
===========================================

This project studies dimension bounds, explicit reflection chambers and
right-angled volume/structure problems. There are **six paper families**,
with matching TeX/PDF editions and separately scoped mathematical reviews,
exact computations and Lean kernels. Updated23 October2026.

Current dimension bounds
------------------------

The new ceilings are internally reviewed written proofs. They are distinct
from published theorems, external refereeing and full geometric formalization.

.. list-table:: Dimension comparison
   :header-rows: 1
   :widths: 43 16 18 23

   * - Class
     - Largest example
     - Published ceiling
     - Repository ceiling
   * - General Coxeter, finite volume
     - 21
     - 995
     - **57**
   * - General compact Coxeter
     - 8
     - 29
     - **18**
   * - Compact arithmetic Coxeter
     - 8
     - 29
     - **16**
   * - Noncompact arithmetic Coxeter
     - 21
     - 21
     - **21**, published and sharp
   * - Right-angled, finite volume, all vertices
     - 8
     - 12
     - **8**, internally sharp
   * - Right-angled, entirely ideal
     - 4
     - 6
     - **4**, internally sharp
   * - Right-angled, compact
     - 4
     - 4
     - **4**, published and sharp

The compact18 and arithmetic16 arguments are supporting work in the existing
compact paper families; their frozen PDFs still state23 and20. Arithmetic
reflection lattices automatically admit the quadratic-form model: “first type”
is not an additional restriction. See the
:download:`current guide <../current_bounds_and_verification.md>` and
:download:`published-input register <../manuscript_assumptions.md>`.

At exact compact dimension18, only **whole D18** remains in the accepted
necessary frontier after the
:download:`complete whole-B18 exclusion <../../results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md>`.
This concerns a selected farthest vertex, not every vertex or an example. The
:download:`complete D18 conjunction <../../results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md>`
proves unconditional center16 strength. The
:download:`new D18 pair theorem <../../results/review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md>`
gives both fork cosh lengths<9.64 and excludes both-near3 for all heads,
plus near3/far3 under native5 head. The
:download:`actual A17+A1 neighbor theorem <../../results/review_compact18_d18_actual_a17_a1_isolated_cutoff_native5_far_pair_root_acceptance_20261023.md>`
also bounds isolated fork owns by341/150 and excludes native5 far3/far3.
That head forces an isolated dotted fork; iso/iso, iso/near3 and iso/far3
remain. WholeD18 is still open.

Arithmetic16 has **four original groups**, after the new
:download:`A11 actual-I coupling <../../results/review_arithmetic16_a11_actual_i_single_endpoint_all_feet_root_acceptance_and_four_group_frontier_20261023.md>`, the two
:download:`A10 actual-defect <../../results/review_arithmetic16_a10_both_actual_typed_seven_n11_root_acceptance_and_six_group_frontier_20261023.md>`
and :download:`A10 actual-I <../../results/review_arithmetic16_a10_actual_i_n11_root_acceptance_and_five_group_frontier_20261023.md>`
theorems, the
:download:`whole-A14 exclusion <../../results/review_arithmetic16_whole_a14_ordinary_rank_two_root_acceptance_and_seven_group_frontier_20261023.md>`
and earlier :download:`whole-B16 exclusion <../../results/review_arithmetic16_whole_b16_complete_census_and_reference_root_acceptance_20261023.md>`.
The ordinary A14 branch reduces to actual field Q(sqrt5) or Q(sqrt2).
Integral endpoint tests and one rebuilt reference retaining every earlier
foot then close that entire branch. The new N11 arguments close both A10
groups with the same404/625 reference and separate actual-defect/all-field
actual-I proofs. The A11 theorem retains every isolated foot in one new
endpoint reference and counts the I energy once. The remaining IDs
are11,14,18,19.
The ceilings stay18 and16; these supporting results remain in the same
two compact paper families.

The six papers
--------------

.. list-table:: Current frozen editions
   :header-rows: 1
   :widths: 53 30 17

   * - Paper
     - Result in PDF
     - Read
   * - General finite volume
     - Dimension at most57
     - :download:`48 pages <../../manuscripts/build/finite_volume57.pdf>`
   * - Sharp right-angled dimensions
     - Finite volume8; entirely ideal4
     - :download:`5 pages <../../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf>`
   * - General compact
     - Dimension at most23
     - :download:`36 pages <../../manuscripts/build/compact_farthest_vertex_bounds.pdf>`
   * - Compact arithmetic
     - Dimension at most20
     - :download:`21 pages <../../manuscripts/build/compact_arithmetic_dimension_bound.pdf>`
   * - Ideal right-angled four-volume and structure
     - Minimum, second volume, restricted chains
     - :download:`17 pages <../../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf>`
   * - Compact right-angled four-volume constraints
     - Capacity, excess and recognition
     - :download:`14 pages <../../manuscripts/build/compact_ra4_volume_constraints.pdf>`

All six are **written, compiled and internally reviewed**. The57 paper has
12 pages of main exposition and36 pages of essential appendices. The
:download:`reader index <../../manuscripts/README.md>` maps each result to its
technique, source, proof map and verification ID. Earlier notes and refinements
are not additional proposed papers.

Recent verified work
--------------------

The new compact arguments use an actual neighboring vertex and an explicit
comparison factor from the ORIGINAL farthest maximum. The neighbor is never
chosen farthest. Complete finite-white and foreign-cost analyses supply
orthogonal costs for ONE vector there. The
:download:`distinct B18 cap theorem <../../results/review_compact18_b18_distinct_terminal_caps_and_seven_common_cases_root_acceptance_20261023.md>`
and :download:`five common-cap theorem <../../results/review_compact18_b18_five_common_cases_and_two_holdouts_root_acceptance_20261023.md>`
and :download:`head-gap/H3-neighbor theorem <../../results/review_compact18_b18_zero_own_short_five_and_last_common_case_root_acceptance_20261023.md>`
first leave one terminal case. The
:download:`last common3/3 exclusion <../../results/review_compact18_b18_last_common_three_three_actual_neighbor_root_acceptance_20261023.md>`
uses a full actual A18 neighbor with comparison factor11/8, fresh .87
pressures and one funded endpoint graft. The separately reviewed complete
conjunction then closes wholeB18. The D18
:download:`dotted fork-three exclusion <../../results/review_compact18_d18_dotted_fork_three_neighbor_root_acceptance_20261023.md>`
and complete zero-own/fork7--10 theorem finish its weak-center inventory;
the :download:`full conjunction review <../../results/review_compact18_d18_unconditional_strong16_complete_conjunction_full_scope_foundations_20261023.md>`
checks that every weak-center case is covered. The wholeD18 fork budget
and compact17 remain open. These new written theorems are not full geometric
Lean formalizations.

The :download:`B16 quadratic census receipt <../../results/b16_isolated_quadratic_pair_census_verification_20261023.json>`
binds FOUR actual guarded units:43 fields and273 ordered pairs, with ONE
necessary pair. A uniform argument excludes every cubic field, and a single
original-vector estimate excludes that quadratic pair. The census is not
empty and constructs no example. The complete written proof has full
outside/root acceptance. The new A14 proof closes both actualN7/O7 and
the entire ordinaryT2 alternative. The two new A10 proofs and the A11
actual-I coupling leave four arithmetic groups, without lowering the
global ceiling16.

The :download:`zero-exchanged row7/near-row8 theorem <../../results/review_finite57_zero_exchanged_all_row7_near_row8_financing_root_acceptance_20261023.md>`
and far-row8 isolated :download:`contact3/4/parallel financing <../../results/review_finite57_far_row8_isolated_intervening_cusp_financing_root_acceptance_20261023.md>`
plus :download:`orthogonal-contact financing <../../results/review_finite57_far_row8_orthogonal_isolated_b4_cusp_financing_root_acceptance_20261023.md>`
retain all older payments. These use22 parameterized whole-cusp families,
actual source reconstruction and every prior debt. The
:download:`affected-D23 finite-contact theorem <../../results/review_finite57_far_row8_d23_finite_a21_dihedral_receiver_root_acceptance_20261023.md>`
has a unique finite receiver with full356+8=364. The D17 analogue
still has a4.5-unit deficit; dotted contacts and other source types
remain. No dimension56 theorem follows.

The :download:`explicit special-face proof <../../results/review_finite57_special_native_bond_compact_face_and_label_restriction_root_acceptance_20261023.md>`
gives a derived bound20 for finite-volume polytopes with a native5 or native7+
bond at a finite vertex, using the internal compact18 theorem. Published
compact29 alone gives31 for this restricted class. Compactness and every
intrinsic Coxeter angle of the codimension-two face are proved directly.
The finite57 application uses only published29 and leaves native6 as the
last finite5+ contact. This does not bound all finite-volume polytopes by20.

The :download:`B18 scalar kernel <../../results/lean_b18_terminal_pressure_verification_20261023/manifest.json>`
now has actual bounded compilation in1.71seconds and a SEPARATE ten-declaration
audit in1.16seconds. The audit reused its object; no successful old module
ran. All ten prints use standard foundational axioms and no ``sorryAx``.
Actual geometry, inventories, original-vector pressure and terminal sums
remain external. This is scalar verification for near3/own6, not wholeB18
or later geometric exclusions. See its :download:`logic map <../b18_terminal_pressure_kernel_logic_20261023.md>`.
Two unused-variable warnings are preserved; temporary proof work is absent.

The new :download:`B16 scalar source/map <../b16_isolated_pair_scalar_kernel_logic_20261023.md>`
has full static review and :download:`root precompile clearance <../../results/review_b16_isolated_pair_scalar_kernel_root_precompile_acceptance_20261023.md>`.
It is **uncompiled**, with no actual axiom prints. Available RAM has remained
below the unchanged6GiB admission gate during its preparation. Twelve footer
requests are not audit evidence. The written mathematics and actual census
have their own separate acceptance and execution records.

The earlier :download:`A13 eleven-declaration <../../results/lean_a13_i_endpoint_graft_verification_20261023/manifest.json>`,
:download:`A12 ten-declaration <../../results/lean_a12_adjusted_loss_verification_20261023/manifest.json>`,
:download:`A18 ten-declaration <../../results/lean_a18_two_dotted_endpoint_verification_20261023/manifest.json>`
and :download:`heavy-centre eleven-declaration <../../results/lean_heavy_centre_forest_verification_20261023/manifest.json>`
audits retain their exact conditional scopes. Preparation labels are
historical; actual receipts supply execution status. Earlier failures and
resource deferrals earn zero PASS credit. No end-to-end geometric
formalization is claimed.

Both the :download:`glued H9 host <../../results/review_glued_e7_a2_two_unit_releases_original_period_and_literal_nonreflectivity_root_acceptance_20261023.md>`
and the :download:`squared-unit host <../../results/review_h9_squared_unit_e7_return_original_period_literal_nonreflectivity_root_acceptance_20261023.md>`
are now proved nonreflective by original chamber symmetries of infinite
order. The latter product has trace16phi^6=80+128phi>10; its earlier
order-two symmetry alone did not establish infinite volume. These close
two literal hosts, not their whole commensurability classes.

A different :download:`prime41 host and first actual edge <../../results/review_h9_cubed_unit_prime41_original_host_first_edge_root_acceptance_20261023.md>`
and its :download:`second actual unit edge <../../results/review_h9_prime41_second_actual_unit_edge_original_germ_obstruction_root_acceptance_20261023.md>`
are proved with complete original-lattice firstness arguments. The
:download:`third edge and original order-two symmetry <../../results/review_h9_prime41_third_actual_edge_original_involution_full_hexagon_root_acceptance_20261023.md>`
close the WHOLE compact E7 hexagon, of area4pi/3. Ambient volume remains
open; the symmetry is not an infinite period. The new
:download:`ambient continuation <../../results/review_h9_prime41_ambient_d6_pentagon_mixed_d4_original_obstructions_root_acceptance_20261023.md>`
proves three further actual walls, a full H3+D4+A1+[2b41] corner and
one whole regular right pentagon. All original norm classes, full
covectors, both embeddings, firstness and local-map obstructions are
checked. Ambient volume and an infinite period remain open; there is
still no new finite-volume example.

Read and reproduce
------------------

.. toctree::
   :maxdepth: 1

   papers
   methods
   verification
   reproducibility
   scope

The `GitHub repository <https://github.com/sashakolpakov/CoxeterPolytopes>`_
contains the source arguments and evidence. Before interpreting a PASS, read
its declared scope: source review, arithmetic replay, conditional kernel logic
and full geometric formalization are different checks. The optional936-file
bulk payload has not been uploaded and is excluded from Git.
