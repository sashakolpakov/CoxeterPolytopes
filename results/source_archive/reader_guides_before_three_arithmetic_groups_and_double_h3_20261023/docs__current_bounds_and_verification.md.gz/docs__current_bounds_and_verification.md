# Current bounds and verification

Updated23 October2026. There are **six paper families**, each with a written,
compiled and internally reviewed TeX/PDF edition. Later supporting proofs improve
the compact bounds without multiplying papers. This page reports the current
mathematical state; dated receipts and preserved predecessor guides record history.

## Dimension comparison

| Class | Largest published example | Published ceiling | Current internally reviewed ceiling | Relation to the PDF |
|---|---:|---:|---:|---|
| General Coxeter, finite volume | 21 | 995, Prokhorov/Khovanskii | **57** | Current48-page paper |
| General compact Coxeter | 8 | 29, Vinberg | **18** | Supporting proof;36-page PDF states23 |
| Compact arithmetic Coxeter | 8 | 29, Vinberg | **16** | Supporting proof;21-page PDF states20 |
| Noncompact arithmetic Coxeter | 21 | 21, Esselmann | **21**, sharp and published | No new claim |
| Arithmetic Coxeter, compact or noncompact | 21 | 29 overall | **21**, sharp overall | New compact proof plus published noncompact theorem |
| Right-angled, finite volume, all vertex types | 8 | 12, Dufour | **8**, internally sharp | Current5-page paper |
| Right-angled, entirely ideal | 4 | 6, Kolpakov | **4**, internally sharp | Same5-page paper |
| Right-angled, compact | 4 | 4, published and sharp | **4**, unchanged | External starting result |

“Internally reviewed” means a complete written argument with the stated external
and finite-data interfaces, another author's source review and root acceptance.
It is distinct from publication, refereeing, complete computational replay and
end-to-end formalization. References and exact published scopes are recorded in
[the assumption register](manuscript_assumptions.md) and the
[right-angled proof map](right_angled_sharp_dimensions_publication_proof_map_20261021.md).
The quadratic-form model is automatic for arithmetic reflection lattices;
“first type” is not an extra restriction on the arithmetic rows.

## Current compact frontiers

The [global compact18 composition](../results/compact_dimension18_global_composition_and_whole_d19_exclusion_candidate_20261022.md)
excludes dimension19 and combines it with the independent higher-dimensional
argument. Its [written acceptance](../results/compact_dimension18_global_written_acceptance_20261022.json)
and [conditional Lean execution](../results/lean_compact18_composition_verification_20261022/manifest.json)
have separate scopes. At exact18 the complete necessary farthest-vertex
list contains only **whole D18**, after the
[complete whole-B18 exclusion](../results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md).
This is a necessary diagram at a selected farthest vertex, not a claim
about every vertex or a realized example. The frozen PDF states23.

For B18, the [complete terminal inventory](../results/review_compact18_b18_uniform_terminal_lengths_complete_seventeen_inventory_root_acceptance_20261023.md)
and earlier finite/dotted far-helper exclusions are followed by two new
actual-neighbor arguments. The [distinct-cap theorem](../results/review_compact18_b18_distinct_terminal_caps_and_seven_common_cases_root_acceptance_20261023.md)
leaves seven common-wall cases; the
[five-case theorem](../results/review_compact18_b18_five_common_cases_and_two_holdouts_root_acceptance_20261023.md)
removes five of them. The
[head-gap and H3-neighbor theorem](../results/review_compact18_b18_zero_own_short_five_and_last_common_case_root_acceptance_20261023.md)
then removes own0/short5. The
[last common3/3 theorem](../results/review_compact18_b18_last_common_three_three_actual_neighbor_root_acceptance_20261023.md)
excludes the final own3/short-white3 role using the actual short-edge
neighbor with full A18 diagram. It retains comparison factor11/8 from
the ORIGINAL maximum and a reverse incident pressure>.8. A fresh .87
inventory, actual helper packing and one legally funded endpoint graft
give a norm above1.0131845 in every weak pattern. The
[complete conjunction](../results/compact18_whole_b18_complete_terminal_role_composition_and_single_d18_frontier_candidate_20261023.md)
has its own [full outside review](../results/review_compact18_whole_b18_complete_role_composition_single_d18_frontier_full_scope_replay_20261023.md)
and root acceptance: every far, near, distinct and common terminal role
is covered, including the explicit older anchor-price erratum. Thus
wholeB18 is excluded at the selected original vertex. No neighbor is
chosen farthest and no original/neighbor energies are added. WholeD18
and compact17 remain open.

For D18, **center16 is unconditionally .58-strong**:
`S16 > 4 - .58/sqrt(2)` for the original farthest vector. The
[complete conjunction](../results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md)
has a separate [full outside composition review](../results/review_compact18_d18_unconditional_strong16_complete_conjunction_full_scope_foundations_20261023.md).
It combines the complete original inventory, both pure-helper exclusions,
the finite-own fork-three exclusion, the
[new dotted fork-three theorem](../results/review_compact18_d18_dotted_fork_three_neighbor_root_acceptance_20261023.md)
and the entire zero-own/fork7--10 exclusion. The last two use actual
A15+A2+A1 or A15+I2+A1 neighbors. They check the complete foreign-cost
alphabet directly rather than importing a farthest-only rule there.
Every weak16 case is excluded, for both signed forks. This does not supply
the remaining fork budget or exclude whole D18.

The [new all-head fork theorem](../results/review_compact18_d18_unconditional_fork_ten_complete_white_native_five_head_root_acceptance_20261023.md)
reassembles the same reference ending16, including a possible weak15
deletion, and gives effective energy>.9729. Both fork cosh lengths are
then<10, with the complete seven-profile and finite isolated-centre
dispatch retained. The [terminal-slack and pair theorem](../results/review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md)
improves both lengths to<9.64. Its actual A18-neighbor lemma retains
factor11/8 and one reverse endpoint pressure; it gives near3 own<1.21
and far3 own<1.6. Both-near3 is impossible for all heads, and near3/far3
is impossible under native5 head. The [actual A17+A1 neighbor theorem](../results/review_compact18_d18_actual_a17_a1_isolated_cutoff_native5_far_pair_root_acceptance_20261023.md)
now gives every isolated fork own<341/150 for all heads. Its full
native5 far3/far3 negative-core argument retains the first-coordinate
reference cross and pays only one terminal price. Thus native5 head
forces at least one isolated dotted fork; iso/iso, iso/near3 and iso/far3
remain. Other heads and wholeD18 remain open. This is written geometry,
without an enlarged scope for older Lean kernels.

The [global arithmetic16 composition](../results/review_arithmetic17_whole_a17_global16_complete_composition_root_acceptance_20261022.md)
closes all exact-dimension17 groups over every actual admissible field.
Its [three-declaration Lean audit](../results/lean_arithmetic16_composition_verification_20261022/manifest.json)
keeps27 written geometric/field/data premises external. The frozen PDF states20.
At exact16 the current necessary list has **four original group IDs**:
11,14,18,19. The
[whole-B16 theorem](../results/review_arithmetic16_whole_b16_complete_census_and_reference_root_acceptance_20261023.md)
removes original15 over every actual field. Its accepted geometric reduction
first exhausts all head/short roles and limits the actual degree to2 or3.
A uniform valuation and small-conjugate argument removes every cubic field.

The [actual quadratic census receipt](../results/b16_isolated_quadratic_pair_census_verification_20261023.json)
binds three disjoint field parts and a separate authenticated combine that
recomputes every field and pair using the same reviewed implementation.
All four guarded units passed:43 fields,100 head models,85 short models
and273 ordered pairs, with168 half-product failures,104 full-field
nonsquares and **one necessary pair**. It is not an empty census or an
independent second implementation. The pair U=5+2sqrt6,V=10+4sqrt6
forces one original-vector norm above1.00640742675 and is excluded
geometrically. Actual runtime was1.918seconds total, maximum sampled
process-tree RSS56,999,936bytes. This proves no arithmetic15 bound or example.

The [A14 typed-seven theorem](../results/review_arithmetic16_a14_both_actual_typed_seven_root_acceptance_20261023.md)
also excludes both actual N7/O7 alternatives of original group10. Fresh
central .55 pressures, complete actual endpoint laws and two legally
funded endpoint grafts give one norm above1.00286445198. This first
leaves group10 with one ordinary T2 and its accepted3/19 floor. Its
[complete all-field ordinary reduction](../results/review_arithmetic16_a14_ordinary_rank_two_actual_triangle_two_field_root_acceptance_20261023.md)
forces one isolated actual common opposite and three triangle types:
(2,4,5),(2,3,8),(3,3,4), with six possible old-component roles. Its actual
field is exactly Q(sqrt5) or Q(sqrt2). The three-cycle is essential in
the last type; unit cos(pi/8) is not assumed field-valued. The new
[complete ordinary theorem and whole-A14 acceptance](../results/review_arithmetic16_whole_a14_ordinary_rank_two_root_acceptance_and_seven_group_frontier_20261023.md)
then exclude every one of these necessary cases. Full-order integral
endpoint tests give both signed coordinates>.44. A rebuilt concave
reference retains all old foot corrections and their individual prices;
its minimum energy>.849036581755, plus ONLY the disjoint ordinary3/19,
contradicts one original norm. This closes WHOLE original group10,
first leaving seven IDs. The arithmetic ceiling remains16.

The [fresh N11 actual-defect theorem](../results/review_arithmetic16_a10_both_actual_typed_seven_n11_root_acceptance_and_six_group_frontier_20261023.md)
closes original2, A10+actualN7/O7+T4. Its complete smaller-rank whitelist
retains the extra A3/H4 and D10 bridge cases. A helper norm/trace
argument and all actual point bounds make four central heights
.65-strong; one reference gives A10 energy>404/625.

The [all-field actual-I theorem](../results/review_arithmetic16_a10_actual_i_n11_root_acceptance_and_five_group_frontier_20261023.md)
then closes original1, A10+actualI+(A5 or D5). It replaces every
K7-only exclusion directly. A nonzero integral norm bound
259209951/320000000<1 eliminates all helper degrees>=3; the quadratic
trace leaves only the golden helper. Its four time norms force11 to
divide the actual I wall's nonzero integer norm of magnitude<8.
All remaining caps are .65-strong. Adding ONLY the disjoint ordinary
5/14 cost to404/625 gives8781/8750>1 for the same original vector.
The actual I is used as a wall, not counted twice as an energy gain.
Those two complete written proofs first left five original groups.
The [new A11 plus actual-I theorem](../results/review_arithmetic16_a11_actual_i_single_endpoint_all_feet_root_acceptance_and_four_group_frontier_20261023.md)
then closes original4, A11+actualI+ordinaryT4, over every actual field.
Its first endpoint is forced by the actual I wall. One new reference
retains every central isolated foot, including adjacent feet and the
full endpoint cross; its remaining individual coefficients pay them all.
The joint A11+I energy is>43986266/61000000>18/25. Only then is
the disjoint ordinaryT4>2/7 added, giving176/175>1. All five T4
types, including H4, are covered. This leaves precisely the four IDs
above, without arithmetic15 or new geometric Lean verification.

## Verification status

| Result or package | Written status | Executed verification and remaining boundary |
|---|---|---|
| General finite volume57 | Complete paper, internal composition review | All25 bounded B13/frontier replacement units passed and are integrated. Matching inherited evidence covers111 other script selections. No combined146-job full runtime PASS or complete transitive regeneration. Selected counting/table/scalar kernels compiled and separately audited; actual geometry remains external. |
| General compact18 | Complete supporting composition, outside review and root acceptance | Its five-declaration composition kernel compiled and separately audited under23 written inputs. The later whole-B18 exclusion and single-D18 necessary frontier are written mathematics; older kernels are not relabelled as verifying them. |
| Compact arithmetic16 | Complete supporting composition, outside review and root acceptance | Three actual audited composition declarations under27 explicit written inputs; separate thirteen-group kernel also passed. The later four-group frontier, new N11 results and A11 actual-I coupling have full written review, without a new number-field or geometric Lean instance. |
| Right-angled8 and ideal4 | One complete5-page paper, internal reviews and exact checks | Projection/height, tensor-polynomial and count logic have selected script/Lean checks. Actual geometry and the cited facet/code/classification results remain external. |
| Ideal RA4 volume and structure | Complete17-page paper and internal reviews | Exact combinatorial/model checks and selected conditional logic; no complete geometric Lean formalization or external referee approval. |
| Compact RA4 volume constraints | Complete14-page paper and internal reviews | Exact capacity/excess checks and conditional logic. It does not prove a global minimum or a unique second-volume double. |

### B16 isolated-pair scalar preparation

The [consolidated source/input map](b16_isolated_pair_scalar_kernel_logic_20261023.md)
has a [full different-author static review](../results/review_b16_isolated_pair_scalar_kernel_precompile_full_source_and_map_replay_20261023.md)
and [root precompile clearance](../results/review_b16_isolated_pair_scalar_kernel_root_precompile_acceptance_20261023.md).
It derives integer valuation parity, the complete small-conjugate cubic
root bound and both case-specific prefix contradictions over a genuine
ordered ring. Number-field/ideal facts, actual geometry, the census,
primitive pressures and real instances remain explicit external inputs.

**No compilation or actual axiom audit has run.** The twelve footer
requests are planned prints, not verification credit. Available RAM has
been below the unchanged6GiB admission gate during this preparation;
no proof child was launched. This does not diminish the separate written
proof or the four actual guarded census units, nor enlarge older Lean scopes.

### B18 terminal-pressure scalar logic

The [new logic map](b18_terminal_pressure_kernel_logic_20261023.md) has
full different-author static review and [root precompile clearance](../results/review_b18_terminal_pressure_kernel_root_precompile_acceptance_20261023.md).
Its [actual bounded compile and separate ten-declaration audit PASS](../results/lean_b18_terminal_pressure_verification_20261023/manifest.json)
took1.71seconds and1.16seconds. The audit reused the successful object;
no older module ran. All ten actual prints contain only propext,
Classical.choice and Quot.sound, with no sorryAx. Two unused-variable
warnings are preserved, and owned temporary proof work is absent.

The module derives the unbounded mixed-pressure polynomial and the full
subcritical radical/convex-sum contradiction from primitive scalar data.
Actual normals, complete inventories, the original farthest vector,
all-wall future feasibility, pressure, terminal sums and a real instance
remain ordinary explicit premises. This is conditional scalar verification
for the near3/own6 theorem, not a full geometric theorem, wholeB18 or
verification of later role exclusions. Preparation source/map headers
retain their historical zero-execution labels; the receipt records PASS.

### Heavy-centre forest logic

The [new kernel map](heavy_centre_forest_scalar_kernel_logic_20261023.md)
has an [actual bounded compilation and separate eleven-declaration audit PASS](../results/lean_heavy_centre_forest_verification_20261023/manifest.json).
Primitive square equations imply the cone inequalities; strong finite-chain
induction derives no-return from two local geometric bridges. Natural variables
index the chain or count incidences; metric quantities remain in an ordered ring.
Actual hyperbolic instances, graph-cycle realization,
forest Euler and reverse ports remain external. All eleven prints use only
standard foundational axioms, with no `sorryAx`. Compilation took2.4seconds
and the separate audit1.93seconds. The earlier5.8GiB admission refusal and
one unused-variable warning are retained. The531912-byte object is ignored;
owned temporary proof work is absent. No older successful module was rerun.

### A18 continuous scalar verification

[A18TwoDottedEndpointScalarKernel](a18_two_dotted_endpoint_scalar_kernel_logic_20261023.md)
now has [actual bounded compilation and a separate ten-declaration audit PASS](../results/lean_a18_two_dotted_endpoint_verification_20261023/manifest.json).
The unchanged12998-byte source derives radical chords from square identities,
the full continuous core gap, endpoint gains, one paid completion and all four
endpoint budget patterns over a genuine ordered ring. Actual geometric pressures,
all-hole references, individual legal prices, orthogonality and a real instance
remain explicit premises. It supports the two-dotted branch, not a wholeA18
exclusion or the later mixed theorem by itself.

Compilation took3.25seconds and the admitted audit1.77seconds. All ten printed
axiom sets contain exactly`propext`, `Classical.choice` and `Quot.sound`; no
`sorryAx` occurs. One unused-variable warning is retained, and no cosmetic rerun
was made. The earlier audit admission refusal is preserved alongside the later
PASS. Owned temporary proof work is absent; its691656-byte object is an ignored
cache, not a publication asset. The linked map and preclear are immutable
preparation records; the execution receipt supplies the later status.

The earlier [eleven-declaration endpoint kernel](general_eighteen_endpoint_refinement_logic_20261023.md)
retains its [actual PASS](../results/lean_general18_endpoint_refinement_verification_20261023/manifest.json)
for the preceding FIVE-case deduction and finite analytic integer seals. Its
scope is not expanded by later source reviews. Printed foundational axioms do
not list theorem parameters; consult each logic map for external assumptions.

## Work toward finite volume56

The latest far-row8 proofs finance the entire isolated first-neighbor
[contact3/4/parallel domain](../results/review_finite57_far_row8_isolated_intervening_cusp_financing_root_acceptance_20261023.md)
and its [orthogonal-contact extension](../results/review_finite57_far_row8_orthogonal_isolated_b4_cusp_financing_root_acceptance_20261023.md).
Their 22 parameterized whole-cusp families have actual edge endpoints,
complete source injections and every prior debt retained. The smallest
remaining capacities after all new loads are3352 and7234 respectively.
The corrected small coefficient factor and the original wording are preserved.

For an affected WHOLE D23, the
[finite-contact receiver theorem](../results/review_finite57_far_row8_d23_finite_a21_dihedral_receiver_root_acceptance_20261023.md)
handles every finite positive contact: an actual A21+I2+2D17 receiver
has full C0=356 and at most one original heavy source, so its8 arrival
reaches364. The analogous affected-D17 receiver has full C0=360.5,
including both half cross payments. Its8 arrival reaches368.5, leaving
a genuine4.5 deficit. Dotted contacts, other first-neighbor forms and
complete global coverage remain open. No56 theorem or new execution
credit follows from these reviewed written arguments.

The [special-face theorem](../results/review_finite57_special_native_bond_compact_face_and_label_restriction_root_acceptance_20261023.md)
proves compactness and the Coxeter property explicitly for the codimension-two
face of a native5 or native7+ bond at a finite vertex. Every intrinsic facet
and projected angle is checked; arbitrary face heredity is not assumed.

| Additional restricted class | From published compact29 | From internal compact18 | Verification |
|---|---:|---:|---|
| Finite volume with a native5 or native7+ bond at a finite vertex | <=31, derived | <=20, derived | Complete written special-face proof, full outside review and root acceptance; no new Lean or historical-novelty claim |

These are consequences of the respective compact bounds, not a claim that31
is the published optimum for this class. The finite57 application uses only
published29: its compact face would have dimension55. Thus the remaining
finite5+ contact is ONLY native6. Native6 can lie in an affine G2 cusp,
so its face need not be compact and that last finite case is not excluded.
The affected-D17 4.5-unit deficit and dotted continuation remain open.


The global ceiling remains57. New accepted selected-domain results finance:

* [all isolated finite short-fork caps](../results/review_finite57_all_isolated_finite_short_fork_receivers_root_acceptance_20261023.md), with unique actual cheap finite centre receivers;
* [every actual ideal fork-centre neighbour](../results/review_finite57_ideal_fork_centre_joint_parallel_financing_root_acceptance_20261023.md), with all parent families, cusp ports and previous debts;
* the [safe finite-centre union](../results/review_finite57_finite_centre_safe_union_and_heavy_escape_root_acceptance_20261023.md), from the complete twelve-class finite endpoint table.

The last result also proves that a component of heavy vertices cannot be closed
under all three centre moves: its actual three-face would be compact and
right-angled, and three facet colours would force every polygon to have an even
number of sides at least six, contradicting Euler's formula.

The [new metric forest theorem](../results/review_finite57_heavy_centre_forest_and_linear_exit_expansion_root_acceptance_20261023.md)
strengthens this: heavy-to-heavy centre edges have cosh length at least16,
and successive directions are orthogonal, so no cycle is possible. Every
heavy set S has exactly |S|+2c(S) centre-edge incidences leaving it. A full
component with H vertices has H+2 nonheavy exits. This supplies linear
expansion. The later [mixed row1/row2 theorem](../results/review_finite57_row_one_two_variable_cone_component_financing_root_acceptance_20261023.md)
extends the forest to both receiving types, including every finite dihedral
label and arbitrary dotted exchanged products. A variable-angle cone argument
handles the nonright row2 turns. Full-component counting supplies enough safe
eight-unit tokens when all nonheavy centre neighbours have these types,
retaining the old K/Q/L1 payments. Other exits remain explicit in its criterion;
there is no universal364 cap or dimension56 theorem.

The [zero-exchanged costly-exit theorem](../results/review_finite57_zero_exchanged_bad_centre_affine_financing_root_acceptance_20261023.md)
finances rows4/5/6/11 through complete actual cusp recoveries. The newer
[all-row7/near-row8 theorem](../results/review_finite57_zero_exchanged_all_row7_near_row8_financing_root_acceptance_20261023.md)
finances every zero-exchanged row7 and the near orientation of row8.
Its actual finite A4/B4 receivers retain all old debts; full restorer
products force at most ONE qualifying source across both A4 ports.
Maximum new finite cost is358<364. Far-row7 instead has an actual ideal
short-leaf endpoint already paid by the retained J allocation.

Among still-unpaid nonheavy finite centre exits with zero exchanged
product, only FAR-row8 remains. Its actual affine B4 kernel lies on an
old two-face and accounts for rank55. It does not supply a rank56 cusp
classification or a virtual extra affine A1. The immediate finite
receivers cost371.75/365 and cannot accept8 under364. Positive exchanged
products and complete global coverage remain open. No universal364 cap
or dimension56 theorem follows.

## Construction search

The glued E7/ternary nine-dimensional host is now [proved nonreflective](../results/review_glued_e7_a2_two_unit_releases_original_period_and_literal_nonreflectivity_root_acceptance_20261023.md).
After the actual norm-four corner, two complete23-profile first-wall proofs
give two actual finite vertices and their full outward germs. Each proof keeps
all primitive norm classes, both embeddings, original-module membership and
unknown-wall firstness. Five displayed projection-sign errors in excluded
rows of the first edge were [corrected with byte-preserved history](../results/review_glued_e7_a2_e2_release_five_sign_successor_root_acceptance_20261023.md);
the repaired exclusions and actual first wall survive.

Two individually nonintegral metric involutions have a product G that preserves
the ENTIRE original module, proved by a universal parity identity. It maps the
two actual full germs and preserves the full chamber. Its exact trace5+4phi>10
proves infinite order. Distinct powers give infinitely many cosets of the full
reflection group in the arithmetic lattice, hence infinite chamber volume.
This closes precisely this literal host. It gives no new compact9 example,
field-wide theorem or commensurability-class exclusion.

The different [squared-unit coupling host](../results/review_h9_squared_unit_e7_return_original_period_literal_nonreflectivity_root_acceptance_20261023.md)
is now also proved nonreflective. Its actual E7 quadrilateral and ambient
D6/B3 walk return to a full E7+A2 germ. The return map is original on all
ten basis columns; composing it with the earlier original involution gives
trace16phi^6=80+128phi>10. This infinite-order chamber stabilizer proves
infinite chamber volume. The earlier order-two symmetry alone did not
supply that conclusion. This closes the second literal host, not its
whole form or commensurability class, and gives no new example.

A genuinely different [prime41 cubed-unit host](../results/review_h9_cubed_unit_prime41_original_host_first_edge_root_acceptance_20261023.md)
has original ternary Gram[[2,-1,phi^3],[-1,2,0],[phi^3,0,-2phi]] and an
independent E7 summand. Its norm41 determinant valuation separates the
specified unit-coupled E8 family up to K-similarity. Complete original
root classes, both embeddings, strips and primitive filters prove the
first actual edge. The [second actual unit edge](../results/review_h9_prime41_second_actual_unit_edge_original_germ_obstruction_root_acceptance_20261023.md)
is also accepted, with its full E7+[2b]+[2] endpoint. A repeated abstract
germ does not provide a period: its uniquely prescribed metric return
fails the ORIGINAL lattice test. The [third actual edge](../results/review_h9_prime41_third_actual_edge_original_involution_full_hexagon_root_acceptance_20261023.md)
returns to a full E7+A2 germ through a genuine original chamber
involution of order two. Its three actual edges and their images close
the WHOLE compact E7 hexagon, with angles(pi/3,pi/2,pi/2,pi/3,pi/2,pi/2)
and area4pi/3. Neither this face nor the finite-order symmetry establishes
ambient finite volume, nonreflectivity or a new H9 example.

The [accepted ambient continuation](../results/review_h9_prime41_ambient_d6_pentagon_mixed_d4_original_obstructions_root_acceptance_20261023.md)
now leaves that E7 face. Three complete original wall censuses produce
U,S,H and a full H3+D4+A1+[2b41] corner through actual intermediate
vertices. They retain all four primitive norm classes, full original
covectors, both embeddings, closed coefficient covers and unknown-wall
firstness. One D6+N-fixed face is recognized as the entire regular
right pentagon. All norm-class-preserving metric candidates there and
all five nonidentity D4 local permutations fail original membership.
Two wording-only scope repairs are byte-preserved. This is local ambient
construction, not a finite-volume chamber or infinite period; no new
H9 example has been established.

## Papers, algorithms and resource limits

The [six-paper index](../manuscripts/README.md) maps results to techniques,
source/PDF editions and proof maps. The
[result-manuscript correspondence](result_manuscript_correspondence.md) preserves
more detailed history. Supporting improvements remain in the same paper families;
parked refinements and earlier editions are preserved rather than added as papers.

The [computational proof contract](computational_proof_contract.md) requires each
algorithm's domain, completeness and termination proof, exact arithmetic, output
and replay boundary. Use [finite57's reproduction guide](finite_volume57_reproduce.md)
and [the formal-project guide](../formal/README.md) for named batches. Hashes,
source review, arithmetic replay and geometric formalization are different checks.

One scientific/Lean/TeX child runs at a time under the shared lock. Admission is
40GiB disk/6GiB available RAM; runtime floors are8GiB/3GiB. Script/TeX batches
retain59seconds/1GiB/one thread; Lean2048MiB/one thread, then a SEPARATE audit.
Remove only owned unused products after each batch. Cleanup starts below20GiB
free disk; sources, certificates, final PDFs and execution history are preserved.

Publication requires the actual staged-index debris/secret audit and strict
Sphinx build through the256MiB sampled-RSS publication watchdog. No compiler
objects, caches or generated sites belong in Git. The optional936-file/33-archive
bulk payload remains unuploaded and excluded from Git; see
[repro/README.md](../repro/README.md).

The exact preceding reader guides are [byte-preserved](../results/source_archive/reader_guides_before_b18_terminal_and_prime41_refresh_20261023/manifest.json).
Historical execution receipts retain their original source bindings and are not
silently rebound to this rewritten current guide.
