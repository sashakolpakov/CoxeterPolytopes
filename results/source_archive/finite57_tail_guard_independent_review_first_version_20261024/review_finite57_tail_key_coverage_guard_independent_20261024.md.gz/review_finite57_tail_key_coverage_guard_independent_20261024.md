# Independent source review of the finite57 tail key supplement

24 October2026. Reviewer `/root/audit_finite57_algorithms`; author of the
guard `/root/consolidate_six_scope`. No authorship of the reviewed guard
is attributed to this reviewer. Source-only review: no import, execution,
test, certificate arithmetic, Lean or TeX job ran.

## Version and outcome

The complete324-line source reviewed is
`scripts/verify_finite57_tail_key_coverage_supplement_20261024.py`,
15,629 bytes, SHA256
`2480998ff71620dd9413abd63d7c3337f341f90c9cbcd40a2d406782e797a137`.
The complete contract is
`results/finite57_tail_key_coverage_supplement_source_plan_20261024.md`.
This review also inspected the legacy unit-charge two-contact producer and
reviewer branches and the classical-coordinate review loop to ascertain
the supplemental binding's actual limits. It does not repeat root's
separate mathematical audit of the unbounded tail.

The literal key sets, type checks, duplicate rejection and stated
cross-bindings are sound at their explicit inherited reference-domain
premises. No numerical or global verification overclaim was found.
One bounded-input implementation correction is recommended before a
positive launch: replace `stat` followed by unbounded `read_bytes` with
an actually bounded read. Two provenance/coverage limitations must remain
explicit, as described below. No mathematical counterexample is alleged.

## Strict independent key domains

`require` uses a real conditional and raises `CoverageError`; no assertion
can disappear under optimized Python. Every row index first checks list
and object shapes, rejects duplicate computed keys, and then compares the
complete actual key set with the expected set. Duplicate JSON object keys
are rejected during parsing as well. There is no silent dictionary overwrite.

The four E7 keys include side, a strict boolean own-omitted state, and both
ordered support tuples. `integer` requires `type(x) is int`, excluding
Python booleans, while `flag` requires `type(x) is bool`. Support entries
are distinct strict integers. Consequently neither boolean/int aliasing,
four repetitions of one valid row, an exchanged side, nor replacement of
one omitted-node state by another can satisfy this set comparison. The
four literal expected tuples agree with the stated two ordered sides and
two own-node states. This is stronger than a four-row count.

The cycle wrappers require exactly the sixteen integer sizes2–17, each
once, in all three primary/review wrapper arrays. Inner support tuples
are nonempty, have distinct nodes and lie inside that cycle's range.
The widened scalar receipts are then required to have exactly the580
cross-bound `(size,left_support,right_support)` keys, once each.

The exceptional descriptors are independently constructed for ranks
1,6,7,8,4,2, using `None` and all r+1 affine-node avoid states. This gives
40 descriptors. All seven relevant primary/review descriptor arrays must
match that complete set without duplicates. The expected singleton,
multiple, subunit and unit singleton key sets are then cross-bound
strictly at each descriptor. The71/16/46 totals are supplemental metadata
checks; they are not presented as proofs of geometric completeness.

The fifteen failure occurrences are indexed by full descriptor plus the
ordered contact-support tuple. Both prescribed E7 same-row occurrences
must be present, and the thirteen remaining floors must be precisely the
set difference. The two rows cannot be removed merely by a count filter.

The three packing budget keys are ordered string pairs. `(1,3/2)` and
`(3/2,1)` are distinct required keys. The five B/C/D analytic-tail keys
include strict boolean modified status and integer start rank; the two
A keys include parity and the complete start-form tuple. The24 classical
coordinate classes preserve the distinction between integer side0/1 and
symbolic string sides `r`/`r-1`. Boolean sides are rejected. The seven
four-thirds cycle-class keys similarly include the complete allowed-distance
tuple. All these arrays require set equality, not containment or counts alone.

## Cross-bound reference assumptions

Inner expected support keys for small cycles and exceptional factors are
taken from named primary or independent-review outputs. The supplement
checks uniqueness and exact agreement; it does not regenerate those
mathematical domains. A coordinated omission from a reference and every
bound output could therefore pass. The contract states this correctly:
legacy domain reconstruction and numerical verification remain premises.

The `two_contact_case` unit-charge check is narrower still. It requires
that exactly descriptor `(E7,None)` has a non-None record, but does not
bind that record's internal `nodes` field to `((0,4),(1,7))`. The original
producer explicitly constructs those contacts, and its independent reviewer
reconstructs the unique cheap support and its polynomial, while checking
the saved record's presence. Thus the inherited mathematical reconstruction
is not missing, but this supplement must not be described as a full
inner-key binding of that single two-contact record. An optional literal
node-key comparison would make the supplement stronger without any new
scientific computation.

Similarly the guard does not validate ignored numerical fields, polynomial
coefficients, KKT slacks, model matrices, packing predecessor arithmetic
or omission choices. Its `PASS_FINITE57_TAIL_KEY_COVERAGE_ONLY` status and
returned scope correctly exclude such claims.

## Input-size correction and execution/provenance boundary

The reviewed `load` first checks `path.stat().st_size<=32MiB`, then calls
`path.read_bytes()`. A file can grow or be replaced between those operations.
The latter read is consequently not bounded by the advertised limit. This
is a resource-hardening defect, not an invalid key comparison. The minimal
fix is to open the file and read at most `MAX_INPUT_BYTES+1` bytes, reject
an over-limit length, then parse/hash precisely those captured bytes. A
post-read length test alone would detect oversize after the allocation,
but would not enforce the intended allocation-read bound.

The source imports only the standard library and launches no child process.
There are no project-worker imports or hidden compilation paths before its
guards. It does not acquire the shared proof lock or monitor resources
itself; the contract requires the coordinating admitted bounded wrapper.
Through the existing public `check` route it is an ordinary script and
must receive the default parent lock, not a self-locking exemption. Direct
invocation is not evidence of compliance with that resource contract.
This review did not run the wrapper or test the lock choice.

The returned `sources` map records SHA256 of the exact consumed JSON byte
buffers and the guard source. It does not compare those input hashes with
an independently fixed expected manifest, and it does not recheck files
after processing. A future receipt therefore needs an outer source/input
identity check against the reviewed frozen bytes before reuse. Alternatively,
the guard can enforce a fixed expected-input manifest. Recording hashes
alone is provenance, not acceptance of arbitrary replacement certificates.
The contract's stated key-only success remains valid for the captured bytes.

All loops are finite iterations over parsed arrays or literal finite sets;
there is no scientific recursion or optimization. Malformed rows fail by
explicit checks or ordinary exceptions and cannot produce a successful
result before all checks have returned. The bounded runner remains necessary
for aggregate JSON memory, parsing depth and runtime control; a per-file
byte limit is not a process heap cap.

## Recommendation

Fix the bounded read, keep the reference-domain and unit two-contact scope
limitations explicit, and bind any future runtime receipt to its exact
seven input hashes and final source hash. Root should review the changed
bytes before admitting the minimal key-only check. This report supplies
no test or execution result and does not authorize a raw proof-process
launch or a numerical/global finite57 PASS.
