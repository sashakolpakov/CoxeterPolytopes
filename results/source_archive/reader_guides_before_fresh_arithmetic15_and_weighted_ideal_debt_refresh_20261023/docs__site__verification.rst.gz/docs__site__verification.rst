What has actually been verified
===============================

There are four distinct layers: written mathematical proof, replay of finite
certificates, compiled conditional Lean logic, and full geometric formalization.
A successful source hash or PDF build is not a mathematical verification.
The :download:`current bounds guide <../current_bounds_and_verification.md>`
and each proof map identify the premises left external.

Papers and later bounds
-----------------------

All six paper editions are written, compiled and internally reviewed, with
matching source/PDF/build records. Their
:download:`delivery receipt <../../results/six_paper_final_tex_delivery_20261021.json>`
retains those exact editions. General compact18 and arithmetic15 are later
supporting arguments; the frozen PDFs still state23 and20. No externally
refereed status or complete geometric Lean formalization is claimed.

.. list-table:: Current verification boundaries
   :header-rows: 1
   :widths: 27 73

   * - Package
     - Actual evidence and limit
   * - Finite volume57
     - Complete written composition review. All25 bounded B13/frontier replacements passed and are integrated; matching inherited records cover111 other script selections. No combined146-job runtime PASS or complete transitive regeneration.
   * - Compact18
     - Complete written composition, outside review and root acceptance. Its five-declaration conditional composition compiled and passed a separate actual audit under23 written inputs.
   * - Arithmetic15
     - Complete handwritten whole-D16 obstruction and global composition, with full different-author review/root acceptance. Older authenticated computations remain premises. Prior16/precursor Lean kernels retain their scopes; the new fourteen-declaration dyadic kernel is prepared, without compilation or separate actual audit.
   * - Sharp right-angled8/ideal4
     - Complete5-page paper, internal reviews, exact polynomial/model checks and selected compiled projection/height/count logic. Published facet/code/classification results and actual geometry remain external.
   * - Ideal RA4 volume/structure
     - Complete17-page paper, reviewed arguments, exact checks and selected conditional logic. No complete geometric Lean proof.
   * - Compact RA4 constraints
     - Complete14-page paper, reviewed capacity/excess arguments and exact checks. No proof of the absolute volume minimum or unique second-volume double.

Relevant maps and actual records:

* :download:`Finite57 proof map <../finite_volume57_lemma_map.md>`
* :download:`Finite57 reproduction guide <../finite_volume57_reproduce.md>`
* :download:`Complete bounded-loader integration <../../results/finite57_complete_loader_catalogue_integration_20261022.json>`
* :download:`Compact18 composition logic <../compact_dimension_eighteen_composition_logic_20261022.md>`
* :download:`Compact18 actual compile/audit receipt <../../results/lean_compact18_composition_verification_20261022/manifest.json>`
* :download:`Arithmetic16 composition logic <../arithmetic_dimension_sixteen_composition_logic_20261022.md>`
* :download:`Arithmetic16 actual compile/audit receipt <../../results/lean_arithmetic16_composition_verification_20261022/manifest.json>`
* :download:`Arithmetic16 thirteen-group logic <../arithmetic_sixteen_frontier_refinement_logic_20261022.md>`
* :download:`Arithmetic16 thirteen-group actual receipt <../../results/lean_arithmetic16_frontier_thirteen_group_verification_20261022/manifest.json>`
* :download:`Sharp right-angled proof map <../right_angled_sharp_dimensions_publication_proof_map_20261021.md>`

Heavy-centre forest kernel
----------------------------------------

The :download:`new scalar/chain kernel <../../formal/CoxeterProofs/HeavyCentreForestScalarKernel.lean>`
has :download:`actual compilation and a separate eleven-declaration audit PASS <../../results/lean_heavy_centre_forest_verification_20261023/manifest.json>`.
Primitive square equations imply both cone gaps; strong finite-chain induction
derives no-return from two LOCAL geometric bridges. Natural variables index
the chain or count incidences; metric quantities remain in an ordered ring.
The :download:`immutable map <../heavy_centre_forest_scalar_kernel_logic_20261023.md>`
retains real geometry, actual classification, graph realization, forest Euler
and finite reverse-port instances as explicit external premises.

Compilation took2.4seconds and the separate audit1.93seconds. Six actual prints
use propext/Classical.choice/Quot.sound, the other five propext/Quot.sound;
none uses sorryAx. The :download:`actual stdout <../../results/lean_heavy_centre_forest_verification_20261023/axiom_stdout.txt>`
retains one unused-variable warning. The :download:`initial RAM refusal <../../results/lean_heavy_centre_forest_verification_20261023/attempt_1_resource_deferral.json>`
is preserved. Owned work is absent; the531912-byte object is an ignored cache.
The complete actual heavy-graph instance is not claimed Lean-verified, and no
capacity or dimension56 conclusion follows. No older successful module ran.

A18 continuous scalar kernel
----------------------------------------

``CoxeterProofs.A18TwoDottedEndpointScalarKernel`` has a
:download:`bounded compile and separate ten-declaration actual audit PASS <../../results/lean_a18_two_dotted_endpoint_verification_20261023/manifest.json>`.
Its :download:`source <../../formal/CoxeterProofs/A18TwoDottedEndpointScalarKernel.lean>`
uses Std only and a genuine generic ordered ring. It derives three radical
chords from exact square-gap identities, the tangent estimate, continuous
core gap, both endpoint gains, one completed square and all four end budgets.

The :download:`immutable preparation map <../a18_two_dotted_endpoint_scalar_kernel_logic_20261023.md>`
identifies actual geometric pressures, all-hole inventories, individual legal
prices, orthogonality, reference norm floors and a real interpretation as
premises. These are theorem parameters, not entries in Lean's printed
foundational axiom list. The source supports the TWO-DOTTED branch, not a
whole-A18 exclusion or the later full mixed-end theorem by itself.

Compilation took3.25seconds and the admitted separate audit1.77seconds.
All ten actual printed sets contain exactly ``propext``, ``Classical.choice``
and ``Quot.sound``. There is no ``sorryAx``. The
:download:`complete actual stdout <../../results/lean_a18_two_dotted_endpoint_verification_20261023/axiom_stdout.txt>`
retains one unused-variable warning. No cosmetic rerun was made. The earlier
:download:`audit admission refusal <../../results/lean_a18_two_dotted_endpoint_verification_20261023/audit_admission_deferral.txt>`
and :download:`pre-audit receipt <../../results/lean_a18_two_dotted_endpoint_verification_20261023/pre_audit_manifest.json>`
are preserved. Owned work is absent; its691656-byte object is an ignored cache.

Later written frontiers do not enlarge older kernels
----------------------------------------------------

The complete :download:`B17+actual-I exclusion <../../results/review_compact18_whole_b17_actual_i_and_four_group_frontier_root_acceptance_20261023.md>`
and :download:`D17+actual-I exclusion <../../results/review_compact18_whole_d17_actual_i_and_three_group_frontier_root_acceptance_20261023.md>`
first leave three necessary groups. The complete
:download:`whole-A18 exclusion <../../results/review_compact18_whole_a18_and_two_classical_group_frontier_root_acceptance_20261023.md>`
first leaves only wholeB18 or wholeD18 at that same vertex. It includes all
actual endpoint contacts, the native-gap orthogonality step and one positive
H4+A1 projection with all legal prices. The full theorem is written and
internally reviewed, not Lean-verified; the scalar module above proves only
its older two-dotted branch. The global compact ceiling stays18, and neither
remaining group is an example. The later
:download:`complete whole-B18 conjunction <../../results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md>`
now excludes B18 too, leaving ONLY wholeD18 necessary at a selected
farthest vertex. It has a separate complete source review and root acceptance;
older kernels acquire no new geometric coverage from this written result.

The :download:`B18 window/head theorem <../../results/review_compact18_whole_b18_fresh_window_head_and_finite_helper_root_acceptance_20261023.md>`
and :download:`D18 window/strong5/head theorem <../../results/review_compact18_whole_d18_fresh_window_strong_five_head_root_acceptance_20261023.md>`
are complete internally reviewed necessary reductions. Neither removes a whole
remaining family or changes the global ceiling. Actual terminal couplings
remain outside those theorems.

The older :download:`five-case endpoint logic map <../general_eighteen_endpoint_refinement_logic_20261023.md>`
retains its :download:`eleven-declaration actual audit PASS <../../results/lean_general18_endpoint_refinement_verification_20261023/manifest.json>`
for its original five-case deduction and finite analytic integer seals.
Eight prints are axiom-free; the other three use propext/Quot.sound.
Its successful six-case dependency was reused, not rerun or relabelled.
The newer written exclusions are not automatically formal instances of it.

The :download:`complete GLOBAL arithmetic15 acceptance <../../results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md>`
binds the entire445-line handwritten obstruction and306-line outside
review. The sole corrected D21 time-product coefficient and full
predecessor are byte-preserved. All odd/even head norms and
inert/ramified/split2 cases fail original cycles, full-order strips,
K-square tests or two original-vector consumers. No prepared D16 census
was executed or assumed. The prior GLOBAL16 bound excludes every n>=17;
its complete dimension16 frontier leaves only the SAME original wholeD16,
which the new proof excludes. Older authenticated computational premises
retain their scopes; this is not a new complete replay or a claim that
the entire global theorem is free of computations.

The :download:`actual quadratic head and BOTH-fork reduction <../../results/review_arithmetic16_whole_d16_actual_quadratic_dotted_head_both_isolated_forks_root_acceptance_20261023.md>`
provides the final dyadic theorem's geometric interface. Its complete
head, endpoint-fork and cubic exclusions have full written review.
The new discrete kernel below keeps those actual fields, finite tables,
square exceptions and geometry external; older modules do not acquire
new formal instances.

The :download:`complete B15+I theorem <../../results/review_arithmetic16_b15_actual_i_complete_terminal_and_all_degree_exclusion_root_acceptance_20261023.md>`
has a fresh complete short-white/foreign inventory, actual-field
reduction and two legal original-vector dispatches. Integer norms
exclude every cubic field; the full quadratic I strip and final
sqrt3/sqrt17 arguments close the rest. The
:download:`complete D15+I theorem <../../results/review_arithmetic16_d15_actual_i_complete_fork_and_all_degree_exclusion_root_acceptance_20261023.md>`
first bounds both genuine fork coshes below14, then excludes ALL
isolated and nonisolated actual caps. Its endpoint norm-two lemma
handles every degree and ramification pattern. A single introductory
price wording correction was byte-preserved; the equations already
used the correct .08 P5 price. Both complete stage reviews and root
gates precede the separate frontier conjunction review. These are
written mathematical proofs, without new field-enumeration execution
or geometric/number-field instances in older Lean modules.

The A11 theorem uses one changed
endpoint reference with every isolated foot and individual price retained;
its joint A11+I energy exceeds18/25 before adding the disjoint T4>2/7.
It covers all five T4 types, including H4. The
:download:`complete A14 typed-seven theorem <../../results/review_arithmetic16_a14_both_actual_typed_seven_root_acceptance_20261023.md>`
first leaves group10 with an ordinary irreducible T2. Its3/19 floor remains;
the typed-defect K7 lock is not transferred to that ordinary case. The
:download:`all-field ordinary reduction <../../results/review_arithmetic16_a14_ordinary_rank_two_actual_triangle_two_field_root_acceptance_20261023.md>`
now gives one isolated common cap, three triangle types and actual field
Q(sqrt5) or Q(sqrt2). The new ordinary proof excludes ALL those cases:
integral endpoint tests give both signed endpoints>.44, and a rebuilt
reference retains every old foot correction and individual price. Its
minimum energy>.849036581755 plus the disjoint ordinary3/19 contradicts
one original norm. This closes whole original group10. The global
arithmetic ceiling was then16. The later whole-D16 closure above proves15.
These predecessor written results do not enlarge
the older thirteen-group or A13/A12 scalar kernels below.

The two new N11 proofs share one404/625 reference after separately
proving the complete four-site .65 window. Each keeps the new retained-A3
H4/D10 cases and every foreign/own boundary. The actual-defect proof uses
the derived actual K7. The actual-I proof instead eliminates all helper
degrees>=3 by a nonzero integral norm below1, then rules out the golden
case by11-divisibility of an I norm with magnitude<8. Their consumers
use one original vector. These are full written/source-reviewed results,
with no new Lean instance or enlarged earlier formal scope.

The :download:`A13 scalar logic map <../a13_i_endpoint_graft_scalar_kernel_logic_20261023.md>`
and source have full different-author static review and
:download:`root precompile acceptance <../../results/review_a13_i_endpoint_graft_scalar_kernel_root_precompile_acceptance_20261023.md>`.
The :download:`first admission refusal <../../results/lean_a13_i_endpoint_graft_verification_20261023/attempt_1_resource_deferral.json>`
records4.7GiB RAM before Lean. The next admitted compile
:download:`failed at two tactic scalings <../../results/lean_a13_i_endpoint_graft_verification_20261023/attempt_2_failed_compile.json>`.
The :download:`two explicit identity rewrites <../../results/review_a13_endpoint_graft_two_identity_rewrites_root_preclear_20261023.md>`
have outside/root clearance. The repaired retry was first
:download:`refused before Lean at5.8GiB <../../results/lean_a13_i_endpoint_graft_verification_20261023/attempt_3_resource_deferral.json>`.
A later retry has an :download:`actual compile PASS in1.33seconds <../../results/lean_a13_i_endpoint_graft_verification_20261023/pre_audit_manifest.json>`.
Its separate audit was initially refused at5.3GiB RAM. A later
:download:`actual eleven-declaration audit PASS <../../results/lean_a13_i_endpoint_graft_verification_20261023/manifest.json>`
took1.28seconds at6.34GiB RAM and reran no successful compilation.
All eleven actual prints use only standard foundational axioms, with no
``sorryAx``. Failed diagnostic prints, including error-propagated sorryAx,
earn zero credit. Actual geometric vector
data, legal payments and weak-foot absorption remain external.

The :download:`A12 scalar logic map <../a12_adjusted_loss_kernel_logic_20261023.md>`
has complete source review. Its initial RAM refusal and
:download:`actual failed compile <../../results/lean_a12_adjusted_loss_verification_20261023/attempt_2_failed_compile.json>`
are preserved. The reviewed repairs now have an
:download:`actual bounded compile and separate ten-declaration audit PASS <../../results/lean_a12_adjusted_loss_verification_20261023/manifest.json>`:
2.37seconds and1.51seconds respectively. All prints use only standard
foundational axioms; no ``sorryAx`` occurs. Earlier failed declarations
retain zero verification credit. The6GiB admission gate is unchanged;
the later full A12/A13 geometry is outside this module. Its source and map
remain dated preparation records, superseded in execution status by the receipt.

The :download:`complete B18 terminal inventory <../../results/review_compact18_b18_uniform_terminal_lengths_complete_seventeen_inventory_root_acceptance_20261023.md>`
provides unconditional S17/S18 sum and actual edge-length bounds, using
one original farthest vector. The :download:`near3/own6 exclusion <../../results/review_compact18_b18_near_three_own_six_complete_short_exclusion_root_acceptance_20261023.md>`
retains every actual short-opposite role and mutual range. The
:download:`finite-own far-helper exclusion <../../results/review_compact18_b18_all_finite_far_helper17_raw_prefix_root_acceptance_20261023.md>`
uses actual H4 finite projections and full A2 cores, all reference cross
terms and legal individual prices. The
:download:`complete dotted far-helper exclusion <../../results/review_compact18_b18_dotted_far_helper17_complete_root_acceptance_20261023.md>`
now leaves only the short-contact family. It retains every actual short and
mutual branch, then uses a full actual A17+I neighbour with a freshly proved
height ratio and1.061 comparison. The neighbour is never chosen farthest.
Its :download:`explicit price erratum <../../results/compact18_b18_strong_helper_neighbor_one_weak_far_opposite_anchor_payment_erratum_20261023.md>`
corrects the asymmetric opposite anchor to .013, fitting>.134; every gain
is unchanged. Historical source/review/gate bytes and the predecessor are
preserved, with no retrospective PASS for the false copied sentence.
The later :download:`B18 distinct-cap theorem <../../results/review_compact18_b18_distinct_terminal_caps_and_seven_common_cases_root_acceptance_20261023.md>`
and :download:`five common-case theorem <../../results/review_compact18_b18_five_common_cases_and_two_holdouts_root_acceptance_20261023.md>`
leave two terminal cases. The
:download:`head-gap/H3-neighbor theorem <../../results/review_compact18_b18_zero_own_short_five_and_last_common_case_root_acceptance_20261023.md>`
then removes own0/short5. The
:download:`last common3/3 theorem <../../results/review_compact18_b18_last_common_three_three_actual_neighbor_root_acceptance_20261023.md>`
removes the final role via an actual A18 neighbor at factor11/8.
Its fresh inventory, actual helper packing, near4 mates and legal single
endpoint graft cover every weak set. The separate complete conjunction
above authenticates the original role cover and every deletion, including
the retained price erratum. This excludes wholeB18 without choosing any
neighbor farthest or adding different norm budgets. The
:download:`D18 complete conjunction <../../results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md>`
now excludes EVERY weak-center16 case. Its
:download:`full outside conjunction review <../../results/review_compact18_d18_unconditional_strong16_complete_conjunction_full_scope_foundations_20261023.md>`
checks the pure, finite-own, dotted-own and zero-own branches exhaustively.
Actual neighboring vertices use explicitly weakened comparisons and one
norm budget there. WholeD18 and dimension18 remain open; the compact
ceiling stays18. None of these new whole-family geometric results is
automatically formalized by the older scalar kernels.

The :download:`new D18 fork10 theorem <../../results/review_compact18_d18_unconditional_fork_ten_complete_white_native_five_head_root_acceptance_20261023.md>`
reassembles an effective>.9729 reference ending16, deleting a possible
weak15 knot before applying pressure and retaining every earlier cross.
The :download:`terminal-slack/pair theorem <../../results/review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md>`
retains its terminal surplus, improving both cosh lengths to<9.64.
Its explicitly extracted actual-A18 local lemma requires factor11/8
and an endpoint pressure>.8, without choosing the neighbor farthest.
It excludes both-near3 for all heads and near3/far3 under native5 head.
The :download:`actual A17+A1 neighbor theorem <../../results/review_compact18_d18_actual_a17_a1_isolated_cutoff_native5_far_pair_root_acceptance_20261023.md>`
then bounds every isolated fork own by341/150, for every head. Its
native5 far/far negative-core argument retains the full first-coordinate
cross and pays one existing terminal price. Native5 head therefore forces
an isolated dotted fork. Iso/iso, iso/near3 and iso/far3 remain open.
The entire new logic is written and source-reviewed, not automatically
verified by the old scalar modules.

The newer :download:`all-head finite-mutual theorem <../../results/review_compact18_d18_all_head_finite_isolated_pair_actual_a16_neighbor_root_full_source_acceptance_20261023.md>`
excludes all finite nonright mutuals within the isolated/isolated pair,
including unequal parameters. Its ACTUAL A16+I2 neighbor has comparison
factor<3/2 and one norm>431/400. Mutual0/DOT and other pair-role families
remain open. This has full written review, without a new Lean instance.

The :download:`B18 terminal-pressure map <../b18_terminal_pressure_kernel_logic_20261023.md>`
has full different-author static review and
:download:`root precompile clearance <../../results/review_b18_terminal_pressure_kernel_root_precompile_acceptance_20261023.md>`.
Its :download:`actual compile and separate ten-declaration audit PASS <../../results/lean_b18_terminal_pressure_verification_20261023/manifest.json>`
took1.71seconds and1.16seconds, with no successful compilation rerun.
All ten prints use only propext, Classical.choice and Quot.sound; no
``sorryAx`` occurs. Primitive scalar products/squares imply the unbounded
polynomial seal and finite radical/convex-sum contradiction. Actual
geometry, complete inventories, original-vector pressure, terminal sums
and a real instance remain ordinary explicit premises. This verifies
one near3/own6 scalar argument, not the whole geometric theorem or later
role exclusions. Two warnings are retained; owned temporary work is absent.

The :download:`fresh arithmetic B16 head theorem <../../results/review_arithmetic16_whole_b16_head_near_short_three_scale_root_acceptance_20261023.md>`
uses rank16 strong6..14 without an initial5 premise, forcing head isolation
and2<U<12 over all actual fields. The
:download:`complete short-family theorem <../../results/review_arithmetic16_whole_b16_complete_short_white_isolated_dotted_field_root_acceptance_20261023.md>`
now excludes EVERY nonisolated short opposite. Its unconditional C<16
bound has a tight SAME-vector strong5 norm>1.000007005; weak5 is stronger.
The complete seven A15-white roles, all owns, every actual null and both
orientations are retained. Full ambient field locking gives eleven
quadratic models; ORIGINAL K-basis square tests dispose of all of them,
including the full Q(sqrt13) ring and both true square-norm exceptions.

The accepted whole-family proof continues from that geometric reduction.
A uniform dyadic/small-conjugate argument excludes EVERY cubic field. The
:download:`actual quadratic receipt <../../results/b16_isolated_quadratic_pair_census_verification_20261023.json>`
binds three disjoint field parts and a SEPARATE authenticated combine that
recomputes every field and pair using the same reviewed implementation.
All four units passed:43 fields,100 head models,85 short models and273
ordered pairs. There are168 half-product failures,104 full-field nonsquares
and ONE surviving pair U=5+2sqrt6,V=10+4sqrt6. That necessary algebraic pair
is not an example; its actual edge pressures force one norm>1.00640742675.
The :download:`whole-B16 acceptance <../../results/review_arithmetic16_whole_b16_complete_census_and_reference_root_acceptance_20261023.md>`
removes original group15 only. The census is not empty, not a second
independent implementation, and not a new arithmetic15 theorem.

Quadratic dyadic triple kernel preparation
------------------------------------------------

The new :download:`Std-only source <../../formal/CoxeterProofs/QuadraticDyadicTripleKernel.lean>`
and :download:`logic/input map <../quadratic_dyadic_triple_kernel_logic_20261023.md>`
prepare fourteen discrete declarations for the new arithmetic15 proof.
They derive valuation/parity contradictions, coupled-fork consequences,
bounded norms and the final numerical implication from explicit premises.
**No actual compile or separate axiom audit has run.** Number fields,
maximal-order tables, full square exceptions and actual geometry remain
external. Footer requests are not actual audit prints. The unchanged
40GiB/6GiB proof admission gate applies before either named batch.

B16 isolated-pair kernel preparation
------------------------------------

The new :download:`Std-only source <../../formal/CoxeterProofs/B16IsolatedPairScalarKernel.lean>`
and :download:`logic/input map <../b16_isolated_pair_scalar_kernel_logic_20261023.md>`
have a :download:`full different-author static review <../../results/review_b16_isolated_pair_scalar_kernel_precompile_full_source_and_map_replay_20261023.md>`
and :download:`root precompile clearance <../../results/review_b16_isolated_pair_scalar_kernel_root_precompile_acceptance_20261023.md>`.
The first admitted compile failed on two local names using reserved token
``prefix``. Its diagnostics/source/map have
:download:`byte-verified preservation <../../results/lean_b16_isolated_pair_scalar_verification_20261023/failed_compile_source_preservation.json>`.
Failed diagnostic ``sorryAx`` prints earn zero audit credit. The two-name
repair has :download:`outside delta review <../../results/review_b16_isolated_pair_scalar_reserved_identifier_and_map_delta_compact_20261023.md>`
and :download:`root clearance <../../results/review_b16_isolated_pair_scalar_reserved_identifier_repair_root_clearance_20261023.md>`.
**No successful compilation or separate actual audit is credited.** Fresh
RAM is below the unchanged6GiB gate, so no retry has launched.

The source derives Int valuation parity, the full cubic root bound and
both literal prefix contradictions over a generic ordered ring. Actual
number fields/ideals, integrality, geometric instances, census completeness,
primitive edge pressures and the raw original-vector square remain external.
Neither static review nor the four successful scientific jobs supplies
Lean compilation evidence. Existing successful modules have not rerun.

Finite-volume discharge and construction
----------------------------------------

The :download:`new far-row8 isolated contact3/4/parallel theorem <../../results/review_finite57_far_row8_isolated_intervening_cusp_financing_root_acceptance_20261023.md>`
and :download:`orthogonal-contact extension <../../results/review_finite57_far_row8_orthogonal_isolated_b4_cusp_financing_root_acceptance_20261023.md>`
have full written proofs, different-author reviews and root acceptances.
Their22 parameterized whole-cusp families have complete actual source counts,
literal cycle charges and prior-debt budgets. The sole coefficient-wording correction
was byte-preserved; every displayed table already used the correct factor.
The theorems cover exactly their isolated first-neighbor domains,
without a next qualifying bridge. The
:download:`affected-D23 finite-contact receiver <../../results/review_finite57_far_row8_d23_finite_a21_dihedral_receiver_root_acceptance_20261023.md>`
has full C0=356 and at most one8-arrival, reaching364. Its complete
source injection includes both I2 orientations and both path ends. The
D17 analogue has full360.5 and retains a genuine4.5 deficit after an8
arrival. Dotted contacts and complete global coverage remain open; no
runtime or dimension56 credit is inferred.


The :download:`special native-bond face theorem <../../results/review_finite57_special_native_bond_compact_face_and_label_restriction_root_acceptance_20261023.md>`
has a complete explicit geometric proof and full outside/root review. A
native5 or native7+ pair at a finite vertex has a compact Coxeter face
of codimension two, with every projected facet/angle checked. Thus that
restricted class has derived bound31 from published compact29, or20 from
the independent internal compact18 result. No optimum or historical
novelty for the class is claimed. The dimension57 application needs only
published29 and reduces the remaining finite5+ contact to native6.
AffineG2 permits a noncompact native6 face. The old unweighted rule retains
the4.5 deficit; the following weighting changes that local comparison.
The :download:`positive native-six weighting <../../results/review_finite57_native_six_positive_weighting_flags_and_single_factor_receiver_root_acceptance_20261023.md>`
uses a positive polygon factor(2/3)^r and an exact weighted height identity.
Its selected D17 receiver has weighted241+8 against1499/6, including
its accepted :download:`complete old-debt audit <../../results/review_finite57_native_six_selected_receiver_zero_old_debt_root_acceptance_20261023.md>`. The
:download:`all-factor extension <../../results/review_finite57_native_six_all_finite_minima_smoothed_ideal_root_acceptance_20261023.md>`
gives every finite shape minimum analytically, with parity included.
At cusps with a non-G2 factor of rank>=13 it compares original normalized
factor envelopes by a complete discrete smoothing argument. Actual
weighted ideal charges and receiving reserves remain separate. The
:download:`complete native-six finite budgets <../../results/review_finite57_all_single_native_six_finite_budgets_root_acceptance_20261023.md>`
now cover EVERY finite vertex containing native6, with Context and all
old tokens. The complete single-factor proof uses two formal same-rank
replacements, a rational row certificate and a strict modular endpoint,
then complete A17 and modified D15 remainder bounds. Both full source
review and root acceptance precede this integration. There is no new
enumeration or Lean instance. Heavy vertices without native6, weighted
ideal charges/reserves, full face coverage and global strictness remain
open; these results do not prove56.
The :download:`local native6 port obstruction <../../results/review_finite57_native_six_unbounded_same_face_local_ports_root_full_source_acceptance_20261023.md>`
has arbitrarily many actual heavy records on one common face with one
specified full G2 cusp, in a region of INFINITE volume. It rules out
a local count from those data alone. Finite volume, the still-unpaid
priority domain and all old debts remain essential; no charge is sent.
No arbitrary-face inheritance or new Lean execution is assumed.

The accepted :download:`isolated finite-cap financing <../../results/review_finite57_all_isolated_finite_short_fork_receivers_root_acceptance_20261023.md>`,
:download:`ideal-centre financing <../../results/review_finite57_ideal_fork_centre_joint_parallel_financing_root_acceptance_20261023.md>`
and :download:`finite-centre safe union/escape theorem <../../results/review_finite57_finite_centre_safe_union_and_heavy_escape_root_acceptance_20261023.md>`
have full written proofs, different-author reviews and root acceptances.
The finite table retains every costly/overloaded holdout. A component escape
is not a Hall condition or a sufficient receiving budget. No56 theorem follows.

The new :download:`heavy-centre forest theorem <../../results/review_finite57_heavy_centre_forest_and_linear_exit_expansion_root_acceptance_20261023.md>`
strengthens escape to exact linear expansion: every heavy subset S has
``|S|+2c(S)`` actual centre-edge incidences leaving it. Heavy-to-heavy edges have
cosh length at least16 and successive centre directions are orthogonal, so
the ambient hyperbolic chain cannot close. Receiver costs and previous debts
remain unresolved in that theorem. The subsequent
:download:`mixed row1/row2 theorem <../../results/review_finite57_row_one_two_variable_cone_component_financing_root_acceptance_20261023.md>`
proves a larger forest by variable-angle cones and finances full components
whose nonheavy centre neighbours all have these types. All old K/Q/L1 tokens
and ideal debts remain included. Other exits stay in its explicit criterion;
there is no universal dimension56 result. The older scalar/chain kernel does
not formalize this newer geometry or create its graph instances.

The :download:`zero-exchanged costly-exit financing theorem <../../results/review_finite57_zero_exchanged_bad_centre_affine_financing_root_acceptance_20261023.md>`
pays full-table rows4/5/6/11 through complete actual cusp recovery and all
shared debts. The :download:`new all-row7/near-row8 theorem <../../results/review_finite57_zero_exchanged_all_row7_near_row8_financing_root_acceptance_20261023.md>`
pays every zero-exchanged row7 and the near orientation of row8. Positive
actual finite projections supply A4/B4 receivers; full restorer products
force at most ONE source across both A4 ports. All previous charges are
retained and the largest new finite cost is358<364. Far-row7 instead
has an actual ideal short-leaf endpoint already financed by J.

Among still-unpaid nonheavy finite zero-exchanged exits only FAR-row8
remains. Its actual affine B4 accounts for rank55 on a two-face, not a
rank56 edge or a virtual affine A1. Immediate finite receivers cost
371.75/365 and cannot accept8 under364. Positive exchanged products and
complete simultaneous coverage remain open. There is no56 theorem.

The :download:`glued-host period theorem <../../results/review_glued_e7_a2_two_unit_releases_original_period_and_literal_nonreflectivity_root_acceptance_20261023.md>`
proves that literal host nonreflective. The different
:download:`squared-unit host is now also nonreflective <../../results/review_h9_squared_unit_e7_return_original_period_literal_nonreflectivity_root_acceptance_20261023.md>`.
A complete15-profile actual return to E7+A2 and all ten original basis
columns establish a new chamber symmetry. Its product with the earlier
original involution has trace16phi^6=80+128phi>10 and infinite order.
Disjoint chamber balls then give infinite volume. The earlier symmetry
of order two alone supplied no such conclusion. Neither theorem excludes
a whole commensurability class or gives a new example or geometric Lean
instance.

A genuinely different :download:`prime41 original host <../../results/review_h9_cubed_unit_prime41_original_host_first_edge_root_acceptance_20261023.md>`
has admissible signatures, a complete primitive root pool and a complete
first actual edge. Its :download:`second actual unit edge <../../results/review_h9_prime41_second_actual_unit_edge_original_germ_obstruction_root_acceptance_20261023.md>`
includes all eight finite profiles, both embeddings, complete closed
strips, dyadic/prime primitivity and unknown-wall firstness. The unique
prescribed metric return between the repeated germs is nonoriginal;
no later period is thereby excluded. The
:download:`third actual edge and whole E7 hexagon <../../results/review_h9_prime41_third_actual_edge_original_involution_full_hexagon_root_acceptance_20261023.md>`
have a complete eight-profile firstness proof, an original map checked
on all ten basis columns, full-germ chamber preservation and convex
whole-face closure. The symmetry has order TWO and trace6; the compact
hexagon has area4pi/3. Neither supplies ambient finite volume, an
infinite period or a new H9 example.

The :download:`accepted ambient D6/mixed-D4 continuation <../../results/review_h9_prime41_ambient_d6_pentagon_mixed_d4_original_obstructions_root_acceptance_20261023.md>`
proves unique firstness of three new original walls U,S,H, through
actual full finite germs to H3+D4+A1+[2b41]. Every primitive norm
class, original covector/parity condition, closed two-embedding cover,
square filter and unknown-wall inequality is retained. It recognizes
the entire regular right pentagon and checks every possible original
local map. The safe-overlist and metric-matching wording precisions
are byte-preserved; formulas are unchanged. This is local ambient
construction, not a finite-volume chamber or infinite period. The
:download:`accepted next two edges <../../results/review_h9_prime41_mixed_d4_two_actual_edges_b2_double_h3_root_acceptance_20261023.md>`
have complete six/nine-profile firstness, resolving the norm4 B2 tie
and reaching full2H3+B2+[2b41]. A prime41 finite-N congruence excludes
both nonunit classes. The final H3 swap is nonintegral in the original
module. Ambient volume, compactness and a period remain open.


The :download:`whole compact quadrilateral theorem <../../results/review_h9_prime41_double_h3_whole_compact_quadrilateral_root_full_source_acceptance_20261023.md>`
continues with two original unit walls and a direct positive projection
to an already actual old wall. It closes the WHOLE two-face retaining
both H3 factors and N, with angles pi/4,pi/2,pi/2,pi/2 and area pi/4.
Every unknown original wall and the intrinsic four halfplanes are checked.
Ambient volume and a new H9 example remain unresolved.

Reproduction and resources
--------------------------

Use named batches in the :download:`formal guide <../../formal/README.md>`
and :download:`computational proof contract <../computational_proof_contract.md>`.
One scientific/Lean/TeX child runs at a time under the shared exclusive lock.
Admission requires40GiB free disk and6GiB available RAM. Script/TeX batches
use59seconds/1GiB/one thread; Lean2048MiB/one thread followed by a SEPARATE
actual audit. Remove owned unused build products after each batch. Start
cleanup below20GiB disk; preserve mathematical sources and evidence.

Strict Sphinx and actual staged-index hygiene checks use the separate
publication watchdog and do not run mathematics. Generated sites, compiler
objects and caches are not publication assets. The optional936-file bulk
payload remains unuploaded and excluded from Git. The preceding reader
guides are :download:`byte-preserved <../../results/source_archive/reader_guides_before_b18_terminal_and_prime41_refresh_20261023/manifest.json>`;
historical receipts retain their original bindings.
