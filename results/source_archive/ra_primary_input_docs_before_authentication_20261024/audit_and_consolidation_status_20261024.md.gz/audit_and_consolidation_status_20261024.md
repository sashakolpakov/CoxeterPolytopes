# Audit and consolidation status

**Active again at the user's explicit request.** The user adopted all four
goals from the [renewed stopping assessment](assessment_stop_checkpoint_20261024.md):
close finite57's audit/reproducibility gaps, finish the sharp right-angled
and ideal RA4 release packages, consolidate compact17/arithmetic15, then
finish selected Lean checks, matching builds and publication checks.
The stopping assessments remain historical records. No dimension search
or exploratory refinement is part of this resumed task.

24 October 2026. The current task is to audit the main arguments, consolidate
the same six paper families, and finish conditional Lean verification and
bounded reproducibility. Later exploratory work toward dimensions 56, 16
and 14 is preserved outside the TeX manuscripts.

The earlier [assessment and stopping checkpoint](assessment_and_next_goals_20261024.md)
is historical: the user subsequently reactivated this full goal. The latest
completed review is the consolidated compact RA4 source; its replacement PDF
is still pending. New draft translations do not count as completed editions.

## Papers and current audit boundaries

| Paper family | Result retained or targeted | Fresh work completed | Still required |
|---|---|---|---|
| General finite volume | Ceiling 57 | Geometry and scoped algorithm audits; current triangle/protected routing, extension implications and short-path/low/disjoint receipt logic accepted at explicit finite-input boundaries; all 35 new binding stages source-cleared | Execute those binding stages; finish other bounded-high receipts, finite/context exchanges, tail interfaces and global integration; no combined full-manuscript runtime PASS |
| Sharp right-angled dimensions | Sharp ceilings 8 and 4 | Complete five-page proof, supporting exact algorithms and conditional interfaces audited; coordinating acceptance | Original Dufour text supporting the precise 27-facet premise remains unavailable; published inputs and geometric interpretation stay explicit premises |
| General compact | Integrate accepted ceiling 17 into the existing family | Consolidated draft contains the final D18 closure; earlier shared proof bodies are being translated into appendices | Finish the identified internal proof transcriptions, independently audit the complete revision and build; two prepared compact17 kernels remain uncompiled |
| Compact arithmetic | Integrate accepted ceiling 15 into the existing family | First expanded forest/field/algorithm and manual dyadic translation has scoped root acceptance; successor proof bodies are being prepared | Finish arithmetic component/row proof bodies and the actual D16 inventory, independently audit the complete revision, build and update formal interfaces |
| Ideal RA4 volume and structure | Published minimum, second volume with unique double, restricted chains | Complete fresh independent manuscript/model-algorithm audit and coordinating full-source acceptance | The exact historical Figure 7 incidence transcription remains an explicit external input; conditional geometric premises stay visible |
| Compact RA4 volume constraints | Capacity/excess, f>=65 and Vol>=49*pi^2/6 | Complete consolidated TeX, full independent translation review and coordinating acceptance; publication source prepared | Resource-admitted matching PDF build, rendered review and compact-RA4 conditional logic; old delivered edition remains current |

The delivered six TeX/PDF pairs are unchanged at this checkpoint. A revision
inside an existing paper family is not an additional proposed paper. The
largest published examples and the internally reviewed ceilings remain as
reported in the [dimension comparison](current_bounds_and_verification.md).
The general finite-volume, general compact and right-angled arguments assume
no arithmeticity.

The [six-paper consolidation map](six_manuscript_audit_and_consolidation_20261024.md)
identifies the common arguments, the point where cases split, and the exact
source homes needed before any old chapter is removed. Its initial proposed
execution counts are preparation history; the actual successor plan counts
are given below.

## Exact audit records

The [coordinating acceptance](../results/audit_sharp_ra_and_finite57_scoped_root_acceptance_20261024.md)
distinguishes the complete sharp-dimension audit from the scoped finite57
algorithm audit. The [finite57 geometry report](../results/audit_finite57_geometry_core_and_tail_interfaces_root_20261024.md)
and [local-routing review](../results/audit_finite57_local_routing_whole_components_fresh_20261024.md)
state what was reconstructed and which obligations remain. They do not
claim a new full-manuscript runtime PASS or transitive regeneration.

The [ideal RA4 audit](../results/audit_ideal_ra4_fresh_20261024.md) checks the
gap, equality-spectrum reduction, actual cutting sections, recognition and
gluing, along with each selected finite-model algorithm. Its separate
classification/input boundary remains visible in the
[coordinating acceptance](../results/review_ideal_ra4_fresh_audit_root_acceptance_20261024.md).

The [new finite57 scoped acceptance](../results/review_finite57_literal_rule_and_extension_logic_root_20261024.md)
records the complete literal-table transcription review, the caught and
corrected A1/D10-center transcription error, the four universal extension
schema implications and the current triangle/protected dependency order.
Numerical tables and the remaining coefficient/terminal bindings retain their
separate obligations. All three binding drivers and their shared literal
library now have complete root and different-author source reviews, with
[35 source-cleared stages](../results/finite57_literal_binding_source_clearance_20261024.json).
None of those stages has been executed. The saved-upper/reachability
premises and complete option-price bridges remain explicit.

The [new short-path root review](../results/review_finite57_short_paths_low_disjoint_root_20261024.md)
accepts the whole-face dependency order and low/disjoint terminal logic at
the stated finite/external premises. In particular, the changed affine-D
order10 corner pays 27/32 and activates its independent whole-face theorem;
it is not treated as an obsolete unit. The cycle7/8 correction is logically
separate from the finite-eight composition. The
[source-bound receipt](../results/finite57_short_path_low_disjoint_scoped_acceptance_20261024.json)
freshly matches 36 listed source/report pins. This is not numerical replay.

The [compact17 foundation freeze](../results/compact17_foundation_transcription_freeze_20261024.json)
preserves a coherent 193,119-byte TeX translation, its ledger and dependency
snapshot pending root review. The separate whole-A18 working fragment is
incomplete and unintegrated. The
[first arithmetic translation review](../results/review_arithmetic15_first_proof_body_translation_root_20261024.md)
likewise states precisely which translated deductions are accepted and which
component/inventory proof bodies remain to be written.

The [compact RA4 publication map](compact_ra4_publication_proof_and_verification_map_20261024.md)
links the complete proofs, explicit external inputs and fixed algorithms.
Its [full independent review](../results/review_compact_ra4_consolidated_translation_root_20261024.md)
accepts the new translation. Only draft-status wording changed in the
[new publication source](../manuscripts/compact_ra4_volume_constraints_publication.tex);
its [editorial-delta record](../results/compact_ra4_publication_source_editorial_delta_20261024.json)
does not claim a matching PDF or reader-edition promotion. This is the existing
sixth family, not an extra paper.

For every computation retained in a revised paper, the text must state its
admissible domain, algorithm, termination proof, soundness and completeness,
and exact output. Code, an attainer, a source hash or a successful PDF build
does not replace those mathematical statements.

## Bounded execution successor

Use the new public entry for the preferred execution route. The old workers,
drivers, resource runners and their receipts remain byte-identical because
existing certificates bind them. The new route rejects optimized Python,
keeps the shared lock and resource monitors, tracks owned descendants, and
separates compilation from an actual parsed axiom audit.

Inspect a plan without running any mathematical child:

```sh
python3 -B scripts/run_proof_batch_20261024.py manuscript finite57 \
  --mode full --pdf --plan
```

The actual [full plan](../results/finite57_audited_successor_full_plan_20261024.json)
has **151 stages**: 136 script selections, nine compilation stages, five
separate actual-axiom stages and one PDF stage. The [core plan](../results/finite57_audited_successor_core_plan_20261024.json)
has **16 stages**. Only five of those nine roots contain the relevant print
commands. The legacy 146/core11 inventory remains historical evidence. A
plan is not execution, and successful unchanged modules need no repeated run.

For a necessary new single-module batch, use a fresh ledger filename:

```sh
python3 -B scripts/run_proof_batch_20261024.py lean-compile \
  CoxeterProofs.D18UniformDottedHeadScalarKernel \
  --ledger results/compact17_scalar_compile_guard_new.json

python3 -B scripts/run_proof_batch_20261024.py lean-audit \
  CoxeterProofs.D18UniformDottedHeadScalarKernel \
  --ledger results/compact17_scalar_audit_guard_new.json
```

The second command requires matching successful capped compilation; it
does not compile a missing target as a fallback. It parses actual output
for every requested declaration and rejects missing, malformed, duplicate
or unapproved results. Ordinary theorem parameters remain assumptions and
must be listed in the logic map even when printed axioms are standard.

For a selected scientific checker, the public entry obtains the correct
shared lock and invokes the unchanged bounded runner:

```sh
python3 -B scripts/run_proof_batch_20261024.py check -- \
  scripts/fresh_d13_context_dimension57_20261018.py --verify
```

Choose checks because an input, implementation or unresolved obligation
requires them; do not rerun successful unchanged parts merely for a new date.
Historical direct worker commands identify mathematical components. Execute
them through the guarded route rather than treating those identifiers as
unmonitored launch instructions.

The [execution clearance](../results/audited_proof_execution_clearance_20261024.json)
binds different-author source reviews, coordinating monitor review and an
actual source-bound **14-test infrastructure PASS**. Those tests exercised
optimization refusal, lock choices, actual-output parsing, plan generation,
PID-reuse/reparent handling and cleanup of two tiny owned Python stand-ins.
They launched no mathematical worker, Lean or TeX. **The first positive proof
execution through the successor remains pending resource admission.**

The [first guarded Lean admission](../results/compact17_scalar_audited_entry_resource_deferral_20261024.json)
was actually attempted and refused before launching a compiler because RAM
was below 6 GiB. This is a recorded admission failure, not an executed Lean
compilation or axiom audit. Subsequent source-only work did not lower that
gate or rerun successful old modules.

Admission remains 40 GiB free disk and 6 GiB available RAM; abort floors remain
8/3 GiB. Scientific/Lean/TeX work is serial under the shared lock, with the
existing 59-second/1 GiB outer monitor and one thread. Lean also retains its
2048 MiB option. The additional process cleanup layer does not relax these
gates. Its birth-identity checks and polling limitations are described in
the [coordinating source review](../results/review_audited_proof_execution_root_clearance_20261024.md).

## Completion still required

Each of the six final editions needs a complete accepted mathematical
argument, precise external/computed premise register, source-bound review,
appropriate changed checks and a matching bounded PDF build. New selected
Lean sources need compilation and a separate actual axiom audit. The site
and catalogue must describe the resulting editions accurately. A final Git
index audit must exclude caches, objects, dependencies, intermediates and
generated sites before publication. This checkpoint completes none of
those remaining requirements by implication.
