# The D19 centre with contacts only on the short branches

21 October 2026. New supporting proof by root, pending full outside-author
mathematical review. No scientific, symbolic, enumeration, TeX or Lean job
was used. This is a lemma for the existing arithmetic argument, not a new
paper or a dimension-eighteen theorem.

## Statement

Consider a farthest vertex of a compact arithmetic first-type hyperbolic
19-polytope, with whole finite diagram D19. Number the long chain
1,...,17 and the two fork leaves 18,19. Let c be the actual opposite
wall along edge 17. Suppose c is orthogonal to the sixteen old walls
1,...,16. Then, for the original farthest vector x,

    h17 = x.omega17 > sqrt(34) - 21/40.                 (1)

There is no restriction on the finite native labels of its contacts
with the two fork leaves. The cases of no fork contact, one contact,
and two contacts are all included. A contact with the left A16
component is outside this statement. In particular, (1) does not
dispose of the whole D19 case.

The new steps are the complete treatment of one-fork labels other
than 3 and of every two-fork profile, together with an explicit
statement of the isolated-wall interface used at zero own contact.
The isolated dotted centre and single-fork3 centre floor are inherited.

## Inputs and the common normalization

The external foundations are compact acute simplicity, finite spherical
classification, the actual farthest-point/edge comparison, and the
first-type criterion of positive definiteness at every nonphysical
embedding. Native angles are pi/m. All conclusions concern actual
walls and one original x, with ||x||^2<1.

The following exact internal sources are used at their displayed local
interfaces. Their larger-rank conclusions are not substituted here.

| Source under results/ | SHA256 | Used interface |
|---|---|---|
| compact_farthest_vertex_mixed_replacement_inequalities_20261020.md | 3732b82614e13dfe2f7a3c66ab6c7fe67e517cbaeb77be0ca533f559ddf6ed84 | Actual finite edge and feasible null-point comparisons |
| arithmetic_full_an_isolated_finite_continuation_packing_20261020.md | 9ab34f073ea95bed2040bafe6b8573331721f9b1e75d65172f814637da046810 | One-contact normalization and elementary cyclotomic label restriction only |
| arithmetic_d19_isolated_centre_dotted_field_time_obstruction_20261021.md | 7f52ff318ec11a709ec483291d8669764b4a06f622af413c097fb902d20ac7bc | Isolated dotted centre satisfies (1) |
| arithmetic_d19_centre_single_fork_helper_classification_20261021.md | 64740e994c666bada6cd3b66951041bd83ab264a02870177b8c9385953f449ae | Loss-.525 single-fork3 classification and the scalar edge target |
| arithmetic_d19_silver_centre_actual_prefix_time_exclusion_20261021.md | 7d9f4facaa3c622ba41a03d570a54b39b9ac0c3fadc3d3c13104798fa4914fcc | Literal silver centre excluded at every height |
| arithmetic_d19_golden_centre_actual_h4_prefix_exclusion_20261021.md | e68422a04484054ecd8a8030a36d4f9e791623dfa1a18cb2efb6d708e0d1480a | Literal golden centre excluded at every height |
| arithmetic_d19_sqrt3_fork_time_anchor_exclusion_20261021.md | 12032b1de93e4c39d4379802238a768893c16ec3f9cb898cec144077695efda2 | General actual-wall sqrt3 time-anchor obstruction |
| arithmetic_d19_golden_isolated_fork_time_anchor_exclusion_20261021.md | e68e9e7b1dfc538d79887f1fc1c8a05a75c0743aeb54f99411117b6614df6512 | General actual-wall golden time-anchor obstruction |

These sources and their full root/outside reviews are accepted in
`arithmetic_d19_frontier_and_off_face_financing_acceptance_20261021.json`
(51934f79b9c6f191f7b3dbfae3d26fe8aa4d06610f240e70461d41319416a27c).
The new argument itself requires a separate full review.

Use the unit D19 roots and duals of the classification source. Put
q=sqrt(34), a=21/40. The actual wall has old pairings

    c.n17=-gamma, c.n18=-beta, c.n19=-eta,

and zero pairings with 1,...,16. A positive beta or eta is the cosine
of a finite native angle: the actual endpoint of edge17 is finite,
so c and the eighteen retained old walls have positive definite Gram.
In particular a fork-white contact is never dotted or parallel.

Projecting c on the mutually orthogonal fork whites gives

    delta=1-beta^2-eta^2 > 0,
    sigma=gamma+(beta+eta)/2,
    cosh(L)/q = sigma/sqrt(delta).

Here L is the actual length of edge17. The other sixteen whites
are orthogonal to c and to the fork leaves, so cause no further term.
The actual finite-edge comparison implies (1) whenever

    sigma/sqrt(delta) >= R(q),
    R(q)=40/21-(q-a)/(q(2q-a)).                       (2)

The exact calculation in the classification source gives R(q)<73/40.
Thus failure of (1) always requires sigma/sqrt(delta)<73/40.
There is no separately optimized vector in this comparison.

For the arithmetic tests set alpha_i=sqrt(2)n_i and Omega_i=omega_i/sqrt(2).
The old Gram is the rational norm-two D19 Cartan Gram, with

    Omega17^2=17, Omega18^2=Omega19^2=19/4,
    Omega17.Omega18=Omega17.Omega19=17/2,
    Omega18.Omega19=17/4.                            (3)

If an actual K-valued raw wall has norm N and spatial projection v,
write H^2=v^2-N. Its Schur complement in the full old19-plus-wall
Gram is -H^2. At every nonphysical embedding of the actual field K,
positive definiteness requires H_sigma^2<0. An embedding of a subfield
of K extends to K; all such embeddings are real. A positive conjugate
H_sigma^2 therefore excludes the wall. No field census is used.

## 1. An isolated finite contact at a fork is impossible

We need this for an actual wall, without assuming it is the opposite
wall of the fork edge. Suppose its sole old contact is finite at a
fork f. The one-contact raw normalization has N=2B, sole old product
-B, B=4cos^2(pi/m), and raw inverse diagonal d=19/4. Nonphysical
Schur positivity gives 0<B_sigma<2/d. The elementary cyclotomic
argument in 9ab34f07 leaves exactly m=3,4,5,6,8,12.

At m3 there is an actual positive-null star about old17 with arms
1,2,5: the other fork, the chosen fork followed by the new wall,
and five old left nodes. At m4 the roots 17,16,otherfork,f,c have
unit-Gram kernel (1,1/2,1/2,1,1/sqrt(2)), all positive. At m6
the actual path c--f--17 is the affine6--3 path. Each null sum has
positive time coefficient and nonpositive product with every other
actual wall; it is a feasible future ideal ray, forbidden by compactness.

At m8, B'=2-sqrt(2) would require d<2+sqrt(2), false for 19/4.
At m5 and m12 the old19-plus-wall Gram derives the actual field
and the time classes of the GENERAL anchor variants in e68e9e7b
and 12032b1d. Those variants require an actual wall in that time
class, not an assertion that the anchor wall bounds a particular
old edge. They exclude both cases. This checks the stronger interface
directly rather than extending an outgoing-edge corollary by wording.

Consequently, if exactly one of beta,eta is positive, gamma=0 is
impossible: the wall would have precisely this isolated finite contact.

## 2. No fork contacts

Here c is isolated from all old walls except possibly 17. Gamma=0
would leave a positive-square wall perpendicular to a full rank19
positive span in Lorentzian rank20, which is impossible. Parallel
own contact has the actual feasible null sum c+n17 and is impossible.

For isolated finite contact at 17 the same one-contact argument has
d=17 and again leaves 3,4,5,6,8,12. Label3 gives the affine all3
four-leaf star on17,c,16,18,19. Label4 gives the affine three-leaf
star at17 with c-label4 and both old forks-label3. Label6 gives the
affine6--3 path using either fork. The feasible-null argument applies.

For labels5,8,12 the respective nonphysical conjugates of B are
(3-sqrt(5))/2, 2-sqrt(2), 2-sqrt(3). All exceed 1/4>2/17,
contrary to Schur positivity. For the first inequality use sqrt(5)<5/2,
and for the last use sqrt(3)<7/4. Thus no isolated finite cap occurs.
An isolated dotted own contact satisfies (1) by 7f52ff31.

## 3. Exactly one fork contact

By symmetry take eta=0, beta=cos(pi/m)>0. Section1 permits us to
assume gamma>0; native own contact then has gamma>=1/2, including
the parallel/dotted alternatives. If m3, the .525 classification
64740e99 leaves only the literal golden and silver cases when (1)
fails; e68422a0 and 7d9f4fac exclude those cases at any height.

If m>=6, beta>=sqrt(3)/2, so

    sigma/sqrt(delta) >= 1+sqrt(3)/2 > 73/40.

Thus (1) holds. We are left with m4 and m5.

### A native5 fork helper

Let phi=(1+sqrt(5))/2, so beta=phi/2. Since phi>8/5,
sqrt(delta)<3/5 and beta/2>2/5. Weakness in (2) would imply

    gamma < (73/40)(3/5)-2/5=139/200<sqrt(2)/2.

Therefore the only positive native own contact is label3, gamma=1/2;
parallel and dotted contacts are already too large. Normalize c to
norm2 using that own3. Its old products are -1 at17 and -phi at f.
Thus phi belongs to the actual K, and (3) gives

    H^2=(79+87phi)/4.

At phi'=(1-sqrt(5))/2>-5/8 the conjugate is strictly positive.
Its embedding extends to a nonphysical embedding of K, contradicting
the required negative time square. This excludes the last weak case.

### A native4 fork helper

Now beta=1/sqrt(2). Weakness would give

    gamma < 53sqrt(2)/80 < 15/16 < cos(pi/9).           (4)

The middle inequality follows on squaring from integer margin896.
For the last, 4(15/16)^3-3(15/16)=495/1024<1/2;
4X^3-3X is increasing for X>1/2 and equals1/2 at cos(pi/9).
Hence the only possible positive own labels in (4) are 3,...,8.

Own4 has the actual affine star on17,c,16,the OTHER fork: its
three squared cosines are1/2,1/4,1/4. Own6 has the actual affine
6--3 path c--17--otherfork. These selections omit the contacted
fork, so its extra c product does not invalidate either principal.
Their positive null sums contradict compactness as before.

For own3,5,7,8 put t=2sqrt(2)gamma. The native4 helper permits a
K-valued normalization of c to norm4 with products -t at17 and -2
at f. Indeed, for a K-valued raw representative r, its squared norm
equals (r.alpha_f)^2; scaling by 2/|r.alpha_f| is over K. Thus t
belongs to K, and

    H^2=17t^2+34t+15.                                (5)

In every one of these four cases -t is a conjugate of t:

* Own3: t=sqrt(2).
* Own5: t=sqrt(2)phi; the two distinct quadratic fields permit
  flipping sqrt(2) while fixing phi.
* Own7: t=sqrt(2)s, s=2cos(pi/7). The field Q(s) has degree3,
  hence cannot contain sqrt(2). The same sign-flip on the compositum
  restricts to an embedding t -> -t of Q(t).
* Own8: t=sqrt(4+2sqrt(2)). The element 4+2sqrt(2) is not a square
  in Q(sqrt(2)), since its norm8 is not a rational square. The
  quadratic extension therefore has its sign-flip embedding.

All physical t here satisfy t>=sqrt(2). At the indicated nonphysical
embedding, (5) becomes

    17(t-1)^2-2 >= 49-34sqrt(2)>0,

where 49^2>2*34^2. This contradicts Schur positivity. It excludes
every remaining weak m4 case, without a global ground-field list.

## 4. Both fork contacts

The finite-white Gram on18,c,19 has no18--19 edge. Finite spherical
classification leaves exactly A3,B3,H3, with unordered contact pairs
(beta,eta)=(1/2,1/2),(1/2,sqrt(2)/2),(1/2,phi/2). A reducible
case would have one zero contact and was already treated.

For H3, even gamma=0 gives ratio sigma/sqrt(delta)=phi+1/2>2,
so (1) holds immediately. For B3, every positive gamma>=1/2 gives
ratio at least (3+sqrt(2))/2>2. Its only weak possibility is gamma=0.
Using the simple3 helper to normalize c to norm2, the products are
0 at17 and -1,-sqrt(2) at the two forks. Formula (3) gives

    H^2=(49+34sqrt(2))/4.

Its conjugate is positive, again impossible over the actual field.

Finally take A3. Here delta=1/2, sigma=gamma+1/2. If the own label
is at least5, or contact is parallel/dotted, the ratio is at least

    phi^2/sqrt(2) > (13/5)/(17/12)=156/85>73/40.

We used phi>8/5 and sqrt(2)<17/12. Thus a weak case has own0,3,4.
Own0 gives the actual all3 affine four-cycle c--18--17--19--c.
Own3 gives an actual all3 affine triangle c,17,18. Their null sums
are feasible regardless of additional nonpositive products outside
the selected principal. Both contradict compactness.

At own4, normalize c to norm2 through either simple3 fork helper.
Its products are -sqrt(2) at17 and -1 at each fork. Hence

    H^2=50+34sqrt(2),

whose conjugate is positive. This excludes the final weak case.

## Conclusion and remaining task

Every finite-white possibility under the stated no-left-contact
hypothesis has been covered, at the same loss21/40 and with the
same original x. Each surviving profile satisfies the strict floor (1).
No new prefix floor, independent energy optimizer, script enumeration,
or unstated strong endpoint is an input to the new steps.

The result leaves centre profiles contacting the left A16 component,
and leaves outgoing-fork profiles outside their independently proved
restrictions. In particular, the accepted arithmetic ceiling remains19;
this lemma alone proves neither impossibility of D19 nor ceiling18.
