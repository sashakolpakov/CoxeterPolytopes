# Compact arithmetic15: consolidation source ledger

24 October2026. **DRAFT pending complete mathematical/root and different-author review. No compilation or proof job has run.** This report binds the same-family revision, its complete declared local proof homes and their direct literal pin tables. Hash checks below establish source identity, not correctness, complete transitive proof coverage or a new acceptance.

Draft after the first proof-body translation batch:
`manuscripts/revisions/compact_arithmetic_dimension_bound_consolidated.tex`;
96362 bytes; SHA256
`027075ab908ade3b9552864211caebd09bd2b627c835ea7fe842e466d326fa4e`.

The original machine-readable source/edge snapshot,
`results/compact_arithmetic15_consolidation_dependency_snapshot_20261024.json`,
is preserved as metadata for the **pre-transcription version**, not a hash
binding of this larger draft. The original 48,961-byte TeX and 23,944-byte
ledger are preserved with verified byte round trips in
`results/source_archive/arithmetic15_consolidation_before_proof_body_translation_20261024/manifest.json`.
This batch's bindings and writing queue are in
`results/compact_arithmetic15_proof_body_translation_batch_20261024.json`.

## Mathematical revision boundary

The proposed final implication is general compact17 -> complete local exact17 arithmetic exclusion -> complete local exact16 frontier -> manual whole-D16 exclusion ->15. The old global arithmetic17/16 arguments in the mixed composition sources are not needed as numerical tails. The local field, component, classification and census interfaces remain explicit internal proof obligations. No old20 angle-rule/13-field chapter or parkedfield19 refinement enters as a global theorem. Section-level acyclicity was inspected in the six-paper consolidation map; full deeper mathematical auditing remains pending.

The draft translates the entire manual D16 dyadic proof, including
odd/even norms, inert/ramified/split two, full maximal-order strips, all
seventeen split heads and both geometric residues. It now also gives the
field/finite-head/endpoint proof of the quadratic dotted reduction, from
an explicit initial whole-D16 inventory. **That initial inventory still
requires its complete TeX proof.** The prepared D16 worker remains
unexecuted and unused; no inventory is made true by citing its source.

The rank17/rank16 covers retain all fourteen/nineteen original groups, ordinary/I/J/typed7 distinctions, every actual field and all component/spectator hypotheses. A source saying candidate or unexecuted retains its historical header; its later exact acceptance or actual runtime record determines current status. No actual runtime is inferred from a contract alone.

## Exact proof homes

|ID|Precise mathematical scope|Source and SHA256|
|---|---|---|
|G17|General compact17, final geometric composition, with its21 restricted direct inputs and prior GLOBAL18 tail; no arithmetic theorem imported.|`results/compact18_whole_d18_uniform_dotted_head_all_initial_references_and_global17_composition_candidate_20261024.md`<br>`08c3a04e84a323832fbeab9c3286aec0b7eb7e191e13dea9e5147d5713b304dd`|
|F17|Sections2--5: complete14-group actual rank17 cover, including all finite types and exact I/J/N7/O7 definitions.|`results/arithmetic_dimension17_complete_forest_frontier_candidate_20261021.md`<br>`9f086687231bb18781d48513cc4907913dd40a4f3b8714dc85886fc540ebde68`|
|E17|Sections1--3 and the local exact17 exclusion only. Its old G17 arithmetic GLOBAL tail is NOT used in this draft; replace that final input by general compact17.|`results/arithmetic17_whole_a17_complete_endpoint_census_and_global16_composition_20261022.md`<br>`2aac289e76e42b49949c918c35df0cbce6fb83e5e889bea7a0c1717165903dce`|
|AE|Complete actualA17 endpoint isolation, actual-field generators, strict strips and golden exception.|`results/arithmetic17_whole_a17_short_endpoints_isolation_and_golden_exclusion_candidate_20261022.md`<br>`b80c27b00dc7ecdbdf7201327d620e10b372e35f1047964c9ae204c2d6996558`|
|AD|Simultaneously paid actual endpoint graft giving actualdegree<=5.|`results/arithmetic17_whole_a17_joint_endpoint_graft_and_degree_five_reduction_candidate_20261022.md`<br>`0c79701afc8d21c31319d905da88eb769a620e8c357d5e93463643be9c0fcf69`|
|AF|Entire two-DOT interval and all remaining centralfeet; finite-anchor and actual four-field conclusion.|`results/arithmetic17_whole_a17_two_dotted_endpoints_exclusion_and_finite_field_reduction_candidate_20261022.md`<br>`36414798f5ffad2920c7f159e3ce79f89a9d22ae573d31fe3a6fde7e6058f658`|
|QA17|ContractSections1--4: fullquadratic-ring domain/algorithm/completeness. Lateractual25-field159-pair emptyoutput/exclusion. Contract's oldUNEXECUTED header is historical.|`results/arithmetic17_a17_two_isolated_quadratic_endpoints_exact_census_contract_20261022.md`<br>`ba2c8f72de389bea30b8a766e62b7ad11957f72a10c0c178183dd5820e69f220`<br>`results/arithmetic17_whole_a17_quadratic_empty_census_exclusion_composition_20261022.md`<br>`4602651666c3c2049109d287f4d0dc6c763b203f9aa88727db4aa23a91f70625`|
|CA17|Sections2--4 prove fullrings, coefficientboxes and fullK-square/sign algorithms; actualoutputs/replay are E17Section5 and runtime manifest.|`results/arithmetic17_a17_finite_cubic_endpoint_exact_census_contract_20261022.md`<br>`74b213461d250df03e601921744fa2831ea404d816e612562402dae3b8a0ec21`|
|QBD17|ContractSections1--5:36-field120-pair algebraicdomain. DIFFERENT actualB17/D17 inclusion proofs and shared two-survivor originalvector consumer. Combinechecks survivors/counters, not all rejectedpairs.|`results/arithmetic17_d17_one_isolated_quadratic_fork_exact_census_contract_20261022.md`<br>`991c97fab25b01a5d7aadc5a2bb220e469525647fac331cf74c02665af01df21`<br>`results/arithmetic17_whole_b17_fresh_long_head_short_cycle_and_coupled_exclusion_candidate_20261022.md`<br>`6dc0a7be8902fbe2b623c66d9590c9d85246248303da51dc2123d1dd7ebf7dd7`<br>`results/arithmetic17_whole_d17_complete_quadratic_census_and_coupled_energy_exclusion_candidate_20261022.md`<br>`33bae906e3ad178ef15b2b1f7e1dbe1fe4edd8271aa8d9bbe47f5f0c17eaacd4`|
|F16|Sections2--7: fresh complete19-group actualrank16 cover; no rank17decrement.|`results/arithmetic_dimension16_fresh_complete_necessary_forest_frontier_candidate_20261022.md`<br>`a8cc202cc364f438e733c5c2536185aa923bc56ee2d3edc9e245a3c8d7e20e3c`|
|A10I|Entireallfield actual-I-conditionedN11 theorem e_A10>404/625 with arbitraryspectators; group1consumer.|`results/arithmetic16_a10_actual_i_fresh_n11_all_field_helper_norm_and_group_one_exclusion_candidate_20261023.md`<br>`9c98e353080d64349aaffb998842fe70c0a534e42fae0dc76a572a53349ca9c7`|
|A10T|EntirefreshN11 theorem under EITHERACTUALtyped7, allfinite/foreign/cubic cases, e_A10>404/625; group2consumer.|`results/arithmetic16_a10_both_actual_typed_seven_fresh_n11_complete_window_and_group_two_exclusion_candidate_20261023.md`<br>`3a29d81b3ad531fdbf5680c55576ad4bef193726c4d2a40c942ac9a8e6cc3188`|
|A11|UniformactualA11 energy>13/20, allhelpers/feetonepaidreference, arbitraryspectators/allfields; group3consumer.|`results/arithmetic16_a11_paid_helper_and_all_isolated_feet_uniform_point65_candidate_20261022.md`<br>`2e69ab9ccdc2fee7700ca12f89574ca59f93caef6f033fff990e4951663a290e`|
|A11I|JointA11+ACTUALI>18/25 with allremainingfeet/bothactualpressures retained; group4consumer countsIonce.|`results/arithmetic16_a11_actual_i_single_endpoint_and_all_feet_joint_energy_group_four_exclusion_candidate_20261023.md`<br>`197173ae130615d68bd287efdbf8f181e709a2a9a4ca4c3765c70b2ddeb33da2`|
|A3|Entireuniversal A3>13/50 and original group5 consumer, correct sourceauthority.|`results/compact_universal_a3_point26_and_arithmetic16_o7_consumer_candidate_20261022.md`<br>`ca4760e31ee105f52d007210dd2222b305fb9f71c0debd8f42c3cfa97c756273`|
|A12|Corrected nearvariance successor: universalactual A12>5/7, allnative/foreign/continuous helpers/feet/endpoints; groups6/7 withjointIcountedonce.|`results/arithmetic16_universal_a12_five_sevenths_actual_helpers_and_endpoints_candidate_20261023.md`<br>`0ec682892c5f8c8463ae5794a2a05657533ddd1d7c2fea98942ad44b253e5285`|
|A12T|Bothactualtyped7 cases with e_A12>.71022505 and defect-conditionedordinaryT2>.2; group8.|`results/arithmetic16_a12_both_typed_seven_rank_two_adjusted_loss_exclusion_candidate_20261023.md`<br>`a35d9f561fad54a5cc21af8448c884ce9528d9b63de50cb2a2b27def4f72394a`|
|A13|THREE distinctgroup9 consumers: ordinary e_A13>53/70, actualO7 K7strip, actualI+ordinaryT2 jointendpoint theorem. Do not interchange scopes.|`results/arithmetic16_a13_fresh_n14_fifty_three_seventieths_and_ordinary_rank_three_exclusions_candidate_20261023.md`<br>`470cfe10b075783cbd58bbc013c7735ddeec5f37274757ece9fe466cdc593f67`<br>`results/arithmetic16_k7_a13_direct_integer_strip_and_old_seven_rank_one_exclusion_candidate_20261023.md`<br>`3f95fb67080c05a73cf9d9268b29c9d9ec6de8fcadee633e3f0db6b518ed6bbf`<br>`results/arithmetic16_a13_actual_i_ordinary_dihedral_endpoint_grafts_group_nine_exclusion_candidate_20261023.md`<br>`d07feb98c6224cd0fd5afa907e8ac10eda9345d66438a3c5ede80866dcbd1b32`|
|A14|UniversalA14>4/5 handlesordinary2A1 and withrankfreejointI+A1>.20204 alsoI+A1. Separatetyped7 and completeordinaryT2 arguments closegroup10. Theolder tiny-marginA14/I/A1 proof is not needed as an independentconsumer here.|`results/arithmetic16_a14_fresh_point597_all_feet_and_four_fifths_energy_candidate_20261023.md`<br>`00171c0d54af8f47d3f6e5bb03522e09b9cdd1694daa4b6ac7b4ebb6bfd8a029`<br>`results/arithmetic16_a14_both_actual_typed_seven_fresh_point55_and_endpoint_gap_exclusion_candidate_20261023.md`<br>`3ee79e423a68b69c540e7070392e85e12853c799a360f100ec364baa0b9254ba`<br>`results/arithmetic16_a14_ordinary_rank_two_small_energy_actual_triangle_and_two_field_reduction_candidate_20261023.md`<br>`8cf87b5485ad2d83d39d4bd74d84536e17f5dc68528114d63bdff9873113ac8c`<br>`results/arithmetic16_whole_a14_ordinary_rank_two_integral_endpoint_and_paid_feet_exclusion_candidate_20261023.md`<br>`13faeeaf0e6db026254c90fde3163650e9316cfd93e8353cbc9b4b8329eee1c8`|
|A15|Complete SAMEactualrankone nonisolated/isolated dichotomy; both mathematicalbranchproofs explicitly bound in itsSection1. Do not use prior-group counts as proofs.|`results/arithmetic16_whole_a15_rank_one_opposite_complete_composition_and_three_group_frontier_candidate_20261023.md`<br>`12efd478437c846f2b476237683afda3fe61da5eef4cf7455159b20d2b6055ea`|
|BD15|Section2's completeB15/D15 nonisolated/ordinary h>=1/2/actualI 0<h<1/2 split; its25 boundobjects give allconstituentproof/reviewhomes. No frontier-count subtraction substituted.|`results/arithmetic16_b15_d15_rank_one_complete_conjunction_and_single_d16_frontier_candidate_20261023.md`<br>`9a08676aff0939e52a58bdc4338728f611b35d6926c39bde9c982ec525f441a1`|
|A16|EntireactualN17 proof: allendpoints/fielddegrees/native30/fullrings/21signedtimenorms/unequal+diagonal cases; group12.|`results/arithmetic16_whole_a16_complete_endpoint_field_and_finite_anchor_exclusion_candidate_20261022.md`<br>`7ba7e0ddf6b4590593edc5e42d89f63b00a79921b624a12a7b1a3ea704aae962`|
|B14|CORRECTEDsuccessor with trueC^2=(3/2)(A^2+2/3), entiretypeddefect head/foreign/native cases; group13.|`results/arithmetic16_b14_typed_seven_actual_defect_wall_head_exclusion_candidate_20261022.md`<br>`237080ad5775d91e83b2fde217acd275ecf1f0949103a937fedbc6497e89b07c`|
|B16|Entireactual reduction+completecubic exclusion+actualquadraticoutput+solepair originalvector consumer; group15. ELEVEN directinputs retain exact oldscopes.|`results/arithmetic16_whole_b16_complete_quadratic_census_and_actual_edge_reference_exclusion_candidate_20261023.md`<br>`5328fa8e04606a209242c1dd9e254dc026f04586e3fa4fc030b22de1cff9243c`|
|QB16|Sections1--4:actualscale formulas,43field boundedfullring domain,completeK-square/cyclic/native tests,completepairreplay.|`results/arithmetic16_b16_isolated_quadratic_head_short_pair_exact_census_contract_20261023.md`<br>`9fb3fa877e82e82bc26a32c10fb37261e6f32cd43c73ef0c5f6fc446c846dc3c`|
|D13|EntirefreshD13shortlayers with purebody>.82436 and jointremainder>.21; group16.|`results/arithmetic16_d13_fresh_short_layers_and_rank_three_spectator_exclusion_candidate_20261022.md`<br>`6cd78a94fabd27d890901ee5e20a70ae462c190b8dec8f6a4bd5a7f57d1c0c19`|
|D14|CorrectedD14typed theorem and SEPARATE ordinarydihedral>3/19 theorem/actualD14consumer jointly closegroup17.|`results/arithmetic16_d14_typed_seven_fresh_centre_and_head_exclusion_candidate_20261022.md`<br>`7331b2bb27e0399785feba45a26b796faaa3a3db950dc0c6f0f6ae02ff8fa351`<br>`results/compact_ordinary_dihedral_three_nineteenths_and_arithmetic16_d14_consumer_candidate_20261022.md`<br>`cc2b38697f0b8afe48b8420ce632dfb8f29a86223bb6f5794fd857778b11fe3c`|
|RD16|Sections2--9 completeactualquadratic DOT-head/BOTHisolatedDOTfork reduction; Section10 conditional sqrt6 SINGLEprefix consumer. ItsM input is ONLY rankfree rationalanisotropy/Meyer, not arithmeticglobal17.|`results/arithmetic16_whole_d16_actual_quadratic_dotted_head_and_both_isolated_fork_reduction_candidate_20261023.md`<br>`fe9e03f34404be34e22972d3b6400a8864d5a3493d16d78e1142d6cc2fcd3f77`|
|MD16|Sections2--8 ENTIRE manualdyadic argument translated here. ItsoldG16/G16A final-global inputs are not needed by the new numerical route; actualC0/R/P/X localinterfaces retained.|`results/arithmetic16_whole_d16_quadratic_dyadic_splitting_complete_manual_exclusion_candidate_20261023.md`<br>`966165a3e381331e8d0ecc1ccc7e42a1b4e6670e51d138aa218a2c3465da5160`|

## Existing mathematical acceptance and full-review homes

These are preserved acceptance boundaries for the supplements, not a new acceptance of this consolidation. Each gate identifies the complete source and different-author review at its stated scope. The draft still requires its own full translation/composition review.

|ID|Existing acceptance or actual-runtime review|
|---|---|
|G17|`results/compact_dimension17_global_written_acceptance_20261024.json`<br>`53713abb711a56afd4566e9b04506974fea22f9f5ab2f2f799e66140ed192f76`|
|F17|`results/review_fresh_compact19_arithmetic17_frontiers_and_prime79_root_20261021.md`<br>`f3e2c122140aba5399bac31688fb12123a33b85b817b98b55bd69d2e561dab22`<br>`results/review_arithmetic17_whole_a17_global16_complete_composition_root_acceptance_20261022.md`<br>`dde2eee3d4ca12a7e1508f36cde6db9592749a4d2c111d0a2f0dddaa18c45ac9`|
|E17|`results/review_arithmetic17_whole_a17_global16_complete_composition_root_acceptance_20261022.md`<br>`dde2eee3d4ca12a7e1508f36cde6db9592749a4d2c111d0a2f0dddaa18c45ac9`|
|AE|`results/review_arithmetic17_whole_a17_endpoint_reduction_root_acceptance_20261022.md`<br>`8ecfde6c66b76346dfe4deba62d4b6738cb18d049152399fd509c928b2e95880`|
|AD|`results/review_arithmetic17_whole_a17_degree_five_root_acceptance_20261022.md`<br>`c2975ee3bcd0df96e712dbf18a4b42691c649fe0dcf1121407aca049f7ccaf2a`|
|AF|`results/review_arithmetic17_whole_a17_four_actual_fields_root_acceptance_20261022.md`<br>`b1df13d1d3b8ba3604832aef49cda0e095b62c12b84f4897267e1f7b75372582`|
|QA17|`results/review_arithmetic17_whole_a17_quadratic_exclusion_root_acceptance_20261022.md`<br>`8acac2f97211d5f114872714a0f7f5c4be2864310d061e17d27cfeec01b12cd9`|
|CA17|`results/review_arithmetic17_whole_a17_global16_complete_composition_root_acceptance_20261022.md`<br>`dde2eee3d4ca12a7e1508f36cde6db9592749a4d2c111d0a2f0dddaa18c45ac9`<br>`results/review_a17_finite_cubic_endpoint_actual_runtime_and_conditional_exclusion_foundations_20261022.md`<br>`6e280be1af1b3f298bb11fff9541103698e2e6166222757e90d4e1295fefafa2`|
|QBD17|`results/review_arithmetic17_whole_b17_complete_exclusion_root_acceptance_20261022.md`<br>`65a5dd47de954ee8f224d41aaba5dfc5cd2abaf106c1602d4924fb7be69f5cbf`<br>`results/review_arithmetic17_whole_d17_complete_exclusion_root_acceptance_20261022.md`<br>`f338ef753c2160490eef6d7e61040711236a01a9311e31aa0aa29715fd34e0e2`|
|F16|`results/review_arithmetic16_fresh_frontier_and_a14_actual_i_rank_one_root_acceptance_20261022.md`<br>`7b7966099f579b505dfd928b1137c45cfb649f11aff6597419e8c595c613572b`|
|A10I|`results/review_arithmetic16_a10_actual_i_n11_root_acceptance_and_five_group_frontier_20261023.md`<br>`5a6638171f88bb76d1e8bf27fb540c700324da6abe7a23c65f175b5220b6b670`|
|A10T|`results/review_arithmetic16_a10_both_actual_typed_seven_n11_root_acceptance_and_six_group_frontier_20261023.md`<br>`7ab763ce151b8d04f4ea269208d74bc827af67793f8f24a643726d5178f7f0d6`|
|A11|`results/review_arithmetic16_uniform_a11_point65_root_acceptance_20261022.md`<br>`1f0aa0f85f889937a5092fe26ac998ccfc9d52ab90792c5afe6338b3e0c78743`|
|A11I|`results/review_arithmetic16_a11_actual_i_single_endpoint_all_feet_root_acceptance_and_four_group_frontier_20261023.md`<br>`7603378bd080bb977fa4fa0a0da4837209780a85c9643eb54845d89602f9a825`|
|A3|`results/review_arithmetic16_whole_a16_and_universal_a3_root_acceptance_20261022.md`<br>`469907748bb203995c343f4e21355ba6dc25faf9a110fa044a65373e2009f6c5`|
|A12|`results/review_arithmetic16_universal_a12_five_sevenths_root_acceptance_and_ten_group_frontier_20261023.md`<br>`188706124ea6622a1fe8449878742fbac4f1c57c6f2b750e17b7c132458a0015`|
|A12T|`results/review_arithmetic16_a12_both_typed_seven_root_acceptance_and_twelve_group_frontier_20261023.md`<br>`209a01e628115b2e6b6368d1a2bb5d3c64082450609a8f4eda1997d54250184a`|
|A13|`results/review_arithmetic16_a13_fifty_three_seventieths_and_two_ordinary_alternatives_root_acceptance_20261023.md`<br>`d0ef11979e9123475ec23fa2c5e30852fd857efb6b487ca9030ee7cdabebef5f`<br>`results/review_arithmetic16_k7_a13_integer_strip_and_three_a13_alternatives_root_acceptance_20261023.md`<br>`c8f27e7be71321eb422ba658e0b735283de3d23e88b7a1e8e02c6d0db5c7f902`<br>`results/review_arithmetic16_a13_actual_i_ordinary_dihedral_group_nine_root_acceptance_20261023.md`<br>`f3da9c7a92a86d24a06a26bdf820be4396b49ffd70a7c52bb4f64210bee61113`|
|A14|`results/review_arithmetic16_a14_point597_four_fifths_root_acceptance_20261023.md`<br>`3c590c99d94c757a20e2aa70da164e3057ec806f4b317eeb571b95e7bb290958`<br>`results/review_arithmetic16_a14_both_actual_typed_seven_root_acceptance_20261023.md`<br>`423273bf993d5d37833a0c2461c244bc1a96973f121efc9f624e462ad6357cab`<br>`results/review_arithmetic16_whole_a14_ordinary_rank_two_root_acceptance_and_seven_group_frontier_20261023.md`<br>`3d8d2959dac4b31a7d0bcb97e8244e5512d9f5454cb1800f4209802e63dc5448`|
|A15|`results/review_arithmetic16_whole_a15_complete_opposite_composition_root_acceptance_and_three_group_frontier_20261023.md`<br>`e949b3201cd4899f6d8b830ed6416591735283d91332093599719988f74ecca2`|
|BD15|`results/review_arithmetic16_b15_d15_complete_conjunction_and_single_d16_frontier_root_acceptance_20261023.md`<br>`fd664c8e7c127ab1b5cd63e84bedd86b9c6763a092ac871cf2009057fd2d8af1`|
|A16|`results/review_arithmetic16_whole_a16_and_universal_a3_root_acceptance_20261022.md`<br>`469907748bb203995c343f4e21355ba6dc25faf9a110fa044a65373e2009f6c5`|
|B14|`results/review_arithmetic16_b14_typed_seven_corrected_root_acceptance_20261022.md`<br>`ed81f16c12db09c87de8dc779138aa2178e82d5f086aba5dfbe6ada47e0cd192`|
|B16|`results/review_arithmetic16_whole_b16_complete_census_and_reference_root_acceptance_20261023.md`<br>`fcb3ae95f196e654a67f5eedbed30368afbcacd2f8bffe6f6fc0354b2d71a0fe`|
|QB16|`results/review_arithmetic16_whole_b16_complete_census_and_reference_root_acceptance_20261023.md`<br>`fcb3ae95f196e654a67f5eedbed30368afbcacd2f8bffe6f6fc0354b2d71a0fe`|
|D13|`results/review_arithmetic16_whole_d13_root_acceptance_and_remaining_frontier_20261022.md`<br>`7d9e43fc822082b4e7da05ed5976e3be464f81a70fa0b1d497ea995cdc3796bd`|
|D14|`results/review_arithmetic16_whole_d14_root_acceptance_and_thirteen_group_frontier_20261022.md`<br>`5931aa492bf7561f3b276f4ec3e675cbabd473ba1e151ef7c6aaff074b2e5cef`<br>`results/review_compact_ordinary_dihedral_three_nineteenths_root_acceptance_20261022.md`<br>`e5e01fd66abe8e0fee881a838543c233a9c0003194574da01736af0a0f0fee66`|
|RD16|`results/review_arithmetic16_whole_d16_actual_quadratic_dotted_head_both_isolated_forks_root_acceptance_20261023.md`<br>`101e52e00ae132ca0b414913a83fb79fb16a1c7932df930aa4e55fc726737a02`|
|MD16|`results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md`<br>`387b135ba766438a0f46eaeee421205649da3718eedafe355072a7c831f3d22e`|

## Retained computed propositions and execution boundaries

|Proposition|Algorithm domain and output|Actual execution home|
|---|---|---|
|QA17|25quadraticfields,53models,159orderedpairs;106field-square/52longcycle/1twocycle failures;ZERO survivors. Complete same-code pairreplay.|`results/a17_two_isolated_quadratic_endpoints_runtime_manifest_20261022.json`|
|CA17|1197+1235fullring coefficienttrials;9stripmodels;7field-square/2longcycle failures;ZERO survivors. Completeallrecord same-code pairreplay.|`results/a17_finite_cubic_endpoint_runtime_manifest_20261022.json`|
|QBD17|36quadraticfields,120pairs,118field-square failures,TWO survivors. Combined record rechecksallfields/counters/survivors but doesNOTrerun rejectedpairtests. DistinctactualB17/D17 inclusions and one-reference geometric consumers remain essential.|`results/d17_one_isolated_quadratic_fork_runtime_manifest_20261022.json`|
|QB16|43quadraticfields,100U/85Vmodels,273pairs,168half-product/104field-square failures,ONE survivor. Fullsame-code pairreplay, thenactualedge/reference contradiction.|`results/b16_isolated_quadratic_pair_census_verification_20261023.json`|

These are inherited actual records, not newly executed outputs or independently regenerated algorithms. Their exact sources, contracts, results, authentic batch receipts and different-author code/runtime reviews remain in each bound project packet. The draft states full finite domains, maximal-order/field-square decisions, halting and inclusion arguments. Every nonempty output has a separate written geometric exclusion.

## Audit and consolidation decisions

- Freshly audit all supplement mathematical statements at their declared scopes before promoting this revision. The source table is not a substitute for the proofs. **This is an incomplete manuscript draft.** The first writing batch below supplies several missing proof bodies; all remaining internal arithmetic proofs must be translated before the manuscript is described as complete.
- Check the general17 companion proof closure is independent of arithmetic17/15. Mixed-source generalSections2--3 and local rank-free interfaces are explicitly separated in `docs/six_manuscript_audit_and_consolidation_20261024.md`.
- Review every fourteen/nineteen-group consumer against its complete original alternatives, particularly actual I versus ordinary A1, both typed-seven cases, group9 A13 subcases and group10 A14 ordinary T2.
- Audit the small consolidation simplification e_A14>4/5 plus jointI+A1>.20204, with the I energy counted once. The older A14/I/A1 small-margin proof remains preserved but is no longer needed as a separate consumer.
- Review the new transparent cubic trace bound: finite anchor U<4,V<10, physical root<415, both other roots<20 =>absolute integral trace<455. It restates the retained algorithm bound; no runtime claim.
- Check external arithmetic model, exact cyclic criterion, anisotropy/Meyer and finite/affine classifications against primary sources. ABSW Lemma5.2 was directly read in the author preprint at the URL below.
- Verify all direct table pins and scoped proof edges in the snapshot. They match current bytes. No full transitive mathematical regeneration or recursive execution is claimed.
- The draft has not been compiled. Root must do any substantive source/static review, then its bounded serial TeX build when admitted; preserve canonical pairs and original receipts.
- Selected successful Lean modules are unchanged and must not be rerun just to rebind this draft. Prepared general17 modules and any new15 composition need their own admitted compilation and separate actual axiom audit; geometric/number-field/script inputs stay explicit.

Primary model source: [Agol–Belolipetsky–Storm–Whyte, author preprint, Lemma5.2](https://homepages.math.uic.edu/~kwhyte/ahfinite.pdf), with [official publication](https://doi.org/10.4171/GGD/47). The lemma supplies the quadratic-form reflection model; it is not a dimension or field-list theorem.

## Current verification state

The original source-index preparation had 29 proof-home groups, 197
distinct authenticated direct source/evidence objects and 352 literal
table edges. Those are historical metadata counts, not a new audit of
this expanded translation. The proof-body author changed only this
revision and ledger and added the small source-preservation/batch metadata.
No scientific worker/import, test, enumeration, optimizer, Lean, TeX or
Sphinx job ran. No global bound, successful module, canonical manuscript
or final PDF was changed by this author.

## First proof-body translation batch

This translation is authored by the agent who previously independently
reviewed the shorter draft. That earlier review is **not independent
review of these new TeX bodies**. Another author and root must review the
new final bytes; no mathematical acceptance is asserted by this ledger.

| Technique / proof body | TeX home | Exact translated input |
|---|---|---|
| Joint I costs, including the rank-free I+A1 bound counted once | `lem:Ijoint` | `arithmetic_dimension19_forest_frontier_and_actual_terminal_exclusions_20261021.md`, Section 2, SHA `c5992464c6d81f38c22b75b8259518f52c69806105e7e364acc325c1147f2211`; `arithmetic_dimension18_fresh_forest_frontier_20261021.md`, Section 2, SHA `8c957454d08ef04e01fffbeaa80508f44225a0ca213d9d2456332420815966d5`; `arithmetic17_a15_isolated_i_and_rank_one_exclusion_20261021.md`, Section 2, SHA `6d51ae85540828b84f38a9d543752b43dbbb9f54d8930920f9c960b40dff0b0d` |
| Arithmetic far/fork helper conjugate seals and mixed B2 tail | `lem:literal-helper`, `lem:B2seal` | `arithmetic_uniform_classical_weak_helper_obstruction_20261021.md`, Sections 1--2, SHA `535ac0d0fa92d28ccab2976fa147a4ccff0bd3bfcd1e04ca4e134c6ae6857905`; `arithmetic_classical_short_tail_composition_20261021.md`, Section 2, SHA `1a2c62ad1e6d676d7cc7bca0cf95d1f9446543619193163541f239e6734f331c` |
| Complete rank17 and fresh rank16 partition proofs, including actual-rank D11, D14/D15 local tail payments | proofs of `prop:f17`, `prop:f16` | F17 and F16, whose literal hashes are given above; ordinary geometric inputs and baseline arithmetic component estimates remain explicit premises requiring their full proof homes |
| Quadratic exact floor formulas; explicit B16 acuteness/zero/conjugate/native predicates | `sec:algorithms`, `prop:pair-output` | QA17, QBD17, QB16 contracts above |
| Cubic full integer orders, all coefficient boxes, native alphabet, complete square/trace/sign decision | cubic subsection of `sec:algorithms` | CA17 contract, Sections 2--4, literal hash above; all root brackets, denominator/term bounds and negative coefficients appear in TeX |
| Universal A3 energy greater than 13/50, all contact/foreign cases | `lem:A3point26` | A3 source above, Sections 1--4; companion actual-opposite and shadow lemmas remain named geometric inputs |
| Uniform dotted scalar greater than .295 and full ten-trace cubic norm-eight lemma | `lem:terminal-scalars` | `classical_dotted_head_scalar_295_and_cubic_norm_eight_pressure_candidate_20261023.md`, SHA `1c28409b9e14f51cc150eed1cf9e6a3bd43c9392d92f63f9a8d653140fcde307` |
| Actual endpoint cycles/degree; every cubic endpoint; finite heads; cubic isolated pair; full quadratic endpoint exclusion; quarter products | proof of `prop:d16reduce` from `lem:D16initial` | RD16, Sections 2--9, literal hash above; uses the initial inventory explicitly, not as a published fact |
| Entire manual D16 dyadic dispatch | `sec:odd-inert`, `sec:ramified`, `sec:split` | MD16, Sections 2--8, as in the first version |

One harmless shortening is new in this translation: after proving the
sharper physical head bound U<98/9, integrality of U/4 in degree d>=3
already gives `0 < N(U/4) < (49/18)(1/2)^(d-1) <= 49/72 < 1`.
This replaces RD16's longer cubic U/4 trace contradiction, which used an
older weaker head bound. It changes no theorem or finite domain, and
requires review as part of the new translation.

## Remaining proof queue and legitimate companion use

The general17 theorem may remain a clearly stated result of the general
compact companion, with its independent higher tail. Universal ordinary
component rates, actual-point/reciprocal-shadow lemmas, and the geometric
prefix/finite-white inventories can also be companion references **only
when that companion contains their complete named proofs at these exact
rank and spectator scopes**. Its current unfinished appendices do not
make those inputs published or already transcribed.

The following arithmetic-specific bodies still belong in this manuscript:

1. Baseline and improved A-component packing/endpoint proofs, with all
   finite-white, native, foreign, golden-helper and simultaneous-foot
   cases. This includes the estimates used by the cover proofs, and
   A10I/A10T/A11/A11I/A12/A12T/A13/A14 and their remaining consumers.
2. E17's complete rowwise exclusions, including AE/AD/AF's whole-A17
   endpoint isolation, degree and finite-anchor steps; the displayed
   simultaneous scalar budget is only one part of those proofs.
3. A15/BD15/A16/B14/B16/D13/D14 actual row reductions, full degree and
   isolated/nonisolated dispatches, and the separate actual B17/D17
   inclusions in the shared QBD17 domain. The finite output statements
   and final scalar consumers do not supply those inclusions.
4. `lem:D16initial`: full head isolation, strong-five and late spine
   inventories; endpoint-four/next-to-end-three and finite-fork cases;
   native-five-head exclusion; conditional both-isolated degree seal.
   Its exact source is
   `arithmetic16_whole_d16_fresh_final_spine_window_and_endpoint_fork_reduction_candidate_20261023.md`,
   SHA `6ac9b4803f9b47a557630bba28325058495dd01e2f87ea5a8215c0760ef2c5e5`,
   with its preceding actual head/domain sources retained.
5. The typed O7 propagation theorem and every arithmetic-specific
   normalization/input that cannot be supplied by a nonarithmetic
   companion lemma. Both actual typed meanings must remain separate.

The paper itself now states this remaining queue. No exact15-toward14
campaign, parked field refinement, new worker or new paper was added.
The next writing batch should consolidate common chain-packing arguments
and actual terminal inventories by technique rather than append one
section for each historical increment.
