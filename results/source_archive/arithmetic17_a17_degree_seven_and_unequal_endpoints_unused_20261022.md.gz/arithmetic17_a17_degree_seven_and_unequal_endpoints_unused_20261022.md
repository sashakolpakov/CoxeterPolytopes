# Whole A17: degree at most seven and unequal isolated endpoint parameters

22 October2026. Complete short MANUAL proof candidate by root, pending
full other-author review and root acceptance. No worker, enumeration,
symbolic process, test, Lean or compiler ran. This note is supporting
research for the existing compact arithmetic paper, not a new manuscript.

## Literal inputs and conditional scope

The accepted endpoint reduction is
`arithmetic17_whole_a17_short_endpoints_isolation_and_golden_exclusion_candidate_20261022.md`,
SHA256 `b80c27b00dc7ecdbdf7201327d620e10b372e35f1047964c9ae204c2d6996558`.
Its outside review and root acceptance are recorded separately. The actual
root/cyclic-integrality input is
`arithmetic_uniform_classical_weak_helper_obstruction_20261021.md`,
SHA256 `535ac0d0fa92d28ccab2976fa147a4ccff0bd3bfcd1e04ca4e134c6ae6857905`.

At an actual whole-A17 farthest vertex, both endpoint opposites are
isolated. Each parameter U is integral, generates the ACTUAL totally real
field K, and satisfies

    36/17<U<3969/425, every other0<U_sigma<36/17.       (1)

The actual raw endpoint root has square2U, sole old product-U and
positive time coefficient with square U(17U-36)/18. The old inverse
raw A17 Gram entry between endpoints is1/18. Only invariant Cartan
cycles are integral; individual root products are not assumed integral.

**Proposition.** Under these inputs, [K:Q]<=7. If [K:Q]>=2, the two
actual endpoint parameters are UNEQUAL. This does not exclude degrees
3..7 or a whole-A17 configuration. No lower global ceiling follows.

## 1. A direct degree bound

Let f(X)=X(X-1)(X-2). At the physical embedding U>36/17>2, so
f(U)>0. Since f is increasing on(2,infinity), (1) gives f(U)<572.
For an entirely rational verification of the latter strict bound,

    3969*3544*3119=43,872,278,184
       <43,909,937,500=572*425^3.

At a different embedding put t=U_sigma-1. Then -1<t<19/17 and
f(U_sigma)=t^3-t. For -1<=t<=1 its absolute value is at most
2/(3sqrt3): differentiation gives the only internal extrema at
t=+/-1/sqrt3. On1<=t<19/17, the function increases, with upper
bound1368/4913<1/3. Since sqrt3>5/3, both estimates give

    |f(U_sigma)|<2/5.                                (2)

None of these algebraic values is zero: U generates K and is not a
rational0,1 or2, so no embedding of it can equal those values. Hence
N_K/Q(f(U)) is a NONZERO integer. For d=[K:Q]>=8, (1)--(2) imply

    0<|N(f(U))|<572*(2/5)^(d-1)
                  <=572*(2/5)^7=73216/78125<1,

which is impossible. Thus d<=7, without a prescribed field list or any
enumeration of minimal polynomials.

## 2. Equal endpoint parameters contradict integral closedness

Suppose now d>=2 and both endpoint parameters equal the SAME element
U of the ACTUAL K at the physical embedding. Because embeddings are
injective this is algebraic equality, not equality of unrelated root
lengths. Their raw norms are2U and their positive time coefficients
have equal squares U(17U-36)/18, hence are equal. The raw spatial
product is U^2/18. Their mutual product therefore is

    g=U^2/18-U(17U-36)/18=2U(9-4U)/9.

The two actual walls are distinct: they have different sole old
contacts. Their invariant TWO-cycle must be integral:

    L=4g^2/[(2U)(2U)]=4(9-4U)^2/81 in O_K.

Set y=2(9-4U)/9. Since y^2=L is integral, y is integral over O_K
and therefore belongs to O_K by integral closedness. Thus8U/9=2-y
is integral. Bezout8*8-7*9=1 gives

    U/9=8*(8U/9)-7U in O_K.

All its conjugates are positive, so its norm is a positive integer.
But (1) gives physical U/9<3969/3825 and every other conjugate
U_sigma/9<4/17. Consequently

    0<N(U/9)<(3969/3825)*(4/17)^(d-1)
               <=15876/65025<1,

again impossible. This excludes equal parameters in EVERY irrational
actual field, with no assumption on the finite/dotted own types and
no norm-squareclass sufficiency assertion. It does not identify or
exclude unequal endpoint pairs.

## Remaining obligations

The source-bound outside review and root acceptance of this NEW note
are pending. Its degree bound is an elementary necessary reduction,
not a full field classification or census. The earlier accepted golden
exclusion remains separate. A complete quadratic ordered-pair census
has been prepared elsewhere; no result of that UNEXECUTED worker is
used here. Degrees3..7 and all possible unequal endpoint pairs require
further actual arithmetic/geometric analysis. Sources, six frozen
paper editions, global bounds and prior runtime/Lean receipts are
unchanged.
