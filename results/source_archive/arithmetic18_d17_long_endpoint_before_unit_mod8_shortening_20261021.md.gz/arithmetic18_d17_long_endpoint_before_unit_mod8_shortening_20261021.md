# D17+I: exclusion of a simple3 opposite at the long endpoint

21 October2026. **Complete manual supporting candidate, pending full outside-author review.** Root derived and wrote this argument. No scientific, symbolic, enumeration, mathematical-worker import, Lean or TeX job was used. No field classification or new manuscript is assumed. Earlier shared foundations are identified below; a review of this source must check the new degree reduction and all of the quadratic and I-contact cases, not just the final table.

**Theorem.** At an actual farthest vertex of a compact arithmetic first-type Coxeter18-polytope with whole finite forest D17+I, the actual opposite on either outgoing fork cannot have a single retained simple3 helper at the long endpoint1. Every own0, finite, parallel and dotted own parameter, and every permitted contact with I, is included.

Together with the pinned fork reduction, this leaves two possible roles for either opposite: isolated within D17, or simple3 at the other fork. Neither role is excluded here. In particular this is not exclusion of the whole D17+I family or arithmetic dimension18, and it does not change a printed paper or dimension ceiling.

## 1. Declared inputs and actual geometry

The paths in the following table are relative to the repository root.

| Input | SHA-256 | Exact interface used |
|---|---|---|
| results/arithmetic18_d17_isolated_i_prefix_and_fork_reduction_20261021.md |694dc7c07462daf1b86ee3758c85f5946a7694539fd30b94c3076a3045ce4bff|The noncircular necessary bound C<=47/5 for BOTH actual fork edges, its D17 coordinates and complete finite-white list; no conclusion about the present role|
| results/arithmetic_uniform_classical_weak_helper_obstruction_20261021.md |535ac0d0fa92d28ccab2976fa147a4ccff0bd3bfcd1e04ca4e134c6ae6857905|Actual K-valued root normalization, actual cyclic integrality and strictly positive nonphysical forms|
| results/compact_classical_rank21_isolated_i_actual_terminal_obstruction_candidate_20261021.md |8183924e37e5153a13a141daa6b7b2af44e3998b4008695ba3b1a0eef1d29bf2|Only Section1's rank-independent actual isolated-I wall and 0<h<1/2; not a rank21 exclusion|
| manuscripts/compact_arithmetic_dimension_bound.tex |5d5235dab7a1842e2fa3a9b0559220957a775608bb61e3097f5fbb17aec8caba|The named Meyer obstruction to compact rational first-type forms in dimension18, and the stated first-type criterion|

Compact acute simplicity, finite spherical classification, elementary algebraic-number norms/traces and the usual quadratic integer bases are the other external foundations. The argument supplies its own complete finite lists.

Use p^2=-1, orthonormal spatial vectors e1,...,e17 and e for the old I, and P_i=e1+...+e_i. The old unit D normals are

    n_i=(e_i-e_(i+1))/sqrt2 (1<=i<=16),
    n17=(e16+e17)/sqrt2,
    omega1=sqrt2*P1, omega17=(P16+e17)/sqrt2.

Release fork17. Its proposed opposite with the specified helper is necessarily

    c=A*p-gamma*omega17-omega1/2-beta*e,
    t=2gamma,
    A^2=(17t^2+4t-4)/8+beta^2, A>0.                 (1)

The retained A16+c is A17 with c an endpoint. A finite I extension there can only append a3 or a4 bond (A18 or B18). Therefore the COMPLETE possibilities are beta=0,1/2,1/sqrt2. The own parameter gamma is0, cos(pi/m), m>=3,1, or>1. At own0, (1) gives A^2=-1/2+beta^2<=0, impossible. Hence t>=1.

The actual fork-edge projection has

    b=(17t+2)/(2sqrt34),
    delta=b^2-A^2=9/17-beta^2,
    C=b/sqrt(delta)<=47/5.                          (2)

This is the ACTUAL endpoint and the already proved NECESSARY bound from694d, not a second energy gain or an isolated-cap parameter estimate. At beta=1/sqrt2, (2) gives C=(17t+2)/2>=19/2>47/5, excluding that contact immediately. For both remaining contacts, the largest residual is beta0; using sqrt2<17/12 gives

    17t+2<=282sqrt2/5,
    1<=t<779/170<55/12<23/5.                        (3)

The fork symmetry changes e17 to -e17 and preserves every formula and earlier edge estimate, so it suffices to treat this fork.

## 2. Integral parameter, actual field and all conjugates

Normalize the old connected D roots OVER the actual field K to square2. The actual helper3 permits the same square2 normalization of c, with helper product-1 and own product-t. The cycle through c, the long old path and the released fork makes t an algebraic integer. The own two-cycle is only t^2; it gives NO extra condition t^2/2. In particular the stronger B17 short-root integrality is not used.

The raw old D17+c principal has Schur complement

    -(17t^2+4t-4)/4<0                            (t>=1).

It is Lorentzian, even without the I coordinate. Its entries all lie in Q(t). If K properly extended Q(t), a nonidentity embedding of K fixing t would preserve this Lorentzian principal in a strictly positive definite nonphysical form, a contradiction. Thus ACTUAL K=Q(t). At every nonidentity embedding its Schur complement must be strictly positive, giving

    (-2-6sqrt2)/17<t_sigma<(-2+6sqrt2)/17,
    |t_sigma|<5/8,
    t_sigma>0 implies t_sigma<2/5.                   (4)

These concern EVERY other embedding of the actual field. Nonzero conjugates cannot vanish because t is nonzero. The following degree argument uses no field list.

## 3. Degrees four and higher are impossible

Put d=[K:Q]. For d>=5, the nonzero integral norm satisfies

    |Norm(t)|<(23/5)*(5/8)^(d-1)<= (23/5)*(5/8)^4<1,

impossible. Suppose d4. If any other conjugate is positive, its sharper bound in(4) gives

    |Norm(t)|<(23/5)*(2/5)*(5/8)^2=23/32<1.

All three other conjugates must therefore be -r_i, with0<r_i<5/8. The norm is negative and has absolute value<575/512<2, so Norm(t)=-1 and t*r1*r2*r3=1. Thus t>512/125 and

    Tr(t)>512/125-15/8=2221/1000>2.

On the other hand AM-GM and t<23/5<(5/3)^3 imply

    r1+r2+r3>=3/t^(1/3)>9/5,
    Tr(t)<23/5-9/5=14/5<3.

No integer trace lies between2 and3. Consequently d<=3.

## 4. Complete cubic exclusion

For d3, |Norm(t)|<(23/5)*(5/8)^2=115/64<2, so the norm is1 or-1. Two positive other conjugates would instead give |Norm(t)|<(23/5)*(2/5)^2<1. There are exactly two remaining sign cases.

First suppose the conjugates are t,u,-r, with0<u<2/5 and0<r<5/8. Then Norm(t)=-1, tur=1 and t>4. Its integer trace T=t+u-r lies strictly between27/8 and5, so T4. Writing E2 for the second elementary symmetric coefficient gives

    E2=t(4-t)-1/t,
    -421/144<E2<0.

For the lower bound use4<t<55/12, so t(4-t)>-385/144 and -1/t>-1/4. Hence E2=-1 or-2, and the minimal polynomial is X^3-4X^2+E2*X+1. If E2=-1 this polynomial decreases on[0,2/5] and has value3/125>0 at2/5, so it has no permitted positive conjugate. If E2=-2 it is concave on[-5/8,0] and positive at both endpoints, with values227/512 and1. It therefore has no permitted negative conjugate. Both alternatives fail.

Now suppose the conjugates are t,-r,-s, with0<r,s<5/8. Then Norm(t)=1, trs=1 and t>64/25. The trace T=t-r-s is an integer>131/100. Since r+s>=2/sqrt(t)>4/5, it is also<19/5. Thus T2 or3.

At T2, r+s=t-2<5/4 forces t<13/4. The decreasing function

    E2=-t(t-2)+1/t

lies between-781/208 and-41719/40000. Thus E2=-3 or-2. The respective cubics X^3-2X^2-3X-1 and X^3-2X^2-2X-1 have discriminants-23 and-83, inconsistent with three real conjugates.

At T3, the strict AM-GM inequality r+s>2/sqrt(t) (the conjugates are distinct) gives t>4; the upper bound r+s<5/4 gives t<17/4. Therefore

    -1381/272<E2=-t(t-3)+1/t<-15/4,

so E2=-5 or-4. At E2=-5 the polynomial factors as (X+1)(X^2-4X-1), contradicting cubic minimality. At E2=-4 the polynomial is X^3-3X^2-4X-1; its values at-1 and-5/8 are-1 and43/512. It has a root in(-1,-5/8), outside(4). This exhausts and excludes degree3.

Degree1 means ACTUAL K=Q by Section2 and is excluded by the compact rational first-type Meyer obstruction in19 variables. Thus K is quadratic.

## 5. Complete quadratic reduction

Write N=Norm(t) and T=Tr(t). From(3)–(4), N is a nonzero integer with |N|<23/8<3. If N>0, the positive-conjugate bound makes N<46/25<2, so N1. Then t>5/2, 29/10<T<5 and T3 or4. If N=-1, t>8/5 and39/40<T<5, so T1,2,3 or4. If N=-2, t>16/5 and103/40<T<5, so T3 or4. These are all eight candidate polynomials X^2-TX+N.

Two violate the strict Schur strip(4). For N1,T3, t=phi^2 and its other conjugate has

    17(t')^2+4t'-4=89-55phi>0.

For N-1,T1, t=phi and the corresponding value is34-21phi>0. Here phi=(1+sqrt5)/2; the elementary tests phi<89/55 and phi<34/21 follow because q^2-q-1 is respectively1/3025 and1/441 at those positive rational q. There remain EXACTLY the six rows below. Define theta13=(1+sqrt13)/2 and theta17=(1+sqrt17)/2.

| N | T | t | K and integer basis | 8A0^2=17t^2+4t-4, with beta0 |
|---:|---:|---|---|---|
|1|4|2+sqrt3|Q(sqrt3), 1,sqrt3|123+72sqrt3|
|-1|2|1+sqrt2|Q(sqrt2), 1,sqrt2|51+38sqrt2|
|-1|3|1+theta13|Q(sqrt13), 1,theta13|68+55theta13|
|-1|4|1+2phi|Q(sqrt5), 1,phi|85+144phi|
|-2|3|1+theta17|Q(sqrt17), 1,theta17|85+55theta17|
|-2|4|2+sqrt6|Q(sqrt6), 1,sqrt6|174+72sqrt6|

The identities theta13^2=theta13+3, theta17^2=theta17+4 and phi^2=phi+1 suffice to check every entry. The earlier degree argument and trace/norm bounds prove completeness; this is not a field census assumed correct.

## 6. Positive I contact

The beta4 contact was excluded before any field reduction. At beta=1/2, equation(2) reads C=(17t+2)/sqrt38. Every row except t=1+sqrt2 has t>33/10 (in particular sqrt13>18/5). Since sqrt38<37/6, those five rows give C>1743/185>47/5. Only t=1+sqrt2 remains, with K=Q(sqrt2) and

    A^2=(53+38sqrt2)/8,
    Norm_K(4A^2)=-79/4.                              (5)

Here we need an actual-field square condition, rather than an unjustified norm of A. The helper3 ties c to the old D roots with raw square2. Its I contact3 also normalizes the OLD I root over K to square2. For the actual I opposite c_I=sqrt(h)p-sqrt(1+h)e, put J=4(1+h). Its own two-cycle and positive nonphysical two-root Gram give

    J in O_K, 4<J<6, 0<J'<4.                         (6)

One can rescale c_I OVER K to have raw square2J and product-J with the old I root: for an original raw root of square d and own product g, J=2g^2/d and rescaling by -J/g has exactly these properties. The time-component squares of these raw c and c_I are respectively2A^2 and J(J-4)/2. Their projections to the orthogonal complement of all18 old roots belong to the SAME one-dimensional K-line. Their ratio is therefore a K-square:

    4A^2/[J(J-4)] in (K^*)^2.                       (7)

No square root of A^2, J or h has been adjoined to K by this argument.

In Z[sqrt2], the COMPLETE strip(6) list is J=3+sqrt2,3+2sqrt2,4+sqrt2. Indeed J=m+n sqrt2 has n>0 and2n sqrt2<6, so n1 or2; applying both strips leaves precisely these three values. In that order, Norm(J(J-4)) is-7,-7,-28. Equations(5)–(7) would make one of79/28,79/28,79/112 a rational square. The prime79 has odd valuation in every such number, a contradiction. Thus beta=1/2 is excluded too.

## 7. Zero I contact: complete actual two-cycle test

It remains beta0. The actual isolated-I opposite still has(6), now in whichever of the six actual quadratic fields occurs; this requires no norm2 normalization of the disconnected old I. Its own two-cycle always supplies J=4(1+h). The simple3-at1 wall c differs from c_I by its nonzero old helper product, so these are distinct actual walls. Their unit product is-A*sqrt(h). Arithmetic cyclic integrality gives the NECESSARY two-cycle condition

    4(c.c_I)^2=A0^2*(J-4) in O_K.                    (8)

For clarity the following is the FULL finite strip list and the product in(8), expressed as an integer-basis numerator over8. Each displayed numerator has a coefficient not divisible by8.

| Field and parameter | Complete J list, in listed order | 8A0^2(J-4), in the same order |
|---|---|---|
|sqrt3, t2+sqrt3|3+sqrt3;4+sqrt3|93+51sqrt3;216+123sqrt3|
|sqrt2, t1+sqrt2|3+sqrt2;3+2sqrt2;4+sqrt2|25+13sqrt2;101+64sqrt2;76+51sqrt2|
|sqrt13, t1+theta13|2+theta13;3+theta13|29+13theta13;97+68theta13|
|sqrt5, t1+2phi|3+phi;4+phi;2+2phi|59+85phi;144+229phi;118+170phi|
|sqrt17, t1+theta17|2+theta17;3+theta17|50+30theta17;135+85theta17|
|sqrt6, t2+sqrt6|3+sqrt6|258+102sqrt6|

There is no script-completeness premise in this table. To verify completeness, write J=m+n*s in the stated integer basis, with s=sqrt2,sqrt3,sqrt6,theta13,theta17 or phi. From J>4>J' we have n>0. The gap J-J'<6 bounds n to1, except n1/2 in Q(sqrt2) and Q(sqrt5). The simultaneous inequalities4<m+n*s<6 and0<m+n*s'<4 then give exactly the displayed m values. The quadratic identities below the previous table check every product. None is in the corresponding integer ring after division by8, contradicting(8).

## 8. Exact conclusion and verification boundary

Own0 failed the actual time coefficient. The common actual fork bound excluded I contact4 directly. Integral cycles, actual-field positivity and complete norm/trace reasoning reduced ALL positive finite, parallel and dotted own parameters to six quadratic anchors. Positive I contact3 and zero I contact are both exhausted above. Thus the stated long-endpoint simple3 role is impossible on either fork.

This proof imports the earlier edge estimate as a necessary geometric theorem, and the first-type criterion and Meyer obstruction as explicit external statements. Its degree, polynomial and thirteen-entry I calculations are proved here in elementary prose; no finite enumeration is assumed or executed. The two remaining roles in the whole D17+I corner are still open. No lower global ceiling, new example, complete geometric Lean theorem or revised manuscript is claimed.
