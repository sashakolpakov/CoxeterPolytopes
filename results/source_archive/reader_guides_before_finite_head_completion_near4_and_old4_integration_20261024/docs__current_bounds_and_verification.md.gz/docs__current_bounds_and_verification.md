# Current bounds and verification

Updated24 October2026. There are **six paper families**, each with a written,
compiled and internally reviewed TeX/PDF edition. Later supporting proofs improve
the compact bounds without multiplying papers. This page reports the current
mathematical state; dated receipts and preserved predecessor guides record history.

## Dimension comparison

| Class | Largest published example | Published ceiling | Current internally reviewed ceiling | Relation to the PDF |
|---|---:|---:|---:|---|
| General Coxeter, finite volume | 21 | 995, Prokhorov/Khovanskii | **57** | Current48-page paper |
| General compact Coxeter | 8 | 29, Vinberg | **18** | Supporting proof;36-page PDF states23 |
| Compact arithmetic Coxeter | 8 | 29, Vinberg | **15** | Supporting proof;21-page PDF states20 |
| Noncompact arithmetic Coxeter | 21 | 21, Esselmann | **21**, sharp and published | No new claim |
| Arithmetic Coxeter, compact or noncompact | 21 | 29 overall | **21**, sharp overall | New compact proof plus published noncompact theorem |
| Right-angled, finite volume, all vertex types | 8 | 12, Dufour | **8**, internally sharp | Current5-page paper |
| Right-angled, entirely ideal | 4 | 6, Kolpakov | **4**, internally sharp | Same5-page paper |
| Right-angled, compact | 4 | 4, published and sharp | **4**, unchanged | External starting result |

“Internally reviewed” means a complete written argument with the stated external
and finite-data interfaces, another author's source review and root acceptance.
It is distinct from publication, refereeing, complete computational replay and
end-to-end formalization. References and exact published scopes are recorded in
[the assumption register](manuscript_assumptions.md) and the
[right-angled proof map](right_angled_sharp_dimensions_publication_proof_map_20261021.md).
The quadratic-form model is automatic for arithmetic reflection lattices;
“first type” is not an extra restriction on the arithmetic rows.
The general finite-volume, general compact and right-angled results assume
no arithmeticity. Their physical Gram, native-angle and local-link
restrictions require neither a number field nor conjugate positivity.
Integrality and nonphysical embeddings are confined to arithmetic proofs.

## Current mathematical frontiers

At compact dimension18 the complete necessary farthest-vertex list has only
**wholeD18**, after the [whole-B18 exclusion](../results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md).
The [global compact18 composition](../results/compact_dimension18_global_written_acceptance_20261022.json)
has separate written and [conditional Lean](../results/lean_compact18_composition_verification_20261022/manifest.json)
boundaries. A necessary diagram is not a realized example or a statement about
every vertex. The PDF still states23.

At the SAME original vector, [centre16 is unconditionally .58-strong](../results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md):
S16>4-.58/sqrt2. Accepted actual-neighbour arguments give isolated fork
own<15/8, near3 own<1.21 and far3 own<1.6. The current exclusions are:

* The [ENTIRE isolated/isolated family](../results/review_compact18_d18_whole_isolated_isolated_pair_root_acceptance_20261023.md), every head, mutual and unequal own. The new dotted case forces a distant ACTUAL side endpoint, lists its full finite germs, and excludes each at a comparison retained from the original maximum.
* The [ENTIRE isolated/near3 family](../results/review_compact18_d18_whole_isolated_near_three_family_root_acceptance_20261023.md), with its orthogonal, finite, parallel and dotted cases separately proved.
* The [isolated native5 long-head BRANCH](../results/review_compact18_d18_isolated_native5_head_complete_exclusion_root_acceptance_20261023.md). Its exhaustive pair cover closes with the new [isolated/far3 dotted interval theorem](../results/review_compact18_d18_isolated_far_three_dotted_native5_interval_root_acceptance_20261023.md). This is the precise isolated head profile at the selected vertex, not a prohibition on every native5 bond elsewhere.
* [Six explicit central bridge configurations](../results/review_compact18_d18_central_bridge_six_configurations_root_full_source_acceptance_20261024.md) at releases6,7,8. Exact actual-edge lengths, positive actual nulls and single positive-vector norm certificates give a field-free handwritten proof. The new search catalogue is not a premise.
* [Three near-side native-four profiles, and far-side own values at least one](../results/review_compact18_d18_near_far_white_four_root_full_source_acceptance_20261024.md). Actual head-core points and one funded vector also give S6<2.197, S7<2.414 and S8<2.613 under the precise remaining-head model.

The [complete finite-head theorem](../results/review_compact18_d18_finite_head_ten_plus_root_acceptance_20261024.md)
excludes every label at least10. The separately reviewed
[native-nine exclusion](../results/review_compact18_d18_native_nine_head_root_acceptance_20261024.md)
now leaves **finite head labels7 or8**. Its four-case proof uses actual
positive points, native gaps and one legally funded geometric square;
it has no arithmetic premise or worker input.
The [dotted-head argument](../results/review_compact18_d18_dotted_head_outer_ranges_root_acceptance_20261024.md)
excludes two whole outer intervals; a remaining dotted head satisfies
**2/7<eta^-2<87/100**. This necessary interval is not claimed optimal.
Both arguments rebuild all four initial reference cases, retain the full
head correlation and pay each new coefficient before pressure. They do not
use the spectral theorem or an enumeration.

For finite heads7/8 the [complete far-next3 exclusion](../results/review_compact18_d18_heads_seven_eight_far_next_three_root_acceptance_20261024.md)
removes that fork role. The further [far3 and near/far reduction](../results/review_compact18_d18_finite_heads_far_three_near_far_orthogonality_root_acceptance_20261024.md)
forces every far3 own to be dotted and every near3/far3 mutual to be
orthogonal. Its positive-mutual branch constructs a genuine full-A18
neighbour, checks every original wall and retains the original comparison
factor and two-dual reverse pressure. The [complete orthogonal-family proof](../results/review_compact18_d18_finite_heads_whole_near_far_family_root_acceptance_20261024.md)
now closes the remaining near3/far3 case too: one reference in each of
four initial cases bounds the distance to EVERY actual point on the
old-A15 face by cosh<10.81. Genuine finite or timelike witnesses exceed
that cap for every remaining own. Together with the older exclusions,
finite heads retain only **isolated/far3 dotted pairs and far3/far3**.
These are necessary alternatives, not examples.
The dotted-head domain has its separate remaining profiles. No arithmetic
premise enters either new theorem.

For other heads, [isolated/far3 has only dotted mutuals left](../results/review_compact18_d18_isolated_far_three_native_three_two_dual_root_acceptance_20261023.md).
Its dotted domain outside the new interval, other nonisolated fork roles and
other central profiles remain open. The all-h<1.6 continuation is a working
lead, not an accepted theorem. **There is no compact17 bound.** Older kernels
are not relabelled as formalizing these later geometric exclusions.

The [compact-arithmetic ceiling15](../results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md)
combines the prior global16 tail with a complete handwritten whole-D16
exclusion. Geometry forces the actual field quadratic and the head/forks
isolated and dotted; all three dyadic splitting types, full maximal-order
strips and K-square exceptions close the arithmetic residues. Two geometric
residues use one legally funded original-vector square. Older authenticated
computations remain explicit inputs; the prepared D16 census was not run or used.
The PDF still states20.

At exact arithmetic15 the [fresh complete cover](../results/review_arithmetic15_fresh_complete_twenty_two_group_frontier_root_full_source_acceptance_20261023.md)
began with22 necessary groups. The accepted [four-family typed-seven extension](../results/review_arithmetic15_four_typed_seven_a_families_full_foreign_root_acceptance_20261023.md),
together with the earlier B14/B13/D13/A13 exclusions, leaves **14 groups**:
**1,3,4,6,7,9,10,12,13,15,16,20,21,22**. A separate [two-ordinary-A1 proof](../results/review_arithmetic15_a13_two_ordinary_a1_root_full_source_acceptance_20261023.md)
narrows original12 to A13 plus ordinary irreducible T2. Extra spectator costs
are retained in the endpoint formulas and one-vector references. These are
necessary alternatives, not examples; **there is no arithmetic14 bound**.

Within original12, the [golden-helper](../results/review_arithmetic15_a13_ordinary_t2_golden_helper_residue_root_acceptance_20261024.md)
and [near-four](../results/review_arithmetic15_a13_ordinary_t2_near_four_residue_root_acceptance_20261024.md)
residue arguments exclude those two weak central cap branches. Actual
points and one-vector estimates first give a complete small-T2 list;
actual-field equality and cyclic integrality then contradict its residues
modulo seven. Isolated feet and other alternatives remain. These are
arithmetic local exclusions, not a deletion of original12 or a reduction
of the fourteen-group count.
The separate [complete old-label exclusion](../results/review_arithmetic15_a13_ordinary_dihedral_eight_plus_root_acceptance_20261024.md)
removes ordinary I2(m) for every m>=8 beside A13. Geometry first forces
old8/9 and pure actual caps; actual-field equality, reduced rings modulo
seven and full conjugate/norm bounds then give four half-strong heights.
One original-vector reference and its actual T2 edge floor sum to
1.0000269261>1. Lower-label cases remain and original12 is not deleted.
This handwritten proof has full336-line source/289-line outside review;
it supplies no new runtime or Lean credit.

## Work toward finite volume56

The selected positive-native6 rule has [ALL native6 finite budgets](../results/review_finite57_all_single_native_six_finite_budgets_root_acceptance_20261023.md)
and [ALL selected weighted ideal budgets](../results/review_finite57_native_six_complete_weighted_ideal_budgets_root_acceptance_20261023.md)
closed, including the retained Context, priority and fixed receiving debts.
The small-factor ideal computation has actual generation and SEPARATE complete
same-implementation replay:6,626 positive cases across862 profiles,6,656
canonical records, strict EOF and no zero/negative margins. The normalized
minimum is3389/21970. This does not replace the distinct analytic reserves or
pay an unrelated old token. Generation/replay took .843/.798 seconds and
57,376,768/57,393,152 B sampled process-tree RSS. No successful part was rerun.

The [strict weighted global comparison](../results/review_finite57_native_six_weighted_global_extrema_strictness_root_acceptance_20261023.md)
is proved conditional on the SAME complete face rule and all vertex caps.
The missing obligations are the remaining finite configurations and complete
face/source coverage. The [infinite-volume local-port counterexample](../results/review_finite57_native_six_unbounded_same_face_local_ports_root_full_source_acceptance_20261023.md)
prevents replacing those obligations with an unsupported cusp-port bound.

For the literal heavy forest2D17+D23, the following additional centre-exit
domains are now financed:

| Complete-table type | Accepted argument | Exact new charges |
|---|---|---|
| Row5 | [Both positive white4 orientations](../results/review_finite57_positive_row_five_two_corner_refund_root_full_source_acceptance_20261023.md), combined with the old affected-D17 and zero-exchanged rules | Two actual unit refunds plus6: source372-2-6=364; unique B21 receiver358+6=364 |
| Row11 | [ALL positive rank/contact choices](../results/review_finite57_whole_positive_row_eleven_refund_root_full_source_acceptance_20261023.md), with the old safe and zero-exchanged rules kept | Source372-3-5 or372-2-6=364; unique new finite receivers359+5=364 or356.5+6=362.5 |
| Positive FAR row6, both affected ranks | [Complete two-corner classification and exception receivers](../results/review_finite57_positive_far_six_both_ranks_root_acceptance_20261024.md), including small E7/E8/affine-E8 roles | Sources reach364; full receiver bounds361.25,362,363 or344.25, with all earlier debts retained |
| ALL positive NEAR row6, both affected ranks | [Complete four-face and receiver-refund theorem](../results/review_finite57_all_positive_near_six_root_acceptance_20261024.md), combined with the accepted native-three affine-D4 rule | Regular source372-4-4=364 and zero net new receiver load; full regular receiver caps2897/8 and363. Finite/ideal exceptions retain all old debt, with new ideal surplus at least3024 |

The shared method proves selected actual polygons have at least five sides.
BOTH finite/ideal PSD corner conditions and an exact full-Gram Schur form
exclude a fourth side. Small exceptional and remote contacts remain in the
cover. These refunds therefore preserve every triangle/quadrilateral face
payment. Full reverse-edge counts bound receiving loads; all old debts and
paired residual-T credits stay accounted for in ONE simultaneous rule.

The earlier complete far-row8 refunds and heavy-centre forest/component
arguments retain their [precise recorded domains](result_manuscript_correspondence.md).
The all-positive-NEAR6 predecessor omitted two old V23 receiver units.
Its full source and failed audit are preserved; the corrected proof keeps
the complete old cap363. Its regular arrivals fund themselves through
distinct held receiver corners. Both this debt repair and the earlier
native-three dual-index repair have exact preserved deltas.

A separate [literal charge correction](../results/review_finite57_row_four_a15_cross_charge_correction_root_acceptance_20261024.md)
sets the auxiliary A15+2A1+D17+D23 row-four charge to362, not361:
two central halves had been omitted. The old source/review/gate remain
unchanged and explicitly qualified. All37 identified prior direct consumers
were audited; the selected safe union excludes this row, and current
NEAR6 uses different D15/D21 receivers. The frozen57 paper already has
the correct defining rule. New row-four financing needs its own proof.

These rules do not force a qualifying exit or cover every k0 forest.
Row4/7/near8 cases, restoration components and universal coverage remain
under investigation. **The ceiling remains57; no universal364 or56 theorem
is claimed.**

A separate [all-actual-facet extension](../results/review_finite57_all_actual_facet_finite_bonds_root_acceptance_20261024.md)
establishes a compact Coxeter codimension-two face for **any actual facet pair**
with native label5 or at least7, without a previously known common vertex.
It proves the common face, finite-volume compactification and full affine
cusp-link property before applying the earlier special-face projection theorem.
Published compact29 gives a ceiling31 for this restricted bond-bearing class;
internal compact18 separately gives20. Consequently every actual facet pair
at dimension57 has finite native label only2/3/4/6. Parallel and dotted pairs
remain. This is not a general finite-volume31 bound or arbitrary face heredity.

## Construction search

The literal glued and squared-unit H9 hosts have accepted nonreflectivity
proofs. The different prime41 cubed-unit host remains active. Its accepted
original-module walk includes compact E7/D6 faces and ambient mixed vertices;
none of those faces alone establishes ambient volume. Their detailed sources
and earlier firstness scopes remain in the [result correspondence](result_manuscript_correspondence.md).

The [new actual E6+B2 edge](../results/review_h9_prime41_e6_b2_actual_unit_wall_and_full_endpoint_root_acceptance_20261023.md)
has a primitive ORIGINAL norm2 facet W and full finite E6+B2+A1 endpoint.
Its [runtime receipt](../results/h9_prime41_e6_b2_firstness_verification_20261023.json)
binds four distinct admitted units: witness[0,64), SEPARATE complete witness
replay, firstness[0,448), and SEPARATE complete recompute/combine. The closed
bound b0..447 covers all five first-simple profiles, both field-square signs
and both E7 orientations. The recorded7,156 quadratics/12 field roots leave
one least mirror; all44 named old-wall checks and both-embedding LDL tests pass.

Each unit took less than .5 seconds and61,000,000 B sampled process-tree RSS.
Replay/combine use the SAME implementation. Actual unknown-wall firstness
comes from the complete domain theorem, not only those44 named inequalities.
The [next Y-release edge is now proved manually](../results/review_h9_prime41_y_release_manual_h3_full_chain_root_acceptance_20261024.md).
A complete nineteen-to-six original-profile reduction and a fundamental
relative-order unit argument exclude every earlier wall. The unique new
simple facet J reaches a full finite **E6+H3** endpoint. A simultaneous upper
R is a positive combination of J and retained roots, hence is not simple.
All original-module glue, both field embeddings and every unknown wall are
accounted for. The prepared Y-release worker remains **unexecuted and unused**.

On a separate original-g branch, the [new actual R7 facet](../results/review_h9_prime41_actual_r7_firstness_old_u_and_nonoriginal_maps_root_acceptance_20261024.md)
is identified by complete closed two-embedding strips, without an executed
search or the separate existential order-unit argument. The unique norm-two
wall R7=omega5+2phi*omega7+phi^3*g reaches full **D7+2A1**; a positive
old-U projection gives another actual edge to **D6+3A1**. All four direct
normalized matches to the earlier D6 germ are nonoriginal. Complete
first-facet coverage, rather than the48 recorded entries, controls unknown
walls. That list includes duplicates. R7 cuts its old omega-seven gap.
A [fresh mixed-direction proof](../results/review_h9_prime41_after_r7_fifty_entry_outer_gap_root_acceptance_20261024.md)
shows the enlarged50-entry outer relaxation still has infinite volume,
including both R7 and its image. Further unknown actual walls may cut
that new patch; no full-host volume conclusion follows.
**Ambient finite volume, compactness, a chamber period and a new H9 example
remain open.**

## Spectral exploration

A [reviewed full-wall Gram-band theorem](../results/review_spectral_frog_canonical_lorentz_gram_band_root_full_source_acceptance_20261023.md)
and [additional complete independent audit](../results/review_spectral_frog_canonical_lorentz_gram_band_full_scope_replay_20261023.md)
prove that at a wall-height-product maximum a positive diagonal Gram scaling
B has spectrum{-1,0} union[1,infinity), hence B³-B is positive semidefinite.
Its exact trace counts weighted edges and triangles. Compactness supplies
the maximum; the unchanged potential has no general noncompact extension.

The [fourth-order transverse theorem](../results/review_spectral_frog_fourth_order_transverse_schur_root_acceptance_20261023.md)
strengthens the condition on a Hessian-null direction. It has a full outside
review and root acceptance, including an exact compact acute pentagon showing
independence at a FIXED stationary point. If the Hessian is positive definite,
that extra null-direction condition is vacuous. Neither theorem permits
omitting unknown-wall walks/moments or changing the chosen centre.
The maximum is an interior point z, distinct from the vertex p chosen farthest
from it. A joint application can choose that z at the outset and must retain
the same z and p throughout.

The unknown-return cone tool is frozen but unreviewed and unapplied. The
[central-prefix search packet](../results/compact18_spectral_central_opposite_native_prefix_search_contract_20261023.md)
and [worker](../scripts/compact18_central_prefix_interval_search_20261023.py)
now have [complete mathematical/static source clearance](../results/review_compact18_central_prefix_interval_packet_root_preexecution_clearance_20261024.md).
Deleting nodes6/7/8 leaves A5+D12, A6+D11 or A7+D10; classifying the actual
finite one-node extensions gives exactly11/12/12 attachment types. Own and
dotted parameters remain bounded interval variables. This avoids enumerating
the full facet diagram. The sole signed-fork direction correction is
byte-preserved; code is unchanged. **The worker remains unexecuted.**
No selected unit or full560-unit cover has execution or exclusion credit.
The separate handwritten bridge and native-four exclusions keep their own
proofs and do not become computational results.

The proposed restriction-cone approach has two premise sets. Its general
version uses physical Lorentz signature/rank, spherical/affine links, actual
incidence and metric inequalities. The arithmetic version additionally uses
the actual cyclic field, integrality and conjugate positivity. A negative
coordinate in an arbitrary basis is not an impossibility certificate; the
chosen functional must be proved nonnegative for every realizable input.
The native-nine geometric exclusion and the two arithmetic residue
applications above are now reviewed local instances. No general dimension
improvement follows from calling their certificates spectral or Fourier.
For a simple geometric separator, consecutive allowed native magnitudes
a,b give the polynomial (lambda-a)(lambda-b), nonnegative on the entire
actual pair support {0,cos(pi/m):m>=3} union[1,infinity). Proving a local
pair lies strictly between a and b contradicts that inequality. This is
a degree-two moment separator; it uses no arithmetic ground field.

## Verification status

| Result/package | Written status | Actual verification and boundary |
|---|---|---|
| General finite volume57 | Compiled48-page edition and complete internal composition review | All25 bounded replacement units PASS and catalogue integration. The136-script/nine-Lean-root/one-PDF selection has no combined146-job runtime PASS or complete transitive regeneration;111 other command matches retain inherited scope. Core11 unchanged. |
| General compact18 | Complete supporting written proof, outside review and root acceptance | Five-declaration conditional composition kernel compiled/separately audited under23 written inputs. Later D18 exclusions are written geometry and do not enlarge old kernel scope. Frozen PDF23. |
| Compact arithmetic15 | Complete supporting written whole-D16 proof/global composition | Older computations remain inputs. New dyadic kernel has14 ACTUAL declarations compiled/separately audited, with field/geometry external. Frozen PDF20. |
| Right-angled8 / ideal4 | Complete5-page edition, reviews and exact checks | Selected projection/height/tensor/count kernels; geometry and cited code/facet/classification facts external. Both internally sharp. |
| Ideal RA4 volume/structure | Complete17-page edition and reviews | Exact model/combinatorial checks and selected conditional logic; no full geometric formalization or classification of all ideal polytopes as24-cell chains. |
| Compact RA4 volume constraints | Complete14-page edition and reviews | Exact capacity/excess checks and conditional logic. No universal120-cell minimum or second-volume-double theorem. |

Two new named Lean modules now have bounded compilation AND SEPARATE actual
axiom audits, reusing their successful objects:

| Module | Actual prints | Compile / audit seconds | Scope and receipt |
|---|---:|---:|---|
| QuadraticDyadicTripleKernel | 14 | 2.35 / .50 | [Primitive Nat valuation/parity and bounded-norm deductions](../results/lean_quadratic_dyadic_triple_verification_20261023/manifest.json); actual number fields, maximal-order strips, K-square exceptions and geometry external |
| B16IsolatedPairScalarKernel | 12 | 2.09 /1.66 | [Cubic and two scalar prefix contradictions](../results/lean_b16_isolated_pair_scalar_verification_20261023/manifest.json); actual field/ideal facts, census, pressures and real instances external |

All26 successful prints use only standard foundational axioms; none uses
sorryAx. The B16 reserved-name compile failure remains byte-preserved with
ZERO audit credit; its two-name repair was separately reviewed before retry.
One dyadic and two B16 unused-variable/section warnings are preserved. The
preparation maps keep their historical labels and hashes; execution receipts
supply the later status. Printed axioms do not enumerate theorem parameters.
The [formal guide](../formal/README.md) records all older packages without
relabeling their scopes or rerunning successful modules.

## Papers, reproduction and resource discipline

There are six frozen editions; later research stays in the same families.
The [paper index](../manuscripts/README.md), [result correspondence](result_manuscript_correspondence.md),
[computational proof contract](computational_proof_contract.md) and
[finite57 reproduction guide](finite_volume57_reproduce.md) identify each
algorithm's domain, completeness, termination, exact output and replay.
A source hash, a compiled PDF, a mathematical review and a runtime PASS are
different evidence. There is no complete geometric Lean formalization or
combined full-manuscript runtime PASS.

Run ONE scientific/Lean/TeX process under the shared lock. Admission stays
40GiB free disk/6GiB available RAM; live abort floors8GiB/3GiB. Scientific/TeX
batches use59seconds/1GiB/one thread; named Lean batches2048MiB/one thread,
then a SEPARATE actual audit. Remove owned unused products after each batch.
Start cleanup only below20GiB; preserve sources, certificates, final PDFs,
evidence and history. Never kill unrelated processes or bypass monitoring.

Before a push, audit the ACTUAL staged index and build Sphinx with warnings
as errors through the publication watchdog. Compiler objects/dependencies,
TeX intermediates, Python caches and generated sites stay untracked. Sphinx
must not launch mathematical checks. The optional936-file/33-archive bulk
payload remains **unuploaded**; see [availability](../repro/README.md) and
[external input retrieval](../repro/EXTERNAL_INPUTS.md). Byte restoration is
not mathematical verification or a redistribution licence.

The [exact predecessor reader guides](../results/source_archive/reader_guides_before_head5_positive_exits_h9_and_lean_execution_20261023/manifest.json)
are byte-preserved. Dated execution receipts retain their original source
bindings; this rewritten current guide does not retroactively change them.
