# Arithmetic16 frontier refinement: conditional logic map

22 October2026. **PREPARED SOURCE ONLY. UNCOMPILED; five requested axiom
prints, zero actual outputs.** No Lean import, compilation, audit, test,
scientific worker or mathematical process ran during preparation. Root
owns any later single-module capped compile and SEPARATE actual audit.
Preparation and source review earn no implementation-verification credit.

Source: [ArithmeticSixteenFrontierRefinement.lean](../formal/CoxeterProofs/ArithmeticSixteenFrontierRefinement.lean),
SHA256 **18cf9215ff771f6290ef23bce950d80e55eecf86c089174dc74d9c8fa1fa938c**,
8,877 bytes/244 lines. It imports **Std only**, no local module or
mathematical worker. This is a conditional logical composition of settled
written interfaces, not a geometric or arithmetic instance in Lean.

The new whole-A16 and A3/O7 proofs were pending root gates when this
preparation task was assigned. Those written gates have now PASSED:
[combined root acceptance](../results/review_arithmetic16_whole_a16_and_universal_a3_root_acceptance_20261022.md),
SHA256469907748bb203995c343f4e21355ba6dc25faf9a110fa044a65373e2009f6c5.
It binds the complete A16/A3 proofs, different-author reviews and the
current fourteen-group table. All six exclusions below are now accepted
written mathematics at their named external boundaries. The FORMAL gate
remains pending; no successful Lean output is assumed here.

## Exact conclusion and application meanings

The source checks the fresh nineteen GROUPS, removes exactly the five
whole groups3,5,12,13,16, and removes the actual-I/ordinary-A1 SUBCASE
inside group10. The result has fourteen distinct group labels. The A14
group remains with four of its five original spectator alternatives.
This is a NECESSARY list, not a realizability or polytope construction.

For one FIXED hypothetical compact arithmetic16 polytope and its original
strict interior point, the application must supply:

* `Vertex`: a type containing the actual vertices under discussion;
* `Selected p`: p is the chosen ACTUAL farthest vertex for that original
  point, not a neighboring vertex declared farthest after a replacement;
* `ActualForest p family`: the ENTIRE actual finite forest at that SAME p
  has the literal meaning of the pinned fresh frontier and `family` label;
* `dimension`: the dimension of that same candidate, with `dimension=16`.

These predicates are parameters. They are not instantiated or proved by
the module. `ForestCase` labels group the ordinary spectator subtypes
listed below; the formal datatype does not construct diagrams, impose
their ranks/angle labels, or decide geometric existence. The exact meaning
of `ActualForest` must therefore include those written conditions.

`TypedSeven` keeps OLD A2/NEW isolated7 and OLD I2(7)/NEW isolated3
distinct. The new opposite wall is ACTUAL in each case; a bare old7 is
not the second defect. Actual I is the isolated short rank-one alternative,
and all unmarked A1/T2/T3/T4 are ordinary. T2 is irreducible dihedral;
T3=A3/B3/H3 and T4=A4/B4/D4/F4/H4.

## Original nineteen groups and retained domain

The names in the second column are the corresponding `Group` and
`ForestCase` constructors; the three typed-seven constructors additionally
retain the explicit `TypedSeven` parameter. Only `a14` needs its five
spectator labels separated for this logical refinement.

| Original group | Constructor | Entire original spectator alternatives | Refined status |
|---:|---|---|---|
|1|a10ActualI|I+(A5 or D5)|Retained|
|2|a10TypedSeven|N7/O7 plus A4/B4/D4/F4|Retained|
|3|a11Ordinary|A5; D5; (A4 or H4)+A1; A3+T2; two T2+A1|Closed|
|4|a11ActualI|I+T4|Retained|
|5|a11OldSevenA3|O7+A3|Closed|
|6|a12Ordinary|A4; H4; two T2|Retained|
|7|a12ActualI|I+T3|Retained|
|8|a12TypedSeven|N7/O7+T2|Retained|
|9|a13|A3; T2+A1; I+T2; O7+A1|Retained|
|10|a14|T2; two A1; I+A1; N7; O7|Retain all EXCEPT I+A1|
|11|a15|one nonshort A1 or actual I|Retained|
|12|wholeA16|none|Closed|
|13|b14TypedSeven|N7/O7|Closed, BOTH meanings|
|14|b15|one nonshort A1 or actual I|Retained|
|15|wholeB16|none|Retained|
|16|d13|I+T2; O7+A1|Closed|
|17|d14|ordinary I2(m),m>=4; N7/O7|Retained|
|18|d15|one nonshort A1 or actual I|Retained|
|19|wholeD16|none|Retained|

For A14 the original enum is `ordinaryT2`, `twoOrdinaryA1`,
`actualIOrdinaryA1`, `oldA2NewIsolatedSeven`,
`oldI2SevenNewIsolatedThree`. Its surviving list omits ONLY the third.
No ordinary A1 case is silently identified with actual I, no typed defect
is converted into an ordinary dihedral, and no whole A14 exclusion occurs.

## Exactly seven external written theorem interfaces

All mathematical paths below are under results/. Source preparation
freshly matched these seven literal source pins. The structure
`WrittenInputs` has exactly the seven fields in the first column.

| Field | Mathematical source | SHA256 | Used statement |
|---|---|---|---|
|freshComplete|arithmetic_dimension16_fresh_complete_necessary_forest_frontier_candidate_20261022.md|a8cc202cc364f438e733c5c2536185aa923bc56ee2d3edc9e245a3c8d7e20e3c|At exact16, each original selected farthest vertex has one of the complete nineteen whole-forest descriptions|
|d13Exclusion|arithmetic16_d13_fresh_short_layers_and_rank_three_spectator_exclusion_candidate_20261022.md|6cd78a94fabd27d890901ee5e20a70ae462c190b8dec8f6a4bd5a7f57d1c0c19|Entire original D13 row, both retained spectator alternatives|
|a11OrdinaryExclusion|arithmetic16_a11_paid_helper_and_all_isolated_feet_uniform_point65_candidate_20261022.md|2e69ab9ccdc2fee7700ca12f89574ca59f93caef6f033fff990e4951663a290e|Uniform component>.65 plus ordinary rank5>5/14 excludes exactly the ordinary A11 row|
|b14TypedSevenExclusion|arithmetic16_b14_typed_seven_actual_defect_wall_head_exclusion_candidate_20261022.md|237080ad5775d91e83b2fde217acd275ecf1f0949103a937fedbc6497e89b07c|B14 with EITHER actual typed7; corrected mixed-head factor and native-gap proof|
|wholeA16Exclusion|arithmetic16_whole_a16_complete_endpoint_field_and_finite_anchor_exclusion_candidate_20261022.md|7ba7e0ddf6b4590593edc5e42d89f63b00a79921b624a12a7b1a3ea704aae962|Complete whole-A16 exclusion over every actual arithmetic field|
|a11OldSevenA3Exclusion|compact_universal_a3_point26_and_arithmetic16_o7_consumer_candidate_20261022.md|ca4760e31ee105f52d007210dd2222b305fb9f71c0debd8f42c3cfa97c756273|Universal nonarith A3>.26 plus disjoint A11>.65 and actual O7>.09 excludes EXACT A11+O7+A3|
|a14ActualIOrdinaryA1Exclusion|arithmetic16_a14_actual_i_and_rank_one_two_endpoint_summed_feet_exclusion_candidate_20261022.md|60bd9822529a58c060ab622de184e49e687d3e6fe437dc4c0dc7623a0431185a|Only A14+actual I+ordinary A1, not the whole A14 group|

All six exclusion fields take exact16, the SAME p, `Selected p`, and
the matching `ActualForest p ...`. They do not accept a different
vertex, chosen replacement point or independent forest witness. The fresh
field produces a family for the supplied p; it does not assume the desired
fourteen-group conclusion. The record contains no `Survives` premise,
no source of a supplied count, and no dimension<=15 or total contradiction.

The earlier written gates, besides the combined469907 record above, are:

* [Fresh list and A14 subcase](../results/review_arithmetic16_fresh_frontier_and_a14_actual_i_rank_one_root_acceptance_20261022.md),
  SHA2567b7966099f579b505dfd928b1137c45cfb649f11aff6597419e8c595c613572b;
* [D13](../results/review_arithmetic16_whole_d13_root_acceptance_and_remaining_frontier_20261022.md),
  SHA2567d9e43fc822082b4e7da05ed5976e3be464f81a70fa0b1d497ea995cdc3796bd;
* [Uniform A11](../results/review_arithmetic16_uniform_a11_point65_root_acceptance_20261022.md),
  SHA2561f0aa0f85f889937a5092fe26ac998ccfc9d52ab90792c5afe6338b3e0c78743;
* [Corrected B14](../results/review_arithmetic16_b14_typed_seven_corrected_root_acceptance_20261022.md),
  SHA256ed81f16c12db09c87de8dc779138aa2178e82d5f086aba5dfbe6ada47e0cd192.

The ecef B14 factor-two predecessor and05f70 A3 premise-attribution
predecessor remain historical byte-preserved records. Only237080 andca476
are the respective current inputs. This module neither recertifies nor
retroactively awards PASS to a superseded mathematical derivation.

## Five requested declarations and what their proofs derive

1. `exact_enumerations`: constructor-by-constructor completeness of the
   initial group and A14 enums, plus closed kernel `decide` proofs of
   distinctness and exact list lengths19/14 and5/4. No `native_decide`,
   external checker or supplied list maximum is used.
2. `a14_actual_i_ordinary_a1_exclusion`: exposes the exact external written
   subcase on the supplied p and original forest relation.
3. `classified_forest_refinement`: exhausts EVERY nineteen-group constructor
   and EVERY A14 spectator. It applies the five whole-group exclusions
   and the one subcase exclusion only to their matching cases; all retained
   membership facts reduce to the explicit finite lists.
4. `same_point_complete_refinement`: obtains the original family from
   `freshComplete` for the given p and keeps that SAME family/forest proof
   while attaching the derived refined membership. No selection switches.
5. `a14_spectators_refine_to_four`: extracts the proved four-label membership
   for any actual A14 description at that same selected vertex.

Every conditional theorem has `written` as an EXPLICIT theorem parameter.
No proof relies on a section variable appearing only in its body, so the
previous missing-`include` failure mode is avoided in the prepared source.
All five names have matching `#print axioms` commands. Those commands are
requests, not actual stdout; no current axiom list or compiled object is
asserted until root's later guarded compile and separate audit succeed.

Arithmetic geometry, energy inequalities, actual incidence, field/angle
classifications, manual finite tables and all prior scientific runtimes
remain EXTERNAL. The module preserves the current arithmetic ceiling16;
it proves no lower global bound and changes no frozen paper/PDF.
