# D20 native5/centre3+4: a short fork edge and five further exclusions

21 October2026. **Complete root-authored manual candidate, pending outside-author review.** No scientific, symbolic/enumeration, mathematical-worker import, Lean or TeX job, arithmeticity assumption or manuscript edit was used.

**Theorem.** Suppose an actual farthest vertex of a compact Coxeter20-polytope has whole finite forest D20, the literal isolated native5 head, and the literal centre18 own3/helper4 wall specified below. Both actual outgoing fork edges have cosh length at most41/5. On fork20, the only possible opposite is dotted, with one retained simple3 contact at the long endpoint1. This is a necessary role reduction within the stated branch, not exclusion of that branch or wholeD20.

## 1. Inputs and the existing single reference

Paths are under `results/`. Use only the interfaces in this table.

| Source | SHA-256 | Interface |
|---|---|---|
| compact_whole_d20_complete_continuation_20261021.md |9cec3f696bd5e67fba56de98db45d433188d5b13ee88eb1be5be788a8d0fe3f3|Complete native5-head .58 floors through15, with only nonadjacent helper holes8..14|
| compact_whole_d20_fork_continuation_foundations_20261021.md |9f79746250fc635fddc79b8acacb72278c1dd9a05dceedad8f6551ead08ff0ca|Section3's actual paid-head reference and retained P15 coefficient|
| compact_whole_d20_centre_three_four_other_fork_finite_contact_exclusion_20261021.md |b629a9e20a28217377f1a002ba0713bff9473e81aea05d8c29710d845e89230a|Complete seven-role fork20 white list and exclusion of every finite/parallel own contact|
| compact_whole_d20_centre_three_four_isolated_other_fork_exclusion_20261021.md |4c6a7dcfe1e6aec522100bebff127ab301fba638d2a7bfd8e160a8cf8a678465|Complete isolated-other-fork exclusion, used only in the final role composition|
| compact_farthest_vertex_mixed_replacement_inequalities_20261020.md |3732b82614e13dfe2f7a3c66ab6c7fe67e517cbaeb77be0ca533f559ddf6ed84|Farthest comparison for actual feasible future points|

Compact acute simplicity, finite spherical classification and the actual Coxeter spectrum are explicit geometric foundations. There is no field or arithmetic premise.

Let p²=-1 and use unit old D20 normals n_i=(e_i-e_(i+1))/sqrt2 for i<20 and n20=(e19+e20)/sqrt2. Write P_i=e1+...+e_i,

    omega_i=sqrt2*P_i (i<=18),
    omega19=(P19-e20)/sqrt2, omega20=(P19+e20)/sqrt2,
    z=E(p-x), ||x||²<1.

The ACTUAL head is b=A0*p-g*omega1 with g=cos(pi/5) and A0²=g-1/2. The ACTUAL centre wall is

    c=A*p-v,
    v=omega18/2+omega19/sqrt2
      =a*P18+(e19-e20)/2,
    s=sqrt2, a=(1+s)/2, A²=13+9s.                    (1)

The first two inputs give one reference w supported through coordinate15. If Aref is its individually certified anchor pressure, then

    L=2Aref-||w||²>.956324,
    sum(w)=f15=sqrt15-.58/sqrt2<3.463,
    remaining P15 coefficient >1/8.                  (2)

The head correction is already paid, has support in the first5 and zero coordinate sum. Internal omissions cost<.000172. There is no centre18 or fork floor in this construction. In particular the reference exists before any of the new exclusions below.

If an actual pressure is x.V>=G, with V=1 through its first15 coordinates and R=V²<=20, pay mu=1/8 from the still available P15 coefficient. The residual V-P15 vanishes on the reference support and has square R-15. One completed square on the ORIGINAL x gives

    ||x||²>=L+(G-f15)/4-(R-15)/64
            >.956324+(3.955-3.463)/4-5/64
             =1.001199>1                              (3)

whenever G>3.955. This is payment from supported individual inequalities; it does not subtract an unknown actual S15 or regard L as the norm of the head-adjusted vector.

## 2. Both actual fork edges have C<=41/5

For either fork put V_+=P19+e20 or V_-=P19-e20. Its square is20 and its first15 coordinates are1. If that ACTUAL finite endpoint has cosh length C>41/5, the farthest comparison gives

    x.V_±>=sqrt20*sqrt((C-1)/(C+1))
           >sqrt(360/23)>791/200=3.955.              (4)

The last strict square comparison has margin9337/920000>0. Equation(3) contradicts ||x||<1. Thus each fork separately satisfies C<=41/5. No addition of two independent fork pressures is made, and their opposite walls need not be distinct.

## 3. Four roles fail the common edge bound

Consider the actual fork20 opposite d=T*p-w. The finite-contact input makes its own product -gamma dotted, gamma>1. The retained A19 permits exactly the isolated role, simple3 at n1,n2,n18,n19, or double4 at n1,n19. The isolated role is excluded by4c6a7dcf, independently of the present length bound.

For simple3 at j<=18, w=gamma*omega20+omega_j/2. Since

    omega20²=10, omega_j²=2j, omega20.omega_j=j,

the time square, edge coefficient and edge residual are

    T²=10gamma²+j*gamma+j/2-1,
    b_edge=(20gamma+j)/sqrt40,
    delta_edge=1-j/2+j²/40.

At j2 or18, delta_edge=1/10, hence C=10gamma+j/2. The respective lower bounds C>11 and C>19 contradict C<=41/5. All dotted parameters in these two roles are excluded.

For double4 at n1, w=gamma*omega20+omega1/sqrt2; direct projection gives delta_edge=1/20 and C=10sqrt2*gamma+1. For double4 at n19, use omega19²=10 and omega19.omega20=9; again delta_edge=1/20 and now C=10sqrt2*gamma+9. Each exceeds41/5 for every gamma>1. This excludes both double4 roles. These calculations use the full actual spatial vector; there are no omitted vertex components in wholeD20.

## 4. The other-fork simple3 role fails acuteness

The remaining simple3 at n19 would have

    w=gamma*omega20+omega19/2,
    T²=10gamma²+9gamma+3/2,
    C=(20gamma+9)/sqrt21.                          (5)

The common length bound and sqrt21<23/5 give

    1<gamma<359/250<3/2.                           (6)

From(1) set

    B=v.omega20=9+(9/2)s,
    H=v.omega19/2=9/2+(5/2)s,
    D=10A²-B²=(17+18s)/2.

Acuteness between the distinct ACTUAL walls c,d requires A*T>=B*gamma+H. Both sides are positive, so it implies

    P(gamma)=A²*T²-(B*gamma+H)²
             =D*gamma²-B*gamma-(53+36s)/4>=0.      (7)

This polynomial is strictly increasing for gamma>=1: 2D-B=8+(27/2)s>0. Yet

    P(3/2)=(-61+36s)/8<0,

using s<3/2. By(6), P(gamma)<P(3/2)<0, contradicting(7). Thus the entire dotted other-fork simple3 role is impossible without considering its mutual native label.

## 5. Exact remaining role and limits

The seven-role list is now exhausted except simple3 at n1: the isolated role is excluded by4c6a7dcf, four roles by Section3 and the fifth by Section4. Therefore the actual opposite must have

    d=T*p-gamma*omega20-omega1/2,
    T²=10gamma²+gamma-1/2,
    1<gamma<=((41/5)*sqrt21-1)/20<459/250.          (8)

This is a necessary actual-wall description only. Its mutual centre and head products still have to satisfy the Coxeter spectrum; this source does not solve those conditions or assert realizability. No other head/centre branch is excluded, and wholeD20, the compact20 frontier and a general19 ceiling remain open. The six TeX/PDF editions and all previous execution/formalization records are unchanged.
