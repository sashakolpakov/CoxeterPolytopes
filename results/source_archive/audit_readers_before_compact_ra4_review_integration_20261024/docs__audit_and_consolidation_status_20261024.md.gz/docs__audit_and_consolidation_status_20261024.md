# Audit and consolidation status

24 October 2026. The current task is to audit the main arguments, consolidate
the same six paper families, and finish conditional Lean verification and
bounded reproducibility. Later exploratory work toward dimensions 56, 16
and 14 is preserved outside the TeX manuscripts.

## Papers and current audit boundaries

| Paper family | Result retained or targeted | Fresh work completed | Still required |
|---|---|---|---|
| General finite volume | Ceiling 57 | Common actual-face geometry and tail interfaces reconstructed; low-eight concentration, terminal algorithm and abstract Bellman logic audited; difficult final D13 consumer chain audited | Remaining local routing and current-table bindings, full finite contexts, dimension-specific tails and exceptional finite propositions |
| Sharp right-angled dimensions | Sharp ceilings 8 and 4 | Complete five-page proof, supporting exact algorithms and conditional interfaces audited; coordinating acceptance | Original Dufour text supporting the precise 27-facet premise remains unavailable; published inputs and geometric interpretation stay explicit premises |
| General compact | Integrate accepted ceiling 17 into the existing family | Necessary dependency and section map prepared | Complete consolidated TeX, fresh proof audit and source-bound build; two prepared compact17 kernels remain uncompiled |
| Compact arithmetic | Integrate accepted ceiling 15 into the existing family | Shorter route through the general17 companion mapped; same-family revision in preparation | Complete local proof closure, independent revision audit, matching build and formal interface update |
| Ideal RA4 volume and structure | Published minimum, second volume with unique double, restricted chains | Complete fresh independent manuscript/model-algorithm audit found no internal defect | Coordinating full-source acceptance; the exact historical Figure 7 incidence transcription stays an explicit external input |
| Compact RA4 volume constraints | Existing capacity/excess results; audit accepted C28 successor before integration | Complete primary manuscript reread; successor audit underway | Complete C26/C28 integration audit, consolidated TeX and appropriate conditional logic/check bindings |

The delivered six TeX/PDF pairs are unchanged at this checkpoint. A revision
inside an existing paper family is not an additional proposed paper. The
largest published examples and the internally reviewed ceilings remain as
reported in the [dimension comparison](current_bounds_and_verification.md).
The general finite-volume, general compact and right-angled arguments assume
no arithmeticity.

The [six-paper consolidation map](six_manuscript_audit_and_consolidation_20261024.md)
identifies the common arguments, the point where cases split, and the exact
source homes needed before any old chapter is removed. Its initial proposed
execution counts are preparation history; the actual successor plan counts
are given below.

## Exact audit records

The [coordinating acceptance](../results/audit_sharp_ra_and_finite57_scoped_root_acceptance_20261024.md)
distinguishes the complete sharp-dimension audit from the scoped finite57
algorithm audit. The [finite57 geometry report](../results/audit_finite57_geometry_core_and_tail_interfaces_root_20261024.md)
and [local-routing review](../results/audit_finite57_local_routing_whole_components_fresh_20261024.md)
state what was reconstructed and which obligations remain. They do not
claim a new full-manuscript runtime PASS or transitive regeneration.

The [ideal RA4 audit](../results/audit_ideal_ra4_fresh_20261024.md) checks the
gap, equality-spectrum reduction, actual cutting sections, recognition and
gluing, along with each selected finite-model algorithm. Its separate
classification/input boundary remains visible.

For every computation retained in a revised paper, the text must state its
admissible domain, algorithm, termination proof, soundness and completeness,
and exact output. Code, an attainer, a source hash or a successful PDF build
does not replace those mathematical statements.

## Bounded execution successor

Use the new public entry for the preferred execution route. The old workers,
drivers, resource runners and their receipts remain byte-identical because
existing certificates bind them. The new route rejects optimized Python,
keeps the shared lock and resource monitors, tracks owned descendants, and
separates compilation from an actual parsed axiom audit.

Inspect a plan without running any mathematical child:

```sh
python3 -B scripts/run_proof_batch_20261024.py manuscript finite57 \
  --mode full --pdf --plan
```

The actual [full plan](../results/finite57_audited_successor_full_plan_20261024.json)
has **151 stages**: 136 script selections, nine compilation stages, five
separate actual-axiom stages and one PDF stage. The [core plan](../results/finite57_audited_successor_core_plan_20261024.json)
has **16 stages**. Only five of those nine roots contain the relevant print
commands. The legacy 146/core11 inventory remains historical evidence. A
plan is not execution, and successful unchanged modules need no repeated run.

For a necessary new single-module batch, use a fresh ledger filename:

```sh
python3 -B scripts/run_proof_batch_20261024.py lean-compile \
  CoxeterProofs.D18UniformDottedHeadScalarKernel \
  --ledger results/compact17_scalar_compile_guard_new.json

python3 -B scripts/run_proof_batch_20261024.py lean-audit \
  CoxeterProofs.D18UniformDottedHeadScalarKernel \
  --ledger results/compact17_scalar_audit_guard_new.json
```

The second command requires matching successful capped compilation; it
does not compile a missing target as a fallback. It parses actual output
for every requested declaration and rejects missing, malformed, duplicate
or unapproved results. Ordinary theorem parameters remain assumptions and
must be listed in the logic map even when printed axioms are standard.

For a selected scientific checker, the public entry obtains the correct
shared lock and invokes the unchanged bounded runner:

```sh
python3 -B scripts/run_proof_batch_20261024.py check -- \
  scripts/fresh_d13_context_dimension57_20261018.py --verify
```

Choose checks because an input, implementation or unresolved obligation
requires them; do not rerun successful unchanged parts merely for a new date.
Historical direct worker commands identify mathematical components. Execute
them through the guarded route rather than treating those identifiers as
unmonitored launch instructions.

The [execution clearance](../results/audited_proof_execution_clearance_20261024.json)
binds different-author source reviews, coordinating monitor review and an
actual source-bound **14-test infrastructure PASS**. Those tests exercised
optimization refusal, lock choices, actual-output parsing, plan generation,
PID-reuse/reparent handling and cleanup of two tiny owned Python stand-ins.
They launched no mathematical worker, Lean or TeX. **The first positive proof
execution through the successor remains pending resource admission.**

Admission remains 40 GiB free disk and 6 GiB available RAM; abort floors remain
8/3 GiB. Scientific/Lean/TeX work is serial under the shared lock, with the
existing 59-second/1 GiB outer monitor and one thread. Lean also retains its
2048 MiB option. The additional process cleanup layer does not relax these
gates. Its birth-identity checks and polling limitations are described in
the [coordinating source review](../results/review_audited_proof_execution_root_clearance_20261024.md).

## Completion still required

Each of the six final editions needs a complete accepted mathematical
argument, precise external/computed premise register, source-bound review,
appropriate changed checks and a matching bounded PDF build. New selected
Lean sources need compilation and a separate actual axiom audit. The site
and catalogue must describe the resulting editions accurately. A final Git
index audit must exclude caches, objects, dependencies, intermediates and
generated sites before publication. This checkpoint completes none of
those remaining requirements by implication.
