# Results and manuscripts

Updated 24 October 2026. There are **six current papers**, with finished
TeX sources and matching PDFs. The other repository-owned TeX files are
predecessors, supporting notes, input fragments or generated atlases.
They are not additional proposed papers. The
[catalogue](../manuscripts/catalogue.json) retains the complete inventory;
the [reader’s index](../manuscripts/README.md) gives the current PDFs and
verification commands.

The [delivery receipt](../results/six_paper_final_tex_delivery_20261021.json)
binds all six source/PDF/build triples. Their theorem scopes and pages
are unchanged by the subsequent audits. Parked field-specific arithmetic
refinements remain excluded and preserved.

## Current correspondence

| Result | Primary manuscript and PDF | Main technique and point where cases separate | Verification scope |
| --- | --- | --- | --- |
| General finite-volume Coxeter dimension ≤57 | [TeX](../manuscripts/finite_volume57.tex), [48-page PDF](../manuscripts/build/finite_volume57.pdf) | One corner-payment rule and global incidence curvature. Separate finite spherical forests from affine cusp links; then handle dimension 58 and the complete higher-dimensional tail. Twelve main pages, 36 essential proof/algorithm appendices. | [Proof map](finite_volume57_lemma_map.md), [reproduction guide](finite_volume57_reproduce.md), [fresh composition audit](../results/review_finite57_geometric_composition_new_audit_20261021.md). Complete bounded replacements, separately matched136 script selections and selected conditional Lean; no combined146-job replay. |
| Compact arithmetic Coxeter dimension ≤20 in this PDF; later reviewed written ceiling15 | [TeX](../manuscripts/compact_arithmetic_dimension_bound.tex), [21-page PDF](../manuscripts/build/compact_arithmetic_dimension_bound.pdf) | The PDF uses arithmetic angle rules. Later work uses one farthest vector and actual-field reduction. The final whole-D16 obstruction exhausts quadratic dyadic splitting, full integer strips and K-square exceptions without a new census. | [PDF proof map](compact_arithmetic20_proof_map.md), [complete fifteen argument](../results/arithmetic16_whole_d16_quadratic_dyadic_splitting_complete_manual_exclusion_candidate_20261023.md), [full acceptance](../results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md). The overall theorem inherits earlier authenticated computations. Older Lean kernels retain their16/precursor scopes; the [new fourteen-declaration map](quadratic_dyadic_triple_kernel_logic_20261023.md) has an [actual fourteen-declaration compile and separate audit PASS](../results/lean_quadratic_dyadic_triple_verification_20261023/manifest.json), with field/geometry still external. The PDF remains20. |
| General compact dimension ≤23 in this PDF; later reviewed written ceiling18 | [TeX](../manuscripts/compact_farthest_vertex_bounds.tex), [36-page PDF](../manuscripts/build/compact_farthest_vertex_bounds.pdf) | One actual farthest vector supplies the norm budget. Ordinary components separate from large-A paired pressures and B/D coordinate-prefix arguments, followed by the terminal forest ledger. | [Proof map](compact_farthest_vertex_bounds_proof_map_20261020.md), [general eighteen composition](../results/compact_dimension18_global_composition_and_whole_d19_exclusion_candidate_20261022.md), [acceptance](../results/compact_dimension18_global_written_acceptance_20261022.json). Full written source and composition reviews. The older accounting kernel retains23; a separate [compact18 kernel](../results/lean_compact18_composition_verification_20261022/manifest.json) now has a compile and actual five-declaration audit PASS under23 written premises, with geometry external. |
| Right-angled dimension ≤8 universally and ≤4 if entirely ideal; both sharp | [TeX](../manuscripts/right_angled_sharp_dimension_bounds_publication.tex), [5-page PDF](../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf) | Shared finite projection and height comparison. The universal branch uses a cubic tensor spherical-code argument; the ideal branch uses the explicitly named Musin/Kolpakov inputs. | [Proof/reproduction map](right_angled_sharp_dimensions_publication_proof_map_20261021.md), fresh [geometry](../results/review_sharp_ra_geometric_foundations_adversarial_20261021.md) and [tensor/equality](../results/review_sharp_ra_tensor_ideal_equality_adversarial_20261021.md) audits. Exact core runs and selected conditional Lean pass; actual geometry remains external. |
| Ideal RA4 minimum, second volume and unique double; restricted 24-cell chains | [TeX](../manuscripts/ideal_ra4_volume_and_structure_publication.tex), [17-page PDF](../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf) | Defect counting proves the gap and equality spectrum first. Actual sections, cutting, metric recognition and gluing then prove the restricted Oct/D chain theorem and identify the second-volume double. | [Proof map](ideal_ra4_volume_and_structure_proof_map.md), [fresh full audit](../results/review_ideal_ra4_volume_structure_fresh_adversarial_20261021.md). Published minimum is an input. Exact model checks and conditional Lean do not replace the universal geometric proof. |
| Compact RA4 volume constraints | [TeX](../manuscripts/compact_ra4_volume_constraints.tex), [14-page PDF](../manuscripts/build/compact_ra4_volume_constraints.pdf) | Perpendicular-facet capacity and neighboring excess. Separate zero-excess recognition from positive-excess graph and metric configurations. | [Reproduction map](compact_ra4_volume_constraints_reproduce_20261019.md), [fresh full audit](../results/review_compact_ra4_volume_constraints_fresh_adversarial_20261021.md). Cases are written out; catalogue execution checks typesetting only. No universal 120-cell minimum or second-volume theorem. |

Supporting results remain within those same families. Earlier entries retain their stage-scoped boundaries; the [current guide](current_bounds_and_verification.md) gives the present frontier:

The [auxiliary row-four cost correction](../results/review_finite57_row_four_a15_cross_charge_correction_root_acceptance_20261024.md)
qualifies the old finite-centre source and its review/acceptance: the A15
receiver has raw362, not361. The source-bound37-consumer audit found no
accepted allocation spending that incorrect cap. Historical bytes remain,
and the frozen57 paper's defining table is unchanged.

| Supporting result | Existing paper family | Shared technique and verification boundary |
|---|---|---|
| [Both remaining finite D18 heads excluded](../results/review_compact18_d18_finite_heads_seven_eight_complete_root_acceptance_20261024.md) | General compact | Complete377/239-line proofs and joint279-line outside review close the entire far3/far3 and isolated/far3 dotted families. A universal old-A16 distance cap, feasible feet, proved forward ordering and all seven finite next germs retain one original vector and every wall. The six-pair conjunction excludes heads7/8; only dotted heads remain. No arithmeticity,17, runtime or new Lean scope. |
| [ALL positive NEAR end3 row4 exits financed](../results/review_finite57_all_positive_near_end_three_row_four_root_acceptance_20261024.md) | General finite volume | Full415-line source/296-line outside review classify BOTH PSD corners at both affected ranks. Old NEAR6 and new exceptions share ONE actual-port union; regular receiver refunds retain corrected362/355, and the new D9 caps are2641/8 and358. All old debt remains. FAR end3 and universal coverage stay open; no56 or new execution. |
| [A13 plus ordinary old I2(m), every m>=4, excluded](../results/review_arithmetic15_a13_ordinary_dihedral_four_plus_root_acceptance_20261024.md) | Compact arithmetic | Full332-line source/213-line outside review retain every foreign contact. Actual Lorentzian triangles force the field; Cartan determinants give integral8||v_A||²; reduced-seven residues and conjugate norms force four .49 heights. One reference plus ordinary T2 exceeds one. Original12 retains ordinary A2 and the fourteen-group count stays; no14, runtime or new Lean scope. |
| [Native-nine D18 head excluded](../results/review_compact18_d18_native_nine_head_root_acceptance_20261024.md) | General compact | Four complete initial cases use actual positive points, native gaps and one jointly paid square with its full cross term. Full260-line proof and212-line outside review leave finite head labels7/8; the dotted interval remains. No arithmetic premise, compact17 or execution. |
| [ALL positive NEAR row6 financed at both ranks](../results/review_finite57_all_positive_near_six_root_acceptance_20261024.md) | General finite volume | Complete four-face classification uses actual finite/ideal exceptions or four source and four distinct receiver-corner refunds. Full487-line corrected source,373-line failure audit and116-line successor review retain all old loads, including V23's two units; regular caps2897/8 and363, new ideal surplus at least3024. Composes the earlier native-three gate; both substantive errors and repairs are preserved. Coverage remains; no56 or execution. |
| [Finite-head far-next3 exclusion](../results/review_compact18_d18_heads_seven_eight_far_next_three_root_acceptance_20261024.md) and [ENTIRE near3/far3 family exclusion](../results/review_compact18_d18_finite_heads_whole_near_far_family_root_acceptance_20261024.md) | General compact | Native gaps, actual A18 neighbours and one old-A15 all-point distance cap retain every wall and the original vector. Full214/273/324-line sources and201/225/257-line outside reviews. These left isolated/far3 dotted and far3/far3 pairs at that stage; the later complete conjunction above closes both. Dotted heads remain separate. No arithmeticity,17 or execution. |
| A13 plus ordinary T2: [golden-helper](../results/review_arithmetic15_a13_ordinary_t2_golden_helper_residue_root_acceptance_20261024.md), [near-four](../results/review_arithmetic15_a13_ordinary_t2_near_four_residue_root_acceptance_20261024.md) and [all old labels at least8](../results/review_arithmetic15_a13_ordinary_dihedral_eight_plus_root_acceptance_20261024.md) excluded | Compact arithmetic | Actual points and one-vector squares precede complete local lists, actual-field equality and modulo-seven integral-cycle/norm obstructions. Full338/190/336-line sources and218/221/289-line outside reports. The old-label proof rebuilds four half-strong heights and has final norm>1.0000269261. Arithmetic premises stay in this lane; original12 and all14 groups remain. No14, execution or new Lean scope. |
| [Finite head labels at least10 excluded](../results/review_compact18_d18_finite_head_ten_plus_root_acceptance_20261024.md) and [dotted outer ranges excluded](../results/review_compact18_d18_dotted_head_outer_ranges_root_acceptance_20261024.md) | General compact | All four original initial cases are rebuilt with their bare/paid references and exact individual prices. Full247/224-line proofs and225/203-line outside reports left finite head labels7/8/9 at that stage and the necessary, nonoptimal dotted interval2/7<eta^-2<87/100. All original walls and one vector remain. No compact17 or execution. |
| [Near/far native-four profiles excluded](../results/review_compact18_d18_near_far_white_four_root_full_source_acceptance_20261024.md) | General compact | Actual positive head cores, exact edge lengths and one funded vector exclude three near profiles for all owns and three far variants for owns>=1; scalar ceilings are extracted with their exact head hypotheses. Full250/234-line proofs and276-line outside report; far finite owns remain, no17. |
| [Positive far-row6 financed at both ranks](../results/review_finite57_positive_far_six_both_ranks_root_acceptance_20261024.md) | General finite volume | BOTH PSD corners, all ordinary and small-E exceptions, genuine >=5-gon refunds, actual first neighbours and full reverse-port counts. Full436/405-line sources and383-line outside review retain every prior debt, including whole-A17 Context. Near6 and coverage remain; no56. |
| [All-actual-facet high-label restriction](../results/review_finite57_all_actual_facet_finite_bonds_root_acceptance_20261024.md) | General finite volume | Positive projection proves a common face; Klein compactification and the full bounded Euclidean cusp link make it compact for label5/7+. The proved special-face projection then gives Coxeter angles. Published29 gives31 only for this class; actual finite labels at57 are2/3/4/6. Full192-line extension and177-line outside review; no arithmeticity or universal31 bound. |
| [Manual prime41 Y-release and full E6+H3 endpoint](../results/review_h9_prime41_y_release_manual_h3_full_chain_root_acceptance_20261024.md) | Construction research | Original index6, complete nineteen-to-six profile reduction, fundamental relative-order unit and norm3 obstruction prove unique simple facet J at the R/J tie. Full911-line chain and279-line outside report; all unknown walls included. Prepared Y worker unexecuted/unused. No ambient volume, period or new example. |
| [Actual R7 facet and old-U edge](../results/review_h9_prime41_actual_r7_firstness_old_u_and_nonoriginal_maps_root_acceptance_20261024.md); [new50-entry outer gap](../results/review_h9_prime41_after_r7_fifty_entry_outer_gap_root_acceptance_20261024.md) | Construction research | Complete original11-to-six profile reduction and closed two-embedding strips prove unique actual R7, full D7+2A1 and old-U continuation to D6+3A1. All four direct germ maps are nonoriginal. Full349/262-line source/review; new197/204-line gap proof/review includes every R7/F-image sign. The enlarged recorded relaxation has infinite volume; full-chamber volume and an example remain open. No jobs. |
| [Entire D18 isolated/isolated family excluded](../results/review_compact18_d18_whole_isolated_isolated_pair_root_acceptance_20261023.md) | General compact | Actual distant far-side endpoint, exhaustive full germs, fresh A17+A1/A18 comparisons and one individually funded square; combines the new dotted case with all earlier mutuals. Full436-line proof,254-line outside report and12 pins accepted. No17 or new Lean scope. |
| [Isolated native5 D18 head excluded](../results/review_compact18_d18_isolated_native5_head_complete_exclusion_root_acceptance_20261023.md) | General compact | Exact three-pair cover plus complete pair exclusions; the new [far3 interval](../results/review_compact18_d18_isolated_far_three_dotted_native5_interval_root_acceptance_20261023.md) renews every local scalar at1.28. Entire62-line conjunction and91-line outside report, five accepted inputs. Selected original isolated-head profile only; no17. |
| [Six central bridges excluded](../results/review_compact18_d18_central_bridge_six_configurations_root_full_source_acceptance_20261024.md) | General compact | Fresh actual bridge lengths, positive affine nulls and two explicit positive-vector certificates use original S16 pressure. Full167-line other-author root review, three pins. Independent of the unreviewed35-profile cover/worker; no17 or execution. |
| [Complete centre row5 financing](../results/review_finite57_positive_row_five_two_corner_refund_root_full_source_acceptance_20261023.md) | General finite volume | BOTH PSD corners and original Schur forms prove two actual polygons have>=5 sides, retaining remote contacts. Refund2/transfer6 gives source364 and unique B21 receiver364. Full352-line other-author root review and15 pins; all rank/exchange row5 cases close with earlier rules. No universal364 or56. |
| [Complete centre row11 financing](../results/review_finite57_whole_positive_row_eleven_refund_root_full_source_acceptance_20261023.md) | General finite volume | Small E roles stay in the Schur cover; an affine-corner own polynomial handles d.c=-1. Three/two refunds plus five/six transfers preserve every old debt, fixed token and residual-T credit. Full322-line other-author root review and15 pins; literal heavy forest only, no56. |
| [Fourth-order transverse Gram obstruction](../results/review_spectral_frog_fourth_order_transverse_schur_root_acceptance_20261023.md) | General compact, method | At the SAME all-wall maximum, a singular-safe Schur optimization strengthens the null-direction fourth moment. Exact compact acute fixed-stationary-point independence example. Full287-line proof and211-line outside review; no numerical or historical-novelty claim. |
| [Actual prime41 E6+B2 unit edge](../results/review_h9_prime41_e6_b2_actual_unit_wall_and_full_endpoint_root_acceptance_20261023.md) | Construction research | Four actual admitted units establish complete five-profile firstness, an original norm2 facet and full E6+B2+A1 endpoint. Full227-line interpretation and243-line source/data review;16 direct/14 live pins. Unknown-wall firstness is from complete coverage. No ambient volume, period or example. |
| [Whole arithmetic B16 excluded](../results/review_arithmetic16_whole_b16_complete_census_and_reference_root_acceptance_20261023.md) | Compact arithmetic | Complete actual-field reduction, uniform cubic argument, four actual exact quadratic census units, then one original-vector square. The census has one necessary pair, excluded geometrically. The first scalar compile failure is preserved; the repaired source now has an [actual twelve-declaration compile and separate audit PASS](../results/lean_b16_isolated_pair_scalar_verification_20261023/manifest.json), with field/census/geometry inputs external. |
| [Whole A14 excluded](../results/review_arithmetic16_whole_a14_ordinary_rank_two_root_acceptance_and_seven_group_frontier_20261023.md) | Compact arithmetic | Typed-seven endpoint laws close both defect cases. The ordinary branch uses complete actual-field reduction, integral endpoint tests and one rebuilt reference retaining all earlier foot corrections. Full written review; no new global ceiling or geometric Lean verification. |
| Both A10 groups and A11+actualI+T4 excluded; [whole A15+A1 excluded; the earlier three-group stage](../results/review_arithmetic16_whole_a15_complete_opposite_composition_root_acceptance_and_three_group_frontier_20261023.md) | Compact arithmetic | The same geometric budget gains a two/three-cycle cancellation. Uniform dyadic and norm arguments handle every field; complete isolated/nonisolated opposite proofs reassemble one legally funded reference before taking its norm. Full written source and conjunction reviews; no new global ceiling or geometric Lean scope. |
| [Whole B18 excluded; only wholeD18 remains necessary](../results/review_compact18_whole_b18_complete_composition_and_single_d18_frontier_root_acceptance_20261023.md); [D18 center16 is strong](../results/review_compact18_d18_zero_own_fork_neighbor_and_unconditional_strong16_root_acceptance_20261023.md) | General compact | Actual neighbors retain explicit comparison factors from the original maximum. Fresh inventories, packing and one funded reference close the last B18 role; a separate complete conjunction covers every terminal role. WholeD18 and compact17 remain open. Full written review; older Lean scopes stay separate. |
| [D18 fork lengths<9.64 and two pair-family exclusions](../results/review_compact18_d18_terminal_slack_a18_neighbor_fork_pairs_root_acceptance_20261023.md) | General compact | The same reference retains its terminal surplus. A generic actual-A18 lemma with its comparison factor handles neighbors; full acuteness and native-gap arguments handle both-near3 and, under native5 head, near3/far3. Remaining pairs and wholeD18 stay open. |
| [D18 isolated owns<15/8](../results/review_compact18_d18_fifteen_eighths_isolated_cutoff_root_acceptance_20261023.md); [native5 head forces an isolated fork](../results/review_compact18_d18_actual_a17_a1_isolated_cutoff_native5_far_pair_root_acceptance_20261023.md) | General compact | Actual A17+A1 geometry with factor8/5, a complete unequal-chain inventory and one paired reference. The earlier far/far core retains the full first-coordinate cross. Full written reviews; remaining fork families and wholeD18 are open, with no new Lean claim. |
| [Complete whole-D16 exclusion and GLOBAL arithmetic15](../results/review_arithmetic16_whole_d16_manual_dyadic_exclusion_and_global15_root_acceptance_20261023.md) | Compact arithmetic | The prior complete frontier leaves only wholeD16. Actual geometry forces a quadratic DOT head and two isolated DOT forks; every inert/ramified/split2 case fails original cycles, a full K-square test or one original-vector budget. Full445-line proof and306-line different-author review; the prepared census is unexecuted and not a premise. |
| [Actual quadratic head and both isolated forks](../results/review_arithmetic16_whole_d16_actual_quadratic_dotted_head_both_isolated_forks_root_acceptance_20261023.md) | Compact arithmetic | Complete finite-head, endpoint-fork and cubic exclusions supply the exact geometric interface for the final dyadic proof. Full written review; the new discrete Lean kernel keeps this geometry and the field tables external. |
| Isolated-fork pairs: [finite nonright mutuals excluded](../results/review_compact18_d18_all_head_finite_isolated_pair_actual_a16_neighbor_root_full_source_acceptance_20261023.md), then [orthogonal mutuals excluded](../results/review_compact18_d18_orthogonal_isolated_pair_root_full_source_acceptance_20261023.md) | General compact | Actual A16+I2 and A15+I2+A1 neighbors retain explicit losses from the original maximum and one norm budget there. Full written reviews; dotted pairs and wholeD18 remain open. |
| [D18 dotted-mutual gap](../results/review_compact18_d18_isolated_fork_mutual_four_thirds_gap_root_full_source_acceptance_20261023.md), and [isolated/near3 finite-mutual exclusion](../results/review_compact18_d18_isolated_near_three_finite_mutual_root_full_source_acceptance_20261023.md) | General compact | An actual future negative core excludes1<mutual<=4/3 for two isolated forks; surviving dotted pairs have both owns dotted and product>7/3. The asymmetric near3 proof uses an actual neighbor. Other roles remain; no compact17 or new Lean scope. |
| [Entire D18 isolated/near3 family excluded](../results/review_compact18_d18_whole_isolated_near_three_family_root_acceptance_20261023.md) | General compact | Finite-mutual, actual future-core dotted and actual A16+2A1 orthogonal arguments compose for every head, signed fork and unequal own parameter. Both reverse coordinates, full two-A1 costs and one norm budget are retained. Full written reviews; isolated/far3 and dotted isolated/isolated pairs remain, with no compact17 or new Lean scope. |
| [D18 isolated/far3 finite-mutual reduction](../results/review_compact18_d18_isolated_far_three_complete_finite_reduction_root_acceptance_20261023.md) | General compact | Exact Minkowski and original-coordinate constraints, actual B18/H3 points, positive affine nulls and a full continuous finite7+ seal exclude0, all finite labels>=4, parallel and both finite owns. At that stage native3/DOT remained for all heads; native5 head left DOT only. Full344-line source and199-line outside review,7 matched pins; no whole-family exclusion or compact17. |
| [D18 isolated/far3 native3 excluded](../results/review_compact18_d18_isolated_far_three_native_three_two_dual_root_acceptance_20261023.md) | General compact | An actual A18 neighbor retains factor8/7 and the full positive TWO-end-dual reverse direction. Fresh .71 geometry and an all-hole reference fund one joint graft, giving norm>1.04285 or>1.02385. Full364-line proof and235-line outside review,7 pins matched. Only dotted mutuals remain for this pair; no compact17 or new Lean scope. |
| [Fresh arithmetic15 necessary cover](../results/review_arithmetic15_fresh_complete_twenty_two_group_frontier_root_full_source_acceptance_20261023.md) | Compact arithmetic | Direct total-rank15 partition exhaustion and actual H4 estimates give the original22-group cover. Complete B14+I, B13, D13 and A13-typed results remove original19,17,18,14, leaving18 at that stage. No rank16 decrement, realized example,14 bound or new Lean instance. |
| [Whole B14+actual I excluded](../results/review_arithmetic15_whole_b14_actual_i_all_degree_manual_root_acceptance_20261023.md) | Compact arithmetic | Complete head/short reductions, one joint scalar, cubic integer obstructions and full quadratic strips/relative-scale/time-square tests exclude every field. Full610-line source and277-line outside review, with one preserved exponent correction. Original19 is removed; the later B13 theorem left20 groups at that stage, with no new global ceiling, execution or Lean credit. |
| [Entire B13 rank-two group excluded](../results/review_arithmetic15_b13_ordinary_and_typed_seven_whole_group17_root_acceptance_20261023.md) | Compact arithmetic | Ordinary spectators use only fresh6..10 and one funded head graft, with tight total>1.00241. Actual typed-seven spectators have a fresh11/12 field/cycle catalogue before the E12 head estimate1.00859. Full452-line source and288-line outside review, all15 pins matched; original17 removed,20 groups remained at that stage. No14 or new Lean instance. |
| [D13 ordinary rank-two subcase excluded](../results/review_arithmetic15_d13_ordinary_rank_two_root_acceptance_20261023.md) | Compact arithmetic | Fresh D4/D3 body through10 and a direct retained-D12 head proof preserve both signed forks, every foreign cost and one paid reference. Full264-line source and188-line outside review, all10 pins matched. At that stage original18 retained actual N7/O7 only. Independent of B13, with no14 or new Lean credit. |
| [Complete D13 typed cases and whole group18 excluded](../results/review_arithmetic15_d13_both_actual_typed_seven_and_whole_group18_root_acceptance_20261023.md) | Compact arithmetic | Full K7 coefficient strips, all seven actual fork whites and a dyadic obstruction force BOTH cosh lengths>6. Signed pressures and exact omitted11 loss<1/20000 supply one reference with head total>1.00854. Full448-line proof and287-line outside review,10 matched pins. Ordinary/typed conjunction removes18;19 groups remained at that stage. No14, execution or new Lean instance. |
| [A13 with either actual typed-seven defect excluded](../results/review_arithmetic15_a13_both_actual_typed_seven_whole_group14_root_acceptance_20261023.md) | Compact arithmetic | The accepted same-rank .574 central theorem is retained. New complete endpoint/foreign/native and denominator13 arguments give both endpoints>.53; one simultaneous two-block reference gives total>1.026465267. Full373-line proof and257-line outside review,8 matched pins. Original14 removed;18 groups remained at that stage. Extra spectator costs are outside this theorem; no14 or new Lean scope. |
| [Four complete typed-seven A groups excluded](../results/review_arithmetic15_four_typed_seven_a_families_full_foreign_root_acceptance_20261023.md) | Compact arithmetic | Fresh A9..A12 central rules and complete endpoint alphabets retain every extra spectator cost, including nonrational A1 values. One modified reference covers each full forest. Full424-line source,259-line outside report and12 pins accepted. Removes original2,5,8,11, leaving14 necessary groups; no numerical14 ceiling or execution. |
| [A13 plus two ordinary A1s excluded](../results/review_arithmetic15_a13_two_ordinary_a1_root_full_source_acceptance_20261023.md) | Compact arithmetic | After the accepted all-field A13 estimate, an exact shadow square or simultaneous two-cap projection forces joint A1 energy>1/4. Full195-line proof and7 pins have other-author root review and acceptance. Original12 retains ordinary irreducible T2; the14-group count stays. No new Lean scope. |
| [Compact full-wall spectral band](../results/review_spectral_frog_canonical_lorentz_gram_band_root_full_source_acceptance_20261023.md) | General compact, exploratory tool | Maximizing the actual wall-height product gives a positive Gram scaling B with spectrum{-1,0} union[1,infinity), hence B³-B positive semidefinite and exact weighted triangle inequalities. Full265-line manual proof has other-author root review. Unknown-wall terms prevent a local dimension deduction so far; no new bound, computation or historical-novelty claim. |
| [Complete D15+actual-I exclusion](../results/review_arithmetic16_d15_actual_i_complete_fork_and_all_degree_exclusion_root_acceptance_20261023.md) | Compact arithmetic | Both signed fork lengths are bounded before classification. Actual K-generators and all-degree norm/valuation arguments exclude every isolated cap; a complete white/foreign catalogue and a norm-two ideal lemma exclude all nonisolated caps. Two full source reviews and root acceptance, with a byte-preserved price-wording precision. No new census execution or geometric Lean instance. |
| [Complete B15+actual-I exclusion](../results/review_arithmetic16_b15_actual_i_complete_terminal_and_all_degree_exclusion_root_acceptance_20261023.md) | Compact arithmetic | Complete short-cap and foreign-head dispatch leaves one pure dotted pair in actual degree2/3. Integer norms close every cubic field; the full quadratic I strip and two final field seals close the rest using one original reference. Both complete stage reviews and root acceptance; no new field-enumeration execution or geometric Lean instance. |
| [Positive native-six weighting](../results/review_finite57_native_six_positive_weighting_flags_and_single_factor_receiver_root_acceptance_20261023.md) and [ALL native-six finite budgets](../results/review_finite57_all_single_native_six_finite_budgets_root_acceptance_20261023.md) | General finite volume | Exact weighted incidence and matched Context conservation, then formal same-rank replacements, a rational certificate and complete finite remainders. EVERY finite vertex containing native6 is financed with all old tokens retained. Other heavy vertices and face coverage remain; the later complete ideal theorem below closes its separate obligation. Full written reviews; no global56. |
| [All selected old weighted ideal debts](../results/review_finite57_native_six_all_old_ideal_debts_root_full_source_acceptance_20261023.md) and [complete actual ideal-budget conjunction](../results/review_finite57_native_six_complete_weighted_ideal_budgets_root_acceptance_20261023.md) | General finite volume | Actual inert-port covariance, complete Context partition, priority savings and original fixed tokens reduce ideal budgets to the bare small-factor domain. Actual generation and SEPARATE full same-implementation replay now pass:6626/6626 positive cases,862 profiles,6656 records. Each unit<1second/<55MiB RSS. Full source/output/composition review closes ALL selected weighted ideal budgets; finite heavy sources and face coverage remain. No56 or new Lean instance. |
| [Strict weighted global comparison](../results/review_finite57_native_six_weighted_global_extrema_strictness_root_acceptance_20261023.md) | General finite volume | Actual weighted link graphs and the two global extrema give correction280*(2/3)^28. Full source review; the contradiction remains conditional on one complete weighted face rule, conservation and all vertex caps. No56 or new Lean instance. |
| [Every zero-exchanged far-row8 source financed](../results/review_finite57_zero_exchanged_far8_all_corner_refund_one_unit_root_acceptance_20261023.md) | General finite volume | Both PSD corner restrictions and fifteen full-Gram/native-gap cases force selected actual polygons to have at least five sides. Eight real corner refunds, or seven plus one globally bounded arrival at a363 receiver, retain every old debt. Full395-line source and272-line outside review; no next-wall/isolation/DOT-width assumption, global56 or new Lean credit. |
| [All positive-exchange far8 sources financed](../results/review_finite57_all_far8_positive_exchange_normalized_refund_root_acceptance_20261023.md) | General finite volume | Normalized full-Gram equations retain every actual positive contact and the native gap. ONE receiver port is shared across the accepted zero/positive union, with every old debt and fixed-face residual retained. Full written reviews; other heavy configurations and global56 remain open. |
| [Arbitrary large inert-D factors at a D17 far8 source](../results/review_finite57_whole_d17_large_inert_d_far8_refund_root_acceptance_20261023.md) | General finite volume | Whole D17 plus any inert D-factors of ranks>=9 and total40, conditional on an actual qualifying centre. Both PSD restrictions and all fifteen profiles give eight corner refunds. The complete old D40+D17 load2177/6<364 is retained. Does not force a centre, realize a forest or prove56; no new execution/Lean scope. |
| [All finite-factor shape minima and smoothed ideal comparison](../results/review_finite57_native_six_all_finite_minima_smoothed_ideal_root_acceptance_20261023.md) | General finite volume | An exact completed square handles every native-six factor count and its parity. Discrete product-link distributions and conditioning compare original ideal envelopes when another factor has rank>=13. Full written review; actual weighted charge maxima, low-rank ideal profiles, absolute old loads and extrema remain separate. No global56. |
| Far-row8 isolated [contacts3/4/parallel](../results/review_finite57_far_row8_isolated_intervening_cusp_financing_root_acceptance_20261023.md), [orthogonal contact](../results/review_finite57_far_row8_orthogonal_isolated_b4_cusp_financing_root_acceptance_20261023.md), and [affected-D23 finite contacts](../results/review_finite57_far_row8_d23_finite_a21_dihedral_receiver_root_acceptance_20261023.md) are financed | General finite volume | Actual full-rank cusps or a unique finite receiver; complete original-source counts retain every prior debt and one residual rule. The old unweighted affected-D17 receiver has a4.5-unit deficit; its selected native-six case is financed by the newer weighted rule. Manual proof and full source review; no global56. |

The same finite-volume family includes the
[explicit special-face restriction](../results/review_finite57_special_native_bond_compact_face_and_label_restriction_root_acceptance_20261023.md)
and its [all-actual-facet extension](../results/review_finite57_all_actual_facet_finite_bonds_root_acceptance_20261024.md).
A native5 or native7+ bond between any actual facets forces a compact Coxeter
codimension-two face, giving derived ceiling31 from published compact29,
or20 from internal compact18. This is a restricted corollary and a
finite57 label reduction, not a new global finite-volume bound or paper.
The [native6 local port obstruction](../results/review_finite57_native_six_unbounded_same_face_local_ports_root_full_source_acceptance_20261023.md)
rules out a count based only on a shared face and cusp. Its constructed
regions have infinite volume; the finite-volume financing problem and
every prior debt remain open. This is a research boundary within the
same family, with no new manuscript or improved global ceiling.

The [prime41 ambient edge continuation](../results/review_h9_prime41_ambient_d6_pentagon_mixed_d4_original_obstructions_root_acceptance_20261023.md)
is construction research rather than a seventh paper: three new actual
wall censuses, one full H3+D4+A1+[2b41] endpoint and a whole right
pentagon, with original-map obstructions. Ambient volume and an infinite
period remain open; the local theorem constructs no finite-volume example.
The [next two actual edges](../results/review_h9_prime41_mixed_d4_two_actual_edges_b2_double_h3_root_acceptance_20261023.md)
reach full2H3+B2+[2b41] through complete six/nine-profile first-wall
censuses. The repeated germ still has no original integral swap.
Two new [norm2](../results/review_h9_prime41_known_outer_gap_actual_e6_unit_cutter_root_full_source_acceptance_20261023.md)
and [norm4](../results/review_h9_prime41_initial_e6_a2_actual_norm_four_b3_edge_root_full_source_acceptance_20261023.md)
facets have complete original-module firstness proofs and cut explicit
open directions of successive known-wall outer polyhedra. Full chamber
volume and a new example remain unproved.
The [next edge terminates finitely](../results/review_h9_prime41_e6_b3_e2_relative_unit_termination_five_profiles_root_acceptance_20261023.md)
by an original relative-unit and index12 congruence argument. Its complete
five-profile [witness/firstness contract and worker](../results/review_h9_prime41_e6_b2_witness_firstness_worker_contract_root_preexecution_clearance_20261023.md)
had full source clearance. Four [actual witness/replay/complete-firstness/combine units](../results/h9_prime41_e6_b2_firstness_verification_20261023.json) now establish the original norm2 W and full finite E6+B2+A1 endpoint after full source/data review and root acceptance. The further [manual Y-release proof](../results/review_h9_prime41_y_release_manual_h3_full_chain_root_acceptance_20261024.md) reaches E6+H3 without using its prepared worker. On a separate original-g branch, the [actual R7 proof](../results/review_h9_prime41_actual_r7_firstness_old_u_and_nonoriginal_maps_root_acceptance_20261024.md) reaches D7+2A1 and a genuine old-U edge to D6+3A1. A [new mixed gap](../results/review_h9_prime41_after_r7_fifty_entry_outer_gap_root_acceptance_20261024.md) proves infinite volume only for the enlarged50-entry recorded relaxation. Full chamber volume and a new example remain open.

These are supporting proofs and algorithm contracts, not new manuscripts.
The [existential omega-seven order-unit theorem](../results/review_h9_prime41_omega_seven_gap_original_upper_six_profiles_root_acceptance_20261024.md)
is an alternative original finite-upper argument; the later explicit R7
proof does not need it. It stays supporting construction material.
The frozen PDFs retain their six accepted editions. Historical frontiers
below record their dated scopes; the current lists are in the
[bounds guide](current_bounds_and_verification.md).

The later [parallel short-fork financing theorem](../results/review_finite57_isolated_parallel_short_fork_financing_root_acceptance_20261022.md)
also belongs in the finite-volume paper's local-to-global argument. It
adds seven actual receiving cusp families with compatible full8 transfers;
it neither changes the PDF's57 theorem nor supplies global coverage for56.
The accepted [merged short-fork matching](../results/review_finite57_merged_short_fork_matching_root_acceptance_20261023.md)
adds the private-receiver or two-neighbor selected domain, retaining the
partial pentagon rule. It belongs in the same paper and does not prove56.

A written review is an internal audit at declared premises. It is not
external refereeing, an independent reproduction of every finite input,
or formalization of all geometric steps.


The [whole compact quadrilateral theorem](../results/review_h9_prime41_double_h3_whole_compact_quadrilateral_root_full_source_acceptance_20261023.md)
now closes the two-face retaining both H3 factors and N, by two further
original unit edges and a direct positive projection to an old actual
wall. Its angles are pi/4,pi/2,pi/2,pi/2 and its area is pi/4.
The all-wall and intrinsic-face proof has full written review. Ambient
volume and a new H9 example remain open; this stays construction research.

## Shared methods and consolidation

The latest [compact eighteen acceptance](../results/compact_dimension18_global_written_acceptance_20261022.json)
closes all six D19 head branches and the complete exact-dimension19 frontier,
then uses the independent previous global19 tail. This belongs in the same
compact paper. The historical checkpoint notes below explain inherited
proof dependencies; their former surviving lists are not current frontiers.

The [complete general18 A16 closure](../results/review_compact18_whole_a16_row_root_acceptance_20261022.md)
belongs in this same compact paper: actual endpoint walls and two legal
residual payments eliminate both typed-seven spectators. The later
[universal A12 energy theorem](../results/review_compact_a12_point65_and_general18_eight_groups_root_acceptance_20261022.md)
uses fresh N13 nonadjacency and one paid actual helper, with arbitrary
spectators and no arithmeticity. It closes the entire A12 row, leaving
eight general18 groups after the earlier A15/A16 closures. The later
[complete D16 typed-seven proof](../results/review_compact18_whole_d16_typed_seven_root_acceptance_and_seven_group_frontier_20261022.md)
combines fresh tails, a native-angle head gap and adaptive centre pressures
in one funded vector. The later
[complete B16 typed-seven proof](../results/review_compact18_whole_b16_typed_seven_root_acceptance_and_six_group_frontier_20261023.md)
adds fresh short-end geometry and an actual neighboring A16 endpoint,
leaving six groups. All belong in the same general compact paper; these
geometric proofs remain written inputs. The later [complete A17 acceptance](../results/review_compact18_whole_a17_actual_i_and_five_group_frontier_root_acceptance_20261023.md)
and [ordinary D17 exclusion](../results/review_compact18_d17_ordinary_rank_one_root_acceptance_20261023.md)
leave FIVE groups: whole A18, B17+actual I, whole B18, D17+actual I and
whole D18. The [A18 analytic endpoint theorem](../results/review_compact18_a18_paired_finite_analytic_root_acceptance_20261023.md)
also closes the two-isolated-finite-endpoint branch. These belong in the
same compact paper. Their [new endpoint logic/arithmetic map](general_eighteen_endpoint_refinement_logic_20261023.md)
records a [bounded compile and separate eleven-declaration audit PASS](../results/lean_general18_endpoint_refinement_verification_20261023/manifest.json)
for the five-case logic and literal finite integer seals, with geometric
and analytic bridges external. The EARLIER
[six-group conditional frontier logic](general_eighteen_frontier_refinement_logic_20261023.md)
has a [bounded compile and separate six-declaration audit PASS](../results/lean_general18_six_group_frontier_verification_20261023/manifest.json)
under nine explicit written premises, without a geometric instance or
global17 conclusion.
The general component
[dihedral floor above3/19](../results/review_compact_ordinary_dihedral_three_nineteenths_root_acceptance_20261022.md)
belongs with its ordinary component estimates. Its arithmetic D14 consumer
belongs in the arithmetic paper. Together with the
[complete typed-D14 proof](../results/review_arithmetic16_whole_d14_root_acceptance_and_thirteen_group_frontier_20261022.md),
it closes that whole dimension16 row, leaving thirteen groups. These results
do not create another paper or change
the frozen PDF statements.

In the arithmetic seventeen research, the
[complete D16+actual-I exclusion](../results/arithmetic17_d16_actual_i_complete_exclusion_composition_20261022.md)
now combines the actual-degree reduction with complete quadratic, cubic
and quartic contradictions. Its [full review and root acceptance](../results/d16_actual_i_exclusion_and_finite57_hexagon_root_acceptance_20261022.md)
remove that ENTIRE forest. The later
[whole-D17 composition](../results/arithmetic17_whole_d17_complete_quadratic_census_and_coupled_energy_exclusion_candidate_20261022.md)
and its [full review/root acceptance](../results/review_arithmetic17_whole_d17_complete_exclusion_root_acceptance_20261022.md)
now exclude whole D17 as well. Its
complete36-field/120-pair census retains two configurations; the common
head/fork metric budget excludes both. Four actual guarded units passed;
a [new scalar kernel](../results/lean_classical17_census_verification_20261022/manifest.json)
also compiled and passed a separate four-declaration audit. Geometry,
complete enumeration and paid-reference applicability remain written
premises. These belong in the
same arithmetic paper family; at that stage the global ceiling remained17 and PDF20.
The later [complete B17 exclusion](../results/review_arithmetic17_whole_b17_complete_exclusion_root_acceptance_20261022.md)
has full internal source/composition review, including its substantive
finite-head repair and derived census applicability. This left whole A17;
its [accepted endpoint theorem](../results/review_arithmetic17_whole_a17_endpoint_reduction_root_acceptance_20261022.md)
isolates both ends, excludes the golden field and proves both edge cosh
lengths below2.1. These supporting results belong in the SAME arithmetic
paper, without changing its printed20 theorem.
The later [four-field reduction](../results/review_arithmetic17_whole_a17_four_actual_fields_root_acceptance_20261022.md)
uses one funded two-endpoint norm argument and complete native conjugates.
The [accepted quadratic census exclusion](../results/review_arithmetic17_whole_a17_quadratic_exclusion_root_acceptance_20261022.md)
has four actual bounded units, complete replay and full runtime/composition
review. This left A17 over K7 or K9. The
[actual cubic census](../results/a17_finite_cubic_endpoint_runtime_manifest_20261022.json)
now has two field units and a separate all-record replay: all2,432
coefficient triples were checked, leaving zero survivors. The
[full runtime review](../results/review_a17_finite_cubic_endpoint_actual_runtime_and_conditional_exclusion_foundations_20261022.md)
and [final global composition acceptance](../results/review_arithmetic17_whole_a17_global16_complete_composition_root_acceptance_20261022.md)
bind the complete evidence and fourteen-group subtraction. Together with
the prior global17 higher-dimensional tail this proves the written
arithmetic ceiling16. The final16 conditional composition now has
[bounded Lean compilation and a separate three-declaration audit PASS](../results/lean_arithmetic16_composition_verification_20261022/manifest.json);
its [logic map](arithmetic_dimension_sixteen_composition_logic_20261022.md)
keeps27 geometric/arithmetic/data inputs explicit, with no geometric instance.
All of this belongs in the same arithmetic paper; no separate paper is
created for an intermediate bound, and all six printed editions stay frozen.

The next [fresh exact-dimension16 frontier and accepted refinements](../results/review_arithmetic16_whole_a16_and_universal_a3_root_acceptance_20261022.md)
leave **thirteen necessary groups**, after six whole-group exclusions
and the selected A14+actual-I+ordinary-A1 subcase from the original
nineteen-group list. The new arguments close D13 with rank-three
spectators, ordinary-rank-five A11, B14 with either actual typed-seven
defect, whole A16 and A11+O7+A3. They belong in the same compact arithmetic
proof family. The reusable statements are arithmetic A11 energy above13/20
with arbitrary spectators and all retained feet, the **nonarithmetic** A3
energy above13/50, and a whole-A16 actual endpoint/finite-anchor argument.
The [comparison guide](current_bounds_and_verification.md) gives the exact
remaining list and typed meanings. This is not a new global dimension15
bound. A separate [conditional frontier kernel](arithmetic_sixteen_frontier_refinement_logic_20261022.md)
now has a [bounded compile and separate six-declaration axiom audit PASS](../results/lean_arithmetic16_frontier_thirteen_group_verification_20261022/manifest.json)
under nine explicit written interfaces. The first failed compile and
pre-child RAM refusal are preserved; the existing
final16 three-declaration Lean PASS under27 external premises is unchanged.

The [separate D16/I and hexagon acceptance](../results/d16_actual_i_exclusion_and_finite57_hexagon_root_acceptance_20261022.md)
records a new
[all-heavy-hexagon financing theorem](../results/finite57_heavy_hexagon_nonadjacent_affine_cusp_global_discharge_candidate_20261022.md):
actual nonadjacent cusps receive the heavy-vertex deficits with complete
preimage counts and prior-debt accounting. This is supporting research
for the finite-volume paper. Other face configurations and costly forests
remain open, so it does not yet replace57 by56 or add a manuscript.
The [later pentagon union](../results/review_finite57_two_or_three_heavy_pentagon_union_root_acceptance_20261022.md)
covers its complete two-/three-heavy zero-payment domain with actual
receivers and bounded multiplicities, replacing its three-heavy predecessor
on overlap. It belongs in the same finite-volume family; one-heavy cases
and complete global coverage remain open.

The six-paper writing milestone is complete. The latest
[completion confirmation](../results/six_paper_completion_confirmation_20261021.json)
and [integrity review](../results/review_six_paper_completion_confirmation_integrity_compact_reviewer_20261021.md)
match all eighteen source/PDF/build bindings and preserve the excluded
refinements. New research does not add a seventh manuscript.

The two angle-payment papers each state the local-to-global mechanism
before introducing their different arithmetic and cusp reductions.
The compact farthest-point method is a separate approach and has its own
paper. The stronger compact eighteen/sixteen results belong in the
same general/arithmetic paper families; they should replace the old arguments
coherently rather than append chapters for successive increments.
The [architecture guide](paper_architecture.md) gives that division and
the intended order of exposition.

The [earlier reviewed research batch](../results/a_family_and_prime79_frontier_continuations_acceptance_20261021.json)
removes the general nineteen A16 family, every arithmetic seventeen A12
family, its A11+typed7 branch, and the typed7/two-ordinary-A1 A15 branches.
These belong to the same farthest-point/arithmetic paper families. The
reduced necessary lists then had eight and eleven grouped rows; the global
ceilings at that checkpoint remained nineteen/seventeen, and the PDFs still prove twenty-three/
twenty. The new cubic-field half-loss argument is a case-specific refinement
after the common actual-vector geometry; it is not another dimension paper.
The [previous endpoint batch](../results/endpoint_case_exclusions_and_prime79_interval_acceptance_20261021.json)
closes the general A17 row, the ordinary-A1 choice beside general A18,
and the arithmetic A15/A16 rows. The [previous accepted batch](../results/a14_a18_and_prime79_period_acceptance_20261021.json)
also closes the last general A18 companion and every arithmetic A14 case,
leaving six and eight necessary groups at that checkpoint. The ceilings then remained nineteen and
seventeen, and the six printed editions are unchanged. Its restricted
large-D quadrilateral theorem supplies no charge372 improvement.

The same batch closes the literal norm79 construction host by an integral
period between two full actual D9 germs, with explicit geometric/arithmetic
premises and separate END0 and two-map execution records. This is a
literal-module nonreflectivity result, not a field/form-class exclusion,
new example or additional manuscript; an END8 search is unnecessary.

The [previous written batch](../results/b18_a11_and_restricted_continuations_acceptance_20261021.json)
excludes general B18+actual-I and arithmetic A11+actual-I+(A5 or D5),
leaving five and seven necessary groups. These stay within the same two
compact paper families. Its
[five-result evidence map](../results/publication_b18_a11_batch_evidence_map_20261021.md)
also assigns the local D18+I tail argument to general compact geometry,
the full D16 cusp allocation to finite57, and the good-prime odd-glue
reduction to the construction lane. None is a new manuscript, lower global
ceiling, realized example or newly executed Lean proof. The unchanged six
editions retain their stated results and page counts.

The [previous accepted batch](../results/d18_exclusion_b16_reduction_and_prime239_first_edge_acceptance_20261021.json)
adds the complete general D18+I exclusion, leaving four general19 and
seven arithmetic17 groups. Its B16 short-opposite reduction refines an
open arithmetic group rather than removing it. These belong in the two
existing compact paper families. The restricted cheap-third-corner
quadrilateral belongs in finite57, and the norm239 first edge belongs
in the construction lane. All four have complete source-bound written
reviews; none is an additional manuscript, new global ceiling or example.

The [previous accepted batch](../results/d17_typed7_cubic_b16_and_prime239_transverse_acceptance_20261022.json)
closes general D17+either actual typed7, leaving only whole A19, B19
and D19 at nineteen. This is the same general compact prefix/actual-point
method. Its arithmetic B16+I cubic exclusion adds a complete integral-basis
strip after the common actual-field reduction, within the arithmetic
paper family. At that checkpoint the quadratic branch and all seven
arithmetic groups remained open. The next norm239 edge belongs in construction research,
not a seventh manuscript. These results have complete source-bound
written reviews, with no new scientific runtime or Lean credit.

The next [accepted batch](../results/quadratic_b16_b19_and_rank_transfer_acceptance_20261022.json)
closes that quadratic branch and hence the entire arithmetic B16+I
forest. The [previous batch](../results/b15_b19_short4_and_prime239_e7_a2_acceptance_20261022.json)
also excludes B15 with either actual typed7, leaving five arithmetic
groups. The relative-length cancellation, invariant cycles and complete
same-field strips belong in the arithmetic compact paper. Its B15
argument instead uses the actual cubic-seven field and long-head feet.

The [previous batch](../results/d15_d16_and_norm239_progress_acceptance_20261022.json)
also excludes D15+either actual typed7 and the ordinary nonshort D16+A1
branch. Its common method is the original-vector prefix reference with
actual head/centre feet and shared spectator funding. At that checkpoint
four arithmetic rows remained, including the now-excluded D16+actual-I.
This belongs in the arithmetic
compact paper; it adds no manuscript and lowers no global ceiling.
The [previous A19 batch](../results/whole_a19_exclusion_and_construction_progress_acceptance_20261022.json)
closes the zero-weak-end case too: the three A19 cases now exclude the
whole forest. These joint-foot proofs and the D19 head reductions belong
in the existing general compact argument, whose dimension ceiling
at that checkpoint remained nineteen, with only D19 in its necessary list.
The D19 old-.61 strong5 proof adds an explicit rational supporting
vector using an actual foot, a weak upper bound and the chamber sign.
It supplies no whole-D19 contradiction or unconditional late floors.

The necessary B19 reduction and exclusion of its short4 terminal wall
belong in general compact geometry. The common method is the original
vector prefix reference; the new branch audits a smaller loss at one
index and pools slopes before raising its floor. The
[final accepted short3 exclusion](../results/whole_b19_exclusion_acceptance_20261022.json)
then closes the whole B19 forest through a fresh loss.50 audit at that
same index. These are parts of one coherent general compact argument,
not separate manuscripts. Whole A19 and D19 remained at that checkpoint;
the later three-case A19 composition leaves D19 alone.
The stronger353.640625 restricted third-corner bound belongs
in finite57, with the global allocation still open. None adds a manuscript.

The third norm239 edge belongs in construction research. Its proof states
the complete finite domain, algorithm, termination and firstness argument,
then the actual twenty-unit output and direct original-coordinate check.
It proves a full E7+A2 germ, not chamber completion or a polytope example.

The fourth and fifth norm239 edges likewise remain construction research.
Their complete finite-domain proofs have separate actual20-unit and15-unit
executions, separate combiners and full mathematical/runtime reviews.
The fifth full germ is E8+A1 with the actual norm2b spectator. The
subsequent accepted original-module isometry proof maps the FULL
outward base germ to that full fifth germ, proves integrality and
future preservation, and gives an infinite-order chamber symmetry.
The arithmetic index/covolume theorem then proves this literal
norm239 lattice nonreflective. This is construction research, with
no field/form-class exclusion or new example.

The distinct norm379 first binary edge and
[accepted first transverse edge](../results/review_prime379_first_transverse_wall_full_germ_root_acceptance_20261022.md)
also belong in construction research. The proof keeps the original
index-two glue, quarter-integral signed boosts, all five profiles and
eleven nearest phases. The five actual units and separate combination
cover21,835 scalar rows and identify a full E7+I2(5) germ. The next
[released-m edge](../results/compact_h9_prime379_third_edge_and_e7_two_a1_germ_candidate_20261022.md)
now has a fully reviewed mathematical/runtime proof of the full E7+2A1 germ.
Five NEW profiles and their separate combine passed; its isolated wall
has norm2b. The earlier admission refusal is preserved with zero execution
credit. The later
[fourth-edge/original-period proof](../results/compact_h9_prime379_fourth_edge_e8_long_corner_and_original_period_candidate_20261022.md)
has complete [review and root acceptance](../results/review_prime379_fourth_germ_original_period_root_acceptance_20261022.md).
It reaches a full E8+long germ, uses six actual bounded units, and proves
an original integral chamber symmetry has infinite order. Thus this literal
norm379 host is nonreflective. These are construction notes in the existing
research lane, with no added manuscript family, new example or form-class
exclusion. The new geometry is written and internally reviewed; no new
geometric Lean verification is claimed.

The distinct composite551 host is now also
[proved nonreflective](../results/review_composite551_binary_release_and_literal_nonreflectivity_root_acceptance_20261022.md).
The [seven actual profile units and separate combine](../results/composite551_transverse3_actual_runtime_manifest_20261022.json)
give the intermediate E7+two-A1 germ, with one norm2b component. A complete
manual next-edge proof reaches a FULL E8+norm2b corner and an original
integral future chamber map with trace843+1354phi>10. Its infinite order
and the arithmetic index/covolume argument close that literal module.
The intermediate corner is not mislabeled E8, and the manual continuation
claims no new checker execution. No example or commensurability-class
exclusion follows, and these construction notes add no manuscript family.

The glued golden host's [U edge](../results/review_glued_e7_a2_released_e2_actual_a5_bridge_root_acceptance_20261023.md)
and [F edge](../results/review_glued_e7_a2_v_e2_actual_d4_edge_root_acceptance_20261023.md)
are construction research, with full H3+A5+A1 and H3+D4+A1+[2b] corners.
Complete firstness excludes the later upper mirrors T and P2 as actual
facets. The [complete H3+D4 face acceptance](../results/review_glued_e7_a2_complete_right_hexagon_root_acceptance_20261023.md)
adds a whole compact right-angled hexagon of area pi. Its finite face
normalizers are not ambient lattice maps. These notes add no paper
family, ambient finite-volume chamber, period or example.

The ideal RA4 paper already follows the requested sequence: the published
minimum, the universal gap and equality reduction, the restricted
structure theorem, then its application to the unique double. The chain
hypothesis is proved at second volume before it is used. No unrestricted
chain or volume-divisibility theorem is claimed. The compact case uses
different metric and capacity arguments, so it remains a separate paper.

## Algorithms and formal logic

Every proof-relevant computation has separate obligations: a finite
input domain, the algorithm, termination, soundness, completeness and
the exact output from execution. These are mathematical propositions;
a list of filenames or a saved PASS cannot establish coverage.
The [computational proof contract](computational_proof_contract.md)
and each paper’s proof map record those obligations.

Finite57’s complete25-unit bounded loader replacement has actual PASS
records and is integrated into the primary catalogue. The
[integration receipt](../results/finite57_complete_loader_catalogue_integration_20261022.json)
binds parser + 16 B13 + 8 frontier, full runtime/source-equivalence reviews,
the exact preserved catalogue delta and current 146-job full plan.
With inherited matching records for 111 unchanged commands, separate
evidence covers136 selected scripts. No combined full-manuscript run
or complete transitive regeneration is claimed. Partial predecessors
and the earlier admission refusal remain preserved.

Selected Lean kernels prove internal implications with external theorem,
geometry and script premises explicit. Their assumption maps separate
those premises from derived conclusions; actual axiom audits are recorded
separately from compilation. The [assumption register](manuscript_assumptions.md)
and [verification guide](manuscript_verification.md) explain that boundary.
The regular 24-cell coordinate-height kernel and classical dimension
composition kernel now have bounded compilation and separate actual
five-/four-declaration axiom audits. The
[completion receipt](../results/lean_publication_completion_20261021/manifest.json)
records the sources and output; actual geometry and field/script bridges
remain explicit premises.

The additional [endpoint triangle kernel](endpoint_triangle_norm_kernel_logic_20261021.md)
has a bounded compile and separate ten-declaration audit
[PASS](../results/lean_endpoint_triangle_verification_20261021/manifest.json).
It supplies internal algebra and norm logic for the latest arithmetic
endpoint arguments, retaining their actual geometric and field interfaces.

The [Lorentz obstruction kernel](lorentz_obstruction_kernel_logic_20261021.md)
has bounded compilation and a separate seven-declaration actual axiom audit
[PASS](../results/lean_lorentz_obstruction_verification_20261021/manifest.json),
with standard axioms only and no `sorryAx`. Its second-orbit and restricted
Schur/rank implications remain conditional on their written geometric,
original-lattice, actual-germ and arithmetic application inputs.

The [D15 typed-seven centre kernel](d15_typed_seven_centre_kernel_logic_20261022.md)
also has bounded compilation and a separate six-declaration actual axiom
[PASS](../results/lean_d15_typed_seven_centre_verification_20261022/manifest.json).
Its continuous radical/funded-energy deductions retain explicit geometric,
classification and actual-application premises. Successful output uses
only standard axioms; failed tactic evidence is preserved without credit.

## Preserved material

The parked [eight-field](../manuscripts/appendices/compact_arithmetic_eight_field19.tex)
and [K7](../manuscripts/appendices/compact_arithmetic_k7_field19.tex)
refinements, combined predecessor and its PDF remain intact. Earlier
right-angled bounds, compact intermediate bounds and generated proof
atlases are supporting history, not new manuscript families.
The previous complete 33-file inventory and execution chronology are
byte-preserved by the [archive manifest](../results/source_archive/six_paper_completed_audits_status_20261021/manifest.json)
and remain indexed in the catalogue. The
[completed-audit checkpoint](../results/six_paper_completed_audits_and_restricted_continuations_20261021.json)
binds the earlier status-page versions, full reviews and unchanged papers.
Current guide bytes and their exact predecessor recovery are bound by the
[earlier research checkpoint](../results/a_family_and_prime79_frontier_continuations_acceptance_20261021.json)
at its recorded edition; later guide revisions are preserved by Git history.
