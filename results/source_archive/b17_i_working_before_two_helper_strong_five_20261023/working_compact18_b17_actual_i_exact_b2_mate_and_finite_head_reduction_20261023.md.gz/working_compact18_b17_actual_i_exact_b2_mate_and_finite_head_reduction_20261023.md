# Working checkpoint: fresh B17+actual-I tails and finite-head reduction

23 October 2026. SOURCE-ONLY mathematical work, **not reviewed or accepted**.
This is one supporting working checkpoint, not a paper or a whole-B17+I
exclusion. The exact B2 row and finite-head arguments below are complete
at the stated inputs, but the isolated dotted-head/weak5 remainder is
still open. No scientific job, import, enumeration, test, compiler, Lean,
TeX, Sphinx or Git operation ran. Frozen sources and guides are unchanged.
I authored the B18/I input and contributed to other local foundations;
the new actual-rank derivation needs another author's review.

All paths in this input table are under results/; current hashes match.

|Source|SHA256|Only interface used|
|---|---|---|
|compact19_b18_isolated_i_full_endpoint_foot_exclusion_candidate_20261021.md|d7e6fa43104c001c0e0263e9b3e6e98d5fdc00c56783fbab394383a7f0ef9cdb|Rank-free actual-I identities/barriers, local prefix/helper and head points and their fully funded scalar certificates; NOT its B18 exclusion or strong16 conclusion|
|compact_dimension18_complete_forest_frontier_candidate_20261022.md|66adce66676f6fe0f6fe50af43c029154c8e30a2bdab4b13f809aa8ad10cf028|Actual ordinary/I distinction and local B3/B2 finite classification; no ordinary energy assigned to I|
|compact_classical_generic_prefix_energy_20261020.md|f637d7294d17e37581330ca508c914c23a08ce259845614b055e45815d2790ef|Direct B17 M12 coverage5..13, pure helpers, nonadjacency, weak5 actual pressures and interpolation proof|
|compact_farthest_vertex_mixed_replacement_inequalities_20261020.md|3732b82614e13dfe2f7a3c66ab6c7fe67e517cbaeb77be0ca533f559ddf6ed84|Positive actual finite projection/future feasible points and original farthest-point comparison|
|compact_actual_wall_reciprocal_shadow_20261020.md|c913ec3bd8e0f26a8c679a1ede2b98b251ad3f36efeae60486213ddfa3e8badc|Same actual wall recognition; compact boundary T=1 excluded|
|compact_farthest_vertex_orthogonal_component_opposite_obstruction_20261020.md|4216d06c2e03fd336898b8dac289b9969fa096c8a1d08bd67ddeb8ab5ec2f23d|No actual wall closes directions in two old orthogonal components|

Use ACTUAL unit old B17 normals n_i=(e_i-e_(i+1))/sqrt2, i<=16,
n17=e17, and the old orthogonal I normal e. Write the original farthest
vector (x,y), x1>...>x17>0, y>0, ||x||²+y²<1. Put Omega_i=sqrt2 P_i
for i<=16, Omega17=P17, f_i=sqrt(i)-.61/sqrt2. The ACTUAL I opposite
is cI=sqrt(h)p-sqrt(1+h)e, 0<h<1/2. With
s²=(sqrt(1+h)-1)/(sqrt(1+h)+1), t=sqrt(1+4h)-2sqrt(h), the rank-free
interfaces give y>=s, x1>=t, t+1.5s>.767 and t+2.5s>.923.

## 1. Fresh complete tail list and the exact exceptional B2 floor

Generic M12 applies to B17 and gives coverage5..13, with pure far3
helpers only. At14 the right white B3 has exactly long3 and short3/F4
extensions. Their residuals are1/2-Q and1/4-Q, and numerators
gamma+1/2 and gamma+1/(2sqrt2). Long3 own0/3 has its actual affine
star/triangle; remaining positive owns are strong. Short3 own0 has
the actual affine F4 path c,17,16,15,14; all positive owns are strong.
Its finite F4 white block is foreign-sealed. Full endpoint bridges are
B17 with internal c and are foreign-sealed. Isolated/left/foreign rows
use the same local matrices with the existing long root15; only pure
far3 helpers remain. Adjacent helpers through14 use the unchanged
positive two-cap Schur block, so at least one of13/14 is strong.

At15 the right white B2 consists of long16 and short17. Its only finite
extensions are3 at either endpoint. Long3 is affine at own0/3 and
strong otherwise. Short3 is affine at own0/4/6, null at parallel,
and strong at own5/finite>=7/dotted since sqrt2 gamma+1/2>100/61.
Own3 with positive foreign cost Q>=1/4 is strong. Bridges are the
foreign-sealed full B17 and have the same direct stronger ratio.
Left/isolated rows retain their local actual points. Thus the ONLY
additional weak row is pure

    v=(Omega15+Omega17)/2, own3/short3, Q0.        (1)

The SAME wall, with retained old walls except16, forms finite A17.
Positive acute projection proves the actual finite mate endpoint,
not just a formal completion. Its exact outgoing length is

    C16=(16+15sqrt2)/sqrt18=5+8sqrt2/3.

Consequently the original farthest vector satisfies

    S16>=4sqrt((C16-1)/(C16+1))
        =(8+12sqrt2)/7=:G,  3.56722<G<3.5673.     (2)

Here (C16-1)/(C16+1)=(22+12sqrt2)/49 and
22+12sqrt2=(2+3sqrt2)². Crucially G<f16; this is NOT strong16.

If5 is weak, its actual first-six point gives x1>.5965,S6>2.01815.
Interpolation through1,6,16 with(2) has positive decreasing slopes
and squared norm greater than

    C=.7600299945+(3.5672-2.01815)²/10
      =.99998558475.                             (3)

Retain S6 and G, graft the first coordinate to max(.5965,t), and
hold the other five coordinates of that block equal. For t<=.8 the
remaining block slope is at least.24363, above the last slope<.154915;
all duals therefore remain nonnegative. Its gain is
(6/5)max(t-.5965,0)². Together with y²>=s² the .923 barrier gives

    s²+(6/5)max(t-.5965,0)²
      >(.3265)²/(25/4+5/6)>.015.

If t>.8, clip at.8: the graft alone gives
(6/5)(.2035)²=.0496947>.015 and the same slopes remain legal.
Either case contradicts(3). Thus row(1) cannot coexist with weak5.

If5 is strong, use the actual strong K13 or14 reference, then append
its chord to G at16. Concavity is preserved: the last chord slope is
<.132 for K13 or<.129 for K14, below the preceding actual sqrt slope.
The direct reference bounds give respectively

    q13+(G-f13)²/3 >.88864+(.39299)²/3>.9401;
    q14+(G-f14)²/2 >.90715+(.25688)²/2>.9401.       (4)

The seals use f13<3.17423,f14<3.31034 and G>3.56722. These follow
by positive squaring, e.g. sqrt13<3.60556,sqrt14<3.74167 and
.61/sqrt2>.43133. The first5 mean stays b<.361 and its INDIVIDUAL
P5 coefficient stays>.146. The q14 entry here is the interpolation
proof on the fresh coverage with actual endpoint14, not application
of P's original B-rank hypothesis at invalid rank.

The rank-free head/I certificates of the B18 input now exclude row(1)
also in this strong5 branch. All their constructions use only n1,n2,
n3 and first5, so preserve(4), the terminal16 floor and ALL original
B17/I/unknown walls. The applicable lower gains over(4) are:

* Nonisolated head: x1>.643, legal first5 graft gain>.0994.
* Pure finite head>=7: the actual core plus I/initial graft gives
  joint gain>.06136, including its full cross term and clipped branch.
* Pure native5 is already impossible by the native-I argument below.
* Pure dotted head: the complete continuous u in(0,1) calculation gives
  joint gain>.06029364, including the adverse head/I cross and clipping.
* Positive-foreign finite head: the cleared pure-D foot gains>.04;
  the native-I argument below gives I energy>.0557, used only once.
* Positive-foreign dotted head: the complete g² intervals (1,6/5],
  [6/5,8/5],[8/5,infinity) give joint gains>.06180125,.062925,.06498.

These are LOCAL funded certificates, not the B18 theorem: head and
initial residuals have support in first5 and zero sum; their total P5
price is at most.14<.146. The same square includes their mixed cross.
The pure-dot minimum plus(4) already exceeds1.00039364. Every head
is isolated or the single long2 simple3 extension; own0/3/4/6/parallel
and all finite foreign labels are treated by the listed local null,
shadow and clearing arguments. Hence(1) is excluded in both5 branches.

## 2. Nonisolated and ALL finite-own isolated long heads are then excluded

Coverage5..15 now has only nonadjacent pure helpers. It supplies an
actual strong K14 or15, without assuming5 strong. A nonisolated head
has A²=2g²+2g+Q and C1=(2g+1)/sqrt(1-2Q). Own0 is zero-time or
has the positive full-old-B null clearing; own3 is the triangle and
parallel is null. Every remaining own gives x1>.643. If5 is strong,
its q14 reference plus graft gain>.0994 contradicts1. If5 is weak,
interpolate1,6,K with first value.643. Its energy is greater than

    .7916565045+(3.7416-2.4495)²/8
      =1.00034680575.

All slopes decrease. Thus the head is isolated WITHIN B, including
when it contacts the retained I normal. No arithmetic assumption is used.

Write c=A p-g Omega1-beta e, A²=2g²+beta²-1. The distinct actual
I opposite gives lambda=-c.cI=sqrt(h)A-sqrt(1+h)beta>=0. Its nonzero
native magnitude is at least1/2. If own is finite, g<1. For beta0,
0<lambda<1/sqrt2, so lambda=1/2. For beta>0, beta>=1/2 and

    lambda<sqrt((1+beta²)/2)-beta sqrt(3/2)
      <=(sqrt10-sqrt6)/4<1/2,

so lambda0. Squaring the exact zero relation then gives
beta²=h(2g²-1)<1/2, hence beta=1/2. BOTH cases therefore imply

    h(2g²-1)=1/4, h>1/4.                         (5)

Own0/3/4 are impossible, own5 would give h=phi/2>1/2, and own6
would give h=1/2 (also its actual affine6--3 principal). Parallel is
always forbidden by c+n1. Thus a finite isolated head has native>=7.

Before using any P5 coefficient, (5) proves strong5: otherwise its
first-six interpolation through a strong K14/15 has energy
>.7600299945+(1.2921)²/8>.96872, and I alone costs>.0557.
Only now take the ordinary q14>.90715 reference, b<.361 and
coefficient(P5)>.146.

For positive beta, (5) gives beta1/2 and u=(1-beta²)/g²<1. The actual
foreign-cleared head core gains>.04 at price.072; I costs>.0557, so
the total exceeds1.00285. For beta0 put u=g^-2 in(1,1.232). At mu=.5
the first-three-root core's head gain is
eta=H(u)-b-(R(u)-.2)/4, where
H=sqrt(1-u/2)-sqrt((7u-3u²-4)/2), R=3-4u+3u²/2.
The actual positive core is c+g^-1*n1+2(g^-1-g)*n2; its first-three
displacement has sum1. The increasing native7 cubic8s³-4s²-4s+1
has opposite signs at .90096 and .901; since1.232*(.90096)²>1,
every finite>=7 own has u<1.232. No label cutoff is used.
The following positive-square interval seals, plus(5), are complete:

|u interval|eta lower|h lower|I energy lower|sum lower|
|---|---:|---:|---:|---:|
|[1,1.1]|.0477|1/4|.0557|.1034|
|[1.1,1.15]|.033025|11/36|.066|.099025|
|[1.15,1.2]|.0213875|23/68|.072|.0933875|
|[1.2,1.232]|.0186|3/8|.079|.0976|

Here h=u/[4(2-u)] is increasing. The head seals use respectively
the lower sqrt(1-u/2) bounds .6708,.6519,.63245,.6196, upper
second radicals .1871,.204125,.204125,.2, and R maxima
.5,.415,.38375,.36. The I seals follow from h(q)=4q/(1-q)².
Every sum exceeds1-.90715=.09285. The head foot clears no I energy
in the beta0 case; adding y² once is legitimate. All finite heads fail.

## 3. Exact unresolved branch and further actual inequality

The proposed necessary reduction leaves an isolated-within-B DOTTED
long head, possibly with finite old-I contact beta. Strong5 is NOT proved
for that remaining branch. Its universal weak5 interpolation has energy
only>.96872, and the I/initial-graft lower bound>.015 is insufficient.
Using q14 as though5 were strong would be circular. No current B17+I
exclusion, new frontier subtraction or bound improvement is claimed.

For beta0 there is an additional valid all-wall point when
lambda=sqrt(h)A<1: the actual set c,cI,oldB2..17 is positive definite.
Put rH²=1-1/(2g²),rI²=h/(1+h). Its finite projected point gives

    rH*x1+rI*y >=1-sqrt(1-rH²-rI²).               (6)

This is more than separate edge bounds. If lambda>=1 instead,
h(2g²-1)>=1. Any attempt to combine(6), a retained weak15 foot and
a dotted head core must include ALL residual crosses and the weak5
reference's unequal first coordinates. A complete simultaneous scalar
certificate for those domains remains open here; no sample or formal
Gram relaxation is promoted to actual chamber geometry.
