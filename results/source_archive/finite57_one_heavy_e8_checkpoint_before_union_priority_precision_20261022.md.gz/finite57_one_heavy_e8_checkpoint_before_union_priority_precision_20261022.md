# One-heavy checkpoint: an isolated fork3 forces an off-face E8 cusp

22 October2026. **SOURCE-ONLY mathematical checkpoint, UNREVIEWED and
UNACCEPTED.** No worker/import, enumeration, test, symbolic process,
compiler, Lean, TeX or Git operation ran. This records the actual affine
mechanism and a prospective complete selected-profile financing proof
before the higher-priority A17 code review. No bound/guide/table changes.
Root and another author must scrutinize the complete cusp classification,
preimages and simultaneous ledger before any financing credit is taken.

This concerns an actual finite-volume57-polytope and a finite heavy
vertex p with WHOLE2D17+D23, original held C0=372. Suppose the actual
opposite c to ONE short fork leaf a is isolated from ALL other old
incident roots and has native3 with a, in norm-two notation (a,c)=-1.
This is a genuine selected local profile, not all one-heavy pentagons.
It contains the explicit one-heavy working model's C wall. No ambient
existence or finite-volume completion of that working model is inferred.

Inputs to inspect at the eventual full-review boundary are current c300,
the full-cusp deletion source ed578, the complete original-C0/7e53 ledger,
the H/J cusp allocation c7ae, the selected hexagon d460, and the accepted
two-/three-heavy union cc4ab. No optional full-unit D16 restoration or
dependent finite deletion is used. Sources/frozen evidence remain unchanged.

## 1. Exact actual affine block and the missing off-face cusp

Let the affected D_(r+1) have r=16 or22. Delete its selected short
leaf a, leaving A_r on q1,...,q_r, with a attached to q2 by3.
All old simple products are-1 and all diagonal entries2. The roots

    q1,q2,q3,q4,q5,q6,q7,a,c

form ACTUAL affine E8: centre q2 with arms1,2,5. Its positive kernel is

    nu=3q1+6q2+5q3+4q4+3q5+2q6+q7+4a+2c.

Direct multiplication gives nu²=0 and zero product with each displayed
root. It is NONZERO: its product with a strict interior timelike point
is strictly negative. Positivity of all coefficients and actual all-wall
acuteness make nu future and feasible against EVERY other wall, including
unobserved facets. Finite volume makes its projective point an actual
ideal vertex. Moreover nu.q8=-1, so this cusp is NOT on the original
two-face retaining the entire A_r support.

The other two whole D components at p are orthogonal to nu, as are
q9,...,q_r. Thus the cusp contains the finite forest

    r16: D17+D23+A8;
    r22: 2D17+A14.

Both have rank48. Together with the actual affine E8 rank8 they exhaust
the cusp's rank56. This is the correction to the earlier informal
rank47 count: in the literal working model B is incident to nu, so its
D16 is restored to the WHOLE finite D17. The isolated triple C,D,E has
no affine kernel by itself; its union with the supporting whites and a
DOES have this affine E8 block. The old checkpoint's finite-corner
obstruction therefore does not establish absence of an external cusp.

## 2. Complete prospective receiving parent families

The displayed affine E8 is a WHOLE cusp factor: an irreducible affine
diagram has only positive proper principal subdiagrams. The other48
chosen positive roots form a maximal elliptic set in all remaining
whole affine factors; hence exactly one node is omitted from each.

One-node affine classification gives a connected D_s output,s>=17,
only from whole affine B_s or D_s, at no more than4 deletion ports.
Two such large D outputs may instead come from a single affine
D_(s+t), at no more than2 internal ports. No classical one-node
deletion gives three large output components, or joins an A8/A14
output to a large D output: affine B/C give B-containing outputs,
while affine D's internal split gives two D pieces (the fork splits
only add small A1 pieces). Exceptional parents cannot contain a D17.
A connected A14 output forces whole affine A14, with15 ports.
A connected A8 output forces whole affine A8 or E8, with at most9
ports; the E8 option has the short-arm deletion giving A8.

Consequently the ONLY receiving whole affine families are

    (I)   E8+U8+T17+T23,
    (II)  E8+U8+D40,
    (III) E8+A14+T17+T17,
    (IV)  E8+A14+D34,

where every symbol denotes a WHOLE AFFINE factor, T_s=B_s orD_s,
and U8=A8 orE8. These profiles have ranks(8,8,17,23),(8,8,40),
(8,14,17,17),(8,14,34), respectively. The classification/port claim
must receive full outside scrutiny before this checkpoint earns credit.

## 3. Actual source uniqueness and conservative preimage bounds

Choose the forced whole affine E8 factor. Its unequal arm lengths1,2,5
intrinsically identify a,c,q1,...,q7, in their stated roles. Choose the
one-node deletion ports in the other parent factors and, for the A8/A14
output, ONE OF ITS TWO endpoints. The missing old root q8 must have
square2, product-1 with q7 and that endpoint q9, and product0 with all
other chosen cusp roots. The chosen57 cusp roots span nu-perpendicular:
their only Gram kernel is nu, a NONZERO null vector, so they are linearly
independent. Any two actual q8 choices differ by lambda*nu. As q8.nu=-1,
equality of their squares gives-2lambda=0. Therefore q8 is UNIQUE.
All57 old roots at p are now fixed, so there is at most one actual p.
There is no claim that an abstract q8 candidate exists.

Safe full-domain counts are as follows. The A8 path has two possible
endpoint attachments; omitting this factor2 would undercount. In r16
either remaining D17 orD23 could be the second marked/restored component
of the original face; allow another factor2. In r22 the two equal D17
outputs give at most two such roles. The forced E8 factor has at most
two choices in(I)/(II), and one in(III)/(IV). Thus conservative bounds are

    (I)   N<=2*9*2*4*4*2=1152;
    (II)  N<=2*9*2*2*2=144;
    (III) N<=15*2*4*4*2=960;
    (IV)  N<=15*2*2*2=120.

These deliberately overcount choices. They apply to the full short-leaf
profile, not a count of diagram embeddings offered as a face injection.
For the literal W=D16+A16+D23 working model alone the other active
component is specified D17, so bounds576/72 suffice; the larger numbers
above are used for the union and should NOT be replaced by the narrower
literal-model bounds. Select one qualifying leaf/cap per heavy source.
Source uniqueness then bounds distinct selected heavy sources per cusp.

## 4. Exact prospective canonical budgets and no assumed spare credit

For affine ranks summing56, put V=product(r_i+1) and
A=[t27] product(1+...+t^r)/(1-t)^2. The canonical shape quantity is
kappa=42V-5A and the held c300 envelope is I0=V*sum c(r_i).
The four calculations are

| Profile | V | A | I0 | kappa-I0 | Proposed8N | Remaining |
|---|---:|---:|---:|---:|---:|---:|
|8,8,17,23|34992|134024|759132|40412|9216|31196|
|8,8,40|3321|17550|47304|4428|1152|3276|
|8,14,17,17|43740|157593|1020843|28272|7680|20592|
|8,14,34|4725|22365|313245/4|33255/4|960|29415/4|

For independent hand reproduction, the A values are respectively

    binom32,5 -2binom23,5 -binom8,5 +2;
    binom31,4 -2binom22,4 +binom13,4;
    binom32,5 -binom23,5 -binom17,5 -2binom14,5 +binom8,5 +2;
    binom31,4 -binom22,4 -binom16,4 +binom7,4.

Use c8=4,c14=367/60,c17=119/18,c23=85/12,
c34=226/35,c40=256/41. No saved maximum or mathematical execution
was used to obtain these integer/rational expressions.

There is NO whole affine D16/A15/A16 in these families, so the explicit
old Context662 and A15/A16-E8 priorities add no debt. A D16 subdiagram
is not a whole varying factor. Their whole rank profiles differ from
EVERY c7ae J or selected-hexagon ideal receiving profile. H and the
two-/three-heavy union receive at finite vertices, not these cusps.
At the complete original-C0/7e53 boundary, it is therefore prospective
to choose H/J/hexagon first, then subtract8 from each remaining heavy
source of this isolated-fork3 type and add8 to its selected E8 cusp.
The table's worst8N fits all four canonical margins strictly. The total
charge is preserved; no optional full-D16 restoration or74/280 reserve
is spent. This is the proposed simultaneous selected-profile theorem,
subject to full source/debt/interface review.

## 5. What remains open

This checkpoint is NOT an accepted financing theorem. It records a
complete actual affine mechanism and a concrete finite parent/port/budget
proposal for review. It does not force a short isolated3 cap in every
one-heavy pentagon. Other isolated finite/dotted caps, attachments to
whites, other lengths and expensive whole forests retain their prior
scope. A full dimension56 proof still needs actual global coverage and
routing of every heavy/costly vertex; neither the local model nor this
new off-face cusp supplies that missing universal claim. No new ambient
example, field-wide exclusion, computation or extra manuscript is claimed.
