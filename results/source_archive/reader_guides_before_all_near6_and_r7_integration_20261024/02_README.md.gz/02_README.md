# The six papers and their techniques

There are **six current paper families**, with written, compiled and internally
reviewed TeX/PDF editions. The compact18 and arithmetic15 supporting improvements
belong in the existing compact families when integrated. They are not extra
papers, and the frozen PDFs still state23 and20. Earlier TeX notes, fragments,
predecessors and generated atlases are preserved supporting material.

| Paper and TeX | Main technique | Result in this PDF | PDF | Proof/reproduction map | Verification ID |
|---|---|---|---|---|---|
| [General finite volume](finite_volume57.tex) | Corner payments, Coxeter forests and cusp curvature | Dimension at most57 | [48 pages](build/finite_volume57.pdf),12 main +36 essential appendices | [Proof map](../docs/finite_volume57_lemma_map.md) | `finite57` |
| [Sharp right-angled dimensions](right_angled_sharp_dimension_bounds_publication.tex) | Actual projections, descending heights and spherical codes | Finite volume at most8; entirely ideal at most4; both internally sharp | [5 pages](build/right_angled_sharp_dimension_bounds_publication.pdf) | [Proof map](../docs/right_angled_sharp_dimensions_publication_proof_map_20261021.md) | `right_angled_sharp` |
| [General compact](compact_farthest_vertex_bounds.tex) | One farthest vertex and additive component energies | Dimension at most23; later supporting proof18 | [36 pages](build/compact_farthest_vertex_bounds.pdf) | [Proof map](../docs/compact_farthest_vertex_bounds_proof_map_20261020.md) | `compact_farthest_bounds` |
| [Compact arithmetic](compact_arithmetic_dimension_bound.tex) | Field reduction and exact angle rules, with the same geometric budget | Dimension at most20; later supporting proof15 | [21 pages](build/compact_arithmetic_dimension_bound.pdf) | [Proof map](../docs/compact_arithmetic20_proof_map.md) | `compact20` |
| [Ideal RA4 volume and structure](ideal_ra4_volume_and_structure_publication.tex) | Volume gap, equality recognition and restricted decomposition | Published minimum; second volume and unique double; restricted24-cell chains | [17 pages](build/ideal_ra4_volume_and_structure_publication.pdf) | [Proof map](../docs/ideal_ra4_volume_and_structure_proof_map.md) | `ideal_ra4_volume_and_structure` |
| [Compact RA4 volume constraints](compact_ra4_volume_constraints.tex) | Facet capacity, excess and recognition | Necessary volume/structure constraints | [14 pages](build/compact_ra4_volume_constraints.pdf) | [Proof map](../docs/compact_ra4_volume_constraints_reproduce_20261019.md) | `compact_ra4` |

The57 and sharp right-angled papers are the priority entry points. The
[current comparison guide](../docs/current_bounds_and_verification.md) distinguishes
published bounds, supporting improvements and actual verification. The
[detailed result correspondence](../docs/result_manuscript_correspondence.md)
preserves the longer provenance. The
[six-paper delivery receipt](../results/six_paper_final_tex_delivery_20261021.json)
binds the matching frozen sources, PDFs and build records.

## Where the common arguments split

Finite57 first establishes one simultaneous corner-payment rule. Finite vertices
then require exact spherical-forest maxima; ideal vertices require affine-factor
charges and actual cusp multiplicities. Both branches reunite in one incidence
contradiction. The higher-dimensional tail is separate and does not assume a
facet is itself Coxeter.

The compact proofs start with the same original farthest vector. Ordinary,
large-A and large-B/D component estimates have separate geometric arguments,
then reunite through additive squared norms. Rank-specific endpoint and fork
cases close the surviving configurations. Arithmeticity adds field/angle
restrictions rather than a second unrelated geometric framework.

The sharp right-angled paper shares one actual projection lemma between its
general and entirely ideal cases. Spherical-code estimates and the relevant
published facet minima enter at clearly identified later steps. Its internally
sharp8/4 bounds do not assume arithmeticity.

The ideal four-dimensional paper combines the published minimum, second-volume
recognition and restricted24-cell chains as one sequence. It does not classify
arbitrary ideal right-angled polytopes as24-cell garlands. The compact RA4 paper
does not prove that the120-cell is the absolute volume minimum, nor that its
double is the unique second-volume example; those remain open here.

## Supporting research and actual checks

The later compact18 and arithmetic15 arguments are complete reviewed written
supporting proofs. Their frozen paper editions remain23 and20. Consolidate
future improvements within those families rather than create a paper per
numerical increment. The [result correspondence](../docs/result_manuscript_correspondence.md)
links the individual sources, reviews, accepted interfaces and verification.

At dimension18 only wholeD18 remains in the necessary farthest-vertex list.
The entire isolated/isolated and isolated/near3 fork families are now excluded,
as is the isolated native5 long-head branch. A further direct proof excludes
six central bridge configurations. New complete all-initial-case arguments
leave finite head labels7/8 and a restricted dotted interval, after the
separately reviewed native-nine exclusion. Three near-side
native-four profiles and far-side parallel/dotted-own variants are excluded.
Other heads/profiles remain open; no17 ceiling or realized example follows.
Arithmetic15 retains fourteen necessary
groups, with original12 narrowed to ordinary irreducible T2; old labels
at least8 and weak golden-helper/near-four cap branches are excluded.
These residue and discriminant proofs use arithmeticity; the general
compact exclusions do not.

Toward finite volume56, all selected weighted ideal budgets and all native6
finite budgets are accepted. Actual generation and separate replay cover
6,626 small-factor ideal cases. The new polygon-refund method also finances
complete centre-exit rows5 and11 for literal2D17+D23. Both positive far-row6
rank cases now have complete refund/receiver proofs too. The corrected
native-three near-row6 proof finances both affected ranks with an actual
affine-D4 receiver and one polygon refund. Its original dual-index error
and exact repair are preserved. An all-actual-facet extension restricts
finite native labels to2/3/4/6 at dimension57. Other near-row6 values,
other finite configurations and complete face/source coverage remain open.

The compact spectral work proves a full-wall Gram band and a fourth-order
transverse obstruction. Its unknown-return and bounded central-prefix work
has no numerical bound or execution credit. Construction research has one
new actual original H9 facet and E6+B2+A1 endpoint after four authenticated
units, followed by a manually proved J facet and full E6+H3 endpoint.
The prepared Y-release worker was not run or used. Ambient finite volume and
a new example remain open. These are supporting
methods and research notes, not additional paper editions.

Finite57's25 bounded replacement units have actual PASS and catalogue
integration. Its full136-script/nine-Lean-root/one-PDF selection has no combined
146-job replay or complete transitive regeneration; the111 other command
matches retain inherited execution scope. The core11 selection is unchanged.
See the [reproduction guide](../docs/finite_volume57_reproduce.md).

Selected Lean packages have compilation and SEPARATE actual axiom audits,
including the new [fourteen dyadic declarations](../results/lean_quadratic_dyadic_triple_verification_20261023/manifest.json)
and [twelve repaired B16 scalar declarations](../results/lean_b16_isolated_pair_scalar_verification_20261023/manifest.json).
Their [logic maps and receipts](../formal/README.md) retain the external geometric,
field, classification and enumeration premises. This is not a complete geometric
formalization. A compiled PDF, a source review and an executed replay remain
different evidence. All six TeX/PDF bindings stay unchanged.
