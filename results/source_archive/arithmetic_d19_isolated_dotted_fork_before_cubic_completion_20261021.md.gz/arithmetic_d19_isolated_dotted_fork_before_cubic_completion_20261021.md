# Whole D19: physical and field bounds for an isolated dotted fork

21 October2026. New manual mathematical supporting candidate, pending
full root and outside-author review. No scientific, symbolic, enumeration,
optimizer, Lean or TeX job ran; no frozen source, manuscript or canonical
bound changed. This is a continuation, not an isolated-fork exclusion.

**Proved reduction.** At a whole-D19 farthest vertex in a compact
arithmetic first-type hyperbolic19-polytope, an isolated dotted actual
opposite at either fork has parameter B=4gamma^2 satisfying

    4<B<53,   K=Q(B),   [K:Q]<=3,
    B an algebraic integer, 0<B_sigma<8/19
                          at every nonphysical embedding.       (1)

The physical upper bound comes from actual same-vector pressures; no
weak-fork height is assumed. The degree restriction uses a fresh .48
prefix inventory, not unproved universal .48 or .525 floors. Rational
K is excluded separately by the standard compactness/Meyer input, so
only actual quadratic/cubic fields remain. No field census is assumed.

## 1. Exact inherited interfaces

All source paths below are under results/. Compact acute simplicity,
all-wall nonpositive products, actual native angles and first-type
cyclic-integrality/conjugate-form admissibility are supplied foundations.

| Source | SHA256 | Interface |
| --- | --- | --- |
| arithmetic_classical_short_tail_composition_20261021.md | `1a2c62ad1e6d676d7cc7bca0cf95d1f9446543619193163541f239e6734f331c` | COMPLETE D18..20 local .61 continuation, including D4/D3 and initial weak5 |
| compact_classical_generic_prefix_energy_20261020.md | `f637d7294d17e37581330ca508c914c23a08ce259845614b055e45815d2790ef` | Actual weak5 interpolation and its strong16 contradiction |
| arithmetic_uniform_classical_weak_helper_obstruction_20261021.md | `535ac0d0fa92d28ccab2976fa147a4ccff0bd3bfcd1e04ca4e134c6ae6857905` | K-valued normalization, all conjugates, classified .61 bulk helper obstruction |
| compact_dn_large_components_short_tail_transfer_20261020.md | `651a9d047d904f1b6496ba2664df5f313878466f67d011dcda144edef6a5620a` | Local finite-white list, affine principals and actual H4 correction |
| compact_farthest_vertex_mixed_replacement_inequalities_20261020.md | `3732b82614e13dfe2f7a3c66ab6c7fe67e517cbaeb77be0ca533f559ddf6ed84` | Actual finite/negative-core point comparison |
| arithmetic_full_an_isolated_finite_continuation_packing_20261020.md | `9ab34f073ea95bed2040bafe6b8573331721f9b1e75d65172f814637da046810` | Raw one-contact normalization/cyclotomic test, not An spacing |
| whole_a20_summed_isolated_feet_technical_input_20261021.md | `8d93c23c9bf268813334dd12fef09f37f523eb22208971847cf8b04e1d659ab4` | Actual dotted foot and finite-foot monotonicity |

The author contributed earlier to535ac0d0 and8d93c23c; those are shared
inherited inputs, not independent reviews of this new argument.
The rational-field compactness obstruction is the existing explicit
Meyer input in the arithmetic paper, not a new claim about arbitrary
quadratic forms. No other published theorem is newly invoked here.

Use unit old D19 normals n_i=(e_i-e_(i+1))/sqrt2,i1..18,
n19=(e18+e19)/sqrt2. Write omega_i=sqrt2 P_i,i<=17,
omega18=(P18-e19)/sqrt2, omega19=(P18+e19)/sqrt2.
The actual x satisfies ||x||^2<1 and x.n_i>0. There are no spectator
components. Put S_i=x.P_i and f_i=sqrt(i)-.61/sqrt2.

The .61 floors S_i>f_i for ALL i5..16 really are available here.
This is the COMPONENT-local D19 interface in1a2, not its dimension20
forest conclusion. Its proof checks the complete bulk through14,
then D4 at15 and D3 at16: only own5/fork3 survives their finite-white
list and conjugate test, and the actual left-H4 grafts using K11/K12
exclude both. Classified pure helpers at indices>=6 are excluded by
535ac0d0. Thus6..16 are strong. If5 were weak, its full actual-core
interpolation with strong6 and16 has L16>1.000438, impossible. No
ordinary A1, isolated I, extra component energy, centre17 or outgoing
fork premise enters these local arguments. This also explains why
ambient19 is permitted despite1a2's dimension20 frontier application.

## 2. A same-vector proof of B<53

Let c=A p-gamma omega_f be the actual isolated dotted fork wall,
gamma>1, u=gamma^-2=4/B. Its actual feasible dotted core gives

    x.(omega_f-u n_f)>=sqrt(19/2-u)-sqrt(u(1-u)).

After multiplying the spatial vector and pressure by sqrt2, put

    V=P17+(1-u)e18 +/- (1-u)e19,
    G(u)=sqrt(19-2u)-sqrt(2u(1-u)),
    R(u)=V^2=19-4u+2u^2.

The last sign is the chosen fork. In particular V is EXACTLY flat1
on the first14 coordinates, for every u. This is an actual feasible
point pressure on the same x, not a desired height or norm estimate.

Let w be the ordinary .61 prefix reference through14: constant
f5/5 on coordinates1..5, then sqrt(j)-sqrt(j-1) at6..14, zero later.
Its energy E14 and endpoint F satisfy

    E14>.9087204,       F=f14<3.3104.                    (2)

Here is an exact refinement of the old coarse E14>.9084. If
d=4i+2 and z=(sqrt(i+1)-sqrt(i))^2, then z+1/z=d, so
z>d/(d^2-1). At i5..13, lower integers in units10^-6 are

    45548,38518,33370,29437,26334,23823,21749,20008,18524.

Their sum is257311. Each inequality clears against d^2-1 with
positive integer margin. The initial term exceeds.6514094 because
sqrt(.4)<.63246, proving(2). Also sqrt14<3.74166 and sqrt2>1.4142
give F<3.3104. The endpoint coefficient
d13=1/(sqrt14+sqrt13)>2/15.

Take mu=2/15 and W=w+mu(V-P14). The endpoint coefficient pays the
subtracted floor. Thus actual pressures give
x.W>E14+mu(G-F). The correction vanishes through14 and is
orthogonal to w, with squared norm R-14. Completing the square gives

    ||x||^2 > E14+2mu(G(u)-F)-mu^2(R(u)-14).          (3)

Suppose B>=53, hence0<u<=4/53<1/10. The expression
2mu G(u)-mu^2 R(u) decreases with u on this interval: G'(u)<-8/5
and -mu^2 R'(u)<16/225, so its derivative is negative. Its worst
endpoint is therefore u=4/53. At that endpoint

    G=sqrt(999/53)-14sqrt2/53>3.9679,
    R-14=13229/2809<4.71.

For the first bound use sqrt(999/53)>4.3415 and sqrt2<1.4143;
53(4.3415-3.9679)=19.8008>14*1.4143. Substitution into(3) gives

    ||x||^2 > .9087204+(4/15)(3.9679-3.3104)
                            -(4/225)*4.71
             =1.0003204>1,

a contradiction. Consequently B<53. This never assumed a weak
fork floor or added two independent energy lower bounds.

## 3. The actual field and the first degree reduction

In raw old square-two normalization an isolated cap has a K-valued
normal of square2B, sole old product-B. Cyclic integrality makes B
integral. Its old19-plus-cap Gram is over Q(B), full rank20 and
physically Lorentzian. An extra embedding of K fixing Q(B) would
preserve that signature at a nonphysical place; hence K=Q(B).
The fork raw inverse19/4 gives strict nonphysical Schur positivity

    0<B_sigma<8/19=:delta.                            (4)

All norms below are nonzero integers. Degree d>=6 is impossible
because53delta^5<1. At d5, Norm(B)<53delta^4<2, so Norm(B)=1.
Each of the other four conjugates a satisfies

    a>1/(53delta^3)=6859/27136>14/57.

Together with a<8/19 this gives |1-3a|<5/19. But then

    |Norm(1-3B)|<158(5/19)^4=98750/130321<1,

again impossible. Thus d<=4. None of these bounds is an assumed
list of fields or a numerical scan.

## 4. A fresh .48 inventory removes degree4

Here we need ONLY the conditional statement that every .48-weak
prefix cap5..16 forces actual degree<=3. The finite-white inventory
is A_(i-1)+D_(19-i), with D4 at15 and D3=A3 at16. Its complete
one-node list is left endpoint3/4,D-position3,E-position3; right
long3 and the D5/D6/D7 fork3; all D4 leaf3; D3 middle3,end3,end4,
end5; the full D19/A19 simple3 bridges; and isolated caps.
Tree and rank19>8 exclude another branch or exceptional completion.
Zero-own roles have the same exact affine principals or forbidden
positive D20 extension as in Section1. Parallel actual pairs have
a feasible null sum. D3 end5 at own0 is retained, not discarded.

The fresh sufficient edge target is
R(q)=25/12-(q-.48)/(q(2q-.48))<2 for sqrt10<=q<=sqrt32;
at17/3 the subtracted term1167/13838>1/12 proves it.

For each simple3 helper, normalize to square2 and put t=2gamma.
The full-rank star locks actual K=Q(t). The following list includes
every role that could fail this new target:

* **Near simple3.** Own5 is strong by the actual H4 on the opposite
  side: its residual delta5=(5-3phi)/8 has square root<.136.
  With v=gamma omega_i+omega_j/2,j=i+/-1 and gamma=phi/2,
  actual pressure exceeds A-sqrt(delta5), while weakness bounds it
  above by B0-.48gamma, B0=gamma q_i+q_j/2. The adjacent inverse
  gap gives B0-A<(1+gamma)/(B0+A)<.235, using B0+A>7.71 at
  the smallest i5,j4. But .48gamma-sqrt(delta5)>.25232.
  Both orientations, including the fork-ending right path at16,
  are actual H4 selections. For a dotted left-near helper,
  2<t<2.3 and every other conjugate lies in(-1.3,0). Therefore
  z=t(t+1) has physical value<7.59 and other absolute values<.39;
  degree>=4 gives |Norm(z)|<7.59(.39)^3<1. Right-near dotted
  helpers already have edge ratio>3/sqrt2.
* **D/E positions.** A dotted D-position is strong from i6.
  At i5 the near j3 ratio is>13/(2sqrt10)>2. Far j2 weakness
  gives2<t<107/50 and conjugate interval(-.8,0); t(t+1)
  excludes degree>=3. Own5 has actual field Q(phi), irrespective
  of whether its edge is strong. All E-position own>=5 and dotted
  ratios exceed2 (E6 minimum phi+1/2; E7/E8 have smaller residuals).
* **Far simple3.** Dotted weakness gives2<t<3, with conjugates
  in(-.7,.3). Again |t_sigma(t_sigma+1)|<.39, excluding
  degree>=4. Own5 has actual field Q(phi).
* **Fork3/end3.** Own5 has actual field Q(phi). Dotted weakness
  gives2<t<8/3 and every other conjugate in(-1,0). Thus
  t(t+1) has physical value<10 and other absolute values<=1/4,
  excluding degree>=3. This covers D5/D6/D7,D4 and D3 fork roles.

No higher finite own label has been hidden in that list. Even m>=8
has conjugate -2cos(pi/m)<-1.8. For odd m>=9, the coprime exponent
m-2 gives -2cos(2pi/m)<=-2cos(2pi/9)<-1.5. These violate the
near-left(-1.3,0), near-right(-1-1/sqrt(i),-1+1/sqrt(i)),
D-position(-.8,0) or(-1,-1+4/i), far(-.7,.3), and fork(-1,0)
windows. At m7 the extra positive conjugate2cos(3pi/7)>0 violates
these windows. Own3 is affine; own6 has its affine6--3 principal.
Own4 is affine or has actual field Q(sqrt2). Thus every remaining
finite simple3-helper case has degree<=2 or is already strong.

For **terminal4 helpers**, near-end4 is strong for every positive
own contact. Far-end4 own3 has affine F4, own4 the affine terminal
four fork; every own>=5/dotted ratio exceeds2 at i5. For **D3
end4**, own3 locks actual K=Q(sqrt2), whereas own>=4 has ratio
at least3/sqrt2. For **D3 end5, INCLUDING OWN0**, the residual
is(5-3phi)/8 and numerator>=phi/4, giving ratio>2.99. Full D19
bridges have ratio>2. For the A19 bridge at16, own3 is affine,
and every own>=4 already exceeds2; own0 is the bridge cycle.

For an **isolated finite** cap, the raw one-contact test leaves
only5,8,12 besides affine3/4/6; all surviving fields are quadratic.
For an **isolated dotted** weak cap, its actual foot gives
4<B_i<16 and all other conjugates0<B_i,sigma<2/i<=.4.
The full star locks K=Q(B_i). Degrees>=5 have norm<16(.4)^4<1.
At degree4 its norm is1, so each other conjugate exceeds
1/[16(.4)^2]=25/64. Consequently

    |Norm(1-2B_i)|<31(7/32)^3<1,

excluding degree4 as well. This completes EVERY fresh .48 role.

If the actual K in(1) had degree4, no prefix index5..16 could be
.48-weak. The positive prefix reference would therefore give

    ||x||^2>E16(.48)>1.009327>1.

For the exact last scalar, E17(.61)>.95691 follows from the first
block>.6514 plus the twelve reciprocal lower integers
4545,3846,3333,2941,2631,2380,2173,2000,1851,1724,1612,1515
in units10^-5. Subtract the last increment<1/64 to get
E16(.61)>.941285. Then
E16(.48)=E16(.61)+.13sqrt(.4)-.01417>1.009327.
This contradiction proves degree<=3 in(1).

## Remaining mathematical obstruction

The original isolated-fork wall is not proved impossible. A genuine
remaining model must have actual quadratic/cubic K=Q(B),4<B<53,
all other conjugates in(0,8/19), and fork time-square class

    H_f^2=B(19B-8)/4.

At least one earlier prefix cap must fail .48, since otherwise the
last reference already contradicts the norm. Its complete possible
roles are now restricted by Section4, and its ACTUAL K-time square
must have K-square ratio to H_f^2. This simultaneous compatibility,
rather than a smaller unsupported uniform B bound or independent
dotted-foot errors, is the next task. No B<16 or B<34 claim follows.
The centre-floor or nonisolated outgoing-fork research is not an
input, and no whole-D19 or dimension18 conclusion is asserted.
