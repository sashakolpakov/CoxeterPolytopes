Coxeter polytopes: results and verification
===========================================

This project studies dimension bounds, explicit reflection chambers and
right-angled volume and structure problems. There are **six paper families**,
with frozen TeX/PDF editions, supporting proofs and separately scoped reviews,
exact computations and Lean kernels. Updated24 October2026.

Current dimension bounds
------------------------

The repository improvements are internally reviewed written proofs, distinct
from publication, external refereeing and full geometric formalization.

.. list-table:: Dimension comparison
   :header-rows: 1
   :widths: 43 16 18 23

   * - Class
     - Largest example
     - Published ceiling
     - Repository ceiling
   * - General Coxeter, finite volume
     - 21
     - 995
     - **57**
   * - General compact Coxeter
     - 8
     - 29
     - **18**
   * - Compact arithmetic Coxeter
     - 8
     - 29
     - **15**
   * - Noncompact arithmetic Coxeter
     - 21
     - 21
     - **21**, published and sharp
   * - Right-angled, finite volume, all vertices
     - 8
     - 12
     - **8**, internally sharp
   * - Right-angled, entirely ideal
     - 4
     - 6
     - **4**, internally sharp
   * - Right-angled, compact
     - 4
     - 4
     - **4**, published and sharp

Arithmetic reflection lattices automatically admit the quadratic-form model;
“first type” adds no restriction here. General results assume no arithmeticity.
The :download:`current comparison guide <../current_bounds_and_verification.md>`
and :download:`assumption register <../manuscript_assumptions.md>` give exact
premises and references. **No new polytope example has been established.**

Current research frontiers
--------------------------

At compact18 only wholeD18 remains necessary at the selected farthest vertex.
Complete actual-neighbour arguments exclude entire fork families and the
isolated native-five head. The
:download:`finite-head theorem <../../results/review_compact18_d18_finite_head_ten_plus_root_acceptance_20261024.md>`
now leaves only labels7,8,9, while the
:download:`dotted-head theorem <../../results/review_compact18_d18_dotted_head_outer_ranges_root_acceptance_20261024.md>`
leaves the necessary, nonoptimal interval2/7<eta^-2<87/100. The
:download:`near/far native-four theorem <../../results/review_compact18_d18_near_far_white_four_root_full_source_acceptance_20261024.md>`
excludes further central profiles. All use one original vector with actual
points and every unknown-wall inequality. Other profiles remain; no17 follows.
The frozen compact PDF still states23.

Compact arithmetic15 has a complete supporting proof, ending in a handwritten
whole-D16 dyadic obstruction. It retains older authenticated computations as
inputs. At exact15, fourteen necessary diagram groups remain; original12
retains ordinary irreducible T2 only. These are necessary alternatives, not
examples or a14 bound. The frozen arithmetic PDF still states20. See the
:download:`full current frontier <../current_bounds_and_verification.md>`.

Toward finite volume56, all selected weighted ideal budgets and native-six
finite budgets are closed. Actual generation and separate same-implementation
replay cover6,626 positive ideal cases. Complete centre-exit rows5/11 and
:download:`positive far-row6 at both ranks <../../results/review_finite57_positive_far_six_both_ranks_root_acceptance_20261024.md>`
are financed for the literal heavy forest2D17+D23, retaining all old debts and
one simultaneous refund/transfer rule. The
:download:`all-actual-facet label theorem <../../results/review_finite57_all_actual_facet_finite_bonds_root_acceptance_20261024.md>`
restricts finite labels at57 to2/3/4/6 without arithmeticity. Near-row6,
other heavy configurations and complete face/source coverage remain open.

The spectral lane has a reviewed
:download:`full-wall Gram band <../../results/review_spectral_frog_canonical_lorentz_gram_band_root_full_source_acceptance_20261023.md>`
and :download:`fourth-order transverse obstruction <../../results/review_spectral_frog_fourth_order_transverse_schur_root_acceptance_20261023.md>`.
The maximum is an interior centre; a farthest vertex is a separate point.
Every unknown-wall moment stays in the constraints. The proposed restriction
cone uses geometric premises generally and adds cyclic integrality/conjugate
positivity only in the arithmetic lane. No new dimension bound follows yet.

A :download:`bounded central-profile packet <../../results/review_compact18_central_prefix_interval_packet_root_preexecution_clearance_20261024.md>`
has complete mathematical/static code review. Actual finite one-node
extensions give11/12/12 profiles at three chosen D18 edges; metric parameters
stay in bounded intervals. The sole signed-pressure notation correction is
byte-preserved. **The worker is unexecuted:** no selected-unit exclusion or
full560-unit runtime cover is credited.

The prime41 H9 construction has an actual original norm-two W facet and full
E6+B2+A1 endpoint after four recorded units. A further
:download:`manual relative-unit firstness proof <../../results/review_h9_prime41_y_release_manual_h3_full_chain_root_acceptance_20261024.md>`
reaches the unique J facet and full E6+H3 endpoint. Its prepared Y-release
worker was not run or used. Ambient volume, compactness and a chamber period
remain unresolved.

The six papers
--------------

All six editions are written, compiled and internally reviewed. Supporting
improvements remain in these families; earlier notes and atlases are not
additional proposed papers. The
:download:`paper index <../../manuscripts/README.md>` and
:download:`result correspondence <../result_manuscript_correspondence.md>`
identify the common techniques and where their cases separate.

.. list-table:: Current frozen editions
   :header-rows: 1
   :widths: 53 30 17

   * - Paper
     - Result in PDF
     - PDF
   * - General finite volume
     - At most57
     - :download:`48 pages <../../manuscripts/build/finite_volume57.pdf>`
   * - Sharp right-angled dimensions
     - Finite volume8; entirely ideal4
     - :download:`5 pages <../../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf>`
   * - General compact
     - At most23; supporting proof18
     - :download:`36 pages <../../manuscripts/build/compact_farthest_vertex_bounds.pdf>`
   * - Compact arithmetic
     - At most20; supporting proof15
     - :download:`21 pages <../../manuscripts/build/compact_arithmetic_dimension_bound.pdf>`
   * - Ideal right-angled four-volume and structure
     - Minimum; unique second-volume double; restricted chains
     - :download:`17 pages <../../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf>`
   * - Compact right-angled four-volume constraints
     - Capacity, excess and recognition
     - :download:`14 pages <../../manuscripts/build/compact_ra4_volume_constraints.pdf>`

The ideal four-dimensional paper does not classify all ideal polytopes as
24-cell chains. The compact four-dimensional paper establishes neither an
absolute120-cell minimum nor a unique second-volume double.

Read and reproduce
------------------

Finite57 has25 actual bounded replacement PASS units and catalogue integration.
Its full136-script/nine-Lean-root/one-PDF selection has no combined146-job
runtime PASS or complete transitive regeneration;111 other command matches
retain inherited execution scope. Core11 is unchanged. See the
:download:`reproduction guide <../finite_volume57_reproduce.md>`.

Selected Lean kernels have actual compilation and SEPARATE actual axiom audits.
The new dyadic and B16 scalar modules have14 and12 audited declarations;
their field, census, geometry and real-instance premises remain external.
The :download:`formal guide <../../formal/README.md>` preserves logic maps,
exact receipts, failures and resource deferrals. No selected conditional kernel
is called a full geometric formalization.

One root-owned scientific/Lean/TeX process runs at a time under the shared lock.
Admission requires40GiB disk and6GiB available RAM. Script/TeX batches use
59seconds/1GiB/one thread; Lean2048MiB/one thread followed by a separate audit.
Owned unused products are removed after each batch; cleanup starts below20GiB.
Publication I/O and strict Sphinx use their separate monitored watchdog and
must not launch mathematical checks. Generated sites, compiler objects and
caches remain untracked. The optional936-file bulk payload is **unuploaded**.

.. toctree::
   :maxdepth: 1

   papers
   methods
   verification
   reproducibility
   scope

The `GitHub repository <https://github.com/sashakolpakov/CoxeterPolytopes>`_
contains source arguments and evidence. Read each check's declared scope before
interpreting PASS: written review, arithmetic replay and conditional Lean
logic supply different evidence.
