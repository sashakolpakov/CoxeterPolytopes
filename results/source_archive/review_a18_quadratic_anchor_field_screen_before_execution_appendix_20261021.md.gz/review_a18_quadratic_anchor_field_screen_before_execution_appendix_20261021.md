# Whole A18 quadratic anchor screen: full outside-author source review

21 October2026. **PASS before execution.** I read the entire new proof and
worker, independently checked their new mathematical arguments and every
source branch, and checked the relevant inherited interfaces. This is a
review of a conditional proof and a finite comparison algorithm. The new
comparison has not been executed by this reviewer, and its proposed output
predicate is not assumed or promoted here.

## Frozen sources and inherited data

* Proof: `results/arithmetic_whole_a18_quadratic_anchor_field_screen_20261021.md`,
  SHA256 `cbdaf7b6240b0da96d7017d4982255d96edc4a71949a4d2964c2243824d8577e`
  (9112bytes,183lines).
* Worker: `scripts/check_a18_quadratic_anchor_field_screen_20261021.py`,
  SHA256 `048221c82d0821c59784d32c858f76864ff7cd3025ef3bafdccf79a34789ff39`
  (4373bytes,85lines).

I streamed and matched both frozen hashes and all seven worker FIXED pins:
the two saved outputs `671550c2...` and `8c3b9ffb...`; the three written
inputs `b57aa75a...`, `06172cc3...`, `bcefd51d...`; and their two generating
workers `29da7434...`, `2ef5c365...`. Read-only inspection of the saved
outputs confirms37/59 retained quadratic polynomials and314/504 quadratic
index cells. Their stored source pins agree with the current inputs.
These checks inspect existing artifacts; they do not regenerate either
domain or constitute the new comparison run.

The degree-three exclusion is an inherited, separately reviewed argument
using the recorded30-anchor cubic comparison, not a consequence of this
new worker. Its actual-field conclusion and the rational Meyer obstruction
are exactly the interfaces used at proof lines32–37. The old and expanded
isolated domains retain their explicit Sturm, irreducibility, raw-time and
necessary-signature completeness boundaries.

## Complete fresh mathematical composition

At proof lines39–75 the changed loss is handled freshly. The inherited
finite white TYPES and zero/parallel exclusions are threshold independent;
the fresh half-loss source supplies the E, endpoint4 and two-endpoint3
strong inequalities. Dotted D-position ratio is at least6/sqrt10. Finite
near/D own labels at least7 are excluded by the conjugate Schur interval,
independently of weakness. Full old-plus-new Lorentzian Gram locking makes
the remaining helper parameter generate the ACTUAL field, so the argument
does not merely place it inside a possibly larger field.

For far endpoint3, the new upper bound t<68/25 and conjugate interval
(-193/250,12/25) allow exactly traces1,2,3. I independently checked the
three integral-norm intervals. They give t=phi,1+sqrt2,phi^2 respectively;
the trace3 case is retained rather than importing its earlier exclusion
at a different threshold. Near dotted t in(2,21/10) has trace1 or2 and
norm in(-2.31,-2) or(-.21,0), neither containing an integer. Thus all
nonisolated weak quadratic caps lie in the two stated fields.

The isolated finite case at lines77–99 also closes. Native8 has conjugate
beta=2-sqrt2>19/35 and violates the actual Schur condition. For native12,
xi=c+gamma*n_i has square delta=1-gamma^2>0, products xi.n_i=0 and
xi.c=delta. Therefore the displayed normalized projection annihilates
both core normals, is future timelike, and satisfies every unselected
actual-wall inequality: all correction coefficients are positive.
Farthest comparison gives x.(omega_i-n_i)>=sqrt(D_i-1)-tan(pi/12).
Together with x.n_i>0 this yields loss<.191+2-sqrt3<.459. No dotted
formula is applied with u>1, and no formal chamber completion is used.

For fields outside Q(sqrt2),Q(sqrt5), every half-loss weak central cap
is consequently isolated dotted. A .52-weak anchor exists byb57 and is
one of the OLD314 cells, with3/10<u=4/beta<1.

I independently checked the continuous bound at lines108–127. For
u<=4/5 the denominator sum exceeds100/19, so the square-root loss is
<.19u; the circle bound is <.604 because1+.19^2<1.018^2. With
sqrt(140/19)>2.714 this gives g>2.11. For u>=4/5, the separate lower
bound is2.523-.4=2.123. All printed decimal seals are valid strict
rational square comparisons.

The reference at lines129–151 is one legal same-x certificate. An internal
omission costs at most.043^2/4 and leaves energy>=1.02041795. At endpoint5,
the coefficient b6=1717/12000 pays5mu/6=2/15 for mu=4/25. The residual
Y=omega5-u*n5-(5/6)omega6 is orthogonal to the reference's flat initial
six-coordinate block, with Y^2=5/3-2u+u^2<347/300. Since
g-5H6/6>167/1200, completing one square gives exactly
60019491/60000000=1.00032485>1. All remaining positive coefficients
use strict strong floors on this SAME x. Reversal covers endpoint14.
There is no independent-energy addition or unpaid negative coefficient.

## Worker correctness and the conditional output interface

Worker lines33–35 use precisely the necessary signature
(degree, squarefree polynomial discriminant, squarefree absolute time-norm
numerator). In quadratic degree the discriminant square class identifies
the field; a same-field time ratio that is a K-square necessarily has the
same norm square class. Passing this screen is not asserted to prove a
K-square or realizability.

Lines51–67 visit EVERY degree-two target and EVERY degree-two old anchor,
retain every matching target ID, and compare actual coefficient dictionaries
and k. The generating workers construct consecutive array IDs, matching
the indexing convention here. The anchor inclusion assertion prevents an
empty list from vacuously passing. No expected match pattern is asserted;
the outside-silver/golden predicate at lines68–74 is a computed Boolean,
and all314 anchor match lists remain in the output. The loops are finite
over the two hash-fixed saved arrays; no root generation or scientific
module is called.

If that Boolean is true, the matching polynomial has a unique physical
root, and equal k gives only the same or reflected index. The inherited
raw Cartan cycle then rules out the distinct reflected pair: its OLD
anchor norm M<=7 is not divisible by19, whereas integrality of
beta^2*i*(19-2i)/19 would require an integral norm with uncancelled
denominator19^2. This uses the old anchor parameter, not the expanded
domain's larger norm allowance. Hence exactly the single weak index
handled above remains. This proves the stated field restriction IF the
new finite comparison returns the required predicate.

The imported primitive module has only standard-library imports,
definitions/constants and a guarded main; importing it runs no census.
The new worker hashes its proof, source, saved data and generating inputs
before/after the comparison. It requires parent-runner ownership, a new
results destination and exclusive output creation. Its compact output
retains matches, pins, counts, predicate and limited scope; stdout omits
the match arrays. No frozen input is written. The resource watchdog and
admission checks remain duties of the existing guarded runner, not claims
that the environment-variable check alone enforces resource limits.

## Verdict and contribution boundary

No correction is required before the root's guarded comparison. A successful
predicate would restrict ACTUAL K to Q(sqrt2) or Q(sqrt5) for a hypothetical
whole-A18 farthest vertex. This review alone establishes no execution
result, no exclusion of those two fields or wholeA18, and no ceiling17.
The six primary paper sources/PDFs and accepted ceilings are untouched.

I did not author the new proof or worker. I previously reviewedb57 and
contributed to older shared actual-foot/positive-reference inputs; those
inherited contributions are disclosed rather than called independent
reproofs here. The new finite-projection, quadratic-field inventory,
continuous endpoint estimates and complete worker/control-flow composition
were checked independently for this review. No scientific, Lean, TeX or
comparison job was run; only source reading and artifact metadata inspection
were used.
