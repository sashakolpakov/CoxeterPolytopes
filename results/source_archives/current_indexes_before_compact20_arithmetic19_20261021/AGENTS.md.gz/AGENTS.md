# Resource limits and proof batches

The user resumed the research with a new goal prioritizing lower dimension
bounds and new examples, subject to disk and memory control. Finish the
resource-control audit before starting a new heavy computation.

The user requires proofs in batches and removal of unused files after each
batch. This machine has24GiB RAM and has already suffered OOM and a full disk.
Prioritize mathematical progress; use Lean as the final verification of
settled statements.

## Research priorities: user steering,20 October2026

CURRENT PHASE CHECKPOINT: the six source-completion deliverables, their
initial full internal mathematical audits, and the requested selected
logic formalization now have evidence at the declared input boundaries.
The two priority papers additionally have fresh adversarial and published
input audits. Seven selected kernels/62 actual axiom prints pass. The
publication hold described below governed that completed finishing phase;
it is not an indefinite ban on the active mathematical goal. Resume work
on substantially lower bounds and new examples, while resolving any
concrete proof issue found by continuing audits. Lean remains the final
verification step for settled new mathematics. Do not substitute more
scalar wrappers, repeated successful checks or cosmetic index updates for
mathematical progress. No whole geometric Lean or external refereeing
claim follows from this checkpoint, and the overall goal remains active.

LATEST USER PRIORITY: finish the SIX existing TeX papers before further
dimension-bound research or new manuscript families. Give first attention
to the general finite-volume57 and sharp right-angled8/ideal4 papers.
Then audit the completed texts and formalize selected internal logic.
Exclude the parked nine-field19 refinements from the current universal
arithmetic20 paper, while preserving their source, PDF and verification
evidence. A preserved version or technical input is not a seventh paper.
Finish already-held proof reviews only to preserve their status; do not
promote new bounds or extend the held dimension23 research during this
publication-preparation phase. Mathematical supporting notes must not
become manuscripts for each increment. Resource gates and serial batches
below are unchanged. Do not call the goal paused: the user reprioritized
work within the same active goal.

PUBLICATION FOLLOW-UP: all six current TeX sources are complete at
their declared finite-data/companion-theorem boundaries and have fresh
internal mathematical source audits. All six current PDFs match their
sources. Finite57's current reviewed source isc300db69 (156120B/3322lines):
it adds explicit current-rule triangle exclusions and the full numerical
coarse forest screen, plus typed coarse k12 notation. Independent
fragment and integrated-delta reviews PASS. The current source also makes
the stored-positive-entry tight-witness condition and rank-zero exception
explicit. Its bounded rebuild now PASSes: current48-page PDF1f3c020c
matches sourcec300db69; the44-page PDF/source89bd edition is preserved.
The current57/compact20/compact23/sharpRA/idealRA4/compactRA4 PDFs
have48/17/36/5/17/14 pages. Finite57 main exposition is pp1–12; its
mathematical proof appendices and finite-table documentation are pp13–48.
Compact23 source2718192d/PDF39e665d8 remains36pages after the accepted
one-phrase correlation correction to "at most1/3" and removal of the
stale uncompiled-draft date label; strict demand still contradicts.
Both edits preserve the proof. No dimension bound or replay scope changed.
See `results/finite57_publication_bridge_completion_20261020.json` and
`results/review_finite57_coarse_forest_flattening_batch_guard_20261020.md`.
An adversarial audit found a missing full-budget classical unit-charge
bridge in the written57 tail. It was supplied, independently reviewed
and compiled in source89bd7658; that44-page edition and the earlier41-page edition are
byte-preserved. See `results/finite57_full_budget_bridge_repair_20261020.json`.
Five PDFs have zero warnings; the current48-page finite57 has21 underfull spacing warnings only, with no
overflow or unresolved-reference warning. Selected revised finite57
pages5,16,24,25 pass visual inspection; this is not an all-page audit.
See `results/finite57_publication_delta_visual_review_20261020.json` and
`results/six_paper_pdf_completion_20261020.json`. Parked19, frozen
predecessors, sources and evidence remain preserved. Do not restart
dimension research or create manuscript families during this audit phase.

The seven selected successors documented in
`docs/publication_logic_formalization_20261020.md` NOW have bounded
compilation and 62 actual axiom prints PASS: cubic 10, concentration 10,
compact23 accounting 8, Bellman 8, projection/height 8, finite-volume tail 9,
and dimension58 shape counting 9.
Only propext/Quot.sound/Classical.choice occur;
no sorryAx. Exact source/object/import/compiler bindings are in
`results/publication_logic_verification_20261020.json`. These are
conditional internal kernels with explicit geometric/script inputs,
not end-to-end Lean proofs. Current catalogue lists the verified modules.
Earlier bridge/preparation receipts are historical uncompiled versions.
The new `CoxeterProofs.ResidualBellmanCertificate` source cd2a05a6 now has
actual bounded compilation0.54s and axiom audit0.41s PASS. It derives maximum/attainment/None
equivalence from every transition and tight predecessor, not a supplied
maximum. Its eight actual outputs use only propext and Quot.sound; its
object/inputs/printed-output hashes are bound in the verification receipt.
It is now selected in finite57's catalogue. Concrete alphabets, context
separation, table obligations and geometry remain application inputs.
It imports Std from the pinned toolchain; the empty local dependency map
is not a separately hashed transitive Std object closure.

The coordinate projection/height kernel `RightAngledProjectionHeightKernel`
source 2fac8028 passed its first bounded compilation in 3.47s and the
separate eight-declaration axiom audit in 3.15s. It derives raw and
normalized projection identities, strict wall signs, exact orthogonal
heights, the cleared maximum-height recurrence, every finite descent
bound and the generic radial gap. No projection, height, gap or dimension
conclusion is supplied as a premise. Actual wall/face incidence, positive
real normalizers and geometric interpretation remain explicit inputs;
the old abstract ProjectionGeometry record is not thereby instantiated.
Root and independent source reviews pass. Source/object/dependency/compiler
and actual 1057-byte output bindings are in the logic receipt.
It is selected only in sharpRA's current catalogue, whose core/full now
have six jobs including PDF. All six now have actual combined PASS in
results/right_angled_sharp_projection_height_core_verification_20261020.json
(5.439s total outer job time). All30 actual prints match the source lists
and standard axioms in the separate core axiom-validation receipt; these
repeat existing declarations and do not inflate the seven-kernel62 count.
The seven-kernel receipt now binds fourteen current immutable compile/audit snapshots
under results/publication_logic_records_20261020/ rather than mutable
operational cache paths. Earlier receipts/summaries are byte-preserved.
The original 44-input frozen packet stays
unchanged. Map: docs/right_angled_projection_height_logic_20261020.md.

Finite57's full plan covers31 inherited higher-tail obligations. With
its verified concentration/Bellman/tail modules, two ancestor forest phases
and partitioned D13 selection, full/core have123/11 jobs includingPDF in the actual current plan (not a full runtime
PASS). Thirty original inherited tail commands PASS:65.182s total,
256278528B maximum RSS. The remaining108 obligation now has a complete
56-batch equivalent replay; its old59s timeout remains preserved.
Current combined plan:
results/publication_shape_counting_verification_plan_20261020.json;
the preceding Bellman and partitioned plan receipts are preserved history.
The full44-job replay FAILED at the original D13 loader's1GiB cap after
the final57 endpoint checker passed. No full replay PASS is claimed.
A19-part D13 successor and a partitioned108 successor preserve the
original frozen inputs and computations. Current D13 parser2f6 PASSes,
and all19 D13 parts PASS:24.408s total,184041472B maximum RSS.
Ledger: `results/finite57_d13_batched_replay_runtime_20261020.json`.
The108 replacement is now complete. Its oldd9ab metadata pilot PASSed;
domain execution exposed a SymPy Boolean sum TypeError. The same-predicate
correction126d5fe3 then had actual scanner-fixture PASS1.721s/89882624B
and metadata PASS13.832s, but domains FAILED2.709s at a tuple/list
representation comparison. Current workerf5f0b470 fixes only the three
expected key comprehensions; fixturef6fd1267, coverage456abc2b and
coordinatorcb776f59 change only dependent pins. All predecessors and
failed receipts are preserved. Current-source fixture PASS1.732s/89915392B,
metadata PASS13.792s, domains PASS5.369s and all eight profile units
PASS2.052s are now actual. The complete overlap-generation domain,
all disjoint joins/multi-edge subsets and all 85 inertia types now PASS.
All2196/2196 units now actually PASS in56 capped partitions. This includes
every384 overlap-owner classification and every949 isolation case.
Successful wrappers total388.008s with159,432,704 B maximum RSS.
The heaviest owner356 took35.723s with139,264,000 B peak RSS.
Both isolation pilots and all subsequent isolation batches PASS; earlier
resource deferrals and failed predecessor attempts remain preserved.
The runtime is sealed at1228a4a7; its old root checkpoint is retained in
history. Combined metadata validation now PASSes D1319/19 and distance9
2196/2196. That validates recorded coverage, not a new mathematical run.
Old successes earn
no credit under the new worker pin. See
results/review_distance9_expected_key_json_representation_fix_finite57_20261020.md
and results/distance9_symbolic_boolean_count_repair_20261020.json.
Current coverage validator456abc2b self-tests PASS14 mutations and its
actual D13 coverage PASSes19/19; this validates receipts, not mathematics. See
`results/partitioned_replay_coverage_validation_20261020.json`.
Original producers, wrapper and certificates are unchanged.
Every required partition has now passed under the same resource limits.
The complete56-interval catalogue proposal has root and independent PASS
and is now applied: catalogueea32bf41 replaces only the primary-finite57
old108 selection with the actual scanner contract and56 whole interval
checks. The old108 registry entry, every other paper selection and all
earlier sources/evidence are preserved. Integration receipt:
results/finite57_distance9_catalogue_integration_20261020.json.
A complete partition conjunction is not a combined full-manuscript runtime PASS.
Source-equivalence reviews are
`results/review_d13_transfer_batches_batch_guard_20261020.md` and
`results/review_selective_distance9_batched_replay_root_20261020.md`.
The remaining-phase source/cache audit and saved workload schedule are
results/distance9_remaining_phase_source_equivalence_and_schedule_20261020.md.
Isolation uses saved survivors only in conjunction with complete overlap
domain AND classification verification. Both are now complete. Do not
repeat successful pilots without a new source change or unresolved issue.
Current core sizes for57/compact20/compact23/sharpRA/
idealRA4/compactRA4 are11/10/2/6/7/1 includingPDF. Keep scientific/Lean/TeX
execution serial under the unchanged resource gates and remove unused
build products after each batch. Source audits, metadata and plans are
not mathematical checker executions.

Fresh independent mathematical composition audits of the current finite57
and sharpRA sources found no internal gap under their stated inputs:
results/review_finite57_theorem_composition_adversarial_20261020.md and
results/review_right_angled_sharp_foundations_adversarial_20261020.md.
Two newly selected ancestor replays now PASS:8114 Bellman tables and
10,195,241 transition inequalities,5.106s combined,318,799,872B peak RSS.
Their receipt is results/finite57_ancestor_forest_replay_execution_summary_20261020.json.
The selected full plan is not regeneration of every transitive producer:
some ambient59–65 forest/local-census outputs remain declared finite-data
inputs. Do not claim full123-job runtime PASS. Catalogue932269ff and its
reviewed integration receipt supersede ea32bf41; the older catalogue is
byte-preserved. The new FiniteVolumeTailKernel compiled in1.18s and its
nine actual axiom prints PASS. It checks105 literal cap comparisons and
derives scaled payment subtraction and near/far scalar contradictions;
it does not establish the geometric or finite-data interpretations, the
compact-facet alternative or a complete n<=58 tail. Its assumption map is
docs/finite_volume_tail_kernel_assumptions_20261020.md. All six manuscript
sources/PDFs and dimension bounds remain unchanged.

The dimension58 shape-counting successor40d12b57 now passes its first
bounded compilation0.59s and nine-print audit0.55s. It derives the local
minimum assignment and both841 extrema gains from primitive index splits
and opposite signs, reserves distinct extrema once, then derives the
finite754 and global8410 doubled shape inequality from the two incidence
identities. Curvatures are Int, with degree balance separate. Its source
and mathematical review PASS; actual geometry/index interpretation and
common-denominator Nat encoding remain explicit. This does not by itself
instantiate the older WrittenGeometry.shapeLower field. Map:
docs/finite_volume58_shape_kernel_assumptions_20261020.md.
It replaces only primaryfinite57's standalone ShapeCurvatureArithmetic
root, whose constants described ambient59. Sources/evidence and the
historical finite57_atlas selection are preserved. The finite57 plan
remains11core/123full jobs, not a combined full runtime PASS.

Primary-source audits now verify the sharpRA inputs and finite57's shape
identities. Musin, Kolpakov, Vinberg and Khovanskii originals were read;
Dufour's original full text was not obtained, and the exact mixed-vertex
27-facet consequence was checked in Alexandrov's original text as the
manuscript already declares. These are input-statement checks and internal
proof audits, not external refereeing. Evidence:
results/sharp_ra_external_input_audit_summary_20261020.json and
results/review_finite57_published_shape_inputs_20261020.md.

All proof/TeX jobs are terminal and the shared lock/work directory are
idle/empty. Read-only process names/cwd inspection found no leftover
repository worker; the observed active Lean work belongs to another
workspace and was left untouched. Disk remains above160GiB, well above
the20GiB cleanup trigger. Current sandbox blocks ps unless execution has
process-monitor access: use the approved bounded-runner access, never
disable its RSS watchdog. Earlier low RAM caused external admission
deferrals; recovered headroom admitted every final replay batch and the
sharpRA core run. The6GiB floor was never lowered and no uncapped
substitute was used.

LATEST WRITTEN AND LOGIC CHECKPOINT,21 October: receipt92784b48
(`results/whole_a20_and_two_end_couplings_written_acceptance_20261021.json`)
accepts the all-field WHOLE A20 exclusion (source457debf9,
outside-authorb8274aeb), general A18/A19/A20 two-end couplings
(43951a96, full outside03ab9616), and affine-A cycle order>=26
four-rule transfer/local order25 boundary (e2a637b6, outsidea2b719dd).
The latter does not affect finite57's small-factor negative cusps.
The uniform A_r,r>=15 actual component energy>5/7 theorem3fce3741
now has full root/outside-author PASS (outside977119bf), with all four
A15/A16 consumers. Acceptance54a930cb is
`results/uniform_a15_five_sevenths_and_d21_only_frontier_acceptance_20261021.json`.
The COMPLETE general n21 frontier now leaves ONLY WHOLE D21; no
general compact20 theorem. Arithmetic n20 still has WHOLE D20 and
smaller A alternatives; wholeA20/A18/A19/B20 are excluded. Ceilings
remain57/21/20. These are supporting notes for the same six papers;
compact primary TeX/PDF/accounting kernel remain their23 snapshot.

The new generic SummedActualFootKernel source41d183ca and object4010db9c
have actual bounded compile0.76s and separate ten-declaration axiom
audit0.66s PASS, only standard axioms/no sorryAx. Verificationf93f631d
is `results/summed_actual_foot_kernel_verification_20261021.json`.
Source review504c12b7 and the tiny sum-linearity delta review support
the source; failed predecessor f4dc and actual failure evidence are
preserved. The exact1229B stdout matches compile/audit. This derives
the structural weighted energy inequality, including adjacent feet;
actual geometry/inventory/reference/scalar estimates remain external,
not a formal A20 or dimension theorem. Old seven-kernel/62-print master
and snapshots unchanged; the combined supporting count is8kernels/72
distinct actual declarations, not82. New module is not automatically
added to manuscript catalogue selections. Both capped jobs are terminal,
shared lock free, temporary outputs removed; latest disk161.44GiB/RAM6.61GiB.
No cleanup trigger. No new enumeration/TeX or manuscript in this batch.

Subsequent publication wording batch: sharpRA's final full read74269509
found no gap, but “four-facet Q” was ambiguous. The SAME paper now uses
`manuscripts/right_angled_sharp_dimension_bounds_publication.tex`
source0d607b48, PDFc4449e3d,5pages/0warnings, bounded build0.914s/
83,640,320B. Sole mathematical-text delta is “four-dimensional facet Q”.
The old source/PDF/proof map stay at their paths: all44original freeze
entries freshly hash/size match. Current map is
`docs/right_angled_sharp_dimensions_publication_proof_map_20261021.md`;
catalogue id right_angled_sharp unchanged, six primary paper bundles and
33ownedTeXfiles including preserved predecessors. New build receipt:
`results/right_angled_sharp_publication_terminology_build_20261021.json`.
Old six-job core/30prints remain predecessor evidence, NOT a fresh
combined runtime PASS for the successor. Unchanged figures retain their
old visual-review scope, not a new all-page review. No script/Lean
rerun was needed for this one-phrase mathematical-text change.
The source-bound compact21 integration plan is
`results/compact21_existing_manuscript_integration_plan_20261021.md`:
replace terminal sections in the SAME compact paper and combine foot/
prefix arguments; do not append increment chapters or advertise current
23-stage PDF/kernel as21. Latest resources161.42GiB disk/6.29GiB RAM,
shared lock idle and workdir absent. Temporary TeX outputs removed.
Final successor acceptance9473d142 is
`results/right_angled_sharp_publication_terminology_acceptance_20261021.json`;
six-paper current-pair checkpoint198fae4a is
`results/six_paper_finishing_checkpoint_20261021.json`. All referenced
artifact pins and28new-map local links freshly match. These are integrity
checks, not new mathematical runs. Latest recorded resources161.33GiB
disk/6.65GiB RAM. Six primary bundles/33ownedTeXfiles; goal remains active.

EARLIER CONTINUATION,21 October: the next batch has full root/separate-agent
written PASS, with no ceiling change57/21/20. Complete n21 frontier2edf
excludes every proper B/D component; whole-B21 sourcecec1539f is also
accepted (outside4141c3f5), leaving wholeD21 and the stated A forests.
All-field arithmetic wholeB20 source5f7932b2 is accepted (outside04abe1b4);
its93d predecessor is byte-preserved and only the bare-foot >= wording
changed. Central A packing8599baed has full outside3703a78e PASS: weak
near4 is conjugately impossible; golden nearer-end helpers occupy at
most ONE central index at N19/20/21. The consumers exclude arithmetic
n20 A18/A19. WholeD20, wholeA20 and smaller A alternatives remain open;
there is no arithmetic19 conclusion. Root joint review35298ee1 covers
the complete n21 frontier/B21/B20 proofs. Receipt:
`results/compact21_frontier_and_arithmetic_a_packing_acceptance_20261021.json`.
The finite57 reentry note82295384 and outsidea465d408 prove three analytic
lemmas, but its quadrilateral7/4 rule and ceiling53 remain prospective.
Six TeX/PDF pairs and seven Lean snapshots remain unchanged; compact PDF
and accounting kernel still23. No new manuscript, Lean wrapper or heavy
job. Next manual research may start at D20 actual fork profiles: the .58
centre route is promising but not yet frozen/accepted, and fork closure
is still missing. Preserve all current sources and review boundaries.

CURRENT GLOBAL UPDATE,21 October: arbitrary compact Coxeter dimension
is now at most21 at the complete internally reviewed WRITTEN-PROOF
level. Whole B22/D22 are excluded by the new .58 window/terminal proof
22aaa88e, `results/compact_whole_b22_d22_uniform_terminal_pressure_exclusion_candidate_20261021.md`.
Full root review and complete global21 composition are
`results/review_compact_whole_b22_d22_uniform_terminal_pressure_root_20261021.md`
(fd103b85); full outside-author review51502bfc accepts BOTH the entire
local proof and the global composition. Root review's pending wording
is the preserved pre-outside-review snapshot, not the current status.
It combines the prior global22 theorem8a691e4f, complete dimension22
four-case frontier35598a80 and accepted rank21+I obstruction8183924e.
Every remaining dimension22 diagram is now excluded. No arithmetic
hypothesis, arbitrary-face inheritance or new enumeration is used.
The source explicitly reclassifies the enlarged .58 weak class, keeps
isolated dotted5 until after the tails, and uses effective dual energy
L=2A-||W||^2 rather than silently substituting ||W||^2. Bare actual
point pressures are >=; strict scalar seals retain the final exact
1.000035859375 contradiction. Predecessorceaa is byte-preserved.
Current ceilings are57/21/20 for general finite volume/general compact/
arithmetic compact. All six finished source/PDF pairs and seven selected
Lean snapshots remain unchanged; compact paper/accounting kernel still
state23. Consolidate new support into THAT paper when the next bound is
settled, without per-increment manuscripts or scalar Lean wrappers.
Batch receipt: `results/compact_dimension21_written_acceptance_20261021.json`.

The field-uniform arithmetic short-tail composition1a2c62ad additionally
has full root and outside-author reviewb338a237 PASS, over every actual
ground field. Its first CLASSICAL n20 frontier was whole B20,
D19+isolated I, or whole D20; A alternatives remain separately open.
Its B2 conjugate seal and D fork-helper norm/actual-H4 argument do not
give arithmetic19. The q>=E_K reference-norm clarification preserves
every strict final bound; predecessorb6ab is byte-preserved. The new
D19+I theorem02444f3e additionally has full root and outside-author
review61ae9dd4 PASS: `results/arithmetic_d19_isolated_i_terminal_coupling_candidate_20261021.md`.
It retains the allowed left3/fork3/I3 finite bridge, proves the own0
fork>=7 arithmetic m12 restriction, and uses ONE simultaneous terminal
graft orthogonal to the first-five I adjustment. The CLASSICAL n20
frontier is now ONLY whole B20 or whole D20. A alternatives and the
universal arithmetic20 ceiling remain open/unchanged respectively.
No arbitrary-spectator or whole-D20 conclusion follows from D19+I.
Next manual lanes: general n21 forest/A bottlenecks; all-field arithmetic
whole B20/D20; general finite-volume57 improvements. No heavy jobs
currently admitted or running. Further Lean waits for settled geometry.

EARLIER GLOBAL22 UPDATE: arbitrary compact Coxeter dimension is now at
most22 at the complete internally reviewed WRITTEN-PROOF level.
Accepted composition8a691e4f:
`results/compact_dimension23_exclusion_composition_candidate_20261020.md`;
root acceptanceb314f6a6 and separate composition review8ccd1c7d.
The new inputs are uniform A>=8 actual energy>4/7 (390bbf35),
A19/A20>6/7 (8075f92f), and corrected whole-D23/B22,D22+isolated-I
proof (a77f88f5); all have full root and separate-agent mathematical PASS.
Only one rational-premise paragraph changed in the D source; its original
53986c86 bytes are verified and preserved. No new scientific execution,
TeX or Lean claim. The finished compact manuscript/PDF and accounting
kernel remain their exact23 snapshot; the new22 result is supporting work
for the SAME paper, not a seventh manuscript. Current ceilings are
57/22/20 for general finite volume/general compact/arithmetic compact.
Continue to seek material uniform improvements or a new compactH9
example; do not turn each increment into another long paper or scalar
Lean wrapper. Research acceptance receipt:
`results/compact_dimension22_written_acceptance_20261020.json`.

EARLIER TERMINAL/ARITHMETIC BATCH,21 October: the necessary dimension22
farthest frontier is now ONLY whole B22 or whole D22. The new rank21
plus isolated-I exclusion8183924e has full root mathematical acceptance
and outside-author review29a48bb4. The prior complete four-case frontier
35598a80 plus that theorem gives the two-case frontier; the separate
composition reviewer confirms the quantifiers and scope. Acceptance:
`results/review_rank21_i_and_uniform_arithmetic_root_20261021.md`.
Batch receipt:
`results/compact_terminal_and_uniform_arithmetic_acceptance_20261021.json`.
The same acceptance reviews the new field-UNIFORM arithmetic first-type
weak-helper obstruction535ac0d0, with independent full review4db133a9:
literal far helpers are impossible in B/D long indices>=6 and the stated
A central window. This uses minimal-field norms and conjugate Schur
positivity, not a field census. The isolated end5 star and unclassified
fork/tail patterns are NOT excluded. The limited B18/D17 dimension20
consumers do not give arithmetic19. Current ceilings remain57/22/20;
all six current source/PDF pairs and selected Lean snapshots remain
unchanged. Prioritize the two whole-component alternatives or a material
all-field arithmetic improvement. Do not transfer a .61 weak inventory
to a .58 floor without classifying the newly weak actual profiles.
No scientific, Lean, TeX or enumeration job in this written batch.

EARLIER UNIFORM-PRESSURE BATCH,21 October: the complete root and
separate-agent mathematical composition35598a80 now leaves ONLY these
dimension22 farthest forests: whole B22, whole D22, B21 plus isolated
short A1 I, or D21 plus isolated short A1 I. Source:
`results/compact_dimension22_remaining_forest_frontier_20261021.md`;
outside composition review7046435d. Every A-type alternative in n22
is now excluded, not every A vertex in every dimension. New accepted
actual-energy bounds are A_r>=16 >9/14 (cf14513f) and A_r>=17 >31/40
(194caa4f). The complete A20/rank-two-spectator coupling6ed1ed3c
handles both I intervals and BOTH isolated7 roles via the .91 end-tail
certificate. Uniform classical prefix gain194c2b8b removes D20+7;
do not double-add it to an overlapping first-coordinate I gain.
All have complete root and separate-agent written PASS, no new
enumeration, scientific job, TeX or Lean. The global ceiling remains22;
the six finished manuscripts/PDFs and accounting kernel stay their
exact compact23 snapshot. Keep one paper, with these supporting
research notes consolidated when the next bound is settled. Prioritize
the then-four B/D alternatives, material arithmetic first-type obstructions
or genuinely new compact dimension9 constructions.

The literal golden host `<-phi>+H3+A6` is now CLOSED at the internally
reviewed WRITTEN-PROOF level: accepted period proofb8985c4b,
`results/compact_h9_h3_a6_end_edge_period_obstruction_candidate_20261021.md`,
root review166350c4 and outside reviewdd7669db. Under compactness any
actual first end-edge endpoint forces an integral FULL-chamber period
of trace3+5u>10. This is not a no-finite-endpoint proof. Its actual
starting corner uses the inherited complete H30 lower-height census;
positive-height spatial exhaustion is source-reviewed, not independently
rerun in full in this batch. Noncofiniteness additionally uses the named
anisotropic arithmetic-lattice input. Stop prefix/edge/Pell/compactness
searches of this literal host; older reentry notes calling it open are
historical. Other integral lattices, time coefficient2phi, and entire
similarity/commensurability classes are NOT excluded. No example or new
dimension ceiling, no new executable replay or Lean instance follows.

PREVIOUS GLOBAL23 CHECKPOINT: arbitrary compact Coxeter dimension is at
most23 at the complete internally reviewed WRITTEN-PROOF level.
See `results/compact_dimension23_farthest_forest_composition_20261020.md`,
accepted source12d9112d, with two full separate-agent composition reviews.
The uniform A>=7 half bound, A>=17 five-sevenths bound and generic
classical prefix theorem have complete root and separate-agent PASS.
The generic prefix accepted source is corrected f637d729; an insufficient
scalar justification in3a1188e3 was repaired before acceptance. These
are not new Lean or exact-worker execution claims. At that checkpoint ceilings were
57/23/20 for general finite volume/general compact/arithmetic compact.
The canonical compact farthest-vertex manuscript is being prepared as
ONE paper; do not create separate papers for26/27 predecessor notes.
Earlier statements below about no ambient improvement describe the
individual predecessor lemmas, not the new global23 composition.
Do not restart dimension24--29 compact searches. Both former dimension24
frontiers are now excluded: A20 actual energy>11/14 with arbitrary
spectators (source1720c1d8), and the coupled D23/isolated-short-A1
obstruction (source530d16ad). Both have complete root/separate-agent
written PASS. Prioritize a lower ceiling, stronger arithmetic bounds or a new compact
dimension9 example. Lean remains the final step under unchanged serial
resource gates. See `docs/compact_farthest_vertex_bounds_proof_map_20261020.md`.

The user judges a long field-specific refinement from20 to19 poor value
while compact examples stop at8. Preserve the completed nine-field proof
and verification package, but stop expanding its casework, manuscript or
Lean coverage. Do not promote that refinement as the main research goal.
The right-angled gaps were closed on20 October at the internally reviewed
written-proof level: universal finite-volume ceiling8 and entirely ideal
ceiling4, both matching published examples. One five-page paper is
`manuscripts/right_angled_sharp_dimension_bounds.tex`; its four-job core
and conditional12-theorem Lean audit pass. Geometry and the named
published inputs remain explicit premises; this is not external refereeing
or end-to-end geometric Lean. The44-input immutable packet is
`results/right_angled_sharp_dimensions_20261020_freeze.json`.
Do not continue searches for ideal5 or right-angled9 examples, or refine
the superseded right-angled10 bound. Preserve their earlier evidence.
Prioritize material bounds closer to examples in the remaining general
and compact/arithmetic classes, or a new compact example in dimension9.
The24-cell structure and compact120-cell volume problems remain separate
research lanes. Seek actual dimension exclusions or new examples,
rather than longer proofs for small local improvements.
The existing general57 research is retained support; further incremental
transfer work is deferred in favor of these priorities.
The farthest-vertex research now excludes every whole finite forest
whose irreducible components have rank at most4, in dimensions n>=15.
Full written root and outside-author reviews pass; this is supporting
research, not a new uniform dimension ceiling. Larger A,B,D,E components
remain open. Do not extend small-component n=14 casework or build new
manuscripts/Lean for these lemmas unless they yield a material global
bound. See `results/compact_farthest_rank_four_forest_exclusion_20261020.md`.
The whole-A21 successor now has complete root written PASS and a
separate outside-author mathematical PASS: a whole A21 farthest vertex
is impossible in compact dimension21, without arithmeticity. See
`results/compact_whole_a21_farthest_vertex_exclusion_candidate_20261020.md`
and `results/review_compact_whole_a21_farthest_vertex_root_20261020.md`.
The source's candidate title is historical. Arbitrary spectators, all
higher A ranks and a uniform dimension ceiling are not established.
Keep the theorem in the same farthest-vertex supporting packet, without
new scientific jobs, TeX or Lean expansion for this local result.
The reviewed plateau successor now covers every WHOLE A_n for21<=n<=29,
without arithmeticity. Complete root and outside-author written PASS:
`results/compact_whole_an_geometric_a21_plateau_transfer_20261020.md`.
The compact published29 tail exhausts possible whole A_n ranks>=21;
this is not an arbitrary-spectator component theorem or a new ceiling.
The reviewed extended-D4 successor now also covers D5,D6,E6,E7,E8,
with arbitrary spectators. In n>=15 every farthest vertex must therefore
have an A_r or B_r component with r>=5, or D_r with r>=7. Exact component
energies and a complete restricted-forest aggregation have independent
root PASS; see `results/compact_universal_e6_e7_e8_component_energy_20261020.md`.
This is not a uniform dimension bound. Keep one supporting research
packet, with no extra TeX or Lean expansion.
The reviewed common-opposite successor adds D7 energy>1/2; the new
three-direction proof adds D8 energy>4/7, with arbitrary spectators.
Complete outside-author written PASS and root composition checks:
`results/compact_d8_three_direction_component_energy_20261020.md` and
`results/review_compact_d8_forest_composition_root_20261020.md`.
The earlier uniform E_Dr>4/7 theorem for r>=8 remains accepted:
`results/compact_dn_uniform_energy_and_chain_relaxation_20261020.md`.
The CURRENT successor now proves ACTUAL farthest projection
||x_D||^2>9/14 for EVERY D_r,r>=9, with arbitrary finite spectators:
`results/compact_dn_actual_projection_nine_fourteenths_20261020.md`.
Complete root and outside-author assembly reviews PASS. The complete
common1/2 and2/3 inventories, native7 actual Lanner dual foot and exact
three-pair positive-dual certificate are all separately source-bound.
Do not relabel the new theorem as an edge-only H_K covering-energy
bound: actual feasible negative-core/dual-foot points are essential.
For n>=15 without A/B rank>=5, the unique D now has
r>=max(10,n-5), with spectator total rank at most5. No ambient ceiling
or rank/14 rate for all larger D ranks follows. The supporting
common3/4 inventory also has full root/outside-author PASS in
`results/compact_dn_common_three_four_farthest_obstruction_20261020.md`.
Keep all these in the same research packet, with no primary TeX or
Lean expansion for local lemmas. At that earlier stage the global
ceilings were57/29/20; the new global23 composition above supersedes it.
The whole-B short-tail successor now excludes a WHOLE B_n farthest
vertex for every n>=23, without arithmeticity. Root and outside-author
written reviews PASS; see
`results/compact_whole_b_short_tail_extension_20261020.md`.
The accepted n>=26 predecessor remains unchanged. Whole B21--B22
and arbitrary spectators remain open. These are the same
supporting packet, with no new scientific jobs, primary TeX or Lean.
The CURRENT A/B successors now exclude A_r COMPONENTS21--29 and
B_r COMPONENTS23--29 WITH ARBITRARY finite spectators. The ambient
compact29 theorem covers larger relevant ranks. Both complete
transfers have root and separate collaborating-agent written PASS:
`results/compact_an_large_components_arbitrary_spectator_transfer_20261020.md`
and `results/compact_bn_large_components_arbitrary_spectator_transfer_20261020.md`.
They repair zero-own-contact branches, clear all foreign pressure with
actual finite/timelike points and prove every weak cap has Q0 before
transferring the whole-rank positive-dual certificate. The separately
reviewed finite foreign-far lemma is
`results/compact_classical_foreign_far_packet_strong_20261020.md`.
The localized B successor also proves sum_(j=1)^7 x_j^2>9/14 for
EVERY B_r,r>=9, arbitrary spectators, including the r9 F4 case:
`results/compact_bn_actual_projection_nine_fourteenths_20261020.md`.
Full root/separate-agent written PASS. Do not reopen these transferred
rank ranges or confuse the localized estimate with edge-only H_K.
Smaller components and the global compact/arithmetic ceilings remain
open. Keep the same research packet, with no new primary TeX or Lean.
The CURRENT large-D successor now excludes D_r COMPONENTS24--29 with
arbitrary finite spectators, by complete bulk/D4/D3-tail inventories
and two averaged ACTUAL H4/A2 feasible-point pressures. Full root and
separate collaborating-agent mathematical reviews PASS:
`results/compact_dn_large_components_short_tail_transfer_20261020.md`.
The index5 bootstrap uses only bulk6/16/17 before either averaged
tail; the proof is noncircular. The final prefix20/21 certificate is
unchanged. Thus every farthest vertex of any hypothetical compact
29-polytope MUST contain A5--A20 or B5--B22. Only the restricted
class having a farthest forest without A/B rank>=5 gets ceiling28;
DO NOT announce an unconditional compact28 theorem. Remaining small
A/B component energy rates and large-A energy are the next global
obligations. Same research packet, no new TeX, Lean or scientific job.
The CURRENT small classical successor proves ACTUAL component rates
A5>3/8, A6>3/7, A7>1/2, B5/B6>3/7, B7>1/2 and B8>4/7,
with arbitrary finite spectators. Complete root and separate-agent
written reviews PASS. The corrected A7 source is pinned to5ae61f57;
the rejected predecessor7eac5c72 had a reversal-sign error. Its
positive-correlation repair gives11/20>1/2. See
`results/review_compact_universal_a7_two_end_projection_root_20261020.md`.
The parameterized forest aggregation in
`results/compact_forest_ordinary_a_parameter_and_dominant_classical_frontier_20261020.md`
now applies with M7: every farthest vertex of a hypothetical compact29
polytope must contain A8--A20. This supersedes the earlier necessary
A/B alternative; it does NOT exclude the remaining A components or
prove an unrestricted28 theorem by itself. A8 and the uniform larger-A
theorems now have complete root/separate-agent written PASS. Keep
the same supporting
packet; no new primary manuscript, scientific job, TeX or Lean expansion.
The whole-D_n isolated long-end5 profile is now excluded for EVERY
compatible lattice in compact arithmetic first-type dimension n>=8.
The complete fourfold sandwich/residue/norm-recovery proof, including
odd deep lifts, has full outside-author PASS. See
`results/golden_dn_long_end_five_invariant_lattices_20261020.md`.
Other labels and spectators are open; no uniform ceiling follows.
The compact RA4 global charge gives Nu>=f-2W+N2. The C26 successor
now strengthens the numerical bounds to f>=61 and Vol>=47pi^2/6.
Its complete actual-symmetry proof and stdlib fixed checker have full
root PASS; generation/fresh replay PASS (0.131s,56,033,280B peak).
The count-one fullerene classification and Andreev uniqueness are
explicit inputs. See `docs/compact_ra4_c26_successor_reproduce_20261020.md`.
The checked charge consequence forces a uniform D for W<=33;
separating H2 remains the low-volume obstruction.
The C28 successor now gives the CURRENT compact RA4 bounds f>=65 and
Vol>=49pi^2/6, with boundary-positive excess d>=5. Both written reviews,
reviewed fixed checker generation and separate fresh replay PASS:
0.135s total,56,754,176B peak,29,156-byte certificate. The strengthened
charge forces uniform D for W<=37; a non120-cell at or below its volume
with connected D graph needs W>=38 and f+W>=103. Separating H2 remains
open. See `docs/compact_ra4_c28_successor_reproduce_20261020.md` and its
27-input immutable packet. Keep the C26 predecessor unchanged; no new
primary manuscript, Lean or TeX. Graph classification and actual
metric uniqueness remain explicit premises.
Unrestricted120-cell minimality and its second volume remain open.
These are supporting notes, not new manuscripts or Lean batches.
The full integral root arrangement of `<-sqrt3>+<1>^9` is now EXCLUDED
as a construction host. The complete first-edge census exposes a scalar
facet whose entire integral lattice is E8(O) plus <1-sqrt3>. Two complete
facet edges and an integral isometry of trace5+3sqrt3 certify an
infinite-order stabilizer of its full chamber. All four exact workers
have generation and separate replay PASS, with root and independent
written reviews. Stop further edge searches of this literal host.
This is neither a uniform dimension bound nor an exclusion of its whole
quadratic-form commensurability class. No new example is obtained. See
`docs/compact_h9_sqrt3_first_edge_reproduce_20261020.md`. Keep this
completed search exclusion separate from the dimension-bound packages.
The literal golden discriminant59 host
`E8(O)+[[-2phi,-1],[-1,4+2phi]]` is also now EXCLUDED. Its actual
Bugaenko facet and full E8+c edge lead to a complete D7+c interval with
only one first wall. An explicit integral full-chamber isometry has
trace40+55phi>10, proving nonreflectivity. Both exact workers have
generation and separate replay PASS, root and independent written
reviews. Stop all further edge searches of this literal host. See
`docs/compact_h9_golden_discriminant59_reproduce_20261020.md`.
The completed25-input immutable packet is
`results/compact_h9_golden59_nonreflectivity_20261020_freeze.json`.
Neither closed host yields a uniform dimension bound, a new example or
an exclusion of its entire quadratic-form commensurability class.
The literal quadratic13 host `<-(3+sqrt13)/2>+I9` is now also EXCLUDED.
Four complete finite edges yield two integral chamber involutions whose
product has trace268eta+80>10. Three exact workers have generation and
separate replay PASS; complete written proofs have root and independent
reviews. The shared ChamberPeriod Lean module checks final group/coset
logic conditionally, with actual geometry and trace inputs explicit.
Stop further searches of this literal host. Its33-input immutable packet
is `results/compact_h9_sqrt13_nonreflectivity_20261020_freeze.json`; see
`docs/compact_h9_sqrt13_reproduce_20261020.md`. No uniform ceiling, new
example or whole commensurability-class exclusion follows.
The literal discriminant19 host `E8(O)+[[-2phi,phi],[phi,2]]` is now
EXCLUDED too. A complete binary first edge and all eight D7+c profiles
give a full actual corner; its integral chamber involution and the full
Bugaenko facet reversal have product trace10+14phi>10. The fixed checker
has generation and separate replay PASS, with root and independent
written reviews. Stop all31-wall and other edge searches of this host,
including its x=2 duplicate. Preserve earlier sources unchanged. See
`docs/compact_h9_discriminant19_reproduce_20261020.md` and the25-input
`results/compact_h9_discriminant19_nonreflectivity_20261020_freeze.json`.
The broader E8-plus-binary family is infinite and is not exhausted by the
closed host catalogue. No new uniform bound or compactH9 example follows.
The distinct GOLDEN norm31 host
`E8(O_phi)+[[-2phi,phi^2],[phi^2,2]]` is now also CLOSED. Full base and
E7-germ proofs yield integral full-chamber involutions whose product has
trace28+42phi>10. Root/outside-author mathematical and final code reviews,
bounded generation and separate fresh replay PASS:0.737s total,
57,999,360B peak,38,416-byte certificate. See
`docs/compact_h9_golden31_reproduce_20261020.md`; its18-input packet is
`results/compact_h9_golden31_nonreflectivity_20261020_freeze.json`.
Stop further searches of this literal host. It is distinct from the
silver norm31 host; the infinite golden binary family and other lattices
in the commensurability class remain open. No new example or ceiling.
The uniform unit-coupled golden-family successor now proves the FULL
Bugaenko base and inherited actual chamber involution for EVERY k>=-1,
without a squarefree-discriminant assumption. The exact whole-ideal
congruence handles repeated factors and all nonnative finite angles.
Full root and outside-author written reviews PASS; see
`results/golden_e8_binary_family_full_base_facet_20261020.md`.
Do not repeat base-root calibration for these L_k. The uniform first
binary edge is now also proved for every k>=-1 and ALL divisor norms:
`results/golden_e8_binary_family_uniform_first_edge_20261020.md`.
Complete root and outside-author written reviews PASS. The single
algebraic integer T=-lambda*nu has norm-1, contradicting golden-unit
spacing; no factor/Pell search is needed. Its actual endpoint is the
full E8+A1(c) germ. Other transverse edges and a second independent
involution remain open; this does not close the infinite family.
The growing FULL-base collar now has root/outside-author written PASS:
`results/golden_e8_binary_family_discriminant_collar_and_finite_cutoff_20261020.md`.
Its width is D=asinh(sqrt(N(b))/8)/2 and
Vol(C)>(N(b)^2-256)/2^57. The pinned full-chamber analytic upper,
including the chamber-stabilizer factor, implies reflectivity only
for k<=2268; every literal member k>=2269 is therefore excluded.
The remaining finite range is open apart from separately closed
members. The coarse cutoff is not authorization for a host-by-host
search, and changes no dimension ceiling. No new scientific or Lean job.
The literal k4 golden member b=25+34phi,N(b)=319 is now CLOSED at
the complete reviewed PAPER-PROOF level. All58 scalar strip entries
were hand-recomputed in both root and separate-agent reviews; one
draft norm typo was corrected before acceptance. Proper11/29 norms
are excluded by residues; the first actual transverse full-b wall
gives an integral chamber period of trace158+245phi>10. See
`results/compact_h9_golden_k4_transverse_edge_and_period_candidate_20261020.md`.
The candidate title is historical; source-bound reviews define status.
Its two polynomial identities give a finite transverse UPPER mirror
for EVERY k>=-1, without asserting uniform firstness. Stop searches
of this literal k4 host. Executable reproduction and Lean are pending;
no scientific job, new example, global ceiling or commensurability-
class exclusion is claimed. All earlier frozen packets are unchanged.
The odd silver diagonal family `<-(1+sqrt2)>+I_m` is EXCLUDED for
every m>=7 by the exact published cutoff: Allcock, Geometry & Topology10
(2006), Section2 p.740, attributes to Bugaenko the compact-chamber iff
m<=6 for this literal form. The admissible anisotropic arithmetic input
gives noncofiniteness. The earlier independently reviewed n>=9 stable
isometry, tiny local-basis generation/replay and38-input frozen packet
remain valid historical support; their bytes and narrower guide stay
unchanged. This corrects an overlooked published input, not a new global
dimension bound. Stop all searches of this literal family. See
`results/ramified_silver_uniform_published_facet_closure_20261020.md`.
No field-wide or rational commensurability-class exclusion follows.
The separately reviewed invariant-lattice successor now excludes
isolated native8 contacts at nodes1 and3 of a whole B_n vertex in
compact arithmetic first-type dimension n>=9, for EVERY compatible
invariant lattice. Every dyadic lift is covered; the even neighbor is
excluded by a full facet mirror-SUBSET argument. Root and outside-author
composition reviews pass. Node2 and other labels remain open; this is
not a uniform dimension ceiling or all-silver-form obstruction. Keep
one research packet, no new manuscript/Lean expansion. See
`results/review_silver_b_invariant_lattices_and_star_applications_resource_20261020.md`.
The concise golden invariant-lattice interface now also excludes isolated
native5 contacts at long nodes1 and5 of a whole B_n vertex in compact
arithmetic first-type dimension n>=8. It proves exact equality of the
orthogonal groups for EVERY compatible invariant lattice; root and
outside-author reviews pass. The literal golden diagonal cutoff is an
explicit published input, not an own theorem or an assumption about
commensurability. Nodes2/3/4 and other cap types remain open. This is
support for a uniform compact bound, not a new ceiling, example,
manuscript or Lean task. See
`results/golden_b_isolated_five_invariant_lattice_interface_20261020.md`.
The literal ramified silver family `<-sqrt2>+I_n` is CLOSED for every
n>=8, including M9. The uniform first edge retains B_(n-1), including
B7 at n8, and gives an actual norm(2-sqrt2) wall r. Its divisor forces
every crossing mirror orthogonal, and an exact integral direct sum
identifies the FULL facet with L_(n-1). The published cutoff above and
explicit arithmetic inputs prove noncofiniteness. The complete
composition has outside-author PASS; see
`results/review_ramified_silver_uniform_published_facet_closure_resource_20261020.md`.
Preserve the earlier n>=10 bridge, two M9 edges and reviewed finite L8
involution as historical support. The prospective M8 symmetry proof
was unfinished and is unused; no new worker or job was needed.
Stop all edge, prefix, Pell and period searches of these literal M_n.
Arbitrary native8 node2 invariant lattices remain open; no uniform
ceiling or commensurability-class exclusion follows.
The genuinely biquadratic candidate
`N_n=<-a>+I_n`, a=phi+sqrt2-1 over Z[sqrt2,phi], is now CLOSED
for every n>=8, including N9. Complete first and second actual edges
give two different FULL rank-two faces, I2(8) and I2(4), each carrying
literal N_(n-2). The latter seal handles arbitrary mirrors through a
finite B3 root orbit and integral projection, not native extensions
alone. Exchanging the order of these face constructions gives an
integral future full-chamber period with active trace
196phi+121+sqrt2*(138phi+86)>5. Its powers give infinite reflection-
group index; the explicit arithmetic lattice input gives noncofiniteness.
Full root and outside-author mathematical/source reviews PASS.
Fixed generation and separate fresh replay PASS:0.215s total,
56,311,808B peak,17,021B certificate. See
`docs/quartic_order_exchange_reproduce_20261020.md` and its immutable
manifest. Stop all edge, prefix, Pell, period and compactness searches
of these literal N_n,n>=8. N2 has a compact reflective quadrilateral;
lower dimensions, other lattices and commensurability classes are not
excluded. No uniform dimension ceiling, new example, primary manuscript
or new Lean instance follows. Earlier OPEN source language is historical.
The ramified cubic-seven diagonal family `<-t(2-t)>+I_n`, with
t=2cos(2pi/7), is also now EXCLUDED for every n>=3. Complete norm and
coordinate-facet proofs reduce to dimension3. Two complete actual edges,
a dyadic A3-germ obstruction and two chamber involutions with no common
hyperbolic fixed point contradict compactness. Full root and separate
adversarial written reviews pass. The standard arithmetic lattice and
anisotropic compactness theorem is an explicit external input for the
cofinite conclusion. No new script or Lean execution is claimed. Stop
all further edge, root-prefix and Pell searches of this literal family;
see `docs/cubic7_ramified_diagonal_family_reproduce_20261020.md`.
This excludes neither all K7 forms nor a rational commensurability class,
and changes no dimension ceiling or known example.
The literal golden dyadic family `R_n=<-phi>+I_n+D4(O_phi)` is now
CLOSED: its FULL integral reflection groups are noncofinite for every
n>=5 (hyperbolic dimensions n+4>=9). Complete actual-wall proofs give
two full H4+B3+B2 vertex germs of R5; an integral future chamber period
has trace10+11phi>10. Its powers give infinitely many distinct cosets
modulo the full reflection group. Exact full coordinate facets propagate
noncompactness; the explicitly imported Borel--Harish-Chandra arithmetic
lattice theorem and anisotropic compactness criterion give noncofiniteness
throughout this literal family. No similarity/commensurability-class
exclusion, new example or uniform dimension ceiling follows.
Root and outside-author paper/source reviews PASS. The final fixed
generation and separate fresh replay PASS:108 strip tests,1.031s total,
58,507,264B peak. See
`docs/golden_dyadic_family_nonreflectivity_reproduce_20261020.md` and
`results/golden_dyadic_family_nonreflectivity_20261020_freeze.json`.
The old25-input M6 freeze and its old reproduction guide remain unchanged;
their OPEN language is historical. Compact M6/tetrahedral faces and
finite-prefix escapes are preserved support, not the global obstruction.
Stop all further root-prefix, Pell, edge and compactness searches of
these literal R_n. No new manuscript, Lean or TeX expansion is needed.
The reviewed mixed-wall replacement inequalities now strengthen the
farthest-vertex programme, including full-rank finite-target comparisons
at multicusp polytopes with finite vertices. Adequate replacement
coverage and ideal targets remain open; no new uniform ceiling follows.

## Shared resource rules

* Run one proof process at a time across all agents. Use
  `scripts/run_lean_batches_signal_safe_20261018.py`, never an unrestricted
  `lake build`. This thin wrapper retains all caps and uses the earlier
  runner without changing its frozen bytes. It avoids a sandbox-denied
  signal-zero probe while terminating the owned process group.
* Each batch is one Lean module, one thread, with a2048MiB Lean memory cap.
  Large generated certificates must be split into small imported modules.
* Require40GiB free disk and6GiB available memory before starting. Abort a
  batch below8GiB disk or3GiB available memory. Do not bypass these limits.
* Below20GiB free disk, the coordinating agent must automatically start a
  cleanup agent before further jobs. The proof runner writes a compact
  `formal/.proof-batches/cleanup_needed.json` request; it cannot spawn an
  agent itself. Preserve frozen evidence and active application data.
* Remove temporary logs, C/IR/LSP outputs and TeX intermediates after each
  batch. Keep necessary `.olean` dependencies, a compact verification ledger,
  proof sources, certificates and final PDFs. Never delete frozen evidence.
* Stream large files and hashes. Never load or print a giant result or session
  file merely to inspect it. Keep tool output short and logs bounded.
* Do not launch background proof farms, detached workers, or concurrent heavy
  numerical jobs. Parallel reading and mathematical reasoning are allowed.
  A missing tool handle is not evidence that its OS process
  has stopped; inspect before launching a replacement.
* Native filesystem compression is allowed only after byte-identical hash
  verification; preserve paths and avoid active files. Do not delete chat
  history or modify active application databases for cleanup.
