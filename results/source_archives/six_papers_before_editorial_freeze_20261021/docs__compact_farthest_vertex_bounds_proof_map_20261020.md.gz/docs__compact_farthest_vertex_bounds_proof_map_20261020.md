# Compact bounds: current21, completed manuscript23

21 October 2026. The complete written component proofs and global
composition give an internal theorem: arbitrary compact hyperbolic
Coxeter polytopes have dimension at most21. Published compact
examples remain in dimension8. Arithmetic compact polytopes retain
the already stronger internal ceiling20.

The latest [whole B22/D22 exclusion](../results/compact_whole_b22_d22_uniform_terminal_pressure_exclusion_candidate_20261021.md)
has a full [root review/global composition](../results/review_compact_whole_b22_d22_uniform_terminal_pressure_root_20261021.md)
and [outside-author review](../results/review_compact_whole_b22_d22_uniform_terminal_pressure_outside_author_20261021.md).
The new loss-.58 window is classified afresh, its extra isolated dotted5
is handled by an explicit effective-energy reference, and actual finite
and negative-core points close all B/D tails through20. These remove
the final two diagrams after the accepted rank21+I exclusions, giving
the complete global21 theorem. The [acceptance receipt](../results/compact_dimension21_written_acceptance_20261021.json)
binds the exact chain. No new enumeration or scientific/Lean/TeX job
was needed. Current manuscript and kernel remain their23 snapshot;
these are supporting proofs for that same paper.

The next [reviewed batch](../results/compact21_frontier_and_arithmetic_a_packing_acceptance_20261021.json)
proves the complete [dimension21 necessary frontier and proper B/D continuations](../results/compact_dimension21_forest_frontier_and_small_debit_continuation_20261021.md),
then excludes [whole B21](../results/compact_whole_b21_actual_weak_terminal_pressure_exclusion_candidate_20261021.md)
by retaining the full weak-terminal pressure and its overlap with the
initial reference. Only whole D21 remains on the classical side;
the stated A forests remained at that checkpoint. The global ceiling stays21.
These new results retain written-proof status and the same paper home.

The [accepted two-end couplings](../results/whole_a20_and_two_end_couplings_written_acceptance_20261021.json)
subsequently remove A18/A19/A20 rows. The [uniform A-rank>=15 theorem](../results/uniform_a15_five_sevenths_and_d21_only_frontier_acceptance_20261021.json)
proves actual component energy>5/7 with arbitrary finite spectators,
without arithmeticity. Its complete four-foot argument and all four
A15/A16 consumers have full root/outside-author reviews. **Only whole
D21 now remains** in the complete dimension21 frontier; no general
ceiling20 follows. These supporting notes do not change the current
23-stage primary source/PDF or compiled accounting kernel.

The preceding [dimension23 exclusion](../results/compact_dimension23_exclusion_composition_candidate_20261020.md)
has complete [root acceptance](../results/review_compact_dimension23_exclusion_composition_root_20261020.md)
and [separate composition review](../results/review_compact_dimension23_exclusion_composition_20261020.md).
Its three new inputs are the [uniform A>=8 four-sevenths bound](../results/compact_large_an_actual_four_sevenths_uniform_transfer_candidate_20261020.md),
the [A19/A20 six-sevenths bound](../results/compact_a19_a20_central_window_actual_six_sevenths_20261020.md),
and the [whole-D23 and isolated-I obstruction](../results/compact_last_d23_center_and_isolated_i_frontier_candidate_20261020.md).
Each has full root and separate-agent written reviews. The new result
does not assume arithmeticity and introduces no enumeration or execution.
These are supporting research notes for the same paper. They have not
yet been integrated into its completed23 text or compiled in Lean.
The manuscript/build/formalization account below describes that preserved
23 stage; those source and PDF bindings are unchanged.

This is written mathematics reviewed by the root and separate agents,
not external refereeing or end-to-end geometric Lean. Source integrity,
mathematical audit, execution and manuscript completeness have separate
statuses below. The [canonical TeX source](../manuscripts/compact_farthest_vertex_bounds.tex)
is one completed draft. The ordinary components, small debits, full
B/D low-index estimates, large-component continuation/caps and A7 base
are now integrated into the same text. Its
[fresh full source audit](../results/review_compact_farthest23_full_batch_guard_20261020.md)
passes after an explicit middle-index coverage repair in the A-cap proof.
The current source `2718192d…19705` has a
[36-page PDF](../manuscripts/build/compact_farthest_vertex_bounds.pdf)
(`39e665d8…`), rebuilt without warnings. The accepted
[one-phrase precision correction](../results/compact23_correlation_precision_20261020.json)
replaces a strict correlation upper bound by "at most1/3"; the demand
remains strict, so the contradiction and theorem are unchanged.
The final rebuild additionally removes only the stale uncompiled-draft
date label. The `38c8290b…` correlation-corrected source/PDF/build and
`fb79910e…` predecessor are archived. No new compact23
visual inspection is claimed. The [six-paper PDF receipt](../results/six_paper_pdf_completion_20261020.json)
binds the source, PDF and actual bounded build ledger. The predecessor24,
26 and27 notes are supporting history. A [fresh coupled-D23 adversarial audit](../results/review_compact_d23_coupled_dimension24_adversarial_batch_guard_20261020.md)
also finds no gap in the actual-wall/prefix obstruction or its
dimension24 application; it does not replace the other component proofs.

## The argument and its sources

Choose a vertex farthest from a strict interior point. The actual
spatial vector has squared norm below1 and orthogonal finite-component
projections. Every relevant component estimate concerns this same
vector; actual feasible points, rather than assumed Coxeter metric
faces, supply the stronger pressures.

| Step | Complete written source | Review and scope |
| --- | --- | --- |
| Ordinary components, exceptional short A1/rank-two blocks, B/D9/14 rate and A20/B22/D23 caps | [Forest input packet](../results/compact_forest_ordinary_a_parameter_and_dominant_classical_frontier_20261020.md) and its pinned component proofs | Root and separate-agent PASS. Use its component conclusions, not an unproved ordinary-A parameter. |
| Actual A>=7 projection>1/2 | [Uniform half theorem](../results/compact_large_an_actual_half_uniform_transfer_20261020.md) | [Root](../results/review_compact_large_an_actual_half_root_20261020.md) and [separate-agent](../results/review_compact_large_an_actual_half_uniform_resource_20261020.md) PASS; arbitrary finite spectators. |
| Actual A>=17 projection>5/7 | [Four-foot theorem](../results/compact_large_an_actual_projection_five_sevenths_20261020.md) | [Root](../results/review_compact_large_an_five_sevenths_root_20261020.md) and [separate-agent](../results/review_compact_large_an_five_sevenths_batch_guard_20261020.md) PASS. The new central C foot is retained at the stronger target. |
| Smaller-rank actual B/D prefix energy | [Generic M6--M16 theorem](../results/compact_classical_generic_prefix_energy_20261020.md) | [Root](../results/review_compact_classical_generic_prefix_root_20261020.md) and [separate-agent](../results/review_compact_classical_generic_prefix_batch_guard_20261020.md) PASS; accepted source is corrected f637d729, not predecessor3a1188e3. |
| Exclude dimensions25--29 | [Global dimension24 composition](../results/compact_dimension24_farthest_forest_composition_20261020.md) | [Separate review](../results/review_compact_dimension24_composition_resource_20261020.md) and [second review](../results/review_compact_dimension24_forest_batch_guard_20261020.md) PASS for corrected7dd4495a. Empty ordinary sums are handled explicitly. |
| Actual A20 projection>11/14 | [Flipped-window and two-far-pair theorem](../results/compact_a20_actual_projection_eleven_fourteenths_20261020.md) | [Root](../results/review_compact_a20_eleven_fourteenths_root_20261020.md) and [separate-agent](../results/review_compact_a20_eleven_fourteenths_batch_guard_20261020.md) PASS. Closes A20 with four spectator ranks after either permitted debit. |
| D23 cannot coexist with isolated short A1 I | [Coupled actual-wall/prefix theorem](../results/compact_d23_isolated_a1_coupled_prefix_obstruction_20261020.md) | [Root](../results/review_compact_d23_isolated_a1_coupled_root_20261020.md) and [separate-agent](../results/review_compact_d23_isolated_a1_batch_guard_20261020.md) PASS. Includes all A1 contact alternatives and all three short-wall-height intervals. |
| Exclude dimension24 and conclude23 | [Final global composition](../results/compact_dimension23_farthest_forest_composition_20261020.md) | [Two](../results/review_compact_dimension23_forest_batch_guard_20261020.md) [separate-agent reviews](../results/review_compact_dimension23_composition_resource_20261020.md) PASS for exact12d9112d; no remaining dimension24 alternative. |

The A half bound first makes a dominant component unique. A dominant
A component in dimension>=25 has rank>=18; its stronger5/7 rate
then forces spectator rank<=4, contradicting its cap20. A dominant
B/D has rank>=20 and spectator rank<=5. The generic prefix floors
above.90 and.94 contradict all remaining spectator cases, including
the one-short-A1 debit and the sole rank-two defect. The published
ambient29 theorem then supplies the higher-dimensional tail. The stronger
A20 theorem closes the first necessary dimension24 configuration; the
new actual-wall height gap and D23 prefix coupling close the second.
Consequently that completed manuscript stage gives the global ceiling23.
The separately reviewed dimension23 exclusion above now strengthens it to22.

The only external classification inputs are the stated finite spherical
diagram classification and the named published geometric results in
the companion proofs, including the compact29 ceiling. New internal
component propositions are not attributed to the literature or silently
promoted to external axioms. The source packet records their actual
proof and review homes.

## Reproduction and formalization boundary

The new proofs use exact displayed identities and rational inequalities;
they introduce no combinatorial census, optimization or floating-point
search. Their written audits independently rederive the actual feet,
native/spectator inventories, exact inequalities and final accounting.
Earlier exact certificates retain their original execution records.

The source-integrity packet has a read-only replay:

```sh
python3 -B scripts/verify_compact_farthest_vertex_packet_20261020.py --manifest results/compact_farthest_vertex_dimension23_packet_20261020.json
```

This command checks the bytes and SHA256 of every listed source and
review. **It does not check the mathematics or compile Lean.** Its
success is reported as SOURCE_INTEGRITY_PASS, distinct from the written
mathematical PASS and any future formal proof.

The conditional `CoxeterProofs.CompactFarthestComposition23` kernel now
passes bounded compilation and eight actual axiom prints, using only
`propext`, `Quot.sound` and `Classical.choice`, with no `sorryAx`.
The [logic receipt](../results/publication_logic_verification_20261020.json)
binds source `c02ac8c3…16c0`, compiler, imports and object; the
[assumptions map](publication_logic_formalization_20261020.md#compact23-accounting)
states its scope. It derives the integer budget from real local energy
inequalities, existence and uniqueness of a dominant component, the
sole D23/isolated-I frontier and the final conditional ceiling23.
The actual uniform-A and classical-prefix inequalities, continuation and
caps, and the coupled D/A1 geometric obstruction remain explicit inputs.
Their geometric proofs are written and reviewed, not formalized by this
accounting kernel. Neither PDF compilation nor source-integrity replay
discharges those inputs.

Heavy jobs require40GiB disk and6GiB available memory, run serially
under the exclusive lock, and remove temporary build products after
each batch. The initial source-preparation batch ran below the start
gate. The later PDF and selected-logic batches passed under the same
limits, as recorded in the receipts above. Disk remains well above
the20GiB cleanup trigger.

## Remaining mathematical work

Both former dimension24 configurations are now excluded by the separately
reviewed geometric arguments above. The six-paper finishing and initial
priority-audit milestone now has evidence at its declared boundaries;
mathematical work can resume on the active dimension/example objective.
No example above compact dimension8 has been found. A new compact
dimension9 construction and the other nonsharp dimension classes remain
open; this package is not completion of the broader research objective.
