# Coxeter Polytopes Frontier Project

This repository studies dimension bounds, new reflection-polytope examples,
and right-angled four-dimensional volume and structure. The six-paper
finishing and initial audit milestone is complete at its declared input
boundaries, with particular attention to finite-volume57 and the sharp
right-angled proofs. All six PDFs match their current sources and selected
logic kernels pass Lean. The active mathematical goal remains lower
dimension bounds and new examples; further formalization follows settled
mathematics and concrete audit findings.

All six source audits pass internally. The
[PDF/source receipt](results/six_paper_pdf_completion_20261020.json)
records the completed build phase; the latest
[finite57 bridge receipt](results/finite57_publication_bridge_completion_20261020.json)
records its accepted source changes and successful bounded rebuild.
Seven selected
[logic kernels](docs/publication_logic_formalization_20261020.md)
now compile and pass62 actual axiom prints, with geometric and script
inputs explicit. The finite57
[full-budget classical bridge](results/finite57_full_budget_bridge_repair_20261020.json)
is printed and independently reviewed. Two further accepted bridges now
make the current triangle exclusions and coarse forest screen explicit.
Current source `c300db69…ca82a0` now has a source-matched
48-page PDF (`1f3c020c…`): main exposition pp.1–12 and essential
appendices pp.13–48. It has 21 underfull spacing warnings, with no
overflow or unresolved references; the other five PDFs have zero
warnings. The 44-page `89bd7658…` source / `ebf996a3…` PDF and earlier
41-page phase remain archived. Compact23 also rebuilt at36 pages after
the [one-phrase correlation correction](results/compact23_correlation_precision_20261020.json)
to "at most1/3"; its strict demand and conclusion are unchanged.
[Selected finite57 pages5,16,24,25](results/finite57_publication_delta_visual_review_20261020.json)
passed visual inspection; no all-page inspection is claimed.
These repairs establish no new dimension bound.

All31 inherited higher-tail obligations now have replay evidence:30
original commands passed (65.182 seconds total,256,278,528 B maximum RSS),
and the remaining tail108 has a complete56-part equivalent replay.
Its old59-second timeout remains preserved. The original44-job full run failed at the
eager D13 replay's 1 GiB limit. The replacement
[19-batch D13 replay contract](docs/finite_volume57_lemma_map.md#memory-bounded-d13-replay-contract)
has all19 parts PASS (24.408 seconds total, 184,041,472 B maximum RSS).
The current D13 parser fixture passed. The [coverage validator receipt](results/partitioned_replay_coverage_validation_20261020.json)
records prior validator `41f3c82b…` self-test PASS and complete D13
coverage19/19; it reruns no mathematics. The independently reviewed
[distance9 count repair](results/distance9_symbolic_boolean_count_repair_20261020.json)
preserves the predicate. Its `126d5fe3…` worker's scanner fixture actually
passed (1.721s,89,882,624 B), and metadata passed (13.832s), but domains
failed after2.709s on expected tuple/list representation. The
[three-comparison representation repair](results/review_distance9_expected_key_json_representation_fix_finite57_20261020.md)
changes no mathematical domain or predicate. The [current scanner
fixture](results/distance9_json_key_lists_scanner_fixture_execution_20261020.json)
`f6fd1267…` actually passed under worker `f5f0b470…` (1.732s,89,915,392 B);
this parser result earns no mathematical interval coverage. The current
worker now has actual PASS records for all eight phases: all384 overlap
owners and all949 isolation cases, together with the other domains, cover
2196/2196 units in56 capped batches (388.008s total,159,432,704 B peak RSS).
The complete108 replacement replay passes; prior-source passes earn no
current coverage. Coverage checker `456abc2b…` confirms the recorded
conjunction with19/19 D13 parts. The checker and coordinator `cb776f59…` also have
metadata-only self-tests, which are not mathematical replay. The earlier `abc3b918…`
fixture PASS also remains history. Two additional [ancestor-forest batches](results/finite57_ancestor_forest_replay_execution_summary_20261020.json)
actually pass: 8,114 tables and 10,195,241 Bellman inequalities in 5.106s,
with318,799,872 B maximum RSS. The [current plan](results/publication_shape_counting_verification_plan_20261020.json)
has123 finite57 full jobs (113 script, nine Lean, one PDF) and11 core jobs.
Full denotes selected scope; it does not regenerate every transitive
input. Some ambient59–65 forest and local-census data remain explicit
finite-data inputs. No combined full-manuscript
replay PASS or raised resource cap is claimed.

The [residual Bellman kernel](formal/CoxeterProofs/ResidualBellmanCertificate.lean)
(`cd2a05a6…`) now has capped compile and eight-axiom-print PASS records.
It derives exactness of an abstract integer table from local transition
and tight-predecessor conditions; actual alphabets, contexts, table
validation and geometric interpretation remain inputs.
The [projection/height kernel](formal/CoxeterProofs/RightAngledProjectionHeightKernel.lean)
(`2fac8028…`) also compiled and passed eight actual axiom prints. It derives
the coordinate projection identities, strict wall signs, finite height
descent and scalar radial gap; actual facet/incidence and radial-vector
realization remain inputs. The sharpRA core's current six jobs with PDF
have an actual [combined PASS](results/right_angled_sharp_projection_height_core_verification_20261020.json).
The [finite-volume tail kernel](formal/CoxeterProofs/FiniteVolumeTailKernel.lean)
(`b8f03fd4…`) now has actual compile and nine-axiom-print PASS records.
It checks all105 scalar cap comparisons for dimensions59–163, payment
subtraction and the near/far narrow-wall scalar contradictions. Its
[assumption map](docs/finite_volume_tail_kernel_assumptions_20261020.md)
retains the geometric and finite-data bridges. The
[shape kernel](formal/CoxeterProofs/FiniteVolume58ShapeKernel.lean)
(`40d12b57…`) compiled in0.59s and passed its0.55s audit of nine prints.
It derives the indexed uncut-edge bound,841 at each distinct extremum,
the doubled8410 correction and finite754 contribution, giving the
377/4205 shape inequality under primitive incidence inputs. Its
[map](docs/finite_volume58_shape_kernel_assumptions_20261020.md) explains
why this does not automatically instantiate the legacy natural-number
`WrittenGeometry.shapeLower` field. It replaces the old ambient59 shape
slot; historical sources and evidence remain preserved. The seven-kernel
receipt's62 prints comprise10 cubic,10 concentration,8 compact23,8 Bellman,
8 projection/height,9 tail and9 shape declarations. Current core counts with PDF
are11/10/2/6/7/1 for57/arithmetic20/compact23/sharpRA/ideal4/compactRA4.
The [arithmetic20 field-closure audit](results/review_compact_arithmetic20_field_closure_batch_guard_20261020.md)
is a written proof-closure PASS, with finite-data assumptions explicit
and no parked19 input or new execution.

The current internally reviewed written ceilings are **57 for arbitrary
finite volume, 20 for arbitrary compact, and 19 for compact arithmetic
of the first type over every admissible ground field**. The sharp
right-angled ceilings remain **8 in finite volume, 4 entirely ideal,
and the published 4 in the compact case**. Arithmetic noncompact and
compact-or-noncompact finite volume both retain ceiling21.

The [complete compact20 / arithmetic19 composition](results/compact20_and_all_field_arithmetic19_global_composition_candidate_20261021.md)
has full [root](results/review_compact20_and_all_field_arithmetic19_global_composition_root_20261021.md)
and [outside-author](results/review_compact20_arithmetic19_global_composition_full_scope_20261021.md)
mathematical reviews. It exhausts every dimension21 farthest forest
without arithmeticity, then every arithmetic dimension20 forest. The
last whole D21/D20 cases use actual-point pressures and one summed-foot
energy certificate; the arithmetic A cases additionally use all-field
conjugate and cyclic-integrality restrictions. No field census or parked
nine-field19 result is used. The [acceptance receipt](results/compact20_arithmetic19_written_acceptance_20261021.json)
binds the complete source and review chain.

These are written results for the SAME existing paper families. The
completed general compact source/PDF and accounting kernel still state23;
the completed arithmetic source/PDF still states20. The new20/19 results
are not yet integrated into those PDFs or proved end to end in Lean.
The [summed-foot kernel](docs/summed_actual_foot_kernel_assumptions_20261021.md)
has bounded compilation and ten standard-axiom prints PASS. Together with
the unchanged seven-kernel snapshot this gives eight supporting kernels
and72 distinct audited declarations, with geometry and concrete application
estimates explicit. No new enumeration, scientific job, TeX or Lean batch
was needed for the new written proofs. These are internal mathematical
reviews, without external refereeing, sharpness or a new example claim.
The [comparison table](docs/current_bounds_and_verification.md) separates
current written results, completed PDFs and formal verification.

There are **six current papers**, complete at their declared data and companion-theorem boundaries, with existing PDFs and fresh internal source audits. The
33 TeX files under `manuscripts/` also contain supporting notes,
preserved predecessors, input fragments and generated atlases.
The [current finishing checkpoint](results/six_paper_finishing_checkpoint_20261021.json)
binds all six source/PDF pairs and the separate verification scopes.

| Current paper | Main technique | Existing PDF |
| --- | --- | --- |
| [Finite-volume dimension 57](manuscripts/finite_volume57.tex) | Angle payments and finite/cusp curvature | [48 pages](manuscripts/build/finite_volume57.pdf): main exposition 1–12, essential appendices 13–48;44- and41-page predecessors preserved |
| [Compact arithmetic dimension 20](manuscripts/compact_arithmetic_dimension_bound.tex) | Arithmetic field reduction and exact angle rules | [17 pages](manuscripts/build/compact_arithmetic_dimension_bound.pdf); parked19 refinements excluded and preserved |
| [Compact dimension 23](manuscripts/compact_farthest_vertex_bounds.tex) | Farthest-vertex projections and component energy | [36 pages](manuscripts/build/compact_farthest_vertex_bounds.pdf) |
| [Sharp right-angled dimensions](manuscripts/right_angled_sharp_dimension_bounds_publication.tex) | Projection, heights and spherical codes | [5 pages](manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf) |
| [Ideal RA4 volume and structure](manuscripts/ideal_ra4_volume_and_structure_publication.tex) | Volume gap, equality spectrum and actual cuts | [17 pages](manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf);16-page predecessor preserved |
| [Compact RA4 volume constraints](manuscripts/compact_ra4_volume_constraints.tex) | Facet capacity and neighboring excess | [14 pages](manuscripts/build/compact_ra4_volume_constraints.pdf) |

The [paper architecture](docs/paper_architecture.md) explains the shared
approaches and where case-specific reasoning begins. The
[result–manuscript correspondence](docs/result_manuscript_correspondence.md)
and [catalogue](manuscripts/catalogue.json) identify each result's primary
home, supporting sources and verification status. A PDF's existence is a
rendering record, not a mathematical audit.

Each proof-relevant script needs a mathematical statement: its domain and
algorithm, a proof of termination and soundness/completeness, and its exact
computed conclusion. The [computational proof contract](docs/computational_proof_contract.md)
and [editorial audit](results/editorial_manuscript_inventory_and_algorithm_audit_20261020.md)
record that standard and the earlier exposition gaps. The
[source-completion record](results/six_paper_source_completion_20261020.md)
records the completed texts and six fresh internal audits. Raw tables and
historical proof atlases belong in the reproducibility archive.

The ideal four-dimensional paper combines the published 24-cell minimum,
the internal second-volume/equality proof and the restricted Oct/D chain
theorem. The equality-spectrum reduction must precede applying the chain
theorem. A decomposition of arbitrary ideal polytopes is not claimed.
The compact 120-cell minimum and second-volume problems remain open.

See the [research programme](docs/research_programme.md) for active lanes
and [manuscript verification](docs/manuscript_verification.md) for the
serial reproduction entry point and explicit assumptions. Lean checks
internal implications under named external, script and geometric premises;
its [coverage](formal/README.md) remains partial.

Fresh written adversarial reviews also cover the
[sharp right-angled proof](results/review_right_angled_sharp_fresh_adversarial_finite57_20261020.md)
and the [ideal RA4 equality-to-cutting chain](results/review_ideal_ra4_structure_batch_guard_20261020.md).
The independent [sharpRA foundations audit](results/review_right_angled_sharp_foundations_adversarial_20261020.md)
and [finite57 composition audit](results/review_finite57_theorem_composition_adversarial_20261020.md)
also support the proofs under their explicit inputs.
They add source-review evidence, not new executions or external refereeing.
Primary-source audits check [Musin/Kolpakov](results/review_sharp_ra_published_inputs_ideal_branch_20261020.md),
[Vinberg and the mixed27 statement in Alexandrov](results/review_sharp_ra_published_inputs_dufour_20261020.md),
and [Khovanskii's shape identities](results/review_finite57_published_shape_inputs_20261020.md).
Dufour's original full article was not obtained; the paper already cites
its27-facet consequence through Alexandrov.

Proof jobs run one at a time, with at least 40 GiB free disk and 6 GiB
available RAM to start. Temporary build files are removed after each batch.
Below 20 GiB free disk, the coordinator must start a cleanup agent before
further proof jobs. The persistent rules are in [AGENTS.md](AGENTS.md).

The former long README is preserved byte-for-byte in a
[compressed historical log](docs/history/readme_research_log_through_20261020.md.gz),
with a [round-trip integrity receipt](docs/history/readme_research_log_through_20261020.md.json).
Its old status statements are historical. The underlying sources and
certificates remain in place.
