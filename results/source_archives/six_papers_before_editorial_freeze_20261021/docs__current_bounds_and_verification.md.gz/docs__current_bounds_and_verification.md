# Dimension bounds and proof-package status

Updated 21 October 2026. Dimensions below are ceilings, not existence
claims. “Internal proof” means the written theory and exact scripts have
passed the recorded mathematical reviews. It does not mean external
refereeing or a completed Lean proof of the geometric theorem.

The six-paper finishing and initial audit milestone is complete at the
declared input boundaries, with priority attention to finite-volume57
and the sharp right-angled paper. The active priority returns to lower
dimension bounds and new examples; further formalization follows settled
mathematics and concrete audit findings.
The broader goal is to close the remaining gaps or construct a compact
example in dimension9. A ceiling within two to five dimensions
of examples would mean10--13 for the compact classes and23--26 for the
general finite-volume class; these are targets, not proved bounds.
The completed nine-field ceiling19 is retained below as supporting
history. Its casework, manuscript and Lean coverage are not being expanded.

The latest accepted written bounds are **20 for arbitrary compact
Coxeter polytopes** and **19 for compact arithmetic polytopes of the
first type, over every admissible actual ground field**. The
[complete composition](../results/compact20_and_all_field_arithmetic19_global_composition_candidate_20261021.md)
has full [root](../results/review_compact20_and_all_field_arithmetic19_global_composition_root_20261021.md)
and [outside-author](../results/review_compact20_arithmetic19_global_composition_full_scope_20261021.md)
mathematical PASS. The [acceptance receipt](../results/compact20_arithmetic19_written_acceptance_20261021.json)
binds its complete proof chain. The original compact21 acceptance and
subsequent frontier receipts remain preserved predecessors.

The general argument closes every dimension21 farthest forest, including
its last WHOLE D21 case. The arithmetic argument then closes every
necessary dimension20 forest, including the smaller A16/A17 components
and WHOLE D20. It uses actual-field conjugates, integrality and time-line
packing, with no finite field list or parked nine-field19 premise. Both
proofs keep one actual spatial vector and explicitly combine overlapping
gains before charging its norm. The prior global21 theorem excludes
larger dimensions; no Coxeter-face inheritance is assumed.

The finished general compact source/PDF and accounting kernel remain
the ceiling23 edition, and the arithmetic source/PDF remains the
universal20 edition. The new20/19 written theorems belong to those
same existing paper families and await integration; they have not
been verified end to end in Lean. General finite-volume57, arithmetic
noncompact21 and the arithmetic finite-volume union21 are unchanged.
A new [full-cusp financing argument](../results/finite57_full_cusp_deletion_rigidity_and_curvature_financed_priorities_20261021.md)
has full root/outside-author written reviews, but resolves only one
specified finite-payment producer and does not lower57.

Separately, the [summed-foot logic](summed_actual_foot_kernel_assumptions_20261021.md)
now has bounded compilation and a separate ten-declaration actual axiom
audit PASS, recorded in its [execution receipt](../results/summed_actual_foot_kernel_verification_20261021.json).
It derives the weighted norm, pressure and final energy inequality from
primitive finite-coordinate hypotheses, including adjacent feet.
Geometry, cap inventory and the concrete reference/radical estimates
remain application inputs. The original seven-kernel/62-print receipt
below is unchanged; with this addition there are eight kernels and72
distinct audited declarations. Neither the A20 geometry nor a new
dimension theorem has been formalized end to end.

The six current source drafts are complete at their declared finite-data
and companion-theorem boundaries. Fresh internal source audits pass for
the [sharp right-angled paper](../results/review_right_angled_sharp_dimension_bounds_full_resource_20261020.md),
the [arithmetic20 exposition](../results/review_compact_arithmetic20_exposition_finite57_20261020.md)
the [idealRA4 successor](../results/review_ideal_ra4_publication_full_finite57_20261020.md)
and the [compactRA4 constraints](../results/review_compact_ra4_volume_constraints_full_root_20261020.md).
The [finite57](../results/review_finite_volume57_full_resource_20261020.md)
and [compact23](../results/review_compact_farthest23_full_batch_guard_20261020.md)
full source audits also pass after the small written-coverage repairs
recorded in their reports. Finite57's [full-budget classical bridge repair](../results/finite57_full_budget_bridge_repair_20261020.json) is printed before the first-failing-factor split and has an independent written review. The residual 3/2 and 4/3 estimates did not themselves provide that bridge. The later [publication bridge receipt](../results/finite57_publication_bridge_completion_20261020.json) records two further independently accepted insertions: current triangle exclusions and complete coarse forest-screen domination. These repair the existing proof without a new dimension bound or finite-enumeration result.

All six PDFs match their current sources, with pages48/17/36/5/17/14. Finite57 source `c300db69…ca82a0` / PDF `1f3c020c…` has main exposition pp.1–12 and essential appendices/table documentation pp.13–48; its bounded build has21 underfull spacing warnings and no overflow or unresolved references. The other five PDFs have zero warnings. The44-page `89bd7658…` source / `ebf996a3…` PDF and earlier41-page phase remain archived. Compact23 source `2718192d…` / PDF `39e665d8…` stays36 pages after the [accepted correlation correction](../results/compact23_correlation_precision_20261020.json) to "at most1/3"; strict demand and conclusion are unchanged. [Selected finite57 pages5,16,24,25](../results/finite57_publication_delta_visual_review_20261020.json) passed visual inspection; no all-page inspection is claimed. The [PDF receipt](../results/six_paper_pdf_completion_20261020.json) records the actual builds; the latest bridge receipt records the source clarifications, including tight witnesses at positive stored finite entries and the rank-zero base exception. These written audits and PDF builds do not rerun exact enumerations or by themselves extend conditional Lean coverage.

The sharp right-angled paper's [final read](../results/review_right_angled_sharp_final_read_20261021.md)
finds no gap at the stated boundaries. Its current publication successor
changes only “four-facet” to “four-dimensional facet”; the five-page PDF
has a [fresh zero-warning bounded build](../results/right_angled_sharp_publication_terminology_build_20261021.json).
All44 original frozen inputs, including the predecessor source/PDF/map,
remain at unchanged paths and bytes. The same paper id selects the
successor, and the paper count stays six. The [successor receipt](../results/right_angled_sharp_publication_terminology_acceptance_20261021.json)
does not claim a new combined core replay or expanded geometric Lean.

The [arithmetic20 field-closure audit](../results/review_compact_arithmetic20_field_closure_batch_guard_20261020.md)
(`994b4965…`) is a written proof-closure PASS at its declared finite-data
boundary. No parked19 result is an input and no new execution is claimed.

Seven [logic kernels](publication_logic_formalization_20261020.md)
now verify compact23 accounting, concentration termination/surplus and
the sharpRA cubic endpoint, abstract residual Bellman exactness, and
coordinate projection/height/radial algebra, higher-tail scalar closure,
and indexed shape counting. Capped compilation and62 actual axiom
prints pass, with no `sorryAx`; the
[receipt](../results/publication_logic_verification_20261020.json)
records their exact source and assumption scopes. These are conditional
internal kernels, not whole geometric manuscripts in Lean. The
[residual Bellman certificate kernel](../formal/CoxeterProofs/ResidualBellmanCertificate.lean)
(`cd2a05a6…`) compiled and passed eight actual axiom prints, containing
only `propext` and `Quot.sound`, with its
[assumptions map](residual_bellman_certificate_logic_20261020.md) explicit.
Its local transition and tight-predecessor conditions imply exactness;
concrete alphabets, contexts, table validation and geometry remain inputs.
The [projection/height kernel](../formal/CoxeterProofs/RightAngledProjectionHeightKernel.lean)
(`2fac8028…`) derives projection identities and strict wall signs, maximal
squared-height recurrence, arbitrary finite descent and a scalar radial
gap. Its eight actual prints use standard axioms only; actual facet and
future-sheet interpretation, incidence/face inheritance and radial
realization remain inputs. The sharpRA core now has six jobs with PDF.
The [finite-volume tail kernel](../formal/CoxeterProofs/FiniteVolumeTailKernel.lean)
(`b8f03fd4…`) has actual compile and nine-print PASS records for all105
scalar cap comparisons in59–163, common payment subtraction and the
near/far narrow-wall arithmetic. Its [assumption map](finite_volume_tail_kernel_assumptions_20261020.md)
retains geometric, rule and finite-data bridges. The
[shape kernel](../formal/CoxeterProofs/FiniteVolume58ShapeKernel.lean)
(`40d12b57…`) compiled in0.59s and passed its0.55s audit of nine prints.
It derives the indexed uncut-edge bound,841 at each of two distinct
extrema, the doubled8410 correction and finite754 contribution. The
[map](finite_volume58_shape_kernel_assumptions_20261020.md) retains the
primitive incidence/sign interpretation; the old natural-number
`WrittenGeometry.shapeLower` field is not automatically instantiated.
The62 prints split as10 cubic,10 concentration,8 compact23,8 Bellman,
8 projection/height,9 tail,9 shape;
they do not constitute full geometric Lean proofs.
The expanded
finite57 full replay still has no bounded-pass claim. The
[original 44-job attempt](../results/finite57_publication_full_replay_20261020.json)
passed its endpoint, then failed at the eager D13 check's 1 GiB RSS limit.
Separately, [30 of31 inherited higher-tail checks pass](../results/finite57_higher_tail_replay_batches_20261020.json),
including the [remaining-check ledger](../results/finite57_higher_tail_remaining_replay_20261020.json):
65.182 seconds total,256,278,528 B maximum RSS. The remaining tail108
obligation, covering109–116, now has a complete56-batch replacement
replay; its old59-second timeout remains preserved. The replacement
[19-part D13 replay](finite_volume57_lemma_map.md#memory-bounded-d13-replay-contract)
has all19 actual PASS records (24.408s,184,041,472 B maximum RSS). The
current D13 parser `2f6b63da…` also passed in the
[runtime ledger](../results/finite57_d13_batched_replay_runtime_20261020.json).
The [coverage receipt](../results/partitioned_replay_coverage_validation_20261020.json)
records prior verifier `41f3c82b…` self-test PASS and complete D13
coverage19/19. The validator reruns no mathematics. The [distance9 repair](../results/distance9_symbolic_boolean_count_repair_20261020.json)
preserves the predicate. Worker `126d5fe3…` actually passed its scanner
fixture (1.721s,89,882,624 B) and metadata (13.832s), then failed domains
after2.709s on tuple/list representation, not a saved mathematical
counterexample. The [three-comparison correction](../results/review_distance9_expected_key_json_representation_fix_finite57_20261020.md)
preserves domains and exact values. Current worker `f5f0b470…` has an actual
[scanner-fixture PASS](../results/distance9_json_key_lists_scanner_fixture_execution_20261020.json)
under fixture `f6fd1267…` (1.732s,89,915,392 B), which earns no mathematical
interval coverage. All eight current phases now actually PASS, including
384 overlap owners and949 isolation cases:2196/2196 units in56 capped
batches (388.008s total,159,432,704 B peak RSS). Complete108 replacement
replay and the recorded conjunction with19/19 D13 parts now pass;
earlier-source passes earn no current coverage.
Coverage checker `456abc2b…` and coordinator `cb776f59…` have metadata-only
self-tests. The historical `abc3b918…` scanner PASS remains preserved.
The [current plan](../results/publication_shape_counting_verification_plan_20261020.json)
has123 finite57 full jobs (113 script, nine Lean, one PDF); core has11.
The new shape kernel replaces the old ambient59 standalone shape slot;
historical sources, roots and evidence are preserved.
Two added [ancestor-forest batches](../results/finite57_ancestor_forest_replay_execution_summary_20261020.json)
actually pass:8,114 tables,10,195,241 Bellman inequalities,5.106s total,
318,799,872 B maximum RSS. Full denotes selected scope; some ambient59–65
forest and local-census data remain finite-data inputs without complete
transitive regeneration. Current core sizes with PDF are11/10/2/6/7/1
for57/arithmetic20/compact23/sharpRA/ideal4/compactRA4. All caps remain
unchanged, and these partial results are not a full manuscript replay.

The [fresh sharpRA adversarial review](../results/review_right_angled_sharp_fresh_adversarial_finite57_20261020.md)
rechecks its complete argument, and the
[idealRA4 structural review](../results/review_ideal_ra4_structure_batch_guard_20261020.md)
rechecks the equality-spectrum and actual cutting/chain bridge. These
are additional written reviews under the stated external/geometric inputs,
without external-refereeing claims. Separately, the sharpRA package now
has a [fresh combined six-job PASS](../results/right_angled_sharp_projection_height_core_verification_20261020.json):
two exact scripts, three Lean axiom audits and a temporary PDF build.
Independent [sharpRA foundations](../results/review_right_angled_sharp_foundations_adversarial_20261020.md)
and [finite57 composition](../results/review_finite57_theorem_composition_adversarial_20261020.md)
source audits also support the arguments under their explicit inputs.
Primary-source audits directly check [Musin/Kolpakov](../results/review_sharp_ra_published_inputs_ideal_branch_20261020.md),
[Vinberg and Alexandrov's mixed27 statement](../results/review_sharp_ra_published_inputs_dufour_20261020.md),
and [Khovanskii's shape identities](../results/review_finite57_published_shape_inputs_20261020.md).
Dufour's full original was not obtained; its27-facet consequence was checked
through the original Alexandrov source already identified by the paper.

|Class|Largest known example|Published ceiling|Completed repository ceiling|Proof package and Lean status|
|---|---:|---:|---:|---|
|Arbitrary finite-volume Coxeter|21|995, Prokhorov|57|[Final proof](../results/fresh_d13_context_dimension57_20261018.md), [TeX](../manuscripts/finite_volume57.tex), [proof map](finite_volume57_lemma_map.md), [reproduction](finite_volume57_reproduce.md). Internal proof. Lean checks the forest induction, all5148 used-cap residual tables, all1890 predecessor terminal ideal profiles,180 ordinary base and32400 cross-cost comparisons, contextual-guard logic and final arithmetic; concentration checks termination, terminal-domain recognition and surplus lifting. The Bellman kernel proves abstract table exactness from local certificate conditions; the separate ancestor replay checks8,114 tables. FiniteVolumeTailKernel checks105 bounded cap comparisons and payment/narrow scalar closure. Actual geometric reductions, complete enumeration interpretation, real convex-order comparison and higher-tail geometric/table bridges remain explicit inputs.|
|Arbitrary compact Coxeter|8|29, Vinberg|20|[Complete global composition](../results/compact20_and_all_field_arithmetic19_global_composition_candidate_20261021.md), full [root](../results/review_compact20_and_all_field_arithmetic19_global_composition_root_20261021.md) and [outside-author](../results/review_compact20_arithmetic19_global_composition_full_scope_20261021.md) written PASS. Every dimension21 forest is excluded, including WHOLE D21; prior GLOBAL21 covers all larger dimensions. No arithmetic assumption. Current [36-page PDF](../manuscripts/build/compact_farthest_vertex_bounds.pdf) and its compiled accounting kernel still state23; integration and new formal coverage are pending.|
|Arithmetic compact Coxeter, first type|8|29, Vinberg|19|Same complete composition and full root/outside-author written PASS, over EVERY admissible actual ground field. Every dimension20 forest is excluded, including A16/A17 and WHOLE D20. No field census or parked nine-field19 premise. The [17-page current PDF](../manuscripts/build/compact_arithmetic_dimension_bound.pdf) still states20; integration and new formal coverage are pending. The standard first-type reflection criterion remains an explicit external input if the wording is extended to all arithmetic reflection lattices.|
|Arithmetic noncompact Coxeter|21|21, Esselmann|21|Published and sharp; dimension20 is excluded. This is separate from the new compact bound.|
|Arithmetic compact or noncompact|21|29 overall|21|New compact first-type ceiling19, with the declared first-type reflection criterion, combined with published noncompact21. The noncompact21 example makes the union sharp.|
|Right-angled compact|4|4, Potyagailo–Vinberg|4|Published and sharp.|
|Right-angled entirely ideal|4|6, Kolpakov|4|Sharp; one finite projection, Musin's24 bound and Kolpakov's metric24-cell equality. [Unified five-page PDF](../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf), [proof map](right_angled_sharp_dimensions_publication_proof_map_20261021.md). Full written reviews, two exact core checks, conditional Lean/12-theorem axiom audit and temporary PDF reproduction all pass. Geometry and external theorems remain explicit Lean premises.|
|Right-angled mixed finite/ideal vertices|8|12, Dufour|8|Sharp; three actual projections and a self-contained cubic tensor-square identity force a six-face with at most26 facets, contradicting the published minimum27. The same five-page PDF proves the universal ceiling8. The [preserved four-job core run](../results/right_angled_sharp_core_verification_20261020.json) passes, with zero TeX warnings and one visually inspected figure. Full root/two independent mathematical reviews; conditional Lean, with real geometry explicit.|

The ideal-four volume results share one paper with five figures: the
published24-cell minimum, the internal second-volume
gap and equality theorem, and the general restricted Oct/D chain theorem.
The equality-spectrum reduction precedes the chain theorem's application;
the [paper's proof map](ideal_ra4_volume_and_structure_proof_map.md) records
this dependency and the shared argument.
The [preserved16-page edition](../manuscripts/build/ideal_ra4_volume_and_structure.pdf)
has two full consolidation reviews. Its four exact replays and conditional
`ManuscriptIdeal4` Lean implications pass. Its
[geometric assumptions](manuscript_assumptions.md) remain explicit;
this does not change any dimension ceiling in the table. The
[result–manuscript map](result_manuscript_correspondence.md) separates
current papers, supporting notes and preserved predecessors. The
[current publication source](../manuscripts/ideal_ra4_volume_and_structure_publication.tex)
adds explicit finite-model algorithms and their correctness proofs;
its fresh full source audit passes and its [17-page PDF](../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf) now compiles without warnings.

The [orthogonal-opposite theorem](../results/compact_farthest_vertex_orthogonal_component_opposite_obstruction_20261020.md)
proves that one actual wall cannot close outgoing edges in TWO different
finite components at the farthest vertex. Full written reviews, including
an outside-author audit, pass. This short interiority/Schur-projection
argument is independent of arithmetic and contact multiplicity; it is
research support and does not itself change the numerical table.

The current scoped ceiling19 concerns equality of the actual ground field
with Q(sqrt3), Q(sqrt6), K7, K9, K11, K15, K16, K20 or K24,
where Km=Q(2cos(2pi/m)) and K24=Q(sqrt2,sqrt3).
The remaining fields Q(sqrt2), Q(sqrt5) and Q(sqrt2,sqrt5) retain
the overall compact arithmetic ceiling20. The published21 ceiling
for the original eight-field subclass follows from the published
restriction to Q(sqrt2), Q(sqrt5) and K7 in dimensions at least22.
It does not exclude K7: the uniform published comparison for the
combined nine-field subclass is29, not21. The earlier eight-field
proof,48-file manifest and18-page parent/PDF are preserved history;
the [new manifest](../manuscripts/supplements/compact_arithmetic_nine_field19_sources_20261020.json)
retains the old dependencies, rebinds the current parent and includes
the K7 extension.
The [preserved combined eleven-job core](../results/compact20_nine_field_core_verification_final_20261020.json)
passes all three script checks,seven Lean roots and the76-input temporary
PDF build; the published20-page PDF remains unchanged.

The accepted [K7 composition](../results/compact_arithmetic_k7_dimension19_charge_composition_20261020.md),
SHA256 `e6a28d7e12013be9431b4e9add5bd9b243ea8fed4da59fa82f9955d9038c9f65`,
has full [root](../results/review_k7_dimension19_charge_composition_root_20261020.md)
and [independent](../results/review_k7_dimension19_charge_composition_resource_20261020.md)
written PASS reviews. Its seven local rules fund the surviving actual
A/B quadrilaterals, retain all mixed white-support consumers and bound
every rank20 vertex by35 against the exact lower35*f0+500. The
[conditional K7 Lean module](../formal/CoxeterProofs/ArithmeticK7Field19.lean),
SHA256 `08f1398fd3d80b5176bb4e8f59d844ddd9a9e6f8beae089716f9d92230d4fad6`,
compiled and passed its six-theorem axiom audit. It checks charge/count
logic; actual field, geometric consumers and complete forest coverage
remain explicit premises. The earlier
[far-bridge local model](../results/arithmetic_k7_an_far_bridge_quad_survivor_20261019.md)
remains valid counterevidence to an unfunded deletion, rather than an
obstruction to the now funded theorem or a completed compact example.

The preserved earlier mixed right-angled ceiling10 excludes dimension11 by the
ordinary-count inequalities3722B>159195f+2794E and4B<=168f+3E,
which would force5742f+5E<0. The [12-page successor](../manuscripts/build/right_angled_dimension10.pdf)
has three figures,zero warnings and a [six-job core PASS](../results/mixed10_core_verification_20261020.json).
It formerly left a gap of2 above the known dimension8 examples. The earlier
ceiling11 proof and its11-page PDF are preserved predecessors; their
dimension12 opposition comparison is historical support. The published12
comparison is still recorded in
[Egorov's March2026 preprint,Introduction](https://arxiv.org/html/2603.29925v1).
This was checked after deriving the proof, without a worldwide-priority
claim. The compact ceiling remains4. The new maximum-cusp-height proof
lowers the entirely ideal ceiling from6 to4, matching the regular ideal
24-cell. It excludes dimension5 directly and higher dimensions by face
inheritance. It does not require the longer internal ideal5/6 size
estimates or the restricted facet-spectrum classifications.

The new three-projection proof also closes the mixed gap: its ceiling8
matches the published Potyagailo--Vinberg examples. It is independent
of the earlier opposition/count ceiling10 proof. Both new sharp bounds
now occupy one [five-page primary manuscript](../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf),
with the finite projection argument shared. Its
[preserved four-job core verification](../results/right_angled_sharp_core_verification_20261020.json)
passes two exact workers, one capped Lean module with12 theorem axiom
prints and a temporary PDF build. The final PDF has zero warnings and
one visually reviewed figure. Only standard propext/Quot.sound appear
in the non-axiom-free printed theorem dependencies; there is no sorryAx.
The previous ideal4 cusp-height
proof and the completed mixed10 package remain preserved predecessors.

The right-angled dimension gaps are closed at the internally reviewed
written-proof level. Further construction and general/compact Coxeter
work remains open. The nine-field arithmetic19 package above is preserved;
its casework, manuscript and Lean expansion are deferred under the user's
20 October instruction. The old ideal5/6 necessary-condition manuscripts
remain supporting history, with no further expansion planned.

The intermediate general compact ceiling24 follows from the uniform actual
A>=7 half-bound, the A>=17 five-sevenths bound, generic classical prefix
energy and the complete small-defect accounting. Its global composition
has two separate collaborating-agent written PASS reviews. It uses no
arithmeticity or inheritance of the Coxeter property by arbitrary metric
faces. This is a new internal written theorem, not external refereeing,
a fresh mathematical script replay or an end-to-end Lean result. The
source-integrity replay checks bytes only. The predecessor24/26/27 notes
support the same argument, rather than separate primary manuscripts.
The research table below preserves earlier stages; statements about no
global change describe what each individual predecessor established.
The CURRENT ceiling23 adds the reviewed actual A20>11/14 theorem and
the coupled D23/short-A1 obstruction, closing both dimension24 frontiers.
Its final global composition has two separate-agent written PASS reviews.

The following research proofs have passed written review. Some are
intermediate steps of the scoped19 theorem; the table preserves their
individual scope and verification history:

|Research advance|What it establishes|Verification and manuscript boundary|
|---|---|---|
|[General compact dimension23](../results/compact_dimension23_farthest_forest_composition_20261020.md)|Closes both necessary dimension24 configurations: [A20 actual projection>11/14](../results/compact_a20_actual_projection_eleven_fourteenths_20261020.md) and [D23 with isolated short A1](../results/compact_d23_isolated_a1_coupled_prefix_obstruction_20261020.md).|Both geometric inputs have full root and separate-agent written PASS. The final composition has [two](../results/review_compact_dimension23_forest_batch_guard_20261020.md) [separate reviews](../results/review_compact_dimension23_composition_resource_20261020.md). One [36-page canonical PDF](../manuscripts/build/compact_farthest_vertex_bounds.pdf), complete source and explicit geometric inputs. The compact23 accounting kernel and eight actual axiom prints now pass; its actual geometric estimates remain premises. Arithmetic20 and the other dimension rows are unchanged.|
|[General compact dimension24](../results/compact_dimension24_farthest_forest_composition_20261020.md)|Excludes dimensions25--29 without arithmeticity or Coxeter inheritance by arbitrary metric faces. At dimension24 only A20 plus four spectator ranks with a small exceptional block, or D23 plus one short A1, remain as necessary farthest configurations.|Complete internally reviewed written proof, including [A>=17](../results/compact_large_an_actual_projection_five_sevenths_20261020.md) and [generic prefix](../results/compact_classical_generic_prefix_energy_20261020.md) lemmas. Two global composition reviews PASS; corrected7dd4495a handles empty ordinary sums explicitly. New Lean and manuscript compilation pending. One canonical paper in preparation.|
|[A5/A6](../results/compact_universal_a6_actual_projection_three_sevenths_20261020.md), [corrected A7](../results/compact_universal_a7_two_end_actual_projection_20261020.md) and [B5--B8](../results/compact_b5_b8_ordinary_component_energy_20261020.md)|Actual projection rates A5>3/8, A6>3/7, A7>1/2; B5/B6>3/7, B7>1/2, B8>4/7. All allow arbitrary finite spectators.|Complete root and separate collaborating-agent written PASS. A7 review caught and repaired a real reversal-sign error before acceptance; only successor5ae61f57 is accepted. [Root A7 review](../results/review_compact_universal_a7_two_end_projection_root_20261020.md), [separate A7 review](../results/review_compact_universal_a7_two_end_projection_resource_20261020.md). Supporting lemmas, no new primary manuscript, scientific execution or Lean.|
|[Ordinary-A forest aggregation](../results/compact_forest_ordinary_a_parameter_and_dominant_classical_frontier_20261020.md)|With the accepted A5--A7 rates, every farthest vertex of a hypothetical compact29-polytope must contain A8--A20. Otherwise one large B/D has at most five spectator ranks, contradicting the existing B23/D24 exclusions.|Full [root](../results/review_compact_forest_ordinary_a_frontier_root_20261020.md) and [separate-agent](../results/review_compact_forest_ordinary_a_frontier_resource_20261020.md) written PASS, including all exceptional A1/rank-two debits and parameter substitution. A8 is a separate candidate under audit; no unrestricted compact28 theorem or arithmetic-ceiling improvement is claimed. Same supporting packet, no additional manuscript.|
|[D24--D29 components excluded](../results/compact_dn_large_components_short_tail_transfer_20261020.md)|Arbitrary finite spectators are allowed. Complete short-tail inventories and averaged actual H4/A2 points close both fork obstructions. Any hypothetical compact29-polytope must have A5--A20 or B5--B22 at every farthest vertex.|Full [root](../results/review_compact_dn_large_component_transfer_root_20261020.md) and [separate-agent](../results/review_compact_dn_large_component_short_tail_resource_20261020.md) written reviews PASS. The strong5 bootstrap precedes the tails, avoiding circularity. Only the restricted class without A/B rank>=5 at a farthest vertex gets ceiling28; the unconditional table above is unchanged. No scientific/Lean/TeX job or new primary manuscript.|
|[A21--29](../results/compact_an_large_components_arbitrary_spectator_transfer_20261020.md) and [B23--29](../results/compact_bn_large_components_arbitrary_spectator_transfer_20261020.md), arbitrary spectators|The former WHOLE-vertex exclusions now apply to COMPONENTS with arbitrary accompanying finite components. Every weak cap is proved foreign-free before transferring the full actual-point and positive-dual certificate.|Full root and separate collaborating-agent written PASS for both transfers. Actual finite/timelike clearing, null boundary, zero-own-contact repair and both B tail layers are checked. [A review](../results/review_compact_an_arbitrary_spectator_transfer_resource_20261020.md), [B review](../results/review_compact_bn_arbitrary_spectator_transfer_resource_20261020.md). No ambient ceiling, scientific job, primary TeX or Lean.|
|[Localized actual B projection above9/14](../results/compact_bn_actual_projection_nine_fourteenths_20261020.md)|For every B_r,r>=9, the first seven coordinate squares sum to more than9/14, with arbitrary spectators.|Full [root](../results/review_compact_bn_actual_nine_fourteenths_root_20261020.md) and [separate-agent](../results/review_compact_bn_actual_nine_fourteenths_resource_20261020.md) written PASS. Independent B inventories include the r9 F4 branch; all numerical dual feet have their identical-prefix premises checked. Actual-point theorem, not an edge-only energy rate.|
|[Golden k4 norm319 H9 host excluded](../results/compact_h9_golden_k4_transverse_edge_and_period_candidate_20261020.md)|The literal k4 module is nonreflective. Two proper-prime obstructions and a complete58-value first-simple census give an actual transverse wall and integral chamber period of trace158+245phi>10. Two polynomial identities also give a finite transverse upper for every k.|Full [root](../results/review_compact_h9_golden_k4_paper_root_20261020.md) and [separate-agent](../results/review_compact_h9_golden_k4_finite57_20261020.md) written PASS. Both independently hand-recomputed all58 entries and trace exceptions; one draft norm typo was corrected. Executable reproduction and Lean pending, with no new jobs. No new example, dimension ceiling, uniform firstness or commensurability-class exclusion.|
|[Uniform actual D projection above9/14](../results/compact_dn_actual_projection_nine_fourteenths_20261020.md)|Every D_r,r>=9 at a farthest vertex has actual projection norm squared>9/14, with arbitrary spectators. In n>=15 without A/B rank>=5, the unique D has rank>=max(10,n-5), leaving at most five spectator ranks.|Full [root](../results/review_compact_dn_actual_nine_fourteenths_root_20261020.md) and [outside-author](../results/review_compact_dn_actual_projection_nine_fourteenths_batch_guard_20261020.md) written PASS. Complete low-index inventories and the actual native7 dual foot are separately reviewed; the fixed positive-dual rational gap is70423123/280000000000. This is an actual-point theorem, not an edge-only H_K rate or a new ambient ceiling. No scientific/Lean/TeX job or new primary manuscript.|
|[Whole B_n excluded for n>=23](../results/compact_whole_b_short_tail_extension_20261020.md)|The complete short-tail continuation, actual terminal-triple mate and far-helper pressure extend the earlier whole-B exclusion from26 to23, without arithmeticity.|Preserved reviewed WHOLE-vertex predecessor; the new arbitrary-spectator transfer above supersedes that restriction. B21--B22 and the global compact ceiling remain open. Same supporting packet, no new scientific/Lean/TeX job or primary manuscript.|
|[Three low-index D contact patterns](../results/compact_dn_low_index_three_profile_farthest_obstruction_20261020.md)|For D_r,r>=9, the named common2/3 profiles isolated5@1, isolated5@2 and4@2+3@3 each force actual farthest projection norm squared>9/14, with arbitrary spectators.|Full [root](../results/review_compact_dn_low_index_three_profiles_root_20261020.md) and [outside-author](../results/review_compact_dn_low_index_three_profile_resource_20261020.md) written PASS. The4+3 case uses an actual negative-core point, not an edge-only covering-energy claim. These inputs are now used by the complete uniform9/14 theorem above; no ambient ceiling or formal batch.|
|[Growing full-base collar and finite golden-family cutoff](../results/golden_e8_binary_family_discriminant_collar_and_finite_cutoff_20261020.md)|The entire base has collar width asinh(sqrt(N(b))/8)/2. Volume grows at least quadratically in N(b); reflectivity implies k<=2268, excluding every literal member k>=2269.|Full [root](../results/review_golden_e8_binary_family_discriminant_collar_root_20261020.md) and [outside-author](../results/review_golden_e8_binary_family_discriminant_collar_batch_guard_20261020.md) written PASS relative to the explicit spectral/conformal-volume and arithmetic inputs. The chamber-stabilizer factor is retained. The earlier finite range remains open apart from closed members; no enumeration, new example, dimension ceiling or Lean.|
|[Uniform first binary edge in the golden E8 family](../results/golden_e8_binary_family_uniform_first_edge_20261020.md)|For every k>=-1, the outgoing edge retaining E8 runs from the full Bugaenko base to the norm2 wall c, ending at an actual E8+A1(c) corner. Every allowed proper/full divisor norm is excluded from intervening.|Full [root](../results/review_golden_e8_binary_family_uniform_first_edge_root_20261020.md) and [outside-author](../results/review_golden_e8_binary_family_uniform_first_edge_batch_guard_20261020.md) paper reviews PASS. One norm/unit-spacing argument, with no factorization, root/Pell search or squarefree assumption. Other edges and uniform nonreflectivity remain open; no new example, ceiling or Lean.|
|[Uniform full Bugaenko base in the golden binary family](../results/golden_e8_binary_family_full_base_facet_20261020.md)|For every k>=-1 in the specified unit-coupled E8-plus-binary family, the complete base facet is Bugaenko's compact H8 chamber and its reversal extends to an actual full-chamber involution. Repeated discriminant factors need no exception.|Full [root](../results/review_golden_e8_binary_family_full_base_root_20261020.md) and [outside-author](../results/review_golden_e8_binary_family_full_base_facet_batch_guard_20261020.md) written PASS. Proper-divisor transverse mirrors and uniform nonreflectivity remain open. A structural reduction, with no new example, ceiling, scientific job or formal instance.|
|[Uniform large-D energy and six-rank remainder](../results/compact_dn_uniform_energy_and_chain_relaxation_20261020.md)|For every D_r with r>=8, E_Dr>4/7, with arbitrary spectators. At most one such component occurs. In n>=15, absence of A/B rank>=5 forces a unique D of rank>=max(9,n-6), with at most six spectator ranks.|Full [root successor review](../results/review_compact_dn_uniform_energy_frontier_root_20261020.md) and [outside-author common-opposite review](../results/review_compact_dn_internal_common_opposite_finite57_20261020.md) PASS. Low-index native profiles remain open; no uniform dimension ceiling or new Lean/TeX.|
|[Whole B_n excluded for n>=26](../results/compact_whole_b_bulk_weak_packet_and_endpoint_pressure_20261020.md)|A compact Coxeter polytope cannot have a whole B_n farthest vertex for n>=26, without arithmeticity. Complete bulk classification, endpoint pressure and a minimum-energy contradiction cover all native caps.|Full [root](../results/review_compact_whole_b_bulk_and_high_rank_root_20261020.md) and [outside-author](../results/review_compact_whole_b_bulk_endpoint_finite57_20261020.md) written PASS. Historical rank26 predecessor; the component successor above now covers B23--29 with arbitrary spectators. No dimension-table change. Same supporting packet, no new manuscript or Lean.|
|[Golden norm31 H9 host excluded](compact_h9_golden31_reproduce_20261020.md)|The literal E8-plus-binary host with binary matrix [[-2phi,phi^2],[phi^2,2]] has an infinite-volume full reflection chamber. Two actual chamber involutions have product trace28+42phi>10.|Root/outside-author mathematical and final code reviews PASS; bounded generation/fresh replay PASS:0.737s total,57,999,360B peak,38,416-byte certificate;18 immutable inputs. Full geometry and arithmetic inputs remain written premises. No new polytope, uniform ceiling, whole-family exclusion or geometric Lean instance.|
|[Compact RA4 C28 successor](compact_ra4_c28_successor_reproduce_20261020.md)|Every compact RA3 facet with28 vertices has no entire regular pentagonal face. Hence compact RA4 has f>=65 and Vol>=49pi^2/6; boundary-positive excess is at least5 and the stronger charge guarantees uniform D for W<=37.|Full root and outside-author written PASS; reviewed fixed generation/fresh replay PASS:0.135s,56,754,176B peak,29,156-byte certificate. Primary count-two fullerene classification and actual metric uniqueness are explicit inputs. Connected-D non120-cells at or below its volume need W>=38,f+W>=103. No120-cell minimum, dimension change or new Lean/TeX.|
|[Compact RA4 C26 successor](compact_ra4_c26_successor_reproduce_20261020.md)|A compact RA3 facet with26 vertices has no regular pentagonal face. Hence compact RA4 has f>=61 and Vol>=47pi^2/6; the sharpened charge forces uniform D for W<=33.|Full root mathematical/source PASS and fixed generation/fresh replay PASS:0.131s,56,033,280B peak. Published C26 uniqueness and actual Andreev symmetry are explicit inputs; the checker proves only the fixed graph and Q(sqrt17) identities. No dimension change,120-cell minimum, second volume or new Lean/TeX.|
|[D7/D8 components and restricted forests](../results/compact_d8_three_direction_component_energy_20261020.md)|With arbitrary spectators, E_D7>1/2 and E_D8>4/7. Adding these rates to the prior forest proof leaves A/B rank>=5 or D rank>=9 at every n>=15 farthest vertex.|Complete outside-author [D7](../results/review_compact_dn_center_neighbor_common_opposite_resource_20261020.md) and [D8](../results/review_compact_d8_three_direction_energy_finite57_20261020.md) written PASS; [root composition](../results/review_compact_d8_forest_composition_root_20261020.md). Exact actual-opposite classification and three-direction rational contradiction; no worker, ambient ceiling or formal coverage.|
|[Universal extended-D4 component energies](../results/compact_universal_e6_e7_e8_component_energy_20261020.md)|Adds D5,D6,E6,E7,E8 to the n>=15 farthest-forest exclusion, with arbitrary spectators. Remaining large components are A/B rank>=5 and D rank>=7.|Full [independent root written review](../results/review_universal_extended_d4_component_energy_root_20261020.md) PASS. Direct actual-opposite/minimal-Lanner argument, exact arm inverses and component-energy aggregation. No ambient ceiling, new example, worker, TeX or Lean.|
|[Whole A21--A29 farthest vertices excluded](../results/compact_whole_an_geometric_a21_plateau_transfer_20261020.md)|Without arithmeticity, a farthest vertex cannot have whole diagram A_n for21<=n<=29. The published compact29 tail covers all remaining possible whole A ranks>=21.|Complete [root](../results/review_compact_whole_an_plateau_transfer_root_20261020.md) and [outside-author](../results/review_compact_whole_an_a21_plateau_transfer_resource_20261020.md) written PASS. Uniform adjacent-packet proof and exact positive-dual plateau transfer preserve the A21 energy margin. The arbitrary-spectator gap is now closed by the component successor above; other types and a global ceiling remain open. No new execution, primary manuscript or Lean.|
|[Whole A21 farthest vertex excluded](../results/compact_whole_a21_farthest_vertex_exclusion_candidate_20261020.md)|A farthest vertex of a compact hyperbolic Coxeter21-polytope cannot have whole finite diagram A21. No arithmetic assumption is needed. The adjacent weak far-m/simple3 packet is a reviewed dependency.|Complete [root](../results/review_compact_whole_a21_farthest_vertex_root_20261020.md) and [outside-author](../results/review_compact_whole_a21_farthest_vertex_batch_guard_20261020.md) written reviews PASS. Complete central inventory, both helper assignments, positive-dual pressures and exact floor-hole energy assembly are covered. No arbitrary spectators, higher-rank A theorem, global ceiling, new execution, TeX or Lean.|
|[Whole-D_n long-end5, all invariant lattices](../results/golden_dn_long_end_five_invariant_lattices_20261020.md)|An actual isolated label5 at the long-arm end of a whole D_n vertex is excluded in compact arithmetic first-type n>=8. The all-lattice bridge covers both parities and every odd deep lift.|Full [outside-author mathematical review](../results/review_golden_dn_long_end_five_invariant_lattices_resource_20261020.md) PASS. Exact written algebra, residue classification and norm recovery precede the explicit published literal cutoff. Other contacts and spectators remain; no uniform ceiling, new example, execution, primary manuscript or Lean theorem.|
|[Compact RA4 global facet/volume charge](../results/compact_ra4_global_low_excess_charge_20261020.md)|Universally f>=57 and Vol>=15pi^2/2, with Nu>=f-2W+N2. Non120-cells at or below its volume with W<=28 require separating H2 on facets of excess at least3.|Full [root written review](../results/review_compact_ra4_global_low_excess_charge_root_20261020.md) PASS relative to the pinned written inputs. No universal120-cell minimum or second-volume result. Supporting successor is not yet in the frozen primary TeX or Lean; no scientific execution.|
|[Quartic literal family excluded, every n>=8](quartic_order_exchange_reproduce_20261020.md)|The FULL integral reflection group of `<-(phi+sqrt2-1)>+I_n` over Z[sqrt2,phi] is noncofinite. Two different FULL rank-two face constructions, exchanged in order, give an integral future chamber symmetry of infinite order.|Full root/outside-author mathematical and source PASS. Fixed generation/fresh replay PASS:0.215s total,56,311,808B peak; all five-coordinate identities, inverse integrality, oriented images and exact trace checked. Geometry and the arithmetic lattice theorem remain written inputs. No new global ceiling, compact example, primary manuscript or Lean instance.|
|[Golden whole-B_n isolated-five stars at nodes1 and5](../results/golden_b_isolated_five_invariant_lattice_interface_20261020.md)|The two specified contacts are excluded in compact arithmetic first-type dimension n>=8 for EVERY compatible invariant lattice. Exact orthogonal-group equality precedes use of the published literal golden cutoff.|Full root/outside-author written PASS. Nodes2/3/4 and other cap types remain open; this is supporting research, not a smaller uniform ceiling, new example, manuscript or Lean expansion.|
|[Ramified silver literal family excluded, every n>=8](../results/ramified_silver_uniform_published_facet_closure_20261020.md)|The FULL integral reflection group of `<-sqrt2>+I_n` is noncofinite for n>=8, including M9. A uniform actual first wall, exact integral splitting and its divisor give the FULL odd-silver facet L_(n-1); the published literal cutoff excludes compactness.|Full [outside-author composition audit](../results/review_ramified_silver_uniform_published_facet_closure_resource_20261020.md) PASS, with earlier root/outside edge and product proofs. Allcock Section2 p.740 and the arithmetic lattice/anisotropic compactness inputs are explicit. The earlier n>=10 bridge, M9 edges and finite L8 involution remain historical support. No new job, TeX, Lean, arbitrary node2 lattice exclusion, class exclusion or uniform ceiling.|
|[Arithmetic B_n vertices: isolated label8 at nodes1 or3](../results/silver_long_end_eight_arithmetic_vertex_exclusion_20261020.md), with [node3 transfer](../results/silver_b_node_three_triple_cap_lattice_extension_20261020.md)|No compact arithmetic first-type polytope in n>=9 has either specified actual star. The full-rank star fixes the silver field/form; a complete invariant-lattice classification handles every compatible lattice, with a separate even-neighbor facet obstruction.|Full root reviews of [all flags](../results/review_silver_b_vertex_flags_root_20261020.md) and [node3](../results/review_silver_b_node_three_root_20261020.md), plus [outside-author review of the complete composition](../results/review_silver_b_invariant_lattices_and_star_applications_resource_20261020.md), PASS. The earlier literal silver-family theorem is an explicit inherited input. Node2 and other labels remain open; compact20/29 unchanged. One research packet; no execution, TeX or Lean.|
|[Actual mixed-wall replacements](../results/compact_farthest_vertex_mixed_replacement_inequalities_20261020.md)|Positive acute projection gives actual finite replacement vertices and weighted farthest-vertex inequalities. These reject the previous formal B20 edge-only witness. Full-rank finite-target comparisons also work with several cusps when finite vertices exist.|Full [root](../results/review_farthest_mixed_replacements_root_20261020.md) and [outside-author](../results/review_farthest_mixed_replacement_resource_20261020.md) written PASS. Ideal targets, entirely ideal selection and sufficient replacement coverage remain unresolved. No new ceiling, execution, manuscript or Lean.|
|[Golden dyadic literal family excluded](golden_dyadic_family_nonreflectivity_reproduce_20261020.md)|The FULL integral reflection arrangement of `R_n=<-phi>+I_n+D4(O_phi)` is noncofinite for EVERY n>=5, in hyperbolic dimensions n+4>=9. Two full actual R5 germs are matched by an integral chamber period with trace10+11phi>10; exact full coordinate facets propagate upward.|Complete root/outside-author written and source reviews PASS. Final generation and separate fresh replay PASS:108 strip tests,1.031s combined,58,507,264B peak; integral basis, six profiles, g/Q tie, full germs and inverse checked. Explicit Borel--Harish-Chandra/anisotropic arithmetic input; literal lattices only. Unified frozen packet preserves the old25 core and old guide. No new example, uniform ceiling, commensurability-class exclusion, Lean or TeX.|
|[Ramified cubic-seven diagonal family excluded](cubic7_ramified_diagonal_family_reproduce_20261020.md)|The full integral reflection arrangement of `<-t(2-t)>+I_n`, t=2cos(2pi/7), is noncofinite for EVERY n>=3. Complete actual edges, a dyadic finite-germ obstruction and incompatible chamber involutions give the dimension3 contradiction; full coordinate facets propagate upward.|Full root and separate adversarial written reviews PASS. Paper proof only; explicit field/classification and arithmetic-lattice theorem inputs. No exact worker, Lean, extra manuscript, new example, uniform ceiling or commensurability-class exclusion. Stop further searches of this literal family.|
|[Odd silver diagonal published cutoff, every m>=7](../results/ramified_silver_uniform_published_facet_closure_20261020.md)|The full integral reflection arrangement of `<-(1+sqrt2)>+I_m` is noncofinite for EVERY m>=7. Allcock, Geometry & Topology10(2006), Section2 p.740 records the literal compact-chamber iff m<=6, attributed to Bugaenko[4]; anisotropic arithmetic gives the cofinite implication.|The [source-bound audit](../results/review_ramified_silver_uniform_published_facet_closure_resource_20261020.md) verifies the exact published input and scope. This corrects an overlooked input. The earlier [n>=9 guide](odd_silver_diagonal_family_reproduce_20261020.md), stable-isometry proof,0.120s local-algebra generation/replay and38-input freeze remain unchanged historical evidence. No new execution, manuscript, Lean, field-wide ceiling or commensurability-class exclusion.|
|[Compact: complete rank-at-most-four farthest forests](../results/compact_farthest_rank_four_forest_exclusion_20261020.md)|In n>=15 a farthest vertex must have an irreducible finite component of rank at least5. This covers every mixture of all finite types of ranks1--4, with arbitrary dihedral labels. Earlier A1/A2/A3/A4 and mixed-dihedral n>=14 restrictions remain preserved.|Full [root](../results/review_farthest_rank_four_forest_root_20261020.md) and [outside-author](../results/review_farthest_rank_four_forest_finite57_20261020.md) written audits pass, including the two different isolated7 defects. Component arguments are separately reviewed. No arithmetic assumption, execution, TeX or Lean. Larger A,B,D,E factors remain open; neither compact29 nor arithmetic compact20 changes. Supporting research only.|
|[Bugaenko-facet extensions: binary reduction and uniform collar](../results/bugaenko_facet_binary_extension_and_collar_audit_20261020.md)|Any arithmetic compact H9 polytope with this metric H8 facet has exact field Q(phi) and an invariant even lattice E8+B in two binary glue forms. Mixed mirrors have a uniform collar; determinant growth forces a long actual binary edge. An [analytic addendum](../results/bugaenko_facet_full_reflection_volume_bridge_addendum_20261020.md) gives finite normalized reduction with impractically large constants.|[Root](../results/review_binary_extension_collar_root_20261020.md) and [independent](../results/review_bugaenko_facet_binary_collar_batch_guard_20261020.md) reviews pass; the analytic bridge also has [root](../results/review_full_reflection_volume_bridge_root_20261020.md) and [independent](../results/review_bugaenko_full_reflection_volume_bridge_batch_guard_20261020.md) reviews. No enumeration, build or Lean. No new ceiling, example or exhaustive exclusion; no additional manuscript.|
|[Compact RA4: all center-cutting walls with uniform outgoing edges](../results/compact_ra4_uniform_outgoing_center_cut_volume_cost_20261020.md)|With a regular D facet and all20 outgoing lengths arcosh(phi), any actual wall reaching or cutting the matched120-cell center forces at least48 vertices on its facet and volume>=23pi^2/2>34pi^2/3. At most one such wall exists.|[Complete independent root review](../results/review_compact_ra4_uniform_outgoing_center_cut_root_20261020.md) and [final-source resource review](../results/review_compact_ra4_uniform_outgoing_center_cut_resource_20261020.md) pass; the latter discloses co-derivation. No job, Lean or extra manuscript. Low volume forces only the matched center to be interior; whole120-cell containment and unrestricted minimality remain open.|
|[Compact RA4: irregular outgoing-edge count](../results/compact_ra4_irregular_outgoing_facet_excess_count_20261020.md)|The number of irregular dodecahedral facets satisfies3*N_irregular<=4W. If W<=19, at least f-2W>=7 dodecahedral facets have all20 outgoing edges regular.|[Full independent root review](../results/review_compact_ra4_irregular_outgoing_count_root_20261020.md) passes. At120-cell volume or less, their matched centers are interior by the preceding theorem. Distinct centers, a contained regular inball and a bound W<=19 do not follow. Supporting note only; no job, Lean or extra manuscript.|
|[Compact RA4: whole dodecahedral blocks in uniform neighbors](../results/compact_ra4_uniform_dodecahedron_neighbor_block_20261020.md)|Every neighbor G of a dodecahedral facet with all20 regular outgoing lengths is either the regular dodecahedron or has at least30 vertices, so its facet excess is at least5. At30 vertices it is intrinsically the double of a dodecahedron.|Full [root](../results/review_compact_ra4_dodecahedral_neighbor_block_root_20261020.md) and [independent outside-author](../results/review_compact_ra4_uniform_dodecahedron_neighbor_block_batch_guard_20261020.md) written PASS. The proof contains an entire canonical dodecahedron before cutting; it does not classify arbitrary positive facets or prove a universal120-cell minimum. Supporting note; no job, TeX or Lean.|
|[Compact RA4: regular inball implies120-cell volume](../results/compact_ra4_regular_inball_volume_comparison_20261020.md)|If P contains a ball of radius asinh(phi^(3/2)), then Vol(P)>=34pi^2/3, with equality precisely for the regular120-cell. A direct spherical Gram/cone-integral comparison forces at least600 vertices.|[Full independent root review](../results/review_compact_ra4_regular_inball_volume_root_20261020.md) passes. The inball hypothesis is unproved for arbitrary P; the farthest-wall theorem does not supply it. No universal minimum, dimension improvement, execution, Lean or extra manuscript.|
|[Compact H9 search: discriminant19 host excluded](compact_h9_discriminant19_reproduce_20261020.md)|The full integral arrangement of `E8(O)+[[-2phi,phi],[phi,2]]` is nonreflective. Complete binary/D7+c edges give an integral full-chamber period of trace10+14phi>10.|Full root and independent written/source reviews; fixed checker generation and separate replay PASS. Two runs took0.964s, with peak58.1MB RSS;25-input packet frozen. Full Bugaenko calibration is inherited and bound, not rerun. Shared conditional Lean checks final group/coset logic only. No uniform ceiling, new example or whole commensurability-class exclusion.|
|[Compact H9 search: quadratic13 host excluded](compact_h9_sqrt13_reproduce_20261020.md)|The full integral arrangement of `<-(3+sqrt13)/2>+I9` is nonreflective. Four complete edges give two chamber involutions whose product has trace268eta+80>10.|Complete root and independent mathematical/source reviews; all three workers have generation and separate replay PASS. Six runs took2.918s, with peak57.9MB process-tree RSS. The33-input packet is frozen. Shared conditional Lean checks final group/coset logic; actual geometry and trace interpretation remain premises. No new example, uniform ceiling or commensurability-class exclusion.|
|[Compact H9 search: golden discriminant59 host excluded](compact_h9_golden_discriminant59_reproduce_20261020.md)|The FULL integral arrangement is nonreflective. A complete D7+c edge has one first wall; its actual finite corner and an old Bugaenko corner are matched by an integral chamber isometry of trace40+55phi>10.|Root and independent full paper/source reviews pass. Both exact workers have bounded generation and separate replay PASS: four runs total9.668s, below58MB peak process-tree RSS. The later shared [ChamberPeriod module](chamber_period_logic_verification_20261020.md) compiles and passes seven axiom audits for the final group/coset implication, with actual geometry, groups and trace bound explicit premises. No new example, uniform ceiling, commensurability-class exclusion or geometric Lean proof.|
|[Metric Coxeter facets: restricted compact ceiling8](../results/coxeter_metric_facet_angle_rigidity_20261020.md)|If every actual metric facet of a compact Coxeter polytope is itself Coxeter, its dimension is at most8. A complete rank-three calculation proves parent-wall perpendicularity at every intrinsic nonright label except4; a compact arithmetic simplex realizes that exception.|[Root paper review](../results/review_metric_facet_and_good_prime_scope_root_20261020.md) and [independent full review](../results/review_coxeter_metric_facet_angle_rigidity_resource_20261020.md) pass. No scripts are required; no new TeX or Lean package is proposed. This restricted class has no asserted sharpness or worldwide priority. The arbitrary compact29 and arithmetic compact20 ceilings are unchanged.|
|[Good-prime two-face trees and conditional global action](../results/compact_coxeter_good_prime_global_tree_action_20261020.md)|Under explicit unit-Gram hypotheses at one common odd place, white fixed sets are trees and the full reflection group admits a compatible tree action. An actual compact Lambert quadrilateral shows that one locally bad opposite pair is still possible.|[Root paper review](../results/review_metric_facet_and_good_prime_scope_root_20261020.md) passes. This gives no arithmeticity theorem or dimension improvement: such Coxeter groups need not have the tree fixed-point property. Further expansion is parked pending a quantitative geometric consequence.|
|[Compact H9 search: square-root-of-three host excluded](compact_h9_sqrt3_first_edge_reproduce_20261020.md)|The full integral arrangement of <-sqrt3>+<1>^9 is nonreflective. Its scalar facet lattice is integrally E8(O) plus <1-sqrt3>; two certified edges and an integral isometry of trace5+3sqrt3 give an infinite-order stabilizer of its full chamber.|All four exact workers have generation and separate replay PASS. Root and independent written reviews check the norm pool, complete edge inventories, lattice glue and chamber-germ implication. The seven new executions used at most56.3MB process-tree RSS. The later shared [ChamberPeriod module](chamber_period_logic_verification_20261020.md) conditionally checks the final group/coset implication. Actual groups, geometry and real trace bound remain premises. No new example, uniform ceiling or commensurability-class exclusion.|
|[Compact RA4: intrinsic dodecahedron/double spectrum](../results/compact_ra4_dodecahedral_double_spectrum_cutting_20261020.md)|If every metric facet is a regular right-angled dodecahedron D or its facet double D2, actual disjoint D sections cut the polytope into120-cells. The D2 count is12(m-1), and the restricted second-volume equality is the reflected double. A tree is proved; a chain is not asserted.|[Full root written review](../results/review_compact_ra4_cutting_and_radius_root_20261020.md) and [independent full review](../results/review_compact_ra4_cutting_and_radius_finite57_20261020.md) pass. No new execution, manuscript integration or Lean. The arbitrary low-volume facet-spectrum reduction is still missing.|
|[Compact RA4: farthest facets and sharp wall radius](../results/compact_ra4_farthest_dodecahedron_wall_radius_20261020.md)|For every interior point, each farthest supporting facet is D. Its maximum wall height satisfies T(q)^2>=phi^3, with equality exactly at the120-cell center.|The same two full written reviews check the projection, quartic tensor positivity, inherited polygon-capacity/metric inputs and equality propagation. This is a maximum-wall-distance theorem; it supplies neither an inscribed120-cell nor a volume minimum.|
|[First-type arithmetic: two explicit shortcut obstructions](../results/first_type_projection_and_trace_lift_obstructions_20261020.md)|An actual compact arithmetic triangle makes the right-angled projection height increase. An integral Coxeter trace lift of an actual compact arithmetic quadrilateral has an unsaturated cusp and infinite volume.|[Independent root written review](../results/review_first_type_projection_trace_obstructions_root_20261020.md) passes. No new dimension bound or larger-dimensional finite-volume example. These counterexamples prevent applying the new right-angled argument or the rational arithmetic ceiling without additional global structure.|
|[Rank57: physical coupon capacities](../results/a1_rank16_physical_coupon_capacity_research_20261020.md), read with the [mandatory scope correction](../results/a1_rank16_partial_display_scope_correction_20261020.md)|The complete family containing three rank16 factors has charge at most361, below the364 threshold. Separate guarded D17/D16 exchanges lower other difficult families but leave A1+2D16+D24 at368. The complete safe finite upper remains2965/8; no dimension56 theorem.|[Root review](../results/review_rank57_physical_transfers_root_20261020.md), [independent full review](../results/review_a1_rank16_physical_coupon_capacity_resource_20261020.md) and [new targeted exact generation/replay](../results/review_a1_rank16_physical_coupon_execution_root_20261020.md) pass, with twelve target displays and zero unknowns. Universal geometry remains the inherited written proof. Research support, with no new manuscript or Lean theorem.|
|[Compact rank29: simultaneous rank-four refunds](../results/compact29_all_rank4_leaf_refund_20261018.md)|A valid charge reduction removes2028 of the2126 formerly heavy abstract vertex types, leaving98. The98 types are remaining obligations, not excluded vertices.|[Root mathematical review](../results/review_new_bound_frontier_root_20261018.md) and [independent review](../results/review_compact29_all_rank4_leaf_refund_resource_20261018.md) pass. Research report only; the existing triangle manuscript does not yet contain this theorem.|
|[Compact rank29: essential E7(2,5) exclusion and a full three-unit saving](../results/compact29_e7_pair25_essential_quad_exclusion_20261019.md)|The same valid simultaneous rule gives every E7 cubed+E8 vertex charge at most84. This removes that one type, leaving97 unresolved types:79 at87 and18 at85, against target84.|Complete written proof and [full root review](../results/review_compact29_pair25_and_four_T_root_20261019.md) pass. No arithmeticity assumption, new computation, new dimension ceiling or Lean theorem.|
|[Ideal RA4: exclusion of all antiprism sizes in an enlarged restricted spectrum](../results/review_and_extension_ideal_ra4_antiprism_spectrum_20261018.md)|If every facet is an octahedron, a triangular-face doubled octahedron, or a k-antiprism for k≥4, no antiprism occurs. The Oct/D chain theorem then applies. A positive-kappa ideal4 facet of an ideal5 polytope must contain a three-face outside this whole spectrum.|Author's complete proof and [independent root review](../results/review_new_bound_frontier_root_20261018.md) pass. Awaiting integration; the verified16-page ideal4 paper retains its original Oct/D hypothesis. The next row records the subsequent Figure7 extension.|
|[Ideal RA4: Figure7 exclusion and the complete ten-vertex facet threshold](../results/ideal_ra4_ten_vertex_facet_exclusion_research_20261019.md)|The enlarged spectrum may also include Figure7; it is excluded by its exact golden-ratio cusp shapes and a box/triangle argument. Hence every idealRA4 whose facets have at most10 vertices is an Oct/D chain. Each positive-kappa ideal4 facet in an ideal5 polytope must have a three-face with at least11 vertices.|Direct written proof, [independent full mathematical review](../results/review_ideal_ra4_ten_vertex_facet_exclusion_resource_20261019.md) and [exact model generation/replay](../results/review_ideal_ra4_ten_vertex_facet_exclusion_root_20261019.md) pass. The eleven-vertex translation uses the published complete small-facet classification. No Lean verification or dimension exclusion.|
|[Compact arithmetic: full-D_n isolated-wall quadrilateral obstruction](../results/arithmetic_dn_isolated_quad_obstruction_20261018.md)|For n≥15, excludes the specified isolated-A1 quadrilateral when the opposite ambient walls also satisfy a.c≤−1. It does not cover all fork quadrilaterals or supply a global refund.|Written proof and [independent mathematical review](../results/review_arithmetic_dn_isolated_quad_obstruction_batch_guard_20261018.md) pass, using the stated published field list. No new exact execution or Lean theorem.|
|[Compact arithmetic: double-whisker wall obstruction](../results/arithmetic_dn_double_whisker_obstruction_20261018.md)|For n≥16, excludes the complementary a.c=0 pattern when c contacts only one D_n whisker, d only the other, c.d=0, and d.b<−1. A direct trace/integrality proof avoids the published ground-field list.|[Independent written mathematical review](../results/review_arithmetic_dn_double_whisker_obstruction_batch_guard_20261018.md) passes. This is a second local branch, not an exhaustive quadrilateral classification or an improved ceiling; TeX and Lean integration remain pending.|
|[Compact arithmetic: golden and silver far-end opposed-fork models](../results/review_arithmetic_dn_opposed_fork_survivors_root_20261019.md)|Four exact local face stars at n19/20 survive Lorentz, finite-corner, conjugate-positivity and integrality checks. A proposed simultaneous deletion must account for their two opposite D_n payments. A whisker-swap capacity excludes two matching profiles at one old vertex.|Written root review and separate bounded [generation](../results/arithmetic_dn_opposed_fork_models_generation_20261019.json)/[replay](../results/arithmetic_dn_opposed_fork_models_replay_20261019.json) pass. These are compact two-face models, not globally completed compact polytopes or new examples in dimensions19/20. The enlarged golden triangle/quad capacity has a separate written proof; a complete global refund remains open.|
|[Compact arithmetic: full-D19/D20 whisker-pair refund](../results/review_dn_whisker_pair_retention_root_20261019.md)|Deleting the single short-whisker-pair baseline unit preserves every affected triangle and quadrilateral payment. The complete old vertex must be D19 or D20. This earlier rule gives D20 cost37.|Root and independent full written reviews pass. The subsequent three-unit theorem below goes further in its explicit eight-field scope; no deletion outside a whole-D vertex is asserted. TeX and Lean integration pending.|
|[Compact arithmetic: full-B19/B20 simple-end distance-two refund](../results/arithmetic_bn_simple_end_distance_two_refund_20261019.md)|Deleting the first/third-node mark preserves all face payments in the stated eight fields, including simultaneous selected corners. It composes with the D-whisker deletion; the connected rank20 costs are A20=37, B20=36, D20=37, versus target35.|[Root full review](../results/review_bn_simple_end_distance_two_refund_root_20261019.md) and [independent full review](../results/review_arithmetic_bn_simple_end_distance_two_refund_resource_20261019.md) pass. No improved dimension ceiling; TeX and Lean integration pending.|
|[Compact arithmetic: balanced B-end quarter rule](../results/arithmetic_bn_balanced_quarter_end_rule_20261019.md)|A subsequent rule lowers the adjacent full-B_n mark to1/4 and adds1/4 at two explicit whole-forest recipient roles. Every corner of an affected quad pays at least1/4. With the distance-two refund, B20 and B19+A1 both cost35.25, still above35.|[Root full written review](../results/review_bn_balanced_quarter_end_rule_root_20261019.md) and [independent full review](../results/review_arithmetic_bn_balanced_quarter_end_rule_resource_20261019.md) pass. No implemented global rule, new ceiling, TeX revision or Lean theorem.|
|[Compact arithmetic: both whole-A19/A20 end-distance-two refunds](../results/arithmetic_an_two_end_distance_two_refund_20261019.md)|Within the stated eight fields, the complete consumer proof deletes both path-end units, giving full A20 cost35. It composes with the D-whisker and B reductions; the subsequent mixed A/D lemma below permits the full three-unit D rule too.|[Full root written review](../results/review_an_two_end_distance_two_refund_root_20261019.md) and [independent full review](../results/review_arithmetic_an_two_end_refund_resource_20261019.md) pass. One printed bound is valid but looser than its exact extremal value, as recorded in both reviews. No global allowance35, new ceiling or Lean theorem.|
|[Compact arithmetic: standalone three-unit whole-D19/D20 refund](../results/arithmetic_dn_three_unit_refund_eight_fields_20261019.md)|In the same eight fields, all three fork/whisker units can be removed, giving D20 cost35 with the unmodified A baseline. Its consumer proof includes every placement of simultaneous selected D corners.|[Independent full written review](../results/review_arithmetic_dn_three_unit_refund_resource_20261019.md) passes. The A/D composition is a separate lemma; no outside-factor extension, global allowance or new dimension ceiling.|
|[Compact arithmetic: mixed A/D consumer composition](../results/arithmetic_an_dn_mixed_end_refund_consumers_20261019.md)|The mixed quadrilateral cases reduce to three exact rank equations and an integral-trace obstruction. Combined with the standalone theorems this gives simultaneous A20 and D20 costs35.|[Root full mathematical review](../results/review_arithmetic_an_dn_mixed_consumers_root_20261019.md) and [independent full review](../results/review_arithmetic_an_dn_mixed_end_refund_resource_20261019.md) pass. B20 and B19+A1 remain141/4, and multifactor/other-field coverage remains open. No dimension improvement or Lean theorem.|
|[Compact arithmetic: spectator-aware B19+A1 half refund](../results/arithmetic_b19_a1_spectator_half_end_refund_20261019.md)|A separate complete consumer proof retains arbitrary permitted new contacts with the A1 spectator. It lowers this whole forest from141/4 to139/4, below target35.|[Root full review](../results/review_b19_a1_spectator_half_refund_root_20261019.md) and [independent full review](../results/review_arithmetic_b19_a1_half_end_refund_finite57_20261019.md) pass. Complete white-graph separation permits composition; no new dimension ceiling or Lean theorem.|
|[Compact arithmetic: whole-B20 far-4 quarter refund](../results/arithmetic_b20_far_four_quarter_refund_20261019.md)|The complete21-row consumer proof includes both D-whisker interactions and excludes the remaining quadratic survivor by a nonsquare norm. Whole B20 now costs35.|[Root full review](../results/review_b20_far_four_quarter_refund_root_20261019.md) and [independent full review](../results/review_arithmetic_b20_far_four_quarter_refund_resource_20261019.md) pass. The subsequent spectator theorem below leaves ten two-component D families; no dimension improvement or Lean theorem.|
|[Compact arithmetic: whole-D19+A1 two-fork half refunds](../results/arithmetic_d19_a1_two_fork_half_refund_20261019.md)|The complete spectator-contact argument preserves every consumer while reducing the two fork/leaf weights to1/2. This whole forest now costs35; its short-leaf-pair weight stays unchanged.|[Root](../results/review_d19_a1_two_fork_half_refund_root_20261019.md) and [independent full review](../results/review_arithmetic_d19_a1_two_fork_half_refund_resource_20261019.md) pass. Ambient20/eight fields only; no D+D or D+E refund, new ceiling or Lean claim.|
|[Compact arithmetic: whole-D18+high-I2 two-fork half refunds](../results/arithmetic_d18_high_i2_two_fork_half_refund_20261019.md)|A three-root finite-corner determinant seals both spectator roots. Complete rank18 consumer proofs allow two half refunds, giving cost35 for every allowed high label.|[Root](../results/review_d18_high_i2_two_fork_half_refund_root_20261019.md) and [independent full review](../results/review_arithmetic_d18_high_i2_half_refund_resource_20261019.md) pass. Seven D+D and three D+E families remain above35; no new dimension ceiling.|

The reviewed A/B/D rules give A20,B20,D20,D19+A1 and
D18+I2(m>=6) cost35, with B19+A1 cost139/4, in these eight fields.
The [complete finite-forest reduction](../results/arithmetic_rank20_complete_fourteen_family_frontier_20261019.md)
left exactly ten cost36 forests: seven D+D and three D+E families.
The new [complete two-component consumer theorem](../results/arithmetic_rank20_two_component_d_fork_half_refund_20261019.md)
halves two fork marks in each such forest, reducing every vertex to35.
It covers triangles, all six first-wall quadrilateral rows, simultaneous
changes and separation from the earlier altered roles. The h-vector
count requires at least35*f0+500, a contradiction. Together with the
earlier universal20 tail this proves the scoped ceiling19. The new step
uses finite classification directly, without a new forest search.

The next [isolated-side no-long-contact theorem](../results/arithmetic_rank20_isolated_side_no_long_contact_20261019.md)
has root and independent written reviews. For actual whole vertices
`D_r+T_s`, `10<=r<=16`, in the stated eight fields, it excludes the
specified quadrilateral when the other side is orthogonal to the
spectator and long arm. The [long-contact review](../results/review_arithmetic_rank20_long_finite_and_height_root_20261019.md)
also checks every zero/finite opposite product, including the two E8
attachments at r=10, and proved finite heights for the remaining dotted
rows. A new [quadratic argument](../results/arithmetic_rank20_isolated_long_quadratic_obstruction_20261019.md)
excludes all those dotted long-contact rows over Q(sqrt3) and Q(sqrt6)
by norm and even-trace arguments, without enumeration; author/root and
independent written checking agree. The stronger
[complete dotted long-contact closure](../results/arithmetic_rank20_isolated_d_dotted_long_unit_closure_20261019.md)
now excludes **every** long-contact type in this isolated-side,
spectator-orthogonal setup over **every totally real field**. It combines
the common three-type norm obstruction, a basis-free endpoint3 argument,
a product-unit proof for endpoint3+e3, and the two exceptional E8 contacts.
Both endpoint roles and the quadratic remainder are covered. The
[full root integration review](../results/review_arithmetic_rank20_dotted_long_closure_root_20261019.md)
passes; the new root arguments also received independent mathematical
checking. Earlier quadratic, squarefree-ideal and cubic proofs remain
preserved support. The prepared cubic producer is unexecuted and is no
longer needed to prove this closure. The separate
[spectator-only and bridge rows](../results/review_arithmetic_rank20_spectator_and_bridge_root_20261019.md)
also have complete scoped root review, binding the required E8 coverage
addendum. The new [spectator-contact proof and complete I-row audit](../results/arithmetic_rank20_isolated_d_spectator_contact_obstruction_20261019.md)
now close every remaining c-support in the isolated-d row over all eight
fields. Its [full root review](../results/review_arithmetic_rank20_isolated_d_complete_root_20261019.md)
also checks why beta>1 follows from the actual finite side, without an
ambient-opposites assumption. The [simple finite-beta/T proof](../results/arithmetic_rank20_simple_d_finite_beta_and_far_fork_closure_20261019.md),
[finite-beta B proof](../results/arithmetic_rank20_far4_finite_beta_obstruction_20261019.md),
and [large-beta F/B closure](../results/arithmetic_rank20_far_simple_and_far4_large_beta_closure_20261019.md)
now close all first-d F/B/T rows too, including every spectator contact.
Their complete written root reviews pass. These local branches are now
consumed by the complete rank20 theorem above. Its
[independent full-packet review](../results/review_arithmetic_rank20_two_component_d_fork_half_refund_finite57_20261019.md)
also checks the triangle consumers and simultaneous composition.
`ArithmeticEightField19` subsequently compiled and passed its separate
axiom audit. Actual geometry and complete charge/forest interpretation
remain explicit premises; the checked final logic is conditional.

The completed bound57 combines the ambient58 finite maximum377, cusp
surplus36 and strict correction4205 with the completed58 higher tail.
The final composition has generation, separate replay and two full
independent mathematical reviews. Lean checks the dimension-specific rank
guards and final arithmetic; the D13 geometric transfer and complete
rank58 certificate interpretation still need formalization. The new
`ManuscriptFinite57` conditional composition now also compiles and passes
[its printed-axiom audit](../formal/.proof-batches/CoxeterProofs_ManuscriptFinite57_axiom_audit.json),
using only propext and Quot.sound. Geometric and admitted script premises
remain visible in its theorem interface.

The next-dimension research rule also has a new
[completed A15 A1-absence refund](../results/review_a15_inner_unit_a1_absence_root_20261019.md).
Its actual whole-factor proof and current saved-output audit pass, including
separate bounded generation and replay. It changes the finite charge by
−a15*[a1=0], with no new positive family. The old formal attainer is
unchanged, so the complete finite maximum is still11861/32, above the
target364. Ideal payments remain unchanged; this is not a56 theorem.
The subsequent [D17 physical-face capacity theorem](../results/review_d17_node2_face_capacity_root_20261019.md)
also passes independent written/source review and separate exact generation
and replay. Two selected D17 obligations at one vertex would force an
actual non-Coxeter angle. Activating the payment only where a constructive
face proof needs it gives a guaranteed refund(5/8)max(d17−1,0).
The2D17+D23 upper drops370 to2955/8; the complete maximum remains11861/32.

The new [nonsingular full-seal rank lemma](../results/finite_quad_nonsingular_full_seal_rank_obstruction_20261019.md)
has a [full root mathematical review](../results/review_finite_quad_full_seal_rank_obstruction_root_20261019.md).
A four-black nonsingular quadrilateral core cannot have every additional
actual common white orthogonal to it: that would force rank n+2 in
Lorentz dimension n+1. For the nine old order16 exceptions, every actual
face therefore takes the independently retained short2 route. This
resolves four older D16-half consumers, but a complete current later-output
audit was required before a global refund. That audit now has separate
[bounded generation and replay](../results/review_d16_d13_physical_output_execution_root_20261019.md),
with all54 inputs and zero unknown targets. It supports the long-end
D16 saving-d16*[a1=0]. No exact new finite maximum or dimension56
conclusion is claimed.

A separate [distal D13 physical capacity theorem](../results/order17_distal_d13_physical_coupon_capacity_research_20261019.md)
now bounds the extra marginal payment by two actual angles per finite
vertex, rather than four times the A4/D13 component product. The
[scoped full root review](../results/review_order17_distal_d13_capacity_root_20261019.md)
passes. Two marked angles can share the same omitted walls, so a capacity
of one would be incorrect. The complete current marginal-output audit
now passes generation and fresh replay. At alpha9/32 the former
3D13+4A4+A2 allowance11861/32 falls to11447/32=357.71875, below364. The separate
[complete sequential cover](../results/order17_distal_capacity_sequential_cover_research_20261019.md)
now has a [root review](../results/review_distal_capacity_sequential_cover_root_20261019.md).
With the completed activation audit, all finite forests in this refined
research rule cost at most2965/8. This is a safe upper, not an attained
maximum, and it still exceeds364. The same bound holds through alpha1/2;
no new increasing family is introduced. The
specific completed order11 composition at delta11/512 already has all 2270
ideal profiles positive; the earlier negative-profile counts below belong
to predecessor rules. The written geometric/routing premises remain
explicit; there is no new dimension ceiling or Lean theorem.

The separate [current A2/D13-short rollback audit](../results/review_a2_d13_short_retention_execution_root_20261019.md)
now passes generation and fresh replay across all54 saved inputs, with
zero unknown targets. Its same-target whole-factor seal supports the
pointwise reduction-2*a2*d13 without a transported whole-D15 guard.
It introduces no positive family and changes no ideal weight. The safe
upper2965/8 remains valid; a new exact maximum has not been computed and
no dimension56 theorem follows.

The latest reviewed right-angled necessary constraints are:

The dimension12 statements below are preserved intermediate necessary
conditions. The completed opposition contradiction now excludes that
dimension; they must not be read as an unresolved ceiling12.

|Entirely ideal class|Facets at least|Vertices at least|Current verification|
|---|---:|---:|---|
|Dimension5|63|211|The new [eleven-vertex carrier equality exclusion](../results/right_angled_ideal4_eleven_vertex_equality_exclusion_20261019.md) has [root](../results/review_ideal4_eleven_vertex_equality_exclusion_root_20261019.md) and [independent full reviews](../results/review_ideal4_eleven_vertex_equality_exclusion_finite57_20261019.md). Written geometry reviewed; [current conditional Lean logic and axiom audit](right_angled_eleven_vertex_counts_verification_20261019.md) pass.|
|Dimension6|275|6106|Facet/cusp injection gives275; unchanged reviewed transport combined with63 facets per five-facet gives272V>=6039F and6106 vertices. Written reviews and current conditional Lean logic/axiom audit pass.|

The preceding62/206 and269/5875 results already have conditional Lean
checks. The strongest new proof excludes the36-vertex carrier entirely:
equality forces six octahedral opposite facets, whose square cusps force
an impossible incidence between the carrier's five quadrilaterals.
The remaining opposite-facet count then contradicts its three outside
vertices. Hence each positive carrier has at least37 vertices and25
facets. No eleven-vertex three-dimensional classification or general
garland theorem is used. A separate reviewed triangle-credit proof
also gave the now superseded62/208 and271/5919 counts. The new geometry
has written independent review; its numerical consequences now have a
[successful conditional Lean batch](right_angled_eleven_vertex_counts_verification_20261019.md).
The preceding geometric theorem gives3V(P5)>=13V(Q4)+6F(Q4)
for every four-facet Q4. It uses a five-dimensional good-opposite incidence
bound and no published ideal4 classification for that geometric inequality.
Its carrier input is the earlier V(Q)>=3V(R)+3 theorem
for every three-facet R of an entirely ideal right-angled four-polytope Q.
It forces actual outside vertices with no graph-neighbor in R, using a
spinor polygon lemma and good-cusp counting. Together with the Figure7
exclusion above, it gives the stronger counts. The existing [TeX/PDF package](ideal_right_angled_six_face_constraints_reproduce.md)
now has a fully reviewed12-page consolidated manuscript with four
vector figures and a zero-warning bounded build. The old source/PDF
are preserved in byte-verified gzip archives.
The new [conditional Lean count interfaces](right_angled_cusp_capacity_verification_20261019.md)
have compiled and passed their axiom audits, including positive cusp-defect
counting, strict ideal5 counting, the5875 rounding and the updated mixed
consequences. The successor `RightAngledElevenVertexCounts` now compiles and passes
its separate axiom audit for63/211 and275/6106, including exact rounding
and the fractions4/47 and15/248. The
spinor/actual-opposite geometry, large-facet bridge and
transport are explicit premises. No new
script execution is claimed for the substitutions. The inherited [actual cusp transport](../results/ideal_ra6_cusp_transport_research_20261018.md)
and [sharp reciprocal estimate](../results/ideal_ra6_sharp_reciprocal_20261018.md)
retain their independent reviews and three serial exact replays.

In dimensions11/12 the same reviewed proof lowers the entirely ideal
five-face fraction to less than4/47, and the entirely ideal six-face
fraction to less than15/248. These are necessary incidence constraints,
not improved dimension ceilings. Existing Lean checks concern the earlier
linear consequences from explicit geometric and published premises; the
preceding2/23 and15/242 constants have their own successful conditional
Lean batch. The latest substitutions also have successful conditional Lean verification.
The [compact29 triangle
constraint](../results/fresh_compact29_three_triangle_star_constraint_20261018.md)
now excludes simultaneous designated triangles on different E7 factors at
an E7³+E8 vertex; it has no global charge saving yet.

The new [octahedral-block theorem](../results/ideal_ra5_octahedral_blocks_20261018.md)
improves the restricted ideal RA5 facet counts from30 sixteen-cell carriers
and66 doubles to36 and84. It uses exact intrinsic ridge data, an internal
Lorentz and graph argument, and the published Andrasfai–Erdos–Sos coloring
theorem. The restriction to the stated24-cell/double/particular16-cell
facet spectrum is essential. This is a facet-count improvement, not a new
dimension bound; geometric Lean verification remains pending.

The [mixed-dimension weighted-face theorem](../results/right_angled_mixed_weighted_triangles_research_20261018.md)
now forces a canonical ten-facet mixed four-face in any hypothetical
dimension11 or12 polytope. In dimension12 it requires
(1474/21)*ideal_vertices < finite_vertices < (1298/9)*ideal_vertices.
The corrected exact coefficient replay and
[independent root review](../results/review_right_angled_mixed_weighted_triangles_20261018.md)
pass. These are universal necessary conditions; they do not exclude12.
The latest [local excess argument](../results/right_angled_mixed_nu11_all_ideal_corner_exclusion_research_20261019.md)
and [maximal-ideal-degree theorem](../results/right_angled_mixed_nu12_carrier_forced_by_maximal_ideal_degree_20261019.md)
strengthen the compulsory carrier: every hypothetical dimension11/12
example has an actual three-face with facets+cusps at least12.
The new [universal error estimates](../results/right_angled_mixed_nu12_carrier_error_sharpening_research_20261019.md)
give unbacked-path error at most E12 and companion error at most2E12,
where E12 sums the three-face excess above11. No finite-edge error is
needed. All these written arguments have
[root review](../results/review_mixed_nu12_error_and_maximal_degree_root_20261019.md).
They await integration into the same mixed manuscript and have no new
Lean coverage. Their required exceptional faces may still occur; the
unconditional dimension ceiling remains12.
The [low-facet rigidity theorem](../results/right_angled_mixed_low_facet_rigidity_research_20261018.md)
also identifies P4 uniquely at four-dimensional facet-plus-cusp sum15,
and P5 uniquely among right-angled five-polytopes with16 facets. Written
proofs, exact model checks and an independent internal review pass;
these classify equality cases rather than improving a dimension ceiling.

The [complete-five-corner theorem](../results/right_angled_mixed_complete_five_corner_research_20261018.md)
gives a sharp gap: a five-polytope with a complete triangular corner is
P5 or has at least20 facets. In every other five-polytope, complete
corners occupy at most one eleventh of its finite vertices. The20-facet
double attains both bounds. The [opposition-moment proof](../results/right_angled_mixed_opposition_moments_research_20261018.md)
also gives the universal dimension12 bound2B<=1267552f/6875, where B counts
canonical three-faces, and excludes a closed complete-corner opposition
component in every dimension at least9. These have written cross-review
and exact replays, not full Lean verification. The
[TeX manuscript](../manuscripts/right_angled_mixed_corner_constraints.tex),
[proof map](right_angled_mixed_corner_constraints_map.md) and serial
five-checker package collect these results. The scalar constraints still
admit an exact numerical assignment; no12-to11 bound is claimed.

The new [small-three-face carrier theorem](../results/right_angled_mixed_small_three_face_dimension_research_20261018.md)
proves n<=8 if every three-face has facets+cusps<=10. Its actual-edge
Lorentz proof has [independent mathematical review](../results/review_right_angled_small_three_face_dimension_20261018.md)
and a fresh tiny exact replay. Consequently every hypothetical dimension9--12
example must contain a larger three-face. This conditional structural
bound is not a replacement for the unconditional mixed ceiling12;
it does not by itself give a quantitative density of exceptional faces.
The subsequent [carrier-excess theorem](../results/right_angled_mixed_carrier_excess_fraction_research_20261018.md)
now gives E>=f/5390 in dimension12, where E is the sum of the three-face
facet-plus-cusp excess above10 outside P3 and f counts finite vertices.
At least f/385 finite vertices meet an exceptional three-face. Its full
Lorentz/counting argument and178 rational interval boxes have
[independent root review and fresh replay](../results/review_right_angled_carrier_excess_fraction_20261018.md).
The fraction is still too small to exclude12. No dimension11 fraction
or geometric Lean proof is claimed.
The [actual-opposition support theorem](../results/right_angled_mixed_actual_move_support_research_20261018.md)
now has [independent written root review](../results/review_right_angled_actual_move_support_20261018.md).
Every nontrivial P3-opposition component in dimensions9--12 must reach
a corner whose bad-triangle graph is K9-free. Its symmetric-quad extension
also proves n<=8 when every edge has an ideal endpoint and every three-face
has facets+cusps<=11. The additional edge hypothesis is essential in the
present proof. These actual-move restrictions do not improve the
unconditional mixed ceiling12. No new numerical or Lean execution is
claimed for this structural packet.

The [complete next-dimension diagnostic](../results/fresh_ambient57_payment_frontier_20261018.md)
records finite maximum372 against curvature364,38 above-curvature class
maxima and41 negative terminal ideal profiles among2270. The new
[order17 repair](../results/fresh_order17_d5_alternate_half_zero_transfer_20261018.md)
retains finite372 and reduces the negative terminal count to34; its
verification/freeze record remains in that separate report. Neither proves56.
The new [large-D-guarded D17 transfer](../results/fresh_d17_node3_large_d_guard_transfer_20261018.md)
now lowers the former formal maximizer2D17+D23 from372 to370; its complete
increasing-family upper is365. After that transfer alone, the global
formal maximum stayed372 because A1+2A16+D24 was unchanged. Generation,
separate replay, an independent certificate checker and a
[root mathematical review](../results/fresh_d17_node3_large_d_guard_root_review_20261018.md)
pass. The dimension ceiling is therefore still57.
The subsequent [coupled A16 transfer](../results/fresh_a16_double_large_d_transfer_research_20261018.md)
now lowers A1+2A16+D24 from372 to363.5, below curvature364. Its complete
increasing-family upper is371; after that transfer alone,2D16+D25 still
attained global formal maximum372, and2A16+D25 cost365.5. All17 core seals,
216 interfaces in432 whole-A1 variants, later consumers and exact upper
pass, as do the independent checker and
[completed root review](../results/fresh_a16_double_large_d_root_review_20261018.md).
The ideal deficit remains34 negative terminal profiles and the dimension
ceiling remains57; one local obstruction crossing364 is not the full proof.
The subsequent [guarded D16 transfer](../results/fresh_d16_node3_rank16_large_d_guard_transfer_20261018.md)
lowers the complete formal finite maximum to371.75, attained by
A17+D16+D24. Its new coupon-family upper is359.78125. A fresh independent
checker and [root mathematical review](../results/fresh_d16_node3_guard_root_review_20261018.md)
pass, including all fourteen affected contexts and the complete top-class
refinements. The finite target is still364, and the34 negative ideal
terminal profiles are unchanged. No56 ceiling is claimed.
The [rank17 spectator extension](../results/fresh_d16_rank17_witness_root_review_20261018.md)
then lowers the complete formal maximum further to371.5, attained by
2A17+D23. Its complete new-positive-family upper is358.078125; the two
fresh top classes have maxima370.75 and371.5. Independent mathematical
review and a fresh separate checker pass. The finite target364 and34
negative ideal profiles still prevent a56 conclusion.
The [A17 inner-unit exchange](../results/fresh_a17_inner_unit_guard_root_review_20261018.md)
then lowers the complete formal finite maximum to371, with exact new
positive-family maximum370.25. Its sole decreasing consumer has a full
radical/core proof transporting the actual external witnesses. Fresh
independent geometry, domain and Bellman checks pass.
The [D16 spectator extension of the coupled A16 rule](../results/fresh_a16_d16_spectator_root_review_20261018.md)
further lowers that complete maximum to370.75, attained formally by
A16+D17+D24. The complete old/new positive families have maxima370.25
and370.5; all17 inherited physical seals and current retained outputs
compose. Root mathematical/source review and a fresh independent exact
checker pass. The finite target364 and remaining ideal deficits still
prevent a56 conclusion. These are improvements in the internal payment
rule, not new dimension ceilings or new polytope examples.
The [quarter order10 D transfer](../results/fresh_order10_d_quarter_root_review_20261018.md)
now reduces the complete terminal ideal deficit count from34 to18 while
retaining the finite maximum370.75. Its parameter-independent whole-factor
geometry,1181-class finite cover and every later positive-family overlap
have root mathematical/source review. A fresh independent checker rebuilt
all 2270 terminal h-polynomials and their normalized margins, with no zero
margin. The worst remaining margin is-17719/255552 at(10,10,10,11,15).
The subsequent [order16 epsilon extension](../results/fresh_order16_d_quarter_epsilon_root_review_20261018.md)
reduces those18 ideal deficits to8 while retaining the complete finite
maximum370.75. Its unchanged80 local maps and epsilon-independent whole
seals have a written root review; a fresh independent checker rebuilds all 2270
ideal margins and the complete606-class finite cover, including30 actual
fiber refinements. There are no zero margins; the worst is-1553/22627 at
(10,10,10,10,16). At that stage the finite target364 and these8 ideal
deficits remained open for56.
The [distal7/32 order17 transfer](../results/fresh_order17_d13_shortleaf_root_review_20261018.md)
then reduces the ideal deficit count from8 to5 while retaining370.75.
Its complete new-increase family has upper11861/32; all current later
overlaps, whole-factor seals and the fresh independent checker pass.
The [coupled-A16 rank17 spectator extension](../results/fresh_a16_rank17_spectator_root_review_20261018.md)
subsequently lowers the complete finite maximum to11861/32=370.65625,
attained formally by3D13+4A4+A2. Its actual whole rank17 witnesses persist
under all seventeen physical seals; complete new-family and old-class
refinements have root source/mathematical review and exact separate checks.
Finally the [fractional order11 local repair](../results/review_order11_fractional_cusp_closure_local_root_20261018.md)
and [complete composition](../results/review_order11_fractional_cusp_closure_composition_root_20261018.md)
close **all ideal deficits**. Every2270 terminal profile is positive;
positive low8 concentration gives absolute surplus>=43/128 at every
actual ideal vertex. A separate exact3200-class/567-fiber check and fresh
producer replay preserve the finite maximum11861/32. The old absolute
surplus36 is not reused for this new rule. The finite excess213/32 above
364 still prevents a56 conclusion. The completed ceiling remains57;
these new geometric transfers have not been fully formalized in Lean.
The [arithmetic transfer diagnostic](../results/fresh_compact21_triangle_transfer_scope_20261018.md)
shows that changing only the E7³ vertex allowance leaves one exact golden-field
dual above40; new constraints must reach other supported types or incidences.
The new [D5 quadrilateral witness and arithmetic classification](../results/fresh_compact21_d5_fork_quad_local_witness_20261018.md)
now has a [root proof/source review and fresh replay](../results/review_compact21_d5_fork_quad_local_witness_20261018.md).
It gives an exact local incidence budget linking the specified fork
quadrilateral to absence of both E8 triangle types. Subsequent complete
consumer proofs now justify an [active/inactive charge rule](../results/review_compact21_active_inactive_charge_20261018.md)
at D5+2E8, with a necessary no-half-unit interface strengthening.
Independent mathematical review and four fresh serial coefficient
replays pass. Its [exact saved-dual repair](../results/fresh_compact21_extreme_e8_priority_saved_dual_20261018.md)
lowers one old obstruction from40.02199019 to39.99277728. This is not a
primal certificate or a proof that all obstructions are below40; at that
stage the compact arithmetic ceiling was still21. The later same-hub
model below supersedes that stage with ceiling20.
The bounded support scout subsequently recovered an
[exact new obstruction](../results/fresh_compact21_priority_support_dual_repaired_20261018.md)
at40.0044790362>40. This is a verified dual lower bound for the new
supported-row model, so that charge successor still cannot prove20.
Its dominant mass lies on A1+2E8+H4. The preceding repaired old witness
below40 was not an optimum or a full feasibility certificate.
The [funded H4 transfer](../results/review_compact21_h4_funded_transfer_20261018.md)
now has a complete written geometric review and an independent exact
principal-positivity reconstruction of its1024 contact domain. An
[A5 source-incidence restriction](../results/review_compact21_a5_capacity_and_full_faces_20261018.md)
strengthens its A5 allowance from W+2t to W+t: two required reverse walls
would have positive product, contradicting acuteness. The next exact
candidate satisfies all102917 native face cases and has supported upper
39.9891842712; a fresh independently implemented checker verifies every
case. However complete forest separation rejects it, with maximum
72.2951420029 in an omitted context. A guaranteed shifted rank22 seed
likewise stays above40, at43.954. Neither is a dimension20 certificate.
The new [complete forest Bellman formulation](../results/compact21_full_forest_bellman_formulation_20261018.md)
encodes every additive forest upper and treats the two decreasing physical
forests separately. The full conservative model has now been solved and
replayed exactly: its optimum lies between40.981901703900085 and40.9819083225.
The [rational dual certificate](../results/fresh_compact21_complete_model_dual_repair_20261018.md)
checks all94706 global columns and proves that this model cannot reach the
sufficient dimension21-exclusion threshold z<=40. Its generation and fresh
solver-free replay pass; this is an obstruction to the present payment model,
not a polytope existence theorem. That payment model could not prove
ceiling20 and required additional geometry or incidence restrictions.

That last obstruction has now been overcome by a different payment model.
The new [same-hub pool rule](compact_arithmetic20_proof_map.md) gives the
**compact arithmetic ceiling20**. Normalized additions between distinct
whole A1, I2(5) or H3 factors cost one pool per vertex. The full final
contact-star proof justifies all actual local coefficients; the model
retains all native witnesses before deduplication. The exact rational
candidate has complete finite-forest maximum40. A separate implementation
checks1979 faces,102917 common-spectator cases,729 exact hub tuples and850
final forest offers; minimum quadrilateral payment is
60007431727/60000000000>1. The global h-vector argument proves total weight
at least40v+550, contradicting the upper40v. The completed streamed
composition verifies13 dimension21 field branches and24 higher branches,
with107 recursive manifests/228 files bound. Fresh solver-free replay
passes. The [full root review](../results/review_compact_arithmetic20_composition_root_20261018.md)
states inherited internal and published premises separately. This is an
internally reviewed computer-assisted proof, not external refereeing or
an end-to-end Lean theorem; no compact dimension20 example is claimed.

The successful bounded Lean root compilation and axiom audit are recorded
in the [batch execution status](proof_batch_guard_status_20261018.md).
Existing compiled dependencies were reused; no new geometric theorem was
formalized by that execution check. Mathematical research takes priority.

The construction lane now has an exact **29-wall H9 chamber of infinite
volume**, with at least87 finite vertices. Its [current execution and
negative-volume proof](../results/h19_twenty_nine_wall_completion_root_20261019.md)
records generation and separate replay,406 pairs,29 actual facets and a
new feasible spacelike escape after26 finite vertices were discovered.
The preceding28-wall chamber also has its independent negative certificate: The
[fixed checker and bounded edge walk](../scripts/check_h19_twenty_eight_wall_seed_20261019.py)
passed [generation](../results/h19_twenty_eight_wall_seed_generation_20261019.json)
and [separate replay](../results/h19_twenty_eight_wall_seed_replay_20261019.json):
all378 pairs,28 actual-facet projections, four finite vertices and all nine
initial edges check. The86 count also uses the two inherited complete
disjoint41-vertex H8 facets. Walking from other vertices then found a
feasible spacelike endpoint of square57/100-sqrt(5)/4>0, after discovering
19 finite vertices. With the strict centre this proves infinite volume.
It is a negative volume certificate, not a complete vertex census or a
new finite-volume example.

The two successive bounded contact-profile searches and the26/27-wall
predecessor checks retain their separate exact generation/replay ledgers.
Their [all-height pencil obstructions](../results/compact_h9_discriminant19_edge_pencil_obstructions_20261019.md),
[34-profile reduction](../results/compact_h9_discriminant19_edge_profile_congruences_20261019.md)
and [18-profile reduction](../results/compact_h9_discriminant19_omega3_profile_congruences_20261019.md)
explain the new mirrors without asserting all-height root completeness.
The [affine-slice criterion](../results/h19_affine_slice_edge_walk_completeness_20261019.md)
now gives a reviewed sufficient condition for an eventual complete finite
edge walk to prove compactness. The current walk stopped at an escape,
so it does not meet that condition. On the new escape edge, the
[corrected congruence proof](../results/review_h19_next_edge_long_profiles_mod19_finite57_20261019.md)
excludes all three long-root profiles, leaving eleven short profiles.
Their [bounded search source](../scripts/search_h19_next_edge_short_finite_profiles_20261019.py)
subsequently passed generation and separate replay, as recorded in the
[execution report](../results/h19_next_edge_short_finite_profiles_completion_20261019.md).
The11803 exact profile/parameter tests leave two individually compatible
mirrors. They have positive mutual product and cannot both be added.
The smaller mirror passed the fixed29-wall check and separate replay;
the new walk again proves infinite volume. The next edge has a different
white support, so a fresh contact-profile reduction is in progress. No current manuscript, geometric
Lean theorem or whole-lattice nonreflectivity conclusion is claimed.

## Ideal right-angled four-dimensional volume

These results now share one primary manuscript:
[Volumes and octahedral chains of ideal right-angled hyperbolic four-polytopes](../manuscripts/build/ideal_ra4_volume_and_structure.pdf)
([TeX](../manuscripts/ideal_ra4_volume_and_structure.tex)),16 pages and five
figures. The earlier separate papers remain supporting predecessors.

|Statement|Current result|Verification|
|---|---|---|
|Smallest volume|4π²/3, unique ideal right-angled24-cell|Published, Kolpakov2012.|
|Second distinct volume|8π²/3|Universal defect/injection proof in the unified manuscript, with the [original proof report](../results/ideal_ra4_second_volume_20261018.md) and exact double certificate as support. Two consolidation reviews and the saved arithmetic checks pass. Lean checks the conditional defect-budget and integer-gap logic.|
|Every polytope attaining the second volume|Isometric to the reflected double of the24-cell along a facet; f-vector(42,168,164,38)|The unified manuscript first forces exactly eight doubled-octahedral facets, then applies its general chain theorem. The [original equality proof](../results/ideal_ra4_second_volume_equality_20261018.md) and finite models remain support. Lean verifies the implication from the explicit written geometric premises.|
|All facets octahedra or doubled octahedra|A chain of regular24-cells, with opposite cuts in each intermediate cell|The unified manuscript gives the complete cutting/recognition/path proof once. The [original decomposition proof](../results/ideal_ra4_octahedral_block_decomposition_research_20261018.md) and exact D4 model remain support. Conditional decomposition/counting logic is kernel-verified; actual geometric cuts, recognition and gluing remain written premises.|

The successful [core execution ledger](../results/ideal_ra4_unified_core_verification_final_20261018.json)
records four exact checks and the conditional Lean modules. Its scope is
not an end-to-end formal proof of the hyperbolic geometry. The later
all-antiprism research extension is not silently part of this PDF.

The structure theorem derives the common cutting hyperplane from facet
geometry, cusp boxes and normal-vector relations. At the second volume
its application proves that both halves are24-cells. It is not inferred
from a bounded polytope census.
The [primary-literature scope audit](../results/ideal_ra4_primary_literature_scope_audit_20261018.md)
distinguishes the published pi²/3 volume formula from the stronger,
unestablished-by-this-audit4pi²/3 divisibility assertion. The internal
second-value and equality arguments assume neither stronger divisibility
nor a universal decomposition into24-cells. No such general decomposition,
or compact120-cell analogue, is claimed. The new chain theorem applies only
to its explicit octahedron/double facet spectrum. The geometric structure argument
remains internally reviewed written mathematics, not an externally reviewed
or end-to-end kernel-verified theorem.

For compact right-angled four-polytopes, the
[current manuscript and reproduction map](compact_ra4_volume_constraints_reproduce_20261019.md)
give f>=2V+5 and the stronger neighboring-excess inequality for every
facet with V vertices. They force V<=46 strictly below the regular120-cell
volume, V<=46 at that volume, and V<=96 strictly below its double.
The [neighboring-excess theorem's root review](../results/review_compact_ra4_neighbor_excess_root_20261019.md)
also checks the first positive-excess gap and zero-excess120-cell
recognition. The stronger [positive-facet-link theorem](../results/compact_ra4_positive_facet_link_gap_fifteen_20261019.md)
proved W=0 or W>=15, with [full root](../results/review_compact_ra4_positive_facet_gap_fifteen_root_20261019.md)
and [independent written review](../results/review_compact_ra4_positive_facet_link_gap_fifteen_finite57_20261019.md).
It distinguishes nonpentagonal-ridge adjacency from full positive-facet
adjacency and proves its nine-vertex graph lemma directly, without a census.
The subsequent [fifteen-excess exclusion](../results/compact_ra4_fifteen_excess_equality_exclusion_research_20261019.md)
strengthens this to **W=0 or W>=16**. Its
[full root review](../results/review_compact_ra4_fifteen_excess_exclusion_root_20261019.md)
and [independent full review](../results/review_compact_ra4_fifteen_excess_equality_exclusion_finite57_20261019.md)
pass, including the actual three-edge closure, exact hexagon lengths
and all five-neighbor link cases.
The next [sixteen-excess exclusion](../results/compact_ra4_sixteen_excess_equality_exclusion_research_20261019.md)
now gives **W=0 or W>=17**, with
[root](../results/review_compact_ra4_sixteen_excess_exclusion_root_20261019.md)
and [independent full review](../results/review_compact_ra4_sixteen_excess_exclusion_finite57_20261019.md).
It uses the unique longest edge of a lateral Loebell-L6 pentagon and
an explicit ten-vertex graph lemma. The current consolidated source
contains this W>=17 theorem with one shared proof rather than repeated
staged global arguments. The3D metric uniqueness/classification inputs
remain explicit. Its [14-page PDF](../manuscripts/build/compact_ra4_volume_constraints.pdf)
has four visually reviewed vector figures,
[two complete source reviews](../results/review_compact_ra4_volume_constraints_W17_root_20261019.md),
and a [zero-warning bounded build](../results/compact_ra4_volume_constraints_W17_build_20261019.json).
All temporary build files and raster previews were removed. The
[degree-two corollary](../results/compact_ra4_degree_two_excess_twenty_20261019.md)
gives W>=20 when the positive-ridge graph has a degree-two facet; its
[full root review](../results/review_compact_ra4_degree_two_twenty_root_20261019.md)
passes, and this lemma is integrated in the same paper. It does not
increase the unconditional17 gap.
The frozen seven-page capacity predecessor remains available and does
not contain these successor results. They remain local-size/recognition
theorems, not a universal minimum or second-volume proof, and have no
geometric Lean coverage.

See [formal coverage](../formal/README.md) for precise theorem interfaces
and [the research programme](research_programme.md) for lane ownership.
PDF compilation, Python replay and kernel checking have separate scopes.
