# Manuscripts and reproducibility

There are **six current papers** and **32 TeX files** under this directory.
The remaining files are predecessors, local notes, input fragments and
three generated atlases. One third-party TeX source elsewhere in the
repository is not one of our papers.

| Current paper | Result and method | Existing PDF |
| --- | --- | --- |
| [finite_volume57.tex](finite_volume57.tex) | General finite-volume ceiling 57; angle payments, finite forests and ideal curvature | [48 pages](build/finite_volume57.pdf): main exposition 1–12; essential appendices and table documentation 13–48;44- and41-page predecessors preserved |
| [compact_arithmetic_dimension_bound.tex](compact_arithmetic_dimension_bound.tex) | Compact arithmetic ceiling 20; field reduction, supporting stars and exact angle rules | [17 pages](build/compact_arithmetic_dimension_bound.pdf); [combined predecessor](compact_arithmetic20.tex), parked19 appendices and [20-page PDF](build/compact_arithmetic20.pdf) preserved |
| [compact_farthest_vertex_bounds.tex](compact_farthest_vertex_bounds.tex) | General compact ceiling 23; one farthest vector and component projection costs | [36 pages](build/compact_farthest_vertex_bounds.pdf), two vector figures |
| [right_angled_sharp_dimension_bounds.tex](right_angled_sharp_dimension_bounds.tex) | Sharp ceilings 8/general and 4/entirely ideal; shared projection with two short branches | [5 pages](build/right_angled_sharp_dimension_bounds.pdf) |
| [ideal_ra4_volume_and_structure_publication.tex](ideal_ra4_volume_and_structure_publication.tex) | Same volume/structure theorem, with explicit finite-model algorithms | [17 pages](build/ideal_ra4_volume_and_structure_publication.pdf), five figures; [16-page predecessor](build/ideal_ra4_volume_and_structure.pdf) preserved |
| [compact_ra4_volume_constraints.tex](compact_ra4_volume_constraints.tex) | Compact facet capacity and excess constraints; the 120-cell minimum and second volume remain open | [14 pages](build/compact_ra4_volume_constraints.pdf), four figures |

These are internal research manuscripts. An existing PDF does not imply
external review, a self-contained exposition of every imported internal
lemma, or complete geometric formalization. Per-paper verification is
recorded in the [catalogue](catalogue.json) and execution ledgers.

All six PDFs match their current sources. The
[completion receipt](../results/six_paper_pdf_completion_20261020.json)
records the actual source-bound builds. Current finite57 has48 pages,
21 underfull spacing warnings and no overflow or unresolved references.
The other five have zero warnings. [Selected finite57 pages5,16,24,25](../results/finite57_publication_delta_visual_review_20261020.json)
passed visual inspection; no all-page inspection is claimed.
The audited sources preceding
the three typography-only repairs are byte-preserved. Finite57 now also
includes the independently reviewed
[full-budget classical unit-charge bridge](../results/finite57_full_budget_bridge_repair_20261020.json),
before the first-failing-factor split. Its preceding 41-page source/PDF
are archived. The latest [bridge receipt](../results/finite57_publication_bridge_completion_20261020.json)
records two further independently accepted insertions: the current triangle
exclusions and coarse forest-screen domination. Updated source
`c300db69…ca82a0` now has its bounded-build PASS and matching PDF
`1f3c020c…`; the44-page `89bd7658…` / `ebf996a3…` pair remains archived.
The source also clarifies tight witnesses at stored positive entries and
the reachable rank-zero base. Compact23 source `2718192d…` / PDF
`39e665d8…` remains36 pages after its [correlation wording correction](../results/compact23_correlation_precision_20261020.json)
to "at most1/3"; the strict contradictory demand is unchanged.
These are proof-exposition repairs within the existing57 theorem, not a
new bound or fresh finite-enumeration result.

The finite57 full-manuscript replay has no combined PASS. Thirty of31
selected original higher-tail commands passed (65.182 seconds total,
256,278,528 B maximum RSS). The remaining tail108 obligation now has a
complete56-batch replacement replay. Its old59-second timeout remains
preserved. The original44-job full run failed at D13's1 GiB limit.
The [memory-bounded D13 replacement](../docs/finite_volume57_lemma_map.md#memory-bounded-d13-replay-contract)
has all19 parts PASS (24.408 seconds total, 184,041,472 B maximum RSS).
Its current parser fixture passed. The
[coverage receipt](../results/partitioned_replay_coverage_validation_20261020.json)
records prior validator `41f3c82b…` self-test PASS and complete D13
coverage19/19, without rerunning mathematics. The [distance9 repair](../results/distance9_symbolic_boolean_count_repair_20261020.json)
preserves its predicate. Worker `126d5fe3…` had an actual scanner-fixture
PASS (1.721s,89,882,624 B) and metadata PASS (13.832s), followed by a domains
failure after2.709s on tuple/list representation. The
[three-comparison correction](../results/review_distance9_expected_key_json_representation_fix_finite57_20261020.md)
retains all20 comparison sites and their mathematical domains. Current
worker `f5f0b470…` now has an actual [scanner-fixture PASS](../results/distance9_json_key_lists_scanner_fixture_execution_20261020.json)
for fixture `f6fd1267…` (1.732s,89,915,392 B). That parser result earns no
mathematical interval coverage. All eight current phases now actually
PASS, including384 overlap owners and949 isolation cases:2196/2196 units
in56 batches (388.008s total,159,432,704 B peak RSS). The complete108
replacement replay passes, and
prior-source passes earn no current coverage. Current coverage checker `456abc2b…`
and coordinator `cb776f59…` have metadata-only self-tests. The earlier
`abc3b918…` fixture PASS also remains history. The [current full
plan](../results/publication_shape_counting_verification_plan_20261020.json)
has123 finite57 jobs (113 script, nine Lean, one PDF); core has11.
The two added [ancestor-forest batches](../results/finite57_ancestor_forest_replay_execution_summary_20261020.json)
actually pass:8,114 tables,10,195,241 Bellman inequalities,5.106s total,
318,799,872 B maximum RSS. Full means the selected scope, rather than
regeneration of every transitive input; some ambient59–65 forest and
local-census data remain explicit finite-data inputs. No full runtime PASS or cap increase
is implied.

The seven compiled logic kernels now have62 actual axiom prints.
The [residual Bellman kernel](../formal/CoxeterProofs/ResidualBellmanCertificate.lean)
(`cd2a05a6…`) has capped compilation and eight actual axiom prints,
containing only `propext` and `Quot.sound`. It proves abstract integer-table
exactness from local certificate conditions, leaving concrete alphabet,
context, table validation and geometry as inputs. The
[logic receipt](../results/publication_logic_verification_20261020.json)
records the conditional scope; this is not a fresh concrete table replay.
The [projection/height kernel](../formal/CoxeterProofs/RightAngledProjectionHeightKernel.lean)
(`2fac8028…`) adds eight actual prints for coordinate projection, strict
wall signs, finite height descent and the scalar radial gap. Actual
incidence/facet inheritance and radial realization remain inputs; sharpRA
now selects three Lean roots and six core jobs including PDF. All six have
an actual [combined PASS](../results/right_angled_sharp_projection_height_core_verification_20261020.json),
with30 actual axiom prints across the three roots and a warning-free
temporary five-page PDF build. Repeated prints add no new declarations
to the separate seven-kernel/62-print count.
The [finite-volume tail kernel](../formal/CoxeterProofs/FiniteVolumeTailKernel.lean)
(`b8f03fd4…`) has actual compile and nine-print PASS records. It derives
the105 bounded scalar cap comparisons, payment subtraction and near/far
narrow-wall scalar contradictions; its [map](../docs/finite_volume_tail_kernel_assumptions_20261020.md)
keeps geometry and finite-data bridges explicit. The
[shape kernel](../formal/CoxeterProofs/FiniteVolume58ShapeKernel.lean)
(`40d12b57…`) compiled in0.59s and passed its0.55s nine-print audit.
It derives the uncut-edge/index bound and the841-per-extremum correction,
counted once globally, then the finite754 and377/4205 shape inequality.
Its [map](../docs/finite_volume58_shape_kernel_assumptions_20261020.md)
retains primitive incidence inputs and the uninstantiated legacy
natural-number `shapeLower` bridge. This replaces the old ambient59
standalone shape slot, preserving historical sources and evidence.
The62-print split is10 cubic,10 concentration,8 compact23,8 Bellman,
8 projection/height,9 tail,9 shape.
Current core sizes with PDF are11/10/2/6/7/1 for57/arithmetic20/compact23/
sharpRA/ideal4/compactRA4.
The [arithmetic20 field-closure audit](../results/review_compact_arithmetic20_field_closure_batch_guard_20261020.md)
passes at its declared written-proof/finite-data boundary, without any
parked19 input or new execution.

Further adversarial written reviews cover the
[sharp right-angled proof](../results/review_right_angled_sharp_fresh_adversarial_finite57_20261020.md)
and the [ideal RA4 structural chain](../results/review_ideal_ra4_structure_batch_guard_20261020.md).
The independent [sharpRA foundations](../results/review_right_angled_sharp_foundations_adversarial_20261020.md)
and [finite57 composition](../results/review_finite57_theorem_composition_adversarial_20261020.md)
audits also support the arguments at their explicit input boundaries.
They preserve the stated published/geometric inputs and add no execution claim.
Primary-source audits directly check [Musin/Kolpakov](../results/review_sharp_ra_published_inputs_ideal_branch_20261020.md),
[Vinberg and Alexandrov's mixed27 statement](../results/review_sharp_ra_published_inputs_dufour_20261020.md),
and [Khovanskii](../results/review_finite57_published_shape_inputs_20261020.md).
Dufour's full original remains unread; its consequence was checked through
the original Alexandrov source already named in the paper.

The [paper architecture](../docs/paper_architecture.md) groups the papers
by technique and identifies where their cases split. In particular, the
two angle-payment papers share an overarching principle but have different
arithmetic and cusp arguments. The compact farthest-vertex paper uses a
different method. The ideal volume and chain results already form one
paper; their three former papers are preserved supporting predecessors.

The [result–manuscript table](../docs/result_manuscript_correspondence.md)
contains the complete TeX inventory. The compact29 triangle note,
compact24/26/27 research reports, old mixed10/11 and ideal5/6 papers are
supporting history. The parked nine-field arithmetic refinement needs no
new paper or further expansion. Long generated atlases are data archives,
not publication manuscripts.

Proof-relevant scripts follow the
[mathematical algorithm contract](../docs/computational_proof_contract.md):
define the objects and algorithm, prove termination and completeness,
then state the exact computed result. Checking a saved certificate,
regenerating its domain, and proving that domain covers the geometry are
separate obligations. The
[editorial audit](../results/editorial_manuscript_inventory_and_algorithm_audit_20261020.md)
records the earlier exposition gaps; the
[source-completion record](../results/six_paper_source_completion_20261020.md)
records their integration and subsequent source audits.

Use the [serial verification guide](../docs/manuscript_verification.md)
to inspect a plan before running checks. Scientific, Lean and TeX jobs
share one exclusive lock and the resource gates in [AGENTS.md](../AGENTS.md).
Temporary build products are removed after each batch. No unbounded
parallel compilation is part of the publication workflow.
