# Reproducing the completed general finite-volume bound57

The frozen [endpoint](../results/fresh_d13_context_dimension57_20261018.md)
proves n≤57 for every finite-sided, finite-volume real hyperbolic Coxeter
polytope. The [TeX manuscript](../manuscripts/finite_volume57.tex) and
[lemma map](finite_volume57_lemma_map.md) give the proof and its precise
internal/external boundary. No arithmeticity, compactness, simple-cusp or
facet-count hypothesis is required.

## Endpoint and frozen inputs

|Artifact|JSON SHA256|
|---|---|
|[dimension57 endpoint](../results/fresh_d13_context_dimension57_20261018.json)|`c53d95690a1d6d95a642bc75443ea97b28d792a6a77abf9eb157243af6f8bee5`|
|[D13 local rule and finite closure](../results/fresh_d13_three_rank15_context_transfer_20261018.json)|`2c7d615cd38123bef20cffad68de8ab30baa91826c147a6bb084892590e8ca86`|
|[B13 endpoint repair](../results/fresh_b13_endpoint_retention_20261018.json)|`2bb463c567b393d7c95f211f8199c013bc0c34716a4dc98c98251fad7db2b2da`|
|[complete eight-obstruction predecessor](../results/fresh_d17_a16_coupled_ambient58_frontier_20261018.json)|`0fb359b3b07d6fbabb31adbf611d769f41ebe855075076301975e086055b1223`|
|[completed58 higher tail](../results/fresh_a15_d15_dimension58_20261018.json)|`60a6dbedc03b3c0690c80ab86f276e5767de786469b46468d0990e4a75d25985`|

The final binder also pins the
[low8 ideal certificate](../results/fresh_order10_low8_ambient58_frontier_20261018.json).
Every JSON's `sources` dictionary records the precise recursive inputs.
Preserve frozen sources, data and reports. Use `--verify`; do not overwrite
an expected result to conceal a mismatch.

## Smallest endpoint replay

From the repository root, use the bounded wrapper below. It supplies the
shared lock and live59-second/1GiB resource guard for these legacy
checkers, which do not acquire that lock themselves:

```sh
python3 -B scripts/run_bounded_research_check_20261018.py \
  --parent-lock -- scripts/fresh_d13_context_dimension57_20261018.py --verify
```

Expected child-checker terminal headline:

```text
PASS_COMPLETE_D13_CONTEXT_DIMENSION57_COMPOSITION dimension 57 finite 377 surplus 36 constant 4205
```

This independently checks:

* hashes and matching frozen local/count/ideal/higher-tail interfaces;
* the exact eight old obstruction forests and all six increasing forests;
* all2552 terminal profiles, each full polynomial product, exact moment,
  envelope cost and positive normalized/absolute margin;
* all28 exact low8 stop-loss certificates and the product/cost identities;
* finite curvature377, two-extrema sum841 and once-only correction4205.

It does **not** replay the historical finite DP, geometry, complete native
supporting census or all-label classifications. Those are separate proof
and validation layers, not hidden consequences of the endpoint `PASS`.

## New local geometry replay

```sh
python3 -B scripts/run_bounded_research_check_20261018.py \
  --parent-lock -- scripts/fresh_d13_three_rank15_context_transfer_20261018.py --verify
python3 -B scripts/run_bounded_research_check_20261018.py \
  --parent-lock -- scripts/fresh_b13_endpoint_retention_20261018.py --verify
```

The D13 producer recomputes the801/862 support domain and33/76 affected
cases; all white/edge/core signatures and marked component roles; the
selected four-way proof partition; exact rank15 inverse/native profiles;
two physical30-root one-sided stars;24 quiet repairs;216/564 and newer
output interfaces; and the exact finite closure. Its written arbitrary
attached-forest and universal chosen-output arguments remain mathematical
parts of the proof. Checking finite records does not replace them.

B13 separately checks its complete support and the genuine older singleton
consumers, paid by retained whole A1/D12 units. Its pair(1,12) stays present.
Both local packages and the endpoint have completed generation, separate
saved replay and full internal mathematical reviews. Reviewers' reports
explicitly separate their reading scope from computation they did not run.

## Full finite and cusp layers

The complete actual finite predecessor can be replayed separately:

```sh
python3 -B scripts/run_bounded_research_check_20261018.py \
  --parent-lock -- scripts/fresh_d17_a16_coupled_ambient58_frontier_20261018.py --verify
```

It validates the representative cover, two increasing-family bounds, all
748 actual fixed-type fibers, contextual guard splits and1549 saved
residual Bellman tables. This may take materially longer than the endpoint.
Its final eight378 forests are an exhaustive classification of the
obstructions, not merely saved maximum witnesses. The final D13/B13 step
then lowers exactly those eight to377, while all new positive guards force
six complete families below377. No new global optimization is needed.

The low8 source's full replay also checks its historical finite frontier,
so it is a broader check than needed merely to rederive the cusp rows:

```sh
python3 -B scripts/run_bounded_research_check_20261018.py \
  --parent-lock -- scripts/fresh_order10_low8_ambient58_frontier_20261018.py --verify
```

The new final endpoint already reconstructs all2552 ideal polynomial
products and28 concentration certificates independently. The written
convex-order convolution argument and actual factor-fiber interpretation
still need their own proofs. Terminal normalized positivity is essential;
negative margins cannot be multiplied through the V reduction.

The completed58 higher-tail endpoint is independently available:

```sh
python3 -B scripts/run_bounded_research_check_20261018.py \
  --parent-lock -- scripts/fresh_a15_d15_dimension58_20261018.py --verify
```

It excludes ambient59 and uses its own completed59 tail. The new proof
excludes ambient58. Neither endpoint alone is replaced by an assumption
that every desired lower-dimensional Coxeter face exists.

The current coordinated full selection also includes the contiguous
ambient59--163 layer chain and five all-rank narrow-facet leaves. Inspect
the plan before executing it:

```sh
python3 -B scripts/verify_manuscript.py finite57 --mode full --pdf --plan
```

The [43-job plan](../results/finite57_full_replay_tail_plan_20261020.json)
is source configuration, not a fresh successful replay. It schedules
36 script checks, six existing conditional Lean roots and one temporary
PDF build serially. The [interface audit](../results/review_six_manuscript_verification_interfaces_resource_20261020.md)
lists each leaf and the exact finite inputs it rechecks. No dependency
is automatically regenerated merely because its hash appears in another
checker's source map. The short core selection is unchanged.

## Compact arithmetic boundary for an independent checker

The new finite closure data are in the D13 certificate's `finite` object:

* `all_old_costly_forests`: all eight B13/D13 plus three A15/D15 choices,
  with old378 and new377;
* `complete_increasing_families`: all six D28+two-rank15 or
  A12+D16+two-rank15 forests, with exact old/increment/new costs;
* the exhaustive predecessor count stem and the unchanged ideal interface.

The source's context delta uses integer units1/64:

```text
−64 * d13                          if a15+d15 ≥ 3
+32 * d28 +64 * a12*d16            if a15+d15 ≥ 2.
```

These inequalities occur only in the rank58 domain; the local theorem
requires distinct whole witness components. The B13 endpoint decrease is
already in the imported `Z.value`. A checker must prove the rank-capacity
family classification and pointwise complement, not merely add six numbers.
The preceding count's completeness is a separate internal theorem.

The ideal JSON has2552 rows of rank lists,58 integer coefficients, V,G,
exact rational envelope/margins and the complete normalized envelope array.
An independent checker must enumerate the domain and multiply each factor
polynomial. Symmetry and coefficient sum alone are insufficient. The final
source performs those products directly using Python integers/Fractions.

The Lean development is tracked in [formal/README.md](../formal/README.md).
The arithmetic interfaces are suitable for kernel checks, but complete
geometry, every historical route and the higher tail must also be connected.
No end-to-end Lean verification of57 is asserted by this guide.

## Building the manuscript

The source is [finite_volume57.tex](../manuscripts/finite_volume57.tex).
For an existing build directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=/path/to/build manuscripts/finite_volume57.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=/path/to/build manuscripts/finite_volume57.tex
```

Two passes resolve cross-references. The delivered PDF is a formatting
artifact; successful compilation is not a mathematical proof check. The
manuscript gives the new universal local arguments and explicit internal
certificate interfaces, with primary published assumptions listed separately.
It does not claim external refereeing, novelty or optimality.

## Final contradiction

```text
D5 ≤ 377 vf + sum C_actual
D5 ≥ 377 vf + sum kappa + 4205
kappa − C_actual ≥ 36
therefore 0 ≥ 4205 + 36 vi > 0.
```

The finite equality is sufficient, including vi=0. The global4205 term is
counted once. The completed58 tail handles dimensions≥59. This is the
completed57 theorem, distinct from any future search for56 or construction
of a new finite-volume polytope.
