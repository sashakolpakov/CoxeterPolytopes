# Results and manuscripts

Inventory updated 21 October 2026. The machine-readable counterpart is
[manuscripts/catalogue.json](../manuscripts/catalogue.json). It assigns
each result one primary manuscript, records supporting sources, and gives
solver-free verification commands. This inventory used source reads,
path checks and PDF page-tree metadata initially. Subsequent actual
ideal4 TeX, script and conditional Lean runs are recorded below with
their execution ledgers; an inventory entry alone is not verification.

The source directory includes current primary papers, supporting notes,
preserved predecessors, generated proof atlases, an input fragment and an
external reference. These are not separate claimed publications. The
table below identifies the current paper families; frozen predecessors
remain intact when a successor is prepared.

There are **six current papers** and **33 repository-owned TeX files**
under `manuscripts/`. The additional third-party TeX under `data/external/`
is not one of our papers. The [paper architecture](paper_architecture.md)
explains the division by method and where each argument separates into
cases. The [computational proof contract](computational_proof_contract.md)
specifies the required algorithm, termination, coverage and exact-output
statements; it is a common editorial supplement, not a seventh paper.
The [current finishing checkpoint](../results/six_paper_finishing_checkpoint_20261021.json)
binds the six current source/PDF pairs; earlier completion receipts remain
preserved with their original source and execution scopes.

The nine-field ceiling19 package is preserved, but further field-specific
casework, manuscript expansion and Lean coverage are parked. Current
research prioritizes materially smaller uniform ceilings and a compact
dimension9 example. New structural observations remain short research
notes until they contribute to a dimension or unrestricted volume result.

## Current primary results

|Result|Primary home|Supporting manuscripts and precise scope|
|---|---|---|
|General finite-volume Coxeter dimension at most57|[finite_volume57.tex](../manuscripts/finite_volume57.tex)|Complete source including the higher-dimensional tail, at its declared finite-input boundary. The earlier [full audit](../results/review_finite_volume57_full_resource_20261020.md), [classical bridge repair](../results/finite57_full_budget_bridge_repair_20261020.json) and accepted [triangle/coarse-screen bridges](../results/finite57_publication_bridge_completion_20261020.json) supply the written audit chain. The current [48-page PDF](../manuscripts/build/finite_volume57.pdf) matches its source: main exposition pp.1–12 and essential appendices pp.13–48;44- and41-page phases and old58 remain preserved. No new dimension bound follows.|
|General compact Coxeter: current written ceiling20; completed manuscript23|[Same canonical TeX](../manuscripts/compact_farthest_vertex_bounds.tex), [completed-stage proof map](compact_farthest_vertex_bounds_proof_map_20261020.md)|The [complete new global composition](../results/compact20_and_all_field_arithmetic19_global_composition_candidate_20261021.md) has full root and outside-author written PASS, including the last whole D21 exclusion. The finished [36-page PDF](../manuscripts/build/compact_farthest_vertex_bounds.pdf) and compiled accounting kernel retain23; integration and new formal coverage remain pending. No additional paper is created.|
|Compact arithmetic first-type Coxeter: current all-field written ceiling19; completed manuscript20|[Same arithmetic TeX](../manuscripts/compact_arithmetic_dimension_bound.tex)|The same complete composition has full root/outside-author written PASS over every actual admissible ground field, independently of any finite field list or parked nine-field19 argument. Actual-field cap packing and the whole A20/D20 exclusions complete the dimension20 forest exhaustion. The [17-page zero-warning PDF](../manuscripts/build/compact_arithmetic_dimension_bound.pdf) retains the universal20 proof; integration and new formal coverage are pending. Parked sources/PDFs/evidence remain preserved.|
|Published ideal RA4 minimum; second-volume gap and equality; restricted Oct/D chains|[ideal_ra4_volume_and_structure_publication.tex](../manuscripts/ideal_ra4_volume_and_structure_publication.tex), [proof map](ideal_ra4_volume_and_structure_proof_map.md)|One paper, five figures and a [fresh full source audit PASS](../results/review_ideal_ra4_publication_full_finite57_20261020.md). Fixed-model algorithm/completeness exposition added; [17-page current PDF](../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf) compiles without warnings. Verified16-page predecessor preserved. The published minimum is an external input; equality forces the Oct/D spectrum before the chain theorem identifies the double. No arbitrary decomposition asserted.|
|Right-angled dimension at most8 universally, and at most4 if entirely ideal; both sharp|[One five-page paper](../manuscripts/build/right_angled_sharp_dimension_bounds_publication.pdf), [TeX](../manuscripts/right_angled_sharp_dimension_bounds_publication.tex), [proof/reproduction map](right_angled_sharp_dimensions_publication_proof_map_20261021.md)|Shared finite projection, own cubic tensor-square bound for general8, and Musin/Kolpakov for ideal4. Full root/two independent proof and manuscript reviews pass. The [preserved four-job core run](../results/right_angled_sharp_core_verification_20261020.json) passes two exact scripts, conditional `RightAngledSharpDimensions` with12-theorem axiom audit and a temporary PDF build. The cubic kernel adds ten actual axiom prints and projection/height adds eight; the current core selection has six jobs with PDF. Zero warnings, one visually reviewed figure. Coordinate/tensor inputs and actual geometry remain explicit Lean premises. Old ideal4/mixed10/ideal5–6 size papers are preserved supporting history.|
|Compact RA4 volume constraints|[compact_ra4_volume_constraints.tex](../manuscripts/compact_ra4_volume_constraints.tex), [14-page PDF](../manuscripts/build/compact_ra4_volume_constraints.pdf), [proof/reproduction map](compact_ra4_volume_constraints_reproduce_20261019.md)|One paper contains the complete capacity proof,46/46/96 cutoffs,W=0 recognition,W=0 or W>=17,and degree-two=>W>=20. Two complete manuscript reviews,zero-warning build and four vector-figure visual reviews pass. The frozen seven-page predecessor and earlier source/PDF archives are preserved. No universal120-cell minimum or second-volume gap is claimed.|

The sharpRA paper now also has a current
[six-job combined execution PASS](../results/right_angled_sharp_projection_height_core_verification_20261020.json):
two exact checks, all three selected conditional Lean roots and a
warning-free temporary five-page PDF build. Its
[30 actual printed declarations](../results/right_angled_sharp_projection_height_core_axiom_validation_20261020.json)
match the source printer lists and use only the standard axioms. The
separate seven-kernel/62-print count is unchanged by these repeated audits.

The [latest reviewed supporting batch](../results/compact21_frontier_and_arithmetic_a_packing_acceptance_20261021.json)
belongs to these same two compact papers: the general paper owns the
shared farthest-vector geometry, proper B/D continuation and whole B21
theorem; the arithmetic paper owns the shifted norm restriction, whole
B20 theorem and golden A cap-packing/A18--A19 consumers, citing that
shared geometry. No additional TeX paper is created. The new results
have written root/separate-agent reviews; the six PDFs and selected
Lean snapshots remain unchanged and the ceilings remain57/21/20.

The [latest acceptance](../results/compact20_arithmetic19_written_acceptance_20261021.json)
places both new compact results in those SAME two homes. The general
paper owns the rank-uniform A arguments, actual-foot/prefix construction
and whole D21 exclusion. The arithmetic paper adds restrictions on actual
field-valued caps, their packing and the whole D20 exclusion, with the
shared geometric statements clearly identified. Their proofs should be
integrated by method, not appended as successive proofs of23,22,21,20
and19. The older compact21/wholeA20/A-packing receipts remain provenance.

The [summed-foot kernel](summed_actual_foot_kernel_assumptions_20261021.md)
is shared finite-coordinate logic: bounded compilation and ten actual
axiom prints pass, while the concrete geometry and reference estimates
remain inputs. The six PDFs and older seven-kernel receipt are unchanged;
the combined supporting count is eight kernels/72 distinct declarations.
The new20/19 theorems are written mathematical results awaiting TeX
integration and selected formalization, not newly completed PDFs.

The catalogue's `results` array separates published inputs, new repository
results, conditional statements and drafts. “New repository” describes
the repository's proof status; it does not assert worldwide priority,
external refereeing, or complete formalization. Statements involving
hypothetical rank21 compact arithmetic vertices remain valid local
implications even though the new universal20 theorem excludes such a
polytope.

The nine actual fields are Q(sqrt3),Q(sqrt6),K7,K9,K11,K15,K16,K20,K24,
where Km=Q(2cos(2pi/m)) and K24=Q(sqrt2,sqrt3). Those were field-specific improvements at the preserved universal20
checkpoint. The new independent all-field first-type ceiling is19,
including Q(sqrt2),Q(sqrt5),Q(sqrt2,sqrt5); none of the parked casework
is needed by its proof.
The uniform published comparison for the nine-field subclass is29.
The published21 comparison applies only to the original eight fields:
the dimension-at-least22 field restriction still permits K7. The K7
[composition](../results/compact_arithmetic_k7_dimension19_charge_composition_20261020.md),
SHA256 `e6a28d7e12013be9431b4e9add5bd9b243ea8fed4da59fa82f9955d9038c9f65`,
has full [root](../results/review_k7_dimension19_charge_composition_root_20261020.md)
and [independent](../results/review_k7_dimension19_charge_composition_resource_20261020.md)
written reviews. Its conditional kernel source is
[`ArithmeticK7Field19.lean`](../formal/CoxeterProofs/ArithmeticK7Field19.lean),
SHA256 `08f1398fd3d80b5176bb4e8f59d844ddd9a9e6f8beae089716f9d92230d4fad6`.
The six-theorem axiom audit checks budget and final-count logic; actual
geometry, field interpretation and complete forest coverage remain premises.
The [preserved combined eleven-job compact core](../results/compact20_nine_field_core_verification_final_20261020.json)
passes three script checks,seven Lean roots and the76-input temporary
PDF build, preserving the published20-page PDF unchanged. The old
ten-job universal20 ledger remains historical evidence for its own scope.

## Reviewed research and integration history

Some proofs below remain research reports; others record intermediate
or predecessor stages of a current paper, including the18--20 October2026
integration phases. Their recorded statuses below are historical unless
explicitly identified as current. The primary-results table above
identifies current scope. A planned manuscript home does not mean
that its existing TeX or Lean interface contains every supporting result.
Keep the source-bound ideal4 verification
valid for the preserved16-page edition; integrate any extension in a separately
checked revision instead of silently enlarging its scope.

|Result and current complete proof|Manuscript destination|Current verification|
|---|---|---|
|[Uniform A half/five-sevenths](../results/compact_large_an_actual_projection_five_sevenths_20261020.md), [generic B/D prefix](../results/compact_classical_generic_prefix_energy_20261020.md) and [compact24 composition](../results/compact_dimension24_farthest_forest_composition_20261020.md)|The single canonical compact farthest-vertex paper in preparation; the full proof map above identifies all companion propositions.|Full root and separate-agent written mathematical PASS. These establish the intermediate ceiling24, now superseded by23. Source-integrity replay checks bytes only; new Lean and PDF compilation are pending.|
|[A5--A7](../results/compact_universal_a7_two_end_actual_projection_20261020.md), [B5--B8](../results/compact_b5_b8_ordinary_component_energy_20261020.md) and [forest aggregation](../results/compact_forest_ordinary_a_parameter_and_dominant_classical_frontier_20261020.md)|The same farthest-vertex packet, now supporting the new global24 manuscript. These component lemmas are not additional publication manuscripts.|Complete root/separate-agent written PASS, including the ordinary-rate premise and exceptional debits. The M7 frontier was a predecessor. A7's sign error was repaired before acceptance; A8 now also has both full reviews. No new scientific or Lean job.|
|[D24--D29 component exclusion](../results/compact_dn_large_components_short_tail_transfer_20261020.md)|The same farthest-vertex supporting packet. The two averaged actual-foot lemmas are part of this proof, not additional manuscripts.|Full root/separate-agent mathematical PASS; complete arbitrary-spectator inventories, noncircular strong5 bootstrap and exact prefix closure. The necessary A5--A20 or B5--B22 alternative is superseded by the A8--A20 frontier above. The restricted no-large-A/B class gets28; no unconditional ambient improvement, scientific job, new primary TeX or Lean.|
|[A21--29 component transfer](../results/compact_an_large_components_arbitrary_spectator_transfer_20261020.md), [B23--29 component transfer](../results/compact_bn_large_components_arbitrary_spectator_transfer_20261020.md) and [localized B9/14](../results/compact_bn_actual_projection_nine_fourteenths_20261020.md)|The existing farthest-vertex supporting packet; these are lemmas and transfer interfaces, not new publication manuscripts.|Full root/separate-agent written PASS, arbitrary spectators retained. Every weak cap is proved Q0 before the actual whole-rank certificate is transferred. Localized B applies at every rank>=9, including r9 F4. No new ambient ceiling, scientific execution, primary TeX or Lean.|
|[Golden k4 norm319 host closure](../results/compact_h9_golden_k4_transverse_edge_and_period_candidate_20261020.md)|The existing Bugaenko-facet/binary construction packet; no new primary manuscript.|Full root/separate-agent PAPER PASS, including independent hand recomputation of all58 scalar entries, both square-norm false positives, actual germs and native integral period trace158+245phi. Executable reproduction and Lean pending. All-k polynomial upper is separate from firstness; no new example, ceiling or whole-class exclusion.|
|[Uniform actual D projection>9/14 and five-rank remainder](../results/compact_dn_actual_projection_nine_fourteenths_20261020.md)|Same farthest-vertex supporting packet. The low-index inventories, native7 dual-foot proof and fixed rational certificate are dependencies, not additional manuscripts.|Complete root/outside-author assembly and local-input reviews PASS. Every D_r,r>=9 at a farthest vertex has actual projection norm squared>9/14. In n>=15 without large A/B, the unique D has rank>=max(10,n-5), spectators<=5. Geometry of the actual feasible points is explicit; this is not an edge-only H_K theorem. No global ceiling, scientific job, primary TeX or new Lean.|
|[Whole B_n short-tail exclusion, n>=23](../results/compact_whole_b_short_tail_extension_20261020.md)|Same farthest-vertex research packet; the accepted n>=26 predecessor is unchanged.|Preserved reviewed whole-vertex predecessor. The arbitrary-spectator successor above now transfers its complete certificate. Smaller ranks and the ambient ceiling remain open; no new primary manuscript or formal batch.|
|[Three low-index D profiles](../results/compact_dn_low_index_three_profile_farthest_obstruction_20261020.md)|Same farthest-vertex supporting packet; input to the new uniform9/14 theorem, with no new primary manuscript.|Full root/outside-author written PASS. Actual projection norm squared>9/14 for the three named common2/3 profiles in every D_r,r>=9. The negative-core4+3 case is explicitly stronger than edge-only constraints. No new jobs or Lean.|
|[Growing golden-family base collar and k<=2268 cutoff](../results/golden_e8_binary_family_discriminant_collar_and_finite_cutoff_20261020.md)|Same binary-construction supporting packet; short geometric/analytic reduction.|Full root/outside-author written PASS, with published spectral/conformal inputs explicit and the full chamber-stabilizer factor retained. Excludes k>=2269; other members remain open except earlier closed hosts. No host enumeration, new example, dimension ceiling, primary manuscript or Lean.|
|[Uniform first binary edge of the golden family](../results/golden_e8_binary_family_uniform_first_edge_20261020.md)|Same binary-construction supporting packet; no additional primary manuscript.|Full root/outside-author written PASS. Every k>=-1 and every primitive divisor norm is covered; the endpoint is an actual full E8+A1(c) germ. No factor/Pell enumeration, scientific job or new Lean. Other edges and uniform nonreflectivity remain open.|
|[Uniform full Bugaenko base throughout the unit-coupled golden family](../results/golden_e8_binary_family_full_base_facet_20261020.md)|Same binary-construction supporting packet; short paper proof, no additional publication manuscript.|Full root and outside-author written PASS. All k>=-1, all primitive divisor exponents, nonnative angles and repeated factors are covered. One actual chamber involution is obtained. Transverse-edge completeness and uniform nonreflectivity remain open; no new example, ceiling, job or Lean.|
|[Uniform D_r energy and six-rank spectator frontier](../results/compact_dn_uniform_energy_and_chain_relaxation_20261020.md)|Same farthest-vertex supporting packet; no additional paper or formal batch.|Complete root successor and outside-author common-opposite reviews PASS. E_Dr>4/7 for all r>=8; at most one large D. With n>=15 and no A/B rank>=5, its rank is at least max(9,n-6), with at most six spectator ranks. Native low-index profiles remain; no ambient ceiling.|
|[Whole B_n farthest vertices excluded for n>=26](../results/compact_whole_b_bulk_weak_packet_and_endpoint_pressure_20261020.md)|Same farthest-vertex supporting packet, reusing actual-cap and positive-dual inputs.|Full root and outside-author written PASS. No arithmetic assumption; The component successor above now covers B23--29 with arbitrary spectators; B21--B22 remain open. No changed ceiling, new primary manuscript, scientific job or Lean.|
|[Golden norm31 H9 nonreflectivity](compact_h9_golden31_reproduce_20261020.md)|Existing Bugaenko-facet/binary construction packet; short proof and reproducibility guide, no new primary TeX.|Full root/outside-author mathematical and final code reviews PASS. Fixed generation/fresh replay:0.737s,57,999,360B peak;18-input frozen packet. Closes this literal host only, with no new example, ceiling, family-wide exclusion or geometric Lean instance.|
|[C28 regular-pentagon exclusion and compact RA4 successor](compact_ra4_c28_successor_reproduce_20261020.md)|Current supporting successor to the same compact RA4 paper; the frozen14-page primary TeX and C26 packet remain unchanged.|Full root/outside-author written PASS; reviewed fixed generation/fresh replay PASS:0.135s,56,754,176B peak,29,156-byte certificate. Current bounds f>=65 and Vol>=49pi^2/6; uniform D for W<=37. Primary count-two classification and actual metric uniqueness remain explicit inputs. No120-cell minimum, new manuscript, Lean or TeX.|
|[C26 regular-pentagon exclusion and compact RA4 successor](compact_ra4_c26_successor_reproduce_20261020.md)|Supporting successor to the existing compact RA4 volume paper; its frozen14-page TeX is unchanged.|Full root written proof/checker review PASS; fixed generation/fresh replay PASS:0.131s,56,033,280B peak,9626-byte certificate. Gives f>=61 and Vol>=47pi^2/6 universally; stronger charge and W<=33 reduction are written consequences. Fullerene uniqueness and actual Andreev symmetry remain explicit inputs. No120-cell minimum, second volume or new Lean/TeX.|
|[D7/D8 component energies](../results/compact_d8_three_direction_component_energy_20261020.md)|Same farthest-vertex research packet; no additional manuscript or formal batch.|Complete independent written audits pass, with [root forest composition](../results/review_compact_d8_forest_composition_root_20261020.md). E_D7>1/2 and E_D8>4/7 hold with arbitrary spectators. The n>=15 frontier is now A/B rank>=5 or D rank>=9; no ambient ceiling.|
|[Whole A21--A29 plateau transfer](../results/compact_whole_an_geometric_a21_plateau_transfer_20261020.md)|Same farthest-vertex research packet; reuses A21 certificates without per-rank manuscripts or tables.|Complete [root](../results/review_compact_whole_an_plateau_transfer_root_20261020.md) and [outside-author](../results/review_compact_whole_an_a21_plateau_transfer_resource_20261020.md) written PASS. No arithmeticity; no arbitrary spectators, global ceiling, execution or Lean.|
|[Extended-D4 component energies and restricted forests](../results/compact_universal_e6_e7_e8_component_energy_20261020.md)|Same farthest-vertex research packet; no standalone manuscript or Lean expansion.|Full [independent root written review](../results/review_universal_extended_d4_component_energy_root_20261020.md) PASS. Adds D5,D6,E6,E7,E8 with arbitrary spectators; in n>=15 a farthest vertex must contain A/B rank>=5 or D rank>=7. Lanner order<=5 is an explicit published input. No ambient ceiling or execution.|
|[Whole A21 farthest-vertex exclusion](../results/compact_whole_a21_farthest_vertex_exclusion_candidate_20261020.md)|Same farthest-vertex packet; adjacent weak far-m/simple3 and dotted-only notes are dependencies, not additional manuscripts.|Complete [root](../results/review_compact_whole_a21_farthest_vertex_root_20261020.md) and [outside-author](../results/review_compact_whole_a21_farthest_vertex_batch_guard_20261020.md) written reviews PASS. The whole-A21 conclusion now includes complete central coverage and exact energy assembly, without arithmeticity. Spectators, higher A ranks and a global dimension ceiling remain open. No new worker, TeX or Lean.|
|[Whole-D_n isolated long-end5, every compatible lattice](../results/golden_dn_long_end_five_invariant_lattices_20261020.md)|Supporting compact arithmetic-bound research; no standalone manuscript or Lean expansion.|Full [outside-author mathematical review](../results/review_golden_dn_long_end_five_invariant_lattices_resource_20261020.md) PASS. Complete fourfold sandwich, both parities and odd deep lifts recover the standard golden lattice, before the explicit published cutoff. Excludes the specified actual profile for n>=8; no new uniform ceiling or spectator extension.|
|[Compact RA4 global low-excess charge](../results/compact_ra4_global_low_excess_charge_20261020.md)|Successor supporting the existing compact RA4 paper; the frozen14-page primary source is unchanged.|Full [root written review](../results/review_compact_ra4_global_low_excess_charge_root_20261020.md) PASS relative to pinned inputs. Universal f>=57 and Vol>=15pi^2/2; Nu>=f-2W+N2. Separating H2 remains an unresolved low-volume branch. No unrestricted120-cell minimum, new script/Lean coverage or additional manuscript.|
|[Quartic order-exchange obstruction, every literal N_n for n>=8](quartic_order_exchange_reproduce_20261020.md)|Short construction-research proof and reproduction guide; no standalone TeX manuscript or new Lean instance.|Full root/outside-author mathematical review and separately reviewed fixed checker PASS. Generation/fresh replay:0.215s,56,311,808B peak. Two FULL rank-two faces and actual oriented germs produce an integral infinite-order chamber period. Explicit arithmetic input gives noncofiniteness. No uniform ceiling, new example or commensurability-class exclusion.|
|[Golden whole-B_n isolated-five contacts at nodes1 and5](../results/golden_b_isolated_five_invariant_lattice_interface_20261020.md)|Short supporting uniform-bound lemma; no standalone manuscript or Lean expansion.|Full root/outside-author written PASS. Every compatible invariant lattice has exactly the standard literal lattice's orthogonal group; an explicit published cutoff excludes these two positions for n>=8. Other positions and the global ceiling remain open.|
|[Ramified silver published-cutoff closure, every n>=8](../results/ramified_silver_uniform_published_facet_closure_20261020.md)|Same silver research packet and catalogue entry; no additional manuscript, checker or Lean expansion.|Full [outside-author composition audit](../results/review_ramified_silver_uniform_published_facet_closure_resource_20261020.md) PASS. Uniform firstness includes n8/B7; the exact integral full facet and published L_(n-1) cutoff give noncofiniteness with explicit arithmetic inputs. M9 is closed. The earlier n>=10 bridge, M9 edges and finite L8 involution remain history. No arbitrary node2 lattice exclusion, class exclusion or uniform ceiling.|
|[Arithmetic B_n isolated-eight stars at nodes1 and3](../results/silver_long_end_eight_arithmetic_vertex_exclusion_20261020.md), with [node3 extension](../results/silver_b_node_three_triple_cap_lattice_extension_20261020.md)|Part of the silver-family research packet, reusing its literal-family obstruction. No extra TeX manuscript or Lean expansion.|Complete invariant-lattice flags, every dyadic lift, full-rank field/lattice normalization and even-neighbor mirror-SUBSET proof pass root and [outside-author composition review](../results/review_silver_b_invariant_lattices_and_star_applications_resource_20261020.md). These specified stars are excluded in compact arithmetic first-type dimension n>=9 for every compatible lattice. Node2 and other labels remain open; no uniform ceiling.|
|[Opposite walls respect orthogonal components](../results/compact_farthest_vertex_orthogonal_component_opposite_obstruction_20261020.md)|A short common lemma for the farthest-vertex research package; no standalone manuscript or Lean expansion.|Full source audits and a separate outside-author review pass. One actual wall cannot close edges from different finite components at the selected farthest vertex. No arithmetic or one-contact hypothesis; no dimension ceiling by itself.|
|[Actual mixed-wall replacements](../results/compact_farthest_vertex_mixed_replacement_inequalities_20261020.md)|Part of the existing farthest-vertex research package. No additional manuscript, script or Lean expansion.|Full [root](../results/review_farthest_mixed_replacements_root_20261020.md) and [outside-author](../results/review_farthest_mixed_replacement_resource_20261020.md) written PASS. Positive acute projection supplies actual finite replacements and new weighted inequalities, rejecting the former formal B20 witness. Full-rank finite-target comparisons extend to multicusp polytopes with finite vertices. Adequate coverage and ideal targets remain open; no numerical ceiling.|
|[Golden dyadic literal-family obstruction](golden_dyadic_family_nonreflectivity_reproduce_20261020.md)|One closed research packet, retaining the existing catalogue id and original25-file M6 freeze/guide as unchanged predecessors. No additional primary manuscript, TeX or Lean expansion.|Full root/outside-author mathematical/source PASS and actual fixed generation/fresh replay PASS:108 tests,1.031s,58,507,264B peak. Trace10+11phi gives infinitely many full-reflection-group cosets for R5; exact full coordinate facets and explicit arithmetic lattice inputs close EVERY literal R_n,n>=5. Actual geometry remains written proof; no uniform ceiling or similarity/commensurability-class exclusion.|
|[Ramified cubic-seven diagonal family, every n>=3](cubic7_ramified_diagonal_family_reproduce_20261020.md)|One short uniform proof importing its complete norm/facet and two-edge calculations. Supporting research packet only; no additional primary TeX manuscript or Lean expansion.|Complete root and separate adversarial written PASS. The dyadic full-A3 obstruction and incompatible involutions settle the literal family without computing a first Pell unit. Explicit external arithmetic theorem for noncofiniteness. No checker execution, new example or uniform dimension ceiling.|
|[Published odd silver diagonal cutoff, every m>=7](../results/ramified_silver_uniform_published_facet_closure_20261020.md)|One existing silver research packet. The old [n>=9 guide](odd_silver_diagonal_family_reproduce_20261020.md) and38-input freeze remain unchanged predecessors; no additional TeX manuscript or Lean expansion.|Exact literal iff cutoff checked in Allcock Section2 p.740, attributed to Bugaenko[4], with [outside composition review](../results/review_ramified_silver_uniform_published_facet_closure_resource_20261020.md). The older stable-isometry proof and local-algebra generation/replay remain valid support, not the source of the stronger published cutoff. No new execution, uniform ceiling or class exclusion.|
|[Complete rank-at-most-four farthest forests](../results/compact_farthest_rank_four_forest_exclusion_20261020.md), with the earlier [energy](../results/compact_farthest_vertex_energy_obstruction_20261020.md) and component notes|Supporting research for a future material compact bound; no additional manuscript or Lean expansion. One combined proof uses the reviewed small-A, B/D/F and H component arguments, plus a universal dihedral floor. Earlier sources remain preserved.|Full [root](../results/review_farthest_rank_four_forest_root_20261020.md) and [outside-author](../results/review_farthest_rank_four_forest_finite57_20261020.md) audits pass. Every whole forest of irreducible finite components of rank at most4 is excluded at the farthest vertex in n>=15. Larger A,B,D,E factors remain; no uniform dimension ceiling follows.|
|[Bugaenko-facet binary reduction and uniform E8 collar](../results/bugaenko_facet_binary_extension_and_collar_audit_20261020.md), with [volume-bridge addendum](../results/bugaenko_facet_full_reflection_volume_bridge_addendum_20261020.md)|Short structural research record; no additional primary paper, TeX build or Lean expansion. Use only if a material bound or construction results.|[Root](../results/review_binary_extension_collar_root_20261020.md) and [independent](../results/review_bugaenko_facet_binary_collar_batch_guard_20261020.md) reviews pass. The analytic addendum also has root/independent reviews. Two glue forms, uniform collar, actual-edge estimates and a finite but impractical normalized reduction; no family exclusion, new example or dimension ceiling.|
|[Compact RA4: uniform outgoing-edge center-cut volume cost](../results/compact_ra4_uniform_outgoing_center_cut_volume_cost_20261020.md)|Short research theorem sharing the existing compact RA4 paper's capacity and excess foundations. Earlier fixed/central editions remain support; no additional manuscript or build.|[Complete independent root review](../results/review_compact_ra4_uniform_outgoing_center_cut_root_20261020.md) passes. With twenty regular outgoing lengths, every center-cutting wall, including off-center ones, forces volume>=23pi^2/2. Low volume implies only interior containment of the matched center; universal minimality remains open.|
|[Compact RA4: irregular-facet count](../results/compact_ra4_irregular_outgoing_facet_excess_count_20261020.md) and [regular-inball volume comparison](../results/compact_ra4_regular_inball_volume_comparison_20261020.md)|Supporting geometric lemmas for the existing compact RA4 paper if a universal volume result follows. No additional manuscript or build.|Full independent root reviews pass for both notes. They prove3*N_irregular<=4W and a sharp volume bound under a regular-inball hypothesis. The missing global inball/low-excess reduction remains explicit; unrestricted minimality and all dimension ceilings are unchanged. No Lean or execution.|
|[Compact RA4: uniform-neighbor dodecahedral blocks](../results/compact_ra4_uniform_dodecahedron_neighbor_block_20261020.md)|One supporting structural theorem in the existing compact RA4 research packet; no extra primary manuscript or build.|Full root and independent outside-author written PASS. Each neighbor of a uniform dodecahedral facet is D or has at least30 vertices; equality is the intrinsic D double. Whole-block containment and the cut are proved. Global120-cell minimum/second-volume structure remain open; no execution or Lean.|
|[Nonreflectivity of the literal discriminant19 H9 host](compact_h9_discriminant19_reproduce_20261020.md)|One complete edge/period proof, one fixed checker and reproducibility note. No additional TeX manuscript; reuse shared ChamberPeriod logic.|Full root and independent mathematical/source reviews; generation and separate replay PASS;25-input packet frozen. The complete H8 Vinberg calibration is inherited explicitly. Integral chamber period has trace10+14phi>10. Actual geometry remains outside the conditional final Lean logic. No uniform bound or new example.|
|[Nonreflectivity of the literal quadratic13 H9 host](compact_h9_sqrt13_reproduce_20261020.md)|Four complete edges and a short closure, with three fixed workers and one reproducibility note. No additional TeX manuscript; reuse shared ChamberPeriod logic.|Root and independent full mathematical/source reviews pass. Three workers have bounded generation and separate replay PASS;33-input immutable packet. Integral full-chamber period has trace268eta+80>10. Conditional Lean checks final group/coset logic only. No new example, uniform ceiling or whole commensurability-class exclusion.|
|[Nonreflectivity of the literal golden discriminant59 H9 host](compact_h9_golden_discriminant59_reproduce_20261020.md)|Short closure proof, exact workers and reproducibility note; no additional TeX manuscript. The later shared [ChamberPeriod module](chamber_period_logic_verification_20261020.md) checks the final group-theoretic logic conditionally.|Actual Bugaenko facet, complete E8+c and D7+c edges, full integral period, trace40+55phi and full-chamber/coset logic pass root and independent written reviews. Both workers have capped generation and separate replay PASS. Actual group/geometric/real-trace interpretations remain explicit Lean premises. No new dimension example, ceiling or whole commensurability-class exclusion.|
|[Metric Coxeter facets: parent-wall rigidity and restricted compact ceiling8](../results/coxeter_metric_facet_angle_rigidity_20261020.md)|Short paper proof only. No additional manuscript: the theorem applies when EVERY metric facet is Coxeter and does not lower the general compact ceiling.|[Root](../results/review_metric_facet_and_good_prime_scope_root_20261020.md) and [independent](../results/review_coxeter_metric_facet_angle_rigidity_resource_20261020.md) written reviews pass. The eight-value local classification and h-vector identity are explicit; no census, script or Lean run is needed. Sharpness and worldwide priority remain unascertained.|
|[Good-prime tree construction](../results/compact_coxeter_good_prime_global_tree_action_20261020.md)|Research record only; no new manuscript or formalization expansion without a dimension consequence.|[Root paper review](../results/review_metric_facet_and_good_prime_scope_root_20261020.md) passes under the explicit common-place and building-model inputs. The resulting tree action supplies no fixed-point property, arithmeticity theorem or improved ceiling.|
|[Nonreflectivity of the literal square-root-of-three H9 host](compact_h9_sqrt3_first_edge_reproduce_20261020.md)|Short closure proof and exact workers; no additional TeX manuscript. The later shared [ChamberPeriod module](chamber_period_logic_verification_20261020.md) conditionally checks the final group/coset logic.|All four workers have capped generation and separate replay PASS. Root and independent written reviews check the complete norm pool, edge inventories, glue and full-chamber interface. Actual group/geometric/trace interpretations remain explicit Lean premises. This excludes the full integral arrangement of <-sqrt3>+<1>^9; no uniform ceiling, commensurability-class exclusion or new example is claimed.|
|[Compact RA4: actual D/D2 cutting](../results/compact_ra4_dodecahedral_double_spectrum_cutting_20261020.md) and [farthest-D/wall-radius rigidity](../results/compact_ra4_farthest_dodecahedron_wall_radius_20261020.md)|Short research notes; no additional manuscript. If a universal minimum/second-volume proof results, share the existing compact RA4 paper's geometric foundations.|[Root written review](../results/review_compact_ra4_cutting_and_radius_root_20261020.md) and [independent full review](../results/review_compact_ra4_cutting_and_radius_finite57_20261020.md) pass. No new numerical jobs, builds or Lean. The cutting theorem requires metric D/D2 facets, while the radius theorem is universal. Neither proves unrestricted volume minimality.|
|[Two first-type arithmetic shortcut obstructions](../results/first_type_projection_and_trace_lift_obstructions_20261020.md)|Research record only, with no new manuscript. It explains why the sharp right-angled proof and rational trace restriction cannot directly close the compact arithmetic gap.|[Independent root written review](../results/review_first_type_projection_trace_obstructions_root_20261020.md) passes, with actual compact arithmetic countermodels and the lifted cusp defect calculated explicitly. No new dimension ceiling or verification job.|
|[Rank57 physical coupon capacities and three-rank16 family361](../results/a1_rank16_physical_coupon_capacity_research_20261020.md), with [mandatory correction](../results/a1_rank16_partial_display_scope_correction_20261020.md)|Supporting research for a future general finite-volume bound improvement. The current57 paper does not need this successor rule; no additional manuscript is proposed.|Root and independent full written reviews pass with the corrected zero non-target records. The new targeted exact generation and separate replay pass: twelve saved target displays, zero unknowns, less than94MB peak RSS. Universal geometric activation remains an explicit written proof. Other families still prevent a364 global budget, so the dimension ceiling stays57. No new Lean theorem.|
|[Historical mixed RA ceiling11 by positive-part opposition](../results/right_angled_mixed_dimension11_20261019.md)|Preserved11-page predecessor with complete geometry/count/majorant proof and three vector figures; superseded by the current12-page ceiling10 paper.|Its full written/manuscript reviews, exact generation/replay, conditional final-count Lean/audit and zero-warning build remain evidence. Real-valued transport remains an explicit interface in Lean. This is not another current primary paper.|
|[Original arithmetic eight-field ceiling19](../results/compact_arithmetic_eight_field19_20261019.md)|The first technical appendix of the same compact arithmetic paper, sharing the actual-face setup and six-row classification. Its original18-page parent/PDF and48-file packet are preserved predecessors of the current nine-field edition.|All I/F/B/T/J/bridge rows, triangles, simultaneous half-refunds and earlier-role separation have full written reviews. Every rank20 vertex costs at most35 against35*f0+500. The actual `ArithmeticEightField19` audit is preserved; its compiled source is a dependency of the new K7 kernel. Imported geometry remains explicit premises.|
|[K7 extension and combined nine-field ceiling19](../results/compact_arithmetic_k7_dimension19_charge_composition_20261020.md)|The [second technical appendix](../manuscripts/appendices/compact_arithmetic_k7_field19.tex) in the preserved20-page combined compact paper, with the [preserved76-input supplement](../manuscripts/supplements/compact_arithmetic_nine_field19_sources_20261020.json). No additional standalone paper.|All seven local consumer interfaces and full root/independent composition reviews pass. Three shared white supports, six receiving forests and complete component-deficit coverage give allowance35 against35*f0+500. Conditional `ArithmeticK7Field19` compilation/six-theorem audit and the20-page zero-warning source-bound build pass. No all-field19 claim or new example.|
|[Mixed RA: mandatory nu>=12 carrier and sharper errors](../results/right_angled_mixed_nu12_carrier_forced_by_maximal_ideal_degree_20261019.md)|Supporting geometry for the same mixed research family; not required for the completed ceiling10 proof or its ceiling11 predecessor.|Full written root review passes for the local polygon-excess theorem, maximal-ideal-degree closure and E12/2E12 errors. Its hypothetical dimension11/12 constraints remain valid supporting implications; those dimensions are now excluded by the successor theorem. Its own TeX integration and geometric Lean remain separate.|
|[Compact29: full T=E7 cubed+E8 saving to84](../results/compact29_e7_pair25_essential_quad_exclusion_20261019.md)|The same arbitrary compact-bound research lane; no additional manuscript.|Full written root review passes. A complete essential-pair25 table plus the existing pair35 companion proves a three-unit saving for the already valid facewise rule. The unresolved frontier is97 types,79 at87 and18 at85. No new dimension ceiling or Lean claim.|
|[Arithmetic: spectator-only and bridge continuations](../results/review_arithmetic_rank20_spectator_and_bridge_root_20261019.md)|Supporting lemmas for the scoped19 addition in the same arithmetic paper.|Complete scoped root review binds both the spectator-only report and required E8 coverage addendum, plus the bridge proof. The subsequent full consumer theorem now completes their charge composition.|
|[Finite research: D16 center/D14+A2 repair](../results/d16_center_direct_seal_and_guarded_surcharge_addendum_20261019.md)|General finite-bound research support; not needed for the completed57 paper.|Direct reverse-Cauchy seal fixes a proof-order dependency; four later models have an alternate payment. The complete54-file audit passed generation and separate replay, with zero unknowns and all eight models covered. The shared-A1 capacity proposal has a local countermodel. No new exact complete maximum or dimension ceiling.|
|[All-rank-four compact29 charge reduction:2126 heavy types to98](../results/compact29_all_rank4_leaf_refund_20261018.md)|A future revision of the arbitrary compact argument; the existing [triangle note](../manuscripts/compact29_triangle_constraints.tex) proves only its older local incidence result.|Root and independent mathematical reviews pass. No new dimension ceiling, exact replay or Lean verification.|
|[All-antiprism exclusion under an enlarged ideal4 facet hypothesis](../results/review_and_extension_ideal_ra4_antiprism_spectrum_20261018.md)|A short extension to the unified [ideal4 volume/structure paper](../manuscripts/ideal_ra4_volume_and_structure.tex), if adopted. Its positive-kappa consequence also supports the ideal5/6 bundle. It needs no separate standalone manuscript.|Complete author's proof and independent root review pass. Not in the current PDF or checked conditional kernel.|
|[Figure7 exclusion; all idealRA4 facets≤10 vertices force an Oct/D chain](../results/ideal_ra4_ten_vertex_facet_exclusion_research_20261019.md)|The same short extension to the unified ideal4 paper, sharing the all-antiprism box argument; the resulting≥11-vertex three-face condition supports the ideal5/6 bundle. No separate manuscript is proposed.|[Independent mathematical review](../results/review_ideal_ra4_ten_vertex_facet_exclusion_resource_20261019.md) and [exact model generation/replay](../results/review_ideal_ra4_ten_vertex_facet_exclusion_root_20261019.md) pass. TeX integration and Lean remain pending. Published small-facet completeness is explicit.|
|[Outside-cusp capacity two; ideal5≥59 facets/180 vertices and ideal6≥240 facets/4980 vertices](../results/right_angled_outside_cusp_capacity_20261019.md)|Revise the existing ideal5/6 necessary-conditions paper, sharing the carrier injection and transport proof. Its new use of the ideal4 Figure7 theorem must be cited explicitly.|[Independent full written review](../results/review_right_angled_outside_cusp_capacity_finite57_20261019.md) and the [new conditional Lean implications](right_angled_cusp_capacity_verification_20261019.md) pass. The shared geometry is integrated in the current12-page ideal5/6 paper. Conditional logic compiles; geometric formalization remains pending and no ceiling changes.|
|[Positive ideal4 cusp defect; ideal5≥62 facets/189 vertices and ideal6≥252 facets/5504 vertices](../results/right_angled_ideal4_cusp_defect_research_20261019.md)|The same ideal5/6 bundle. Reuse the capacity setup, add the spinor polygon lemma and good-opposite counting, then quote the stronger propagation in ideal6. No separate manuscript proposed.|Root and [independent full mathematical review](../results/review_right_angled_ideal4_cusp_defect_finite57_20261019.md) pass. `RightAngledCuspDefect` now compiles and passes its axiom audit; the geometric count interfaces remain explicit. The shared proof is integrated in the current12-page ideal5/6 paper.|
|[Ideal5 facet propagation;62/206 in ideal5 and269/5875 in ideal6](../results/right_angled_ideal5_facet_cusp_propagation_20261019.md)|The same ideal5/6 bundle, sharing the spinor and actual-opposite setup with the preceding theorem. No separate paper proposed.|Two independent full written reviews pass. `RightAngledCuspPropagation` compiles and passes its axiom audit, including5875 rounding. The actual-wall/count interfaces remain explicit premises; no new dimension ceiling.|
|[Equality-carrier extra triangle credit;62/208 in ideal5 and271/5919 in ideal6](../results/right_angled_ideal5_carrier_equality_strictness_20261019.md)|The same ideal5/6 paper. A short strengthening after the shared cusp-defect and propagation arguments, not another manuscript.|[Independent full root review](../results/review_ideal5_carrier_equality_strictness_root_20261019.md) passes. No new classification input, numerical execution or Lean coverage; dimension ceilings unchanged.|
|[Eleven-vertex carrier equality exclusion;63/211 in ideal5 and275/6106 in ideal6](../results/right_angled_ideal4_eleven_vertex_equality_exclusion_20261019.md)|The same ideal5/6 paper. Use this stronger proof for the current counts; the preceding208-credit argument can remain supporting research rather than being repeated in the paper.|Root and independent full written reviews pass, including actual square-cusp and tangent-box edge arguments. No new classification input. The current12-page manuscript, conditional63/211 and275/6106 Lean implications and separate axiom audit pass; geometric formalization and dimension ceilings remain unchanged.|
|[A15 A1-absence refund for the ambient57 research rule](../results/review_a15_inner_unit_a1_absence_root_20261019.md)|Finite-volume bound research support. Incorporate only if needed for the next dimension theorem; the completed57 paper does not need this successor rule.|Written root review, independently reviewed checker and separate exact generation/replay pass. No increasing family; current complete finite maximum remains11861/32. No56 conclusion or new Lean theorem.|
|[D17 physical-face capacity refund](../results/review_d17_node2_face_capacity_root_20261019.md)|The same finite-volume bound research lane. Keep its physical-face activation distinct from a formula determined only by a vertex diagram.|Independent written/source review and separate exact generation/replay pass. Guaranteed refund(5/8)max(d17−1,0), no new positive family. Global formal maximum remains11861/32.|
|[Nonsingular quadrilateral full-seal rank obstruction](../results/finite_quad_nonsingular_full_seal_rank_obstruction_20261019.md)|The same finite-volume bound research lane. A short geometric lemma with applications; no separate manuscript proposed.|Full root written review and the [54-file physical-output generation/replay](../results/review_d16_d13_physical_output_execution_root_20261019.md) pass. Nine old order16 cores force a retained short2 route; the long-end D16 absence refund is supported. No new dimension bound or Lean theorem.|
|[At most two active distal D13 marginal coupons](../results/order17_distal_d13_physical_coupon_capacity_research_20261019.md)|The same finite-volume bound research lane; preserve the unchanged old-half versus activated-extra distinction. No separate manuscript proposed.|Scoped full root review and the54-file current-output generation/replay pass. Old-attainer allowance357.71875; the [complete sequential upper2965/8](../results/review_distal_capacity_sequential_cover_root_20261019.md) now has its required activation audit. This is a safe upper, not an exact attained maximum. No dimension bound or Lean theorem.|
|[Arithmetic full-D_n isolated-wall quadrilateral obstruction, n≥15](../results/arithmetic_dn_isolated_quad_obstruction_20261018.md)|Arithmetic compact-bound research support. Append only if it becomes part of a stronger global argument; it is not needed for the current compact20 theorem.|Independent mathematical review passes, with the ambient a.c≤−1 hypothesis retained. No global refund, improved ceiling or Lean verification.|
|[Arithmetic double-whisker wall obstruction, n≥16](../results/arithmetic_dn_double_whisker_obstruction_20261018.md)|The same arithmetic research lane; keep alongside the preceding local lemma. Its a.c=0 and restricted-contact hypotheses cover a different branch. No separate manuscript is proposed.|[Independent mathematical review](../results/review_arithmetic_dn_double_whisker_obstruction_batch_guard_20261018.md) passes for the direct conjugate-trace/integrality proof, without a published field list. Not part of the compact20 TeX or a checked Lean module.|
|[Arithmetic golden/silver opposed-fork local models and capacity](../results/review_arithmetic_dn_opposed_fork_survivors_root_20261019.md)|Arithmetic compact-bound research support; preserve the counterexamples to incomplete local-refund tests and incorporate only if a stronger global argument uses them. No separate manuscript proposed.|Root written mathematical review and separate exact generation/replay pass for four n19/20 local stars, with twin-wall and golden mixed-capacity identities. No global completion, improved dimension ceiling or geometric Lean theorem.|
|[Arithmetic full-D19/D20 whisker-pair refund](../results/review_dn_whisker_pair_retention_root_20261019.md)|The same arithmetic compact-bound research lane. Incorporate in a stronger global argument if useful; no separate manuscript proposed.|Root and independent full mathematical reviews pass. A valid one-unit deletion reduces the simple eight-field rank20 allowance to37; the target remains35. No new dimension ceiling, TeX revision or Lean verification.|
|[Arithmetic full-B19/B20 simple-end distance-two refund](../results/arithmetic_bn_simple_end_distance_two_refund_20261019.md)|The same arithmetic compact-bound research lane. Combine with the D refund only within the explicitly proved field scope; no separate manuscript proposed.|Root and independent full written reviews pass, including simultaneous B corners and D composition. Full-B20 cost37 becomes36; full A20/D20 remain37 against target35. No dimension improvement or Lean theorem.|
|[Balanced B-end quarter rule](../results/arithmetic_bn_balanced_quarter_end_rule_20261019.md)|The same arithmetic compact-bound research lane; retain the source/coupon distinction if a stronger theorem uses it. No separate manuscript proposed.|Root and independent full written reviews pass. B20 and the compensated B19+A1 context both cost35.25. No new ceiling or formal theorem.|
|[Both whole-A19/A20 path-end distance-two refunds](../results/arithmetic_an_two_end_distance_two_refund_20261019.md)|The same arithmetic compact-bound research lane. The separate same-endpoint note is a dependency, not another proposed manuscript.|Root and independent full written reviews pass. This gives A20 cost35 within eight fields; the subsequent mixed lemma permits the full D refund simultaneously. B, outside-factor and other-field obligations remain; no global allowance or dimension improvement.|
|[Whole-D19/D20 three-unit refund](../results/arithmetic_dn_three_unit_refund_eight_fields_20261019.md)|The same arithmetic compact-bound research lane. Its old local sources are dependencies, not proposed papers.|Independent full written review passes: D20 cost35 with the unmodified A baseline in eight fields. No spectator extension or dimension ceiling.|
|[Mixed whole-A/D consumer composition](../results/arithmetic_an_dn_mixed_end_refund_consumers_20261019.md)|The same arithmetic compact-bound research lane; supplies the composition of the two preceding refunds. No separate manuscript proposed.|Root and independent full written reviews pass. Simultaneous A20/D20 cost35 is valid within eight fields. B and multifactor obligations remain; no new global bound or Lean theorem.|
|[Complete rank20 allowance36 and remaining-family frontier](../results/arithmetic_rank20_complete_fourteen_family_frontier_20261019.md)|A short finite-classification reduction in the same arithmetic compact-bound argument, not a separate manuscript.|Root and arithmetic-agent paper checks agree. The reviewed composed charge has global vertex upper36 in eight fields; both B cases, D19+A1 and D18+high-I2 are removed from the original fourteen families, leaving ten D families above35. All connected types meet35. No new dimension ceiling, forest search or Lean theorem.|
|[Spectator-aware half refund at whole B19+A1](../results/arithmetic_b19_a1_spectator_half_end_refund_20261019.md)|The same arithmetic-bound paper, if used in a stronger theorem; no separate manuscript.|Root and independent full written reviews pass. Complete spectator contacts and all consumers are covered; cost139/4<35. No new ceiling or Lean theorem.|
|[Whole-B20 far-4 quarter refund](../results/arithmetic_b20_far_four_quarter_refund_20261019.md)|The same arithmetic-bound argument, sharing the current whole-A/D/B preliminaries. No separate manuscript.|Root and independent full written reviews pass, including all21 finite rows and mixed D-whisker consumers. Whole B20 costs35; the subsequent spectator theorems leave ten cost36 D families. No improved dimension ceiling or Lean theorem.|
|[Whole-D19+A1 two-fork half refunds](../results/arithmetic_d19_a1_two_fork_half_refund_20261019.md)|The same arithmetic-bound argument. Reuse the finite-c inventory, but include the complete spectator analysis rather than importing a whole-D theorem unchanged.|Root and independent full written reviews pass. Two half refunds give cost35 for this entire ambient20 forest in eight fields. The short-leaf pair and all other spectator types are unmodified; no new dimension ceiling or Lean verification.|
|[Whole-D18+high-I2 two-fork half refunds](../results/arithmetic_d18_high_i2_two_fork_half_refund_20261019.md)|The same arithmetic-bound argument, with a finite-corner spectator seal and complete rank18 local proof. No separate manuscript.|Root and independent full reviews pass. All native high labels are covered; this entire forest costs35. Seven D+D and three D+E obligations remain. No new ceiling or Lean theorem.|
|[H9 discriminant19:31-wall chamber and the next escape](../results/h19_thirty_one_wall_execution_root_20261019.md)|Construction research and the fixed31-wall checker; no publication manuscript for an incomplete chamber.|Generation and separate replay PASS:465 pairs,31 actual facets and at least89 finite vertices using inherited caps. A feasible spacelike escape proves infinite volume. Next-edge research continues; no new finite-volume example.|

## Complete TeX inventory

Pages below describe existing PDFs, not a fresh typesetting check. The
canonical PDF path for every entry and all identified additional copies
are in the catalogue. Most canonical PDFs are under `manuscripts/build/`.

|TeX source under `manuscripts/` unless stated otherwise|Role and theorem scope|Existing PDF|
|---|---|---|
|[finite_volume57.tex](../manuscripts/finite_volume57.tex)|Current primary general57 paper; weights, routing, algorithms and full higher tail, with the classical unit-charge bridge, current-triangle/coarse-screen bridges and precise stored-positive-entry/zero-base conditions.|[48-page current PDF](../manuscripts/build/finite_volume57.pdf): main exposition pp.1–12 and essential appendices/table documentation pp.13–48;21 underfull spacing warnings, no overflow or unresolved references. Source `c300db69…ca82a0` / PDF `1f3c020c…` matches the actual bounded build in the [completion receipt](../results/six_paper_pdf_completion_20261020.json) and [bridge receipt](../results/finite57_publication_bridge_completion_20261020.json). The44-page `89bd7658…` / `ebf996a3…` pair and8-/41-page editions are archived.|
|[finite_volume58.tex](../manuscripts/finite_volume58.tex)|Preserved predecessor and essential higher-tail input.|8 pages; duplicate copy in `manuscripts/build/`.|
|[compact_arithmetic20.tex](../manuscripts/compact_arithmetic20.tex)|Preserved combined predecessor: universal20 plus parked19 refinements. Current universal-only paper is compact_arithmetic_dimension_bound.tex.|[20-page PDF](../manuscripts/build/compact_arithmetic20.pdf),zero warnings; [three-TeX-input/source-bound build](../results/compact_arithmetic_nine_field19_included_build_20261020.json). The old18-page parent/PDF are byte-verified compressed archives.|
|[compact_arithmetic_dimension_bound.tex](../manuscripts/compact_arithmetic_dimension_bound.tex)|Current universal-only arithmetic20 publication source. Parked19 appendices excluded; seed/queue/forest algorithms expanded.|Fresh source audit passes at declared data/companion boundaries; [17-page current PDF](../manuscripts/build/compact_arithmetic_dimension_bound.pdf) compiles with zero warnings and matches its source-bound build ledger.|
|[compact_farthest_vertex_bounds.tex](../manuscripts/compact_farthest_vertex_bounds.tex)|Current primary general compact23 paper, with ordinary components, continuation/cap arguments and final forest composition integrated.|[36-page current PDF](../manuscripts/build/compact_farthest_vertex_bounds.pdf),zero warnings; source `2718192d…` / PDF `39e665d8…` matches the completion receipt. The [correlation precision correction](../results/compact23_correlation_precision_20261020.json) says "at most1/3"; strict demand still contradicts it. Its unchanged conditional accounting kernel has eight actual axiom prints in the [logic receipt](../results/publication_logic_verification_20261020.json); geometric energy/cap inputs remain premises.|
|[right_angled_dimension10.tex](../manuscripts/right_angled_dimension10.tex)|Preserved mixed10 predecessor: full actual geometry, balanced incidence, all-size scalar contracts and unweighted opposition reversal. Superseded by the five-page sharp8/4 paper.|[12-page PDF](../manuscripts/build/right_angled_dimension10.pdf),three visually reviewed vector figures,zero warnings; its [six historical core jobs](../results/mixed10_core_verification_20261020.json) PASS.|
|[right_angled_dimension11.tex](../manuscripts/right_angled_dimension11.tex)|Preserved mixed11 predecessor: actual geometry,moments,positive-part certificate and incidence contradiction. Superseded by the mixed10 primary.|[11-page PDF](../manuscripts/build/right_angled_dimension11.pdf),three visually reviewed vector figures,zero warnings; its [historical verification ledger](../results/mixed_dimension11_package_verification_20261019.json) remains preserved.|
|[compact_arithmetic21.tex](../manuscripts/compact_arithmetic21.tex)|Preserved predecessor; compact21 and field-specific stronger exclusions.|9 pages.|
|[compact21_supported_triangle_constraints.tex](../manuscripts/compact21_supported_triangle_constraints.tex)|Supporting local Q(sqrt5) rank21 note: at most7/42 marked triangles at A1+D5+E7+E8; at most1/3 specified D5 triangles at either stated type.|4 pages.|
|[compact29_triangle_constraints.tex](../manuscripts/compact29_triangle_constraints.tex)|Supporting arbitrary compact rank29 note: at least6/9 designated nontriangles at E7³+E8.|3 pages.|
|[ideal_ra4_second_volume.tex](../manuscripts/ideal_ra4_second_volume.tex)|Supporting predecessor: second distinct value8π²/3 and an attaining double; does not itself classify equality.|5 pages; duplicate historical build path.|
|[ideal_ra4_second_volume_structure.tex](../manuscripts/ideal_ra4_second_volume_structure.tex)|Supporting predecessor: all equality cases are the double; f-vector(42,168,164,38).|7 pages; duplicate historical build path.|
|[ideal_ra4_octahedral_decomposition.tex](../manuscripts/ideal_ra4_octahedral_decomposition.tex)|Supporting predecessor: restricted Oct/D facets imply actual octahedral cuts and unique24-cell chains, with opposite intermediate cuts.|9 pages; source/PDF explicitly frozen.|
|[ideal_ra4_square_antiprism_extension_appendix.tex](../manuscripts/ideal_ra4_square_antiprism_extension_appendix.tex)|New unfrozen input fragment, not a standalone paper. Eliminates square-antiprism facets in an enlarged restricted spectrum. It is not silently part of the frozen chain theorem.|Unbuilt; requires a parent document.|
|[compact_ra4_facet_capacity.tex](../manuscripts/compact_ra4_facet_capacity.tex)|Supporting note: f≥2V+5, f+W≥5V/2−5; facet capacities48/50/104 at the stated volume thresholds.|7 pages; source/PDF explicitly frozen.|
|[compact_ra4_volume_constraints.tex](../manuscripts/compact_ra4_volume_constraints.tex)|Current primary compact RA4 successor: capacity,neighboring excess,46/46/96 cutoffs,zero recognition,W=0 or W>=17,and degree-two=>W>=20.|14 pages,four visually reviewed vector figures,zero warnings; source-bound build ledger and two complete written reviews pass.|
|[right_angled_five_face_carriers.tex](../manuscripts/right_angled_five_face_carriers.tex)|Ideal5 sumκ=48/large carrier; ideal6 coface counts; actual sixteen-cell positive-κ ideal4 example and unbounded doubling.|4 pages; duplicate historical build path.|
|[right_angled_five_dimensional_constraints.tex](../manuscripts/right_angled_five_dimensional_constraints.tex)|Actual one-layer attachment with bounded original cusp links but infinite volume; universal ideal5≥56 facets and mixed density consequences.|4 pages; duplicate historical build path.|
|[ideal_ra5_cusp_compatibility.tex](../manuscripts/ideal_ra5_cusp_compatibility.tex)|Restricted explicit C/D/T facet spectrum: y=3z−24,6 divides z; older30/66 count and necessary local cusp CSP. A CSP witness is not a chamber.|3 pages; duplicate historical build path.|
|[ideal_ra5_octahedral_blocks.tex](../manuscripts/ideal_ra5_octahedral_blocks.tex)|Same restricted spectrum: stronger z≥36,y≥84, using intrinsic blocks and the external Andrásfai–Erdős–Sós theorem.|3 pages.|
|[ideal_right_angled_six_face_constraints.tex](../manuscripts/ideal_right_angled_six_face_constraints.tex)|Preserved necessary-condition source: ideal5≥63 facets/211 vertices, ideal6≥275/6106 and mixed densities. The new sharp4 theorem excludes the hypothetical ideal5/6 cases.|12-page PDF, four visually reviewed vector figures, zero-warning build and conditional Lean count/axiom audits PASS for their historical scope. No further paper expansion planned.|
|[right_angled_mixed_corner_constraints.tex](../manuscripts/right_angled_mixed_corner_constraints.tex)|Universal mixed11/12 ratios; P4/P5 low-facet uniqueness; complete five-corner alternative and density; predecessor opposition cap.|7 pages.|
|[right_angled_mixed_opposition_transport.tex](../manuscripts/right_angled_mixed_opposition_transport.tex)|Supporting mixed transport note: two conditional8 theorems, actual move support, carrier fraction, inherited moment cap and unrestricted symmetric-quad error.|No PDF present; build pending resource gate.|
|[generated/finite_volume57_atlas.tex](../manuscripts/generated/finite_volume57_atlas.tex)|Generated arithmetic proof archive, not an independent paper.|1292 pages.|
|[generated/finite_volume58_atlas.tex](../manuscripts/generated/finite_volume58_atlas.tex)|Preserved predecessor arithmetic archive.|1092 pages.|
|[generated/compact_arithmetic21_atlas.tex](../manuscripts/generated/compact_arithmetic21_atlas.tex)|Preserved predecessor arithmetic archive.|79 pages.|
|[data/external/martin_enriques_2019/source/EnriquesFiniteAut.tex](../data/external/martin_enriques_2019/source/EnriquesFiniteAut.tex)|Preserved published external Enriques-surface source; not a Coxeter paper or a new repository theorem.|Published reference PDF retained as `data/external/martin_enriques_2019/Martin2019.pdf`; page metadata in catalogue.|
|[ideal_ra4_volume_and_structure.tex](../manuscripts/ideal_ra4_volume_and_structure.tex)|Preserved verified16-page consolidation, superseded as current text by the publication successor.|16 pages,5 figures,0 warnings; [build ledger](../results/ideal_ra4_volume_and_structure_build_20261018.json).|
|[ideal_ra4_volume_and_structure_publication.tex](../manuscripts/ideal_ra4_volume_and_structure_publication.tex)|Current publication revision of the same ideal4 theorem; explicit fixed-model algorithms and completeness arguments added.|Fresh full source audit passes; [17-page current PDF](../manuscripts/build/ideal_ra4_volume_and_structure_publication.pdf) compiles with zero warnings and matches its source-bound build ledger. Original16-page source/PDF unchanged.|
|[right_angled_sharp_dimension_bounds_publication.tex](../manuscripts/right_angled_sharp_dimension_bounds_publication.tex)|Current primary for sharp universal8 and entirely ideal4; only the reviewed “four-dimensional facet” terminology changed from the frozen predecessor.|5 pages,1 visually reviewed figure,0 warnings. The original four-job core and12-print conditional audit remain preserved; the new cubic kernel passes ten actual axiom prints. The projection/height kernel adds eight actual prints, bringing the current core selection to six jobs with PDF; actual incidence/face inheritance and radial realization remain explicit inputs.|
|[right_angled_sharp_dimension_bounds.tex](../manuscripts/right_angled_sharp_dimension_bounds.tex)|Preserved frozen five-page predecessor of the same sharp-dimension paper.|Original source, PDF, proof map and44-input packet unchanged; final publication revision is the same paper, not a seventh one.|
|[ideal_right_angled_dimension4.tex](../manuscripts/ideal_right_angled_dimension4.tex)|Preserved cusp-height/graph predecessor of the ideal4 theorem. The unified paper uses a shorter one-projection proof.|4 pages,1 visually reviewed figure,0 warnings. Exact model PASS; old graph kernel remains uncompiled and its core run was resource-deferred.|

Explicit frozen predecessor source/PDF manifests include the
[ideal4 chain freeze](../results/ideal_ra4_octahedral_decomposition_20261018_freeze.json)
and [compact RA4 capacity freeze](../results/compact_ra4_facet_capacity_20261018_freeze.json).
Other manuscripts often translate immutable underlying proof packets;
absence of a TeX freeze manifest does not permit changing those packets.
The [compact20 composition freeze](../results/compact_arithmetic20_composition_root_20261018_freeze.json)
binds its original proof evidence separately. The current
[nine-field included-source build](../results/compact_arithmetic_nine_field19_included_build_20261020.json)
binds the20-page PDF, parent, both appendices and76 inputs. The
[earlier48-input manifest](../manuscripts/supplements/compact_arithmetic_eight_field19_sources_final_20261019.json)
and archived18-page parent/PDF retain their historical scope; its old
parent pin is not misrepresented as the current expanded parent.
Generated atlases and preserved external sources remain evidence to keep.

The two publication successor sources add no paper families:
[compact_arithmetic_dimension_bound.tex](../manuscripts/compact_arithmetic_dimension_bound.tex)
excludes the parked refinements, and
[ideal_ra4_volume_and_structure_publication.tex](../manuscripts/ideal_ra4_volume_and_structure_publication.tex)
adds the finite-model algorithm exposition. Both original verified versions
remain at their original paths, preserving every frozen source reference.
The current number is still six papers; the owned TeX-path inventory is32.

## Publication grouping and length planning

These are editorial budgets, not proof truncation rules. Full arguments
must remain available; a legitimate technical appendix may exceed the
planning range. No existing source is merged, deleted, or shortened by
this inventory.

|Eventual bundle|Core budget/current length|Appendix or supplement|Deduplication and boundaries|
|---|---:|---:|---|
|General finite-volume57|Actual main exposition pp.1–12;48 pages total|Essential proof appendices/table documentation pp.13–48|One geometric payment/composition account, with the reviewed full-budget classical and triangle/coarse-screen bridges explicit. The earlier8–12/10–20 page ranges were editorial budgets;41- and44-page editions are preserved. Cite58 as provenance; retain raw atlases outside the paper.|
|Compact arithmetic20|Actual universal-only paper17 pages|Parked nine-field19 refinement excluded from current paper|Expose the common angle-payment method, then the actual-field split and remaining golden-field proof. The combined20-page predecessor remains preserved; the parked19 refinement does not drive the current paper. Full local derivations remain an explicit internal supplement.|
|General compact23|Actual36 pages; earlier core target12–18|Component-classification and continuation arguments integrated|One farthest-vertex method, then ordinary/A/B-D branches, then forest accounting and the two dimension24 terminal patterns. Preserve24/26/27 as supporting history.|
|Ideal RA4 volume and structure|Actual publication paper17 pages; verified16-page predecessor preserved|Earlier optional appendix budget4–8 pages|One shared defect/cusp setup. Published minimum; universal gap; independent equality-spectrum reduction; general restricted chain; equality corollary and exact double. Current finite-model algorithm exposition is included. Keep the antiprism extension optional until separately accepted.|
|Sharp right-angled dimensions8/general and4/ideal|Actual5 pages|None needed|One shared finite-projection lemma, the self-contained cubic code proof, and explicit published inputs. Earlier mixed10, ideal-cusp4 and ideal5/6 size papers are preserved support; no expansion planned.|
|Compact RA4 volume constraints|Actual14 pages; planning range10–16|0–4 pages|One paper for capacity,neighboring excess and the positive-excess gap; it does not prove the120-cell conjecture.|

The1292/1092/79-page atlases are not proposed paper lengths. A paper should
contain the universal argument, exact finite interfaces and a usable
verification map; the complete arithmetic archive can remain a separate
download. The compact29 triangle-incidence note is preserved support,
not a seventh paper. The two angle-payment papers should each give a
short common-method orientation; their different arithmetic and cusp
branches justify separate papers. See the
[architecture](paper_architecture.md) for the section order and the
[algorithm audit](../results/editorial_manuscript_inventory_and_algorithm_audit_20261020.md)
for exact source locations and remaining exposition gaps.

## Verification catalogue and runner contract

The JSON has top-level `bundles`, `results`, `checks`, and `manuscripts`.
Every result names exactly one `primary_manuscript` by ID; support IDs
are separate. Each manuscript's `verification` is a list of IDs into the
`checks` object. Every check has `id`, an **argv array**, `owns_lock`,
`tier`, `coverage`, and, when unambiguous, `expected_status`. All listed
argv are solver-free. No generation, `--write`, TeX build, unrestricted
`lake build`, or optimizer command is offered as a verification step.

`core` means a current saved-certificate/interface replay. `full` is the
selected substantial replay scope and remains subject to the same caps;
it does not imply regeneration of every transitive input. Some ambient59–65
forest and local-census data remain explicit finite-data inputs.
The runner must apply the shared lock and resource/output/process
guards. If `owns_lock` is false, the runner supplies the lock; if true,
it must avoid double-locking the child. In particular the default replay
of `check_right_angled_mixed_carrier_excess_fraction_research_20261018.py`
does **not** acquire the lock: its internal flock is only in the excluded
`--write` branch. This classification was checked at the actual entrypoint.

All proof jobs remain serial under [AGENTS.md](../AGENTS.md):40GiB disk
and6GiB available RAM before starting; abort below8GiB/3GiB. Modest replay
batches retain the 59-second/1 GiB limits. Full-tier status is not permission
to raise caps. Lean batches use the serial signal-safe runner with one
module, one thread and2048MiB. A missing resource gate defers execution.
The coordinating agent owns the push-button driver and integration in
[manuscript_verification.md](manuscript_verification.md).

The inventory validates local script/source/PDF/map paths and import-style
Lean module paths without importing scientific project code. All six PDFs
match their current source/build hashes: finite57 has48 pages, arithmetic20 has17,
compact23 has 36, sharpRA has 5, ideal4 has 17 and compactRA4 has 14.
The [completion receipt](../results/six_paper_pdf_completion_20261020.json)
records both actual new builds; the [latest bridge receipt](../results/finite57_publication_bridge_completion_20261020.json)
preserves finite57's44-page predecessor and earlier no-child deferrals.
[Selected finite57 pages5,16,24,25](../results/finite57_publication_delta_visual_review_20261020.json)
passed visual inspection; no all-page inspection is claimed. No new
mathematical script replay or Lean pass follows from either TeX build.
The ideal4 publication revision has 17 pages, five figures and zero warnings;
its verified16-page predecessor remains preserved. A PDF metadata read or
successful TeX build establishes rendering, not a theorem.

## Exact coverage and formalization gaps

|Result family|What existing checks establish|Lean coverage and remaining obligations|
|---|---|---|
|Mixed dimension10|Complete12-page geometric/scalar/count proof; full written/manuscript reviews; all six current core jobs pass: four exact replays, conditional kernel/audit and temporary build. Three figures visually checked;zero warnings.|`RightAngledMixed10` final count logic and separate eight-theorem axiom audit pass. Actual geometry and real-valued transport remain explicit written premises. `RightAngledMixed11` and its checked11-page paper are preserved predecessors.|
|Nine-field arithmetic19|Complete reviewed consumer/composition packet and20-page parent/two-appendix PDF,with all three TeX files and76 supplement inputs bound before/after compilation.|`ArithmeticK7Field19` coupon/source budgets,ordinary sum and final count logic/six-theorem audit pass. Its imported `ArithmeticEightField19` dependency retains the preserved actual coefficient/cost audit. Geometry,whole-star/forest coverage and actual h-vector/charge data remain explicit premises. The documented legacy `CompactHVector` cache is not relabelled as a new capped build.|
|General57|Saved endpoint/source interfaces, changed forests,2552 ideal profiles and exact377/36/4205 contradiction. Two ancestor batches additionally replay8,114 tables and10,195,241 Bellman inequalities; selected full scope does not regenerate every transitive input.|`GuardedRank58` and `ManuscriptFinite57` check the conditional global contradiction and tail composition. `ConcentrationDescent58` passes ten actual axiom prints for descent/terminal logic; `FiniteVolumeTailKernel` passes nine for105 cap comparisons and payment/narrow scalar closure. Exact rows, cusp interpretation, convex-order comparison, actual domination, the index/shape bridge and geometric retention remain explicit premises; no end-to-end geometric formalization.|
|Preserved58|Full finite/ideal arithmetic and source composition, with substantial historical replay optional.|`FiniteTableArithmetic`, `Generated.Finite59`, `ForestDomination`, `Generated.TypeDomination59`, `IdealProfileArithmetic`, `Generated.Ideal59`, `IdealDomainCompleteness`, and `DimensionComposition` verify specified arithmetic/conditional implications, not all geometry.|
|Compact20|Two independent exact face/forest implementations;1979 native faces,102917 spectator cases,729 hub contexts,maximum40;13 rank21 fields and24 higher branches with streamed recursive integrity.|`CompactArithmetic20`, `ManuscriptDataBounds` and `ManuscriptCompact20` now compile. The [ten-job core ledger](../results/compact20_core_verification_20261019.json) includes coefficient/550-surplus/scaled contradiction and conditional field composition, with printed-axiom audits. Actual whole-star coverage,pools,D5/H4 geometry and complete certificate/field interpretation remain premises.|
|Ideal4 gap/equality|Independent exact double model; finite Figure7/D9/cuboctahedral/cube data. These do not prove the universal partition or equality reductions by enumeration.|The original `IdealRA4Gap` cache and new `CoxeterProofs.ManuscriptIdeal4` conditional kernel are checked. `equality_spectrum_from_stages` and `minimum_gap_and_equality` retain written geometric premises; actual facets/cusps and equality-spectrum stage proofs remain unformalized.|
|Restricted ideal4 chain|ExactD4 root/vertex/product and reflected-octahedron facts; topological/actual-section/cutting proof is written.|`ManuscriptIdeal4.octD_decomposition_and_counts` is conditionally kernel-verified by decreasing doubled-facet count. Actual cuts,24-cell recognition,opposite-cut/path recognition and canonical gluing remain premises. The restriction to Oct/D facets is essential.|
|Carriers/positiveκ/attachment|Exact elimination and rational constructed models, with independent saved helpers. The explicit H5 chamber is infinite-volume.|`FiveFaceCarrier`, `IdealRA5`, `DoublingKappa` prove arithmetic implications/recurrences. Actual cofaces,doubling and attachment geometry remain written.|
|Universal ideal5/6 sizes|Exact rational density/injection consequences;88 transport identity frames and sharp reciprocal103/132 arithmetic. Frames are not a universal width census.|The three successor modules `RightAngledCuspCapacity`, `RightAngledCuspDefect` and `RightAngledCuspPropagation` now compile and pass axiom audits, including conditional62/206 and269/5875. Actual cusp geometry, the large-facet bridge and transport remain explicit premises; see the [verification record](right_angled_cusp_capacity_verification_20261019.md).|
|Restricted C/D/T ideal5|Local necessary cusp CSP and independent intrinsic104-polygon reconstruction; external AES theorem remains explicit.|`RestrictedCarrierCounts` contains the older30/66 arithmetic and congruence. Actual T geometry and stronger36/84 proof are not formalized.|
|Mixed corners/transport|Exact low-facet model data, nine radical rows,178 interval boxes and moment coefficients; actual support/quad reversals have written reviews.|No end-to-end Lean theorem for the new transport geometry, P4/P5 uniqueness, or either conditional dimension8 conclusion. The global edge hypothesis is not discharged by a local certificate.|
|Compact RA4 volume constraints|Full written universal proofs and reviewed14-page successor PDF,with four visually reviewed vector figures and zero-warning bounded build. No numerical theorem certificate is required.|No corresponding checked geometric Lean module.|
|Local compact triangle notes|Complete finite contact/arithmetic domains and exact incompatibility products.|No corresponding checked geometric Lean module; no full global payment improvement follows from these checks alone.|

Conditional manuscript interfaces are present in
`CoxeterProofs.ManuscriptDataBounds`, `ManuscriptCompact20`,
`ManuscriptFinite57`, `ManuscriptIdeal4` and `ManuscriptRightAngled`;
`ManuscriptInterfaces` is an optional aggregate. The exact dependency
order and premise register are in
[manuscript_assumptions.md](manuscript_assumptions.md). In particular
`ManuscriptIdeal4.minimum_gap_and_equality` separates the published
minimum, the internal gap partition, equality-spectrum forcing and
restricted cutting geometry. `ManuscriptRightAngled.ideal6_sharp_vertex_lower4462`
checks the sharp final rounding implication conditionally. These sources
include axiom-audit commands. The ideal4 and compact20 interfaces have
now compiled and passed actual printed-axiom audits. The finite57
interface also has its own fresh successful audit; the right-angled
interface remains pending a separate batch ledger.

Their assumptions and eventual kernel status must be read separately:
compiling an implication does not prove its geometric premises. The
catalogue records the ideal4, compact20 and finite57 interfaces as
`CONDITIONAL_KERNEL_VERIFIED` and the remaining theorem interfaces as
pending. The ideal4 core run replayed
four exact checks, reused the preserved `IdealRA4Gap` kernel cache, and
compiled and audited `ManuscriptIdeal4`; its only printed axioms were
`propext`, `Quot.sound` and `Classical.choice`, with no `sorryAx`. See the
[final core ledger](../results/ideal_ra4_unified_core_verification_final_20261018.json)
and [independent full source review](../results/review_ideal_ra4_unified_manuscript_resource_20261018.md).
These earlier interface records are preserved alongside the
[current seven-kernel receipt](../results/publication_logic_verification_20261020.json):
the cubic, concentration, compact23, residual Bellman, projection/height and
finite-volume tail and shape kernels compile and pass all62 actual axiom prints
(10/10/8/8/8/9/9), with only the standard axioms and no
`sorryAx`. Current core counts with PDF are11/10/2/6/7/1 for finite57/
arithmetic20/compact23/sharpRA/ideal4/compactRA4; the
[current combined plan](../results/publication_shape_counting_verification_plan_20261020.json)
has123 finite57 full jobs (113 script, nine Lean, one PDF) and six sharpRA
core/full jobs. The preceding120-job combined plan is preserved.
The previous123-job forest/tail plan is also preserved. The new shape root
replaces the primary ambient59 standalone shape slot, leaving job counts
unchanged and preserving its historical atlas/root and evidence.
It preserves the [Bellman plan](../results/finite57_bellman_verification_plan_20261020.json)
and earlier
[partitioned plan](../results/finite57_partitioned_verification_plan_20261020.json),
which replaces the eager D13 entry with its parser contract and19 parts;
neither plan is a combined runtime PASS. Of31 inherited higher-tail leaves,30 passed
in the [bounded replay ledger](../results/finite57_higher_tail_replay_batches_20261020.json)
and [remaining-check ledger](../results/finite57_higher_tail_remaining_replay_20261020.json)
(65.182 seconds total,256,278,528 B maximum RSS). The remaining tail108
obligation, covering109–116, now has a complete56-batch replacement
replay; its old59-second timeout remains preserved. The
[original full run](../results/finite57_publication_full_replay_20261020.json)
failed at D13's 1 GiB limit after its endpoint passed. The replacement
[19-batch contract](finite_volume57_lemma_map.md#memory-bounded-d13-replay-contract)
has all19 actual PASS records (24.408s,184,041,472 B maximum RSS) in the
[runtime ledger](../results/finite57_d13_batched_replay_runtime_20261020.json).
The current D13 parser fixture passed. The historical distance9 scanner
fixture `abc3b918…` PASS is preserved separately from its new pin-only successor.
The [coverage validator](../results/partitioned_replay_coverage_validation_20261020.json)
(`456abc2b…`) passed its14-mutation metadata self-test and records complete
D13 coverage19/19. It reran no mathematics. Current distance9 worker
`f5f0b470…` follows the independently reviewed
[same-predicate count repair](../results/distance9_symbolic_boolean_count_repair_20261020.json)
and [expected-key JSON representation repair](../results/review_distance9_expected_key_json_representation_fix_finite57_20261020.md).
Its [current scanner fixture](../results/distance9_json_key_lists_scanner_fixture_execution_20261020.json)
(`f6fd1267…`) now passes. Actual `metadata`/`domains`, full
`overlap-domain` generation, disjoint joins, inertia and all756 scalar
profiles pass in the
[terminal runtime ledger](../results/finite57_distance9_partitioned_replay_runtime_20261020.json).
All384 overlap owners and949 isolation cases also PASS:2196/2196 units
in56 capped batches,388.008s total and159,432,704 B peak RSS. Complete108
replacement replay and the recorded conjunction with19/19 D13 parts pass.
No combined full-manuscript replay PASS
or cap increase is claimed. All geometric and script premises remain explicit.
Two additional [ancestor-forest batches](../results/finite57_ancestor_forest_replay_execution_summary_20261020.json)
actually pass:8,114 tables and10,195,241 Bellman inequalities in5.106s,
with318,799,872 B maximum RSS. These are concrete table replays within the
selected full scope, rather than complete transitive regeneration.

The [residual Bellman module](../formal/CoxeterProofs/ResidualBellmanCertificate.lean)
(`cd2a05a6…`) compiled in0.54s and passed its separate0.41s audit of all
eight actual axiom prints, using only `propext` and `Quot.sound`. Its
compiled object is `d5c0b98f…`. It was the fourth selected verified logic
kernel. Its [assumptions map](residual_bellman_certificate_logic_20261020.md)
keeps the abstract certificate implication separate from the concrete
complete alphabet, integer weights, interaction-free context split, actual
memo-table validation and geometric domination. Compilation does not
discharge those inputs. The completed scientific replay is recorded
separately above.

The fifth selected kernel is
[RightAngledProjectionHeightKernel](../formal/CoxeterProofs/RightAngledProjectionHeightKernel.lean),
source `2fac8028…`, object `b2e265c8…`. Its3.47s compile and3.15s audit
produced [eight actual prints](../results/RightAngledProjectionHeightKernel_axiom_summary_20261020.json)
using only standard axioms. It derives finite-coordinate projection
identities, strict wall signs, squared-height recurrence, arbitrary finite
descent and the scalar radial gap. Positive normalizers, actual facet and
future-sheet interpretation, incidence/face inheritance and radial
realization remain explicit inputs; no end-to-end geometric Lean proof
is claimed.

The sixth selected kernel is
[FiniteVolumeTailKernel](../formal/CoxeterProofs/FiniteVolumeTailKernel.lean),
source `b8f03fd4…`, with actual compilation and nine axiom-print PASS records.
It derives all105 scalar cap comparisons for59–163, common payment
subtraction, and the near/far narrow-wall scalar contradiction. Its
[assumption map](finite_volume_tail_kernel_assumptions_20261020.md) retains
actual rule/cost interpretation, geometric shape and framing bridges,
and the local deficit bounds as explicit inputs; it does not discharge
the complete higher-tail geometry.

The seventh selected kernel is
[FiniteVolume58ShapeKernel](../formal/CoxeterProofs/FiniteVolume58ShapeKernel.lean),
source `40d12b57…`, with0.59s compile and0.55s nine-print audit PASS records.
It derives the indexed uncut-edge bound,841 at each distinct extremum,
the once-counted doubled8410 correction and finite754 contribution, then
the tagged377/4205 shape inequality. Its [map](finite_volume58_shape_kernel_assumptions_20261020.md)
retains primitive index/sign/incidence interpretation and the legacy
natural-number `WrittenGeometry.shapeLower` bridge; compilation does not
instantiate that field automatically.

The additional [sharpRA full adversarial review](../results/review_right_angled_sharp_fresh_adversarial_finite57_20261020.md)
and [idealRA4 equality/structural-chain review](../results/review_ideal_ra4_structure_batch_guard_20261020.md)
provide further written source checks. They do not add execution evidence,
external refereeing or an end-to-end geometric Lean claim.
Independent [sharpRA foundations](../results/review_right_angled_sharp_foundations_adversarial_20261020.md)
and [finite57 composition](../results/review_finite57_theorem_composition_adversarial_20261020.md)
audits also support the current proofs under their explicit inputs.
Primary-source checks directly cover [Musin/Kolpakov](../results/review_sharp_ra_published_inputs_ideal_branch_20261020.md),
[Vinberg and Alexandrov's mixed27 statement](../results/review_sharp_ra_published_inputs_dufour_20261020.md),
and [Khovanskii's shape identities](../results/review_finite57_published_shape_inputs_20261020.md).
Dufour's original full text was not obtained; its consequence was checked
through the original Alexandrov source already cited by the paper.
The actual spectrum/cut/recognition/path/gluing geometry remains explicit
written premises. Prepared `Ideal58` source
families also must not be called kernel-verified merely because files are
present; no corresponding successful per-module ledger was found in this
inventory.

The ambient57/order11/order17 research and joint-parameter note remain
research support outside the current57 theorem's primary paper. They do
not establish dimension56. A future numerical proposal or an abstract
necessary assignment is not a new polytope example. Likewise no universal
ideal4 volume divisibility, unrestricted24-cell decomposition, compact
RA4 minimum, or Garland-based missing step is supplied by this catalogue.
